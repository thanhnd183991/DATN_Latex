<!-- ABOUT THE PROJECT -->

## Hướng dẫn cài đặt

### Tạo file môi trường cho hệ thống

Tạo file `.env` từ file `.env.example` có trong thư mục `api`

### Import dữ liệu vào hệ thống

Thư mục MockData có chứa dữ liệu được fake sử dụng mongodump, mongorestore để export, import dữ liệu MongoDB của bạn

- Local
  ```sh
  mongorestore --host localhost --port 27017 -d newDB <<path-mockdata-folder>>
  ```
- Remote
  ```sh
    mongorestore --uri mongodb+srv://admin:<<password>>@cluster0.sblvb.mongodb.net -d <<nameDB>> <<path-mockdata-folder>> --ssl --nsExclude "admin.system.*"
  ```

### Chạy thử nghiệm

#### Frontend

- Cài đặt gói phụ thuộc và chạy thử nghiệm (cổng 3000)
  ```sh
    yarn hoặc yarn --network-timeout 100000
  ```
  ```sh
    yarn dev
  ```

#### Backend

- Cài đặt gói phụ thuộc và chạy thử nghiệm (cổng 5000)
  ```sh
    yarn
  ```
  ```sh
    yarn dev
  ```

### Sản phẩm

Vào thư mục api `cd api`

#### Tạo giao diện

- Linux

  ```sh
    yarn "build:uiLinux"
  ```

- Windowns (chưa có thư mục dist)
  ```sh
    yarn "build:uiWindowsWithoutDist"
  ```
- Windowns (có thư mục dist)
  ```sh
    yarn "build:uiWindows"
  ```

### Chạy chương trình

Chạy lệnh `yarn start`

Chương trình hiện đang chạy ở cổng 5000
