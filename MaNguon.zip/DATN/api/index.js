const express = require("express");
const path = require("path");
const app = express();
const mongoose = require("mongoose");
const dotenv = require("dotenv");
const cors = require("cors");
const http = require("http");
const morgan = require("morgan");

const authRoute = require("./src/routes/AuthRoute");
const userRoute = require("./src/routes/UserRoute");
const companyRoute = require("./src/routes/CompanyRoute");
const postRoute = require("./src/routes/PostRoute");
const jobRoute = require("./src/routes/JobRoute");
const storeRoute = require("./src/routes/StorageRoute");
const educationRoute = require("./src/routes/EducationRoute");
const languageRoute = require("./src/routes/LanguageRoute");
const experienceRoute = require("./src/routes/ExperienceRoute");
const roomRoute = require("./src/routes/RoomRoute");
const searchRoute = require("./src/routes/SearchRoute");
const notifyRoute = require("./src/routes/NotificationRoute");
const catRoute = require("./src/routes/CategoryRoute");
// const messageRoute = require("./src/routes/messages");
// const notificationRoute = require("./src/routes/notifications");

dotenv.config();

mongoose
  .connect(
    process.env.NODE_ENV === "production"
      ? process.env.MONGO_URL_REMOTE
      : process.env.MONGO_URL,
    {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    }
  )
  .then(() => console.log("DB Connection Successfull"))
  .catch((err) => {
    console.error(err);
  });

app.use(express.static("dist"));

app.use(cors());
app.use(express.json());
app.use(morgan("tiny"));

app.use("/api/auth", authRoute);
app.use("/api/users", userRoute);
app.use("/api/search", searchRoute);
app.use("/api/notify", notifyRoute);
app.use("/api/companies", companyRoute);
app.use("/api/posts", postRoute);
app.use("/api/jobs", jobRoute);
app.use("/api/store", storeRoute);
app.use("/api/rooms", roomRoute);
app.use("/api/educations", educationRoute);
app.use("/api/languages", languageRoute);
app.use("/api/experiences", experienceRoute);
app.use("/api/categories", catRoute);

app.use((req, res, next) => {
  res.sendFile(path.join(__dirname, "dist", "index.html"));
});

// app.use("/api/messages", messageRoute);
// app.use("/api/storage", storageRoute);
// app.use("/api/notifications", notificationRoute);
/** catch 404 and forward to error handler */
app.use("*", (req, res) => {
  return res.status(404).json({
    success: false,
    message: "API endpoint doesnt exist",
  });
});

const server = http.createServer(app);

require("./src/sockets/index")(server);

// // socket
// const io = new Server(server, {
//   cors: {
//     origin: "*",
//   },
// });
// require("./src/middlewares/checkTokenInSocket")(io);
// const { userIo } = require("./src/sockets/userSocket");
// userIo(io);

server.listen(5000, () => console.log(`server is running on port 5000`));

const User = require("./src/models/UserModel");
const Category = require("./src/models/CategoryModel");
const Language = require("./src/models/LanguageModel");
const Education = require("./src/models/EducationModel");
const Experience = require("./src/models/ExperienceModel");
const Job = require("./src/models/JobModel");
const argon2 = require("argon2");

// const getTest = async () => {
//   const users = await User.find().lean();
//   await Promise.all(
//     users.map(async (user) => {
//       await Category.updateMany(
//         { _id: { $in: user.skills } },
//         {
//           $addToSet: { users: user._id },
//         }
//       );
//     })
//   );
// };

// getTest()
//   .then((ids) => {
//     console.log(ids);
//   })
//   .catch((err) => {
//     console.log(err);
//   });
