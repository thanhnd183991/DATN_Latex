const mongoose = require("mongoose");

const TokenSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    required: true,
  },
  token: {
    type: String,
    required: true,
  },
  createdAt: { type: Date, expires: 3600, default: Date.now },
});

const Token = mongoose.model("Token", TokenSchema);

module.exports = Token;
