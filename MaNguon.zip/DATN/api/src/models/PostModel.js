const mongoose = require("mongoose");

const PostSchema = new mongoose.Schema(
  {
    content: {
      type: String,
    },
    files: [
      {
        file: { type: String },
        resource_type: { type: String },
        original_filename: { type: String },
      },
    ],

    ownerId: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      // Instead of a hardcoded model name in `ref`, `refPath` means Mongoose
      // will look at the `onModel` property to find the right model.
      refPath: "onOwner",
    },
    onOwner: {
      type: String,
      required: true,
      enum: ["User", "Company"],
    },
  },
  {
    timestamps: true,
  }
);

PostSchema.virtual("reactions", {
  ref: "Reaction",
  localField: "_id",
  foreignField: "postId",
});

PostSchema.virtual("comments", {
  ref: "Comment",
  localField: "_id",
  foreignField: "postId",
});

PostSchema.virtual("numComments", {
  ref: "Comment",
  localField: "_id",
  foreignField: "postId",
  count: true,
});

PostSchema.virtual("numReactions", {
  ref: "Reaction",
  localField: "_id",
  foreignField: "postId",
  count: true,
});

const Post = mongoose.model("Post", PostSchema);

module.exports = Post;
