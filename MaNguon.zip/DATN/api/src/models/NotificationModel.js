const mongoose = require("mongoose");
const NotifyConstant = require("../constants/NotifyConstant");

const NotificationSchema = new mongoose.Schema(
  {
    onSender: {
      type: String,
      required: true,
      enum: ["User", "Company"],
    },
    sender: {
      type: mongoose.Schema.Types.ObjectId,
      required: true,
      refPath: "onSender",
    }, // Notification creator
    onReceiver: {
      type: String,
      required: true,
      enum: ["User", "Company"],
    },
    receiver: [
      {
        user: { type: mongoose.Schema.Types.ObjectId, refPath: "onReceiver" },
        status: {
          type: String,
          enum: [
            NotifyConstant.PENDING,
            NotifyConstant.VIEWED,
            NotifyConstant.ACCEPTED,
            NotifyConstant.REJECTED,
          ],
          default: NotifyConstant.PENDING, // chua giai quyet
        },
      },
    ],
    message: String, // any description of the notification message
    desc: String,
    onAccess: {
      type: String,
      required: true,
      enum: ["User", "Company", "Job", "Post", "Room"],
    },
    access: {
      type: mongoose.Schema.Types.ObjectId,
      refPath: "onAccess",
    },

    type: {
      type: String,
      enum: [
        NotifyConstant.FOLLOW_USER,
        NotifyConstant.FOLLOW_COMPANY,
        NotifyConstant.FOLLOW_JOB,
        NotifyConstant.ADD_MEMBER,
        NotifyConstant.CREATE_USER_POST,
        NotifyConstant.CREATE_COMPANY_POST,
        NotifyConstant.CREATE_JOB_FOR_USER,
        NotifyConstant.CREATE_JOB_FOR_ADMIN,
        NotifyConstant.CONFIRM_JOB,
        NotifyConstant.CREATE_COMPANY,
        NotifyConstant.CONFIRM_COMPANY,
        NotifyConstant.CONNECT_USER,
        NotifyConstant.CONNECT_JOB,
        NotifyConstant.CONFIRM_CONNECT_USER,
        NotifyConstant.CONFIRM_CONNECT_JOB,
        NotifyConstant.CONFIRM_ADD_MEMBER,
        NotifyConstant.CREATE_POST,
        NotifyConstant.DELETE_MEMBER,
        NotifyConstant.APPLY_JOB,
        NotifyConstant.CHANGE_OWNER,
        NotifyConstant.CONFIRM_APPLY_JOB,
        NotifyConstant.CONFIRM_DELETE_MEMBER,
        NotifyConstant.CREATE_REPORT_JOB,
        NotifyConstant.CREATE_REPORT_POST,
        NotifyConstant.CONFIRM_REPORT_JOB,
        NotifyConstant.CONFIRM_REPORT_POST,
      ],
    },
  },
  {
    timestamps: true,
  }
);

const Notification = mongoose.model("Notification", NotificationSchema);

module.exports = Notification;
