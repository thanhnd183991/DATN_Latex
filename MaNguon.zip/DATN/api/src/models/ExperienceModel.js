const mongoose = require("mongoose");
const { convertToSlug } = require("../utils/convertToSlug");

const ExperienceSchema = mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, "name experience is required"],
      unique: true,
    },
    slug: {
      type: String,
    },
    users: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
      },
    ],
  },
  {
    timestamps: { createdAt: true, updatedAt: false },
    toJSON: { virtuals: true }, // So `res.json()` and other `JSON.stringify()` functions include virtuals
    toObject: { virtuals: true }, // So `console.log()` and other functions that use `toObject()` include virtuals
  }
);

ExperienceSchema.pre("save", function (next) {
  this.slug = convertToSlug(this.name);
  next();
});

const Experience = mongoose.model("Experience", ExperienceSchema);
module.exports = Experience;
