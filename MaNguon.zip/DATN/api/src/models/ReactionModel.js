const mongoose = require("mongoose");

const ReactionSchema = new mongoose.Schema(
  {
    postId: { type: mongoose.Schema.ObjectId, ref: "Post" },
    userId: { type: mongoose.Schema.ObjectId, ref: "User" },
    reaction: {
      type: String,
      enum: ["like", "love", "haha", "wow", "sad", "angry"],
    },
  },
  {
    timestamps: { createdAt: true, updatedAt: false },
  }
);
const Reaction = mongoose.model("Reaction", ReactionSchema);
module.exports = Reaction;
