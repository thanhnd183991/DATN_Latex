const mongoose = require("mongoose");
const { convertToSlug } = require("../utils/convertToSlug");

const EducationSchema = mongoose.Schema(
  {
    school: {
      type: String,
      required: [true, "School is required"],
      unique: true,
    },
    slug: {
      type: String,
    },

    students: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
      },
    ],
  },
  {
    timestamps: { createdAt: true, updatedAt: false },
    toJSON: { virtuals: true }, // So `res.json()` and other `JSON.stringify()` functions include virtuals
    toObject: { virtuals: true }, // So `console.log()` and other functions that use `toObject()` include virtuals
  }
);

EducationSchema.pre("save", function (next) {
  this.slug = convertToSlug(this.school);
  next();
});

const Education = mongoose.model("Education", EducationSchema);
module.exports = Education;
