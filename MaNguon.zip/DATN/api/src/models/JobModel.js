const mongoose = require("mongoose");
const { convertToSlug } = require("../utils/convertToSlug");

const JobSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      minLength: [3, "Tên công việc phải có ít nhất 3 ký tự"],
      maxLength: [200, "Tên công việc không được vượt quá 50 ký tự"],
      required: [true, "Tên công việc được yêu cầu"],
    },
    slug: {
      type: String,
      // required: [true, "Đường dẫn được yêu cầu"],
    },
    salary: {
      type: String,
      required: [true, "Lương được yêu cầu"],
    },
    job_type: {
      type: String,
      enum: ["fulltime", "parttime", "freelance"],
    },
    numbers: {
      type: Number,
      min: [1, "Số lượng tuyển dụng phải lớn hơn 0"],
      max: [100, "Số lượng tuyển phải nhỏ hơn 100"],
      required: [true, "Số lượng cần tuyển được yêu cầu"],
    },
    responsibilities: {
      type: String,
      required: [true, "Mô tả công việc được yêu cầu"],
      minLength: [10, "Mô tả công việc phải có ít nhất 10 ký tự"],
      default: "Create engaging content for our newsletters (Mailchimp)",
    },
    requirements: {
      type: String,
      required: [true, "Yêu cầu công việc được yêu cầu"],
      minLength: [10, "Yêu cầu công việc phải có ít nhất 10 ký tự"],
      default:
        "Bachelor's Degree in Corporate Finance /Investment/ Economics is required; ideally CFA or MBA in Finance and Banking;",
    },
    location: {
      type: String,
      required: [true, "Địa điểm làm việc được yêu cầu"],
      minLength: [3, "Địa điểm làm việc phải có ít nhất 3 ký tự"],
      default: "Hà Nội",
    },
    experience: {
      type: String,
      required: [true, "Kinh nghiệm được yêu cầu"],
      minLength: [3, "Kinh nghiệm phải có ít nhất 3 ký tự"],
      default: "1-3 năm",
    },
    rank: {
      type: String,
      required: [true, "Chức vụ được yêu cầu"],
      default: "Intern",
    },
    other: {
      type: String,
    },
    owner: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: [true, "Người tạo công việc được yêu cầu"],
    },
    company: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Company",
      required: [true, "Công ty được yêu cầu"],
    },
    active: {
      type: Boolean,
      default: false,
    },
    closed: {
      type: Boolean,
      default: false,
    },
    deadline: {
      type: Date,
      default: () => new Date(+new Date() + 7 * 24 * 60 * 60 * 1000),
    },
    note: {
      type: String,
    },
    applicants: [
      {
        user: {
          type: mongoose.Schema.Types.ObjectId,
          ref: "User",
        },
        email: {
          type: String,
          required: [true, "Email người ứng tuyển được yêu cầu"],
        },
        phone: {
          type: String,
          required: [true, "Số điện thoại người ứng tuyển được yêu cầu"],
        },
        CV: {
          type: String,
          required: [true, "CV người ứng tuyển được yêu cầu"],
        },
      },
    ],
    followers: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
      },
    ],
    categories: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Category",
      },
    ],
  },
  {
    timestamps: true,
  }
);

JobSchema.virtual("numFollowers", {
  ref: "User",
  localField: "_id",
  foreignField: "saveJobs",
  count: true,
  match: { active: true },
});

JobSchema.virtual("numApplies", {
  ref: "User",
  localField: "_id",
  foreignField: "jobs",
  count: true,
  match: { active: true },
});

JobSchema.pre("save", function (next) {
  if (this.title) {
    this.slug = convertToSlug(this.title);
  }
  next();
});

const Job = mongoose.model("Job", JobSchema);

module.exports = Job;
