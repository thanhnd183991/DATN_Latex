const mongoose = require("mongoose");
const messageSchema = new mongoose.Schema(
  {
    roomId: { type: mongoose.Schema.ObjectId, ref: "Room" },
    text: String,
    sender: { type: mongoose.Schema.ObjectId, ref: "User" },
    attachment: {
      file: { type: String },
      resource_type: { type: String },
      original_filename: { type: String },
    },
    status: {
      type: String,
      enum: ["sent", "delivered", "seen"],
      default: "sent",
    },
    replyingTo: {
      type: mongoose.Schema.ObjectId,
      ref: "Message",
    },
    reactions: {
      type: [
        {
          reaction: {
            type: String,
            enum: ["like", "love", "haha", "wow", "sad", "angry"],
          },
          userId: { type: mongoose.Schema.ObjectId, ref: "User" },
          createdAt: { type: Date, default: Date.now },
          updatedAt: { type: Date, default: Date.now },
        },
      ],
    },
    isRemoved: Boolean,
  },
  {
    timestamps: true,
  }
);
const Message = mongoose.model("Message", messageSchema);
module.exports = Message;
