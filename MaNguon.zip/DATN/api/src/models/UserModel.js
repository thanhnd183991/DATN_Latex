const mongoose = require("mongoose");
const argon2 = require("argon2");

const UserSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      unique: [true, "Đã tồn tại tài khoản này"],
      minlength: [2, "Tên tài khoản phải có ít nhất 3 ký tự"],
      maxlength: [30, "Tên tài khoản không được vượt quá 30 ký tự"],
      required: [true, "vui lòng nhập tên"],
    },
    email: {
      type: String,
      unique: [true, "Đã tồn tại tài khoản này"],
      required: [true, "vui lòng nhập email"],
    },
    avatar: {
      type: String,
      default:
        "https://vnn-imgs-a1.vgcloud.vn/image1.ictnews.vn/_Files/2020/03/17/trend-avatar-1.jpg",
    },
    password: {
      type: String,
      select: false,
      required: [true, "vui lòng nhập mật khẩu"],
      minlength: [6, "Mật khẩu phải có ít nhất 6 ký tự"],
    },
    about: {
      type: String,
      maxlength: [1000, "Vui lòng nhập ít hơn 1000 ký tự"],

      default: "",
      select: false,
    },
    projects: { type: String, select: false },
    social: {
      youtube: { type: String, default: "" },
      twitter: { type: String, default: "" },
      facebook: { type: String, default: "" },
      linkedin: { type: String, default: "" },
      instagram: { type: String, default: "" },
      website: { type: String, default: "" },
      select: false,
    },
    role: {
      type: String,
      enum: ["admin", "manager", "HR", "employee"],
      default: "employee",
    },
    status: {
      type: String,
      enum: ["online", "offline"],
      default: "offline",
      select: false,
    },
    active: {
      type: Boolean,
      default: true,
    },
    lastActivity: Date,
    educations: {
      type: [
        {
          school: { type: mongoose.Schema.Types.ObjectId, ref: "Education" },
          degree: { type: String },
          field_of_study: { type: String },
          start_date: { type: String },
          end_date: { type: String },
        },
      ],
      select: false,
    },
    experiences: {
      type: [
        {
          name: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Experience",
          },
          position: {
            type: String,
            maxlength: [100, "Vui lòng nhập ít hơn 100 ký tự"],
          },
          desc: {
            type: String,
            maxlength: [1000, "Vui lòng nhập ít hơn 1000 ký tự"],
          },
          start_date: { type: String },
          end_date: { type: String },
        },
      ],
      select: false,
    },
    skills: {
      type: [
        {
          type: mongoose.Schema.Types.ObjectId,
          ref: "Category",
        },
      ],
      select: false,
    },
    languages: {
      type: [
        {
          type: mongoose.Schema.Types.ObjectId,
          ref: "Language",
        },
      ],
      select: false,
    },
    saveJobs: {
      type: [
        {
          type: mongoose.Schema.Types.ObjectId,
          ref: "Job",
        },
      ],
      select: false,
    },
    jobs: {
      type: [
        {
          type: mongoose.Schema.Types.ObjectId,
          ref: "Job",
        },
      ],
      select: false,
    },
    followers: {
      type: [{ type: mongoose.Schema.ObjectId, ref: "User" }],
      select: false,
    },
    following: {
      type: [{ type: mongoose.Schema.ObjectId, ref: "User" }],
      select: false,
    },
    company: {
      type: mongoose.Schema.ObjectId,
      ref: "Company",
      select: false,
    },
    activeCompany: { type: Boolean, default: false, select: false },

    followingCompany: {
      type: [{ type: mongoose.Schema.ObjectId, ref: "Company" }],
      select: false,
    },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true }, // So `res.json()` and other `JSON.stringify()` functions include virtuals
    toObject: { virtuals: true }, // So `console.log()` and other functions that use `toObject()` include virtuals
  }
);

UserSchema.pre("^find", function (next) {
  this.active = true;
  next();
});

UserSchema.methods.correctPassword = async function (
  plainPassword,
  passwordStoreInDb
) {
  return await argon2.verify(passwordStoreInDb, plainPassword);
};

UserSchema.virtual("posts", {
  ref: "Post",
  localField: "_id",
  foreignField: "ownerId",
});

UserSchema.virtual("numFollowers", {
  ref: "User",
  localField: "followers",
  foreignField: "_id",
  count: true,
});

UserSchema.virtual("numFollowingCompany", {
  ref: "Company",
  localField: "followingCompany",
  foreignField: "_id",
  count: true,
});

UserSchema.virtual("numFollowing", {
  ref: "User",
  localField: "following",
  foreignField: "_id",
  count: true,
});

UserSchema.virtual("createJobsForCompany", {
  ref: "Job",
  localField: "_id",
  foreignField: "owner",
});

UserSchema.pre("remove", function (next) {
  // console.log("remove User");
  this.model("Post").remove({ ownerId: this._id }, next);
});

const User = mongoose.model("User", UserSchema);

module.exports = User;
