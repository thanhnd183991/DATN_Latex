const mongoose = require("mongoose");

const CompanySchema = new mongoose.Schema(
  {
    owner: {
      _id: {
        type: mongoose.Schema.Types.ObjectId,
        unique: true,
      },
      name: {
        type: String,
      },
      email: String,
      avatar: String,
    },
    name: {
      type: String,
      minlength: [2, "Tên công ty phải có ít nhất 3 ký tự"],
      maxlength: [100, "Tên công ty không được vượt quá 30 ký tự"],
      required: [true, "vui lòng nhập tên"],
    },
    avatar: {
      type: String,
      default: "https://cdn-icons-png.flaticon.com/512/2083/2083417.png",
    },
    active: { type: Boolean, default: false },
    website: { type: String },
    overview: { type: String },
    industry: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Category",
    },
    headquarters: { type: String },
    followers: {
      type: [{ type: mongoose.Schema.ObjectId, ref: "User" }],
      select: false,
    },
  },
  {
    timestamps: true,

    toJSON: { virtuals: true }, // So `res.json()` and other `JSON.stringify()` functions include virtuals
    toObject: { virtuals: true }, // So `console.log()` and other functions that use `toObject()` include virtuals
  }
);

CompanySchema.virtual("posts", {
  ref: "Post",
  localField: "_id",
  foreignField: "ownerId",
});

CompanySchema.virtual("jobs", {
  ref: "Job",
  localField: "_id",
  foreignField: "company",
});

CompanySchema.virtual("numJobs", {
  ref: "Job",
  localField: "_id",
  foreignField: "company",
  match: { active: true },
  count: true,
});

CompanySchema.virtual("members", {
  ref: "User",
  localField: "_id",
  foreignField: "company",
});

CompanySchema.virtual("numMembers", {
  ref: "User",
  localField: "_id",
  foreignField: "company",
  count: true,
});

CompanySchema.virtual("numFollowers", {
  ref: "User",
  localField: "_id",
  foreignField: "followingCompany",
  count: true,
  match: { active: true },
});

CompanySchema.pre("remove", function (next) {
  this.model("Post").remove({ ownerId: this._id });
  this.model("Job").remove({ company: this._id }, next);
});

const Company = mongoose.model("Company", CompanySchema);

module.exports = Company;
