const mongoose = require("mongoose");
const { convertToSlug } = require("../utils/convertToSlug");

const LanguageSchema = mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, "name language is required"],
      unique: true,
    },
    slug: {
      type: String,
    },
    users: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
      },
    ],
  },
  {
    timestamps: { createdAt: true, updatedAt: false },
    toJSON: { virtuals: true }, // So `res.json()` and other `JSON.stringify()` functions include virtuals
    toObject: { virtuals: true }, // So `console.log()` and other functions that use `toObject()` include virtuals
  }
);

LanguageSchema.pre("save", function (next) {
  this.slug = convertToSlug(this.name);
  next();
});

const Language = mongoose.model("Language", LanguageSchema);
module.exports = Language;
