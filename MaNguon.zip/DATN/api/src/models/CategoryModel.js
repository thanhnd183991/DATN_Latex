const mongoose = require("mongoose");
const { convertToSlug } = require("../utils/convertToSlug");

const CategorySchema = mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, "Tên danh mục được yêu cầu"],
      unique: true,
    },
    slug: {
      type: String,
      unique: true,
    },
    parents: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Category",
      },
    ],
    jobs: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "Job",
      },
    ],
    users: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
      },
    ],
  },
  {
    timestamps: { createdAt: true, updatedAt: false },
    toJSON: { virtuals: true }, // So `res.json()` and other `JSON.stringify()` functions include virtuals
    toObject: { virtuals: true }, // So `console.log()` and other functions that use `toObject()` include virtuals
  }
);

CategorySchema.virtual("companies", {
  ref: "Company",
  localField: "_id",
  foreignField: "industry",
});

CategorySchema.pre("save", function (next) {
  this.slug = convertToSlug(this.name);
  next();
});

const Category = mongoose.model("Category", CategorySchema);
module.exports = Category;
