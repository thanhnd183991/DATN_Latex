const mongoose = require("mongoose");
const { v4: uuidv4 } = require("uuid");

const CommentSchema = new mongoose.Schema(
  {
    postId: { type: mongoose.Schema.ObjectId, ref: "Post" },
    content: { type: String },
    file: {
      file: { type: String },
      resource_type: { type: String },
      original_filename: { type: String },
    },
    root: {
      type: mongoose.Schema.ObjectId,
      ref: "Comment",
    },
    children: {
      type: [mongoose.Schema.ObjectId],
      ref: "Comment",
    },
    userId: { type: mongoose.Schema.ObjectId, ref: "User" },
    reactions: {
      type: [
        {
          reaction: {
            type: String,
            enum: ["like", "love", "haha", "wow", "sad", "angry"],
          },
          userId: { type: mongoose.Schema.ObjectId, ref: "User" },
          createdAt: { type: Date, default: Date.now },
          updatedAt: { type: Date, default: Date.now },
        },
      ],
    },
  },
  {
    timestamps: { createdAt: true, updatedAt: false },
  }
);
const Comment = mongoose.model("Comment", CommentSchema);
module.exports = Comment;
