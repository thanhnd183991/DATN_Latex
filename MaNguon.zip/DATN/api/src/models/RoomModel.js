const mongoose = require("mongoose");

const roomSchema = new mongoose.Schema(
  {
    members: [{ type: mongoose.Schema.ObjectId, ref: "User" }],
    roomType: {
      type: String,
      enum: ["Personal", "Company"],
      default: "Personal",
    },
    company: {
      type: mongoose.Schema.ObjectId,
      ref: "Company",
    },
    jobs: [
      {
        type: mongoose.Schema.ObjectId,
        ref: "Job",
      },
    ],
    roomName: String,
    roomPhoto: {
      type: String,
    },
    latestMessage: { type: Object, default: {} },
    lastSeenMessage: { type: Object, default: {} },
    blocked: {
      type: mongoose.Schema.ObjectId,
      ref: "User",
    },
    active: { type: Boolean, default: true },
  },
  {
    timestamps: true,
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
  }
);

//
roomSchema.virtual("messages", {
  ref: "Message",
  foreignField: "roomId",
  localField: "_id",
});

const Room = mongoose.model("room", roomSchema);
module.exports = Room;
