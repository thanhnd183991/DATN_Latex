// get count notify when online
exports.NOTIFY_COUNT_WHEN_ONLINE_AGAIN = "NOTIFY_COUNT_WHEN_ONLINE_AGAIN";

//follow
exports.FOLLOW_USER = "FOLLOW:USER";
exports.FOLLOW_COMPANY = "FOLLOW:COMPANY";
exports.FOLLOW_JOB = "FOLLOW:JOB";

//apply job
exports.APPLY_JOB = "APPLY:JOB";

// change owner
exports.CHANGE_OWNER = "CHANGE:OWNER";

// member
exports.ADD_MEMBER = "ADD:MEMBER";
exports.DELETE_MEMBER = "DELETE:MEMBER";

// create
exports.CREATE_POST = "Create:Post";
exports.CREATE_USER_POST = "Create:UserPost";
exports.CREATE_COMPANY_POST = "Create:CompanyPost";
exports.CREATE_JOB_FOR_USER = "Create:JobForUser";
exports.CREATE_JOB_FOR_ADMIN = "Create:JobForAdmin";
exports.CREATE_COMPANY = "Create:Company";
exports.CREATE_REPORT_JOB = "Create:ReportJob";
exports.CREATE_REPORT_POST = "Create:ReportPost";

//connect
exports.CONNECT_USER = "Connect:User";
exports.CONNECT_JOB = "Connect:Job";

// confirm
exports.CONFIRM_COMPANY = "Confirm:Company";
exports.CONFIRM_CONNECT_USER = "Confirm:ConnectUser";
exports.CONFIRM_CONNECT_JOB = "Confirm:ConnectJob";
exports.CONFIRM_JOB = "Confirm:Job";
exports.CONFIRM_ADD_MEMBER = "Confirm:AddMember";
exports.CONFIRM_APPLY_JOB = "Confirm:ApplyJob";
exports.CONFIRM_DELETE_MEMBER = "Confirm:DeleteMember";
exports.CONFIRM_REPORT_JOB = "Confirm:ReportJob";
exports.CONFIRM_REPORT_POST = "Confirm:ReportPost";

//status
exports.PENDING = "pending";
exports.VIEWED = "viewed";
exports.ACCEPTED = "accepted";
exports.REJECTED = "rejected";

//action
exports.CONFIRM = "Confirm";
