const Category = require("../models/CategoryModel");
const User = require("../models/UserModel");
const Job = require("../models/JobModel");
const { convertToSlug } = require("../utils/convertToSlug");

exports.upsertCategory = async (name) => {
  const category = await Category.findOne({
    slug: convertToSlug(name),
  });
  if (category) {
    return category;
  }

  const newCategory = await Category.create({
    name,
  });
  return newCategory;
};

exports.upsertArrayCategory = (names, userId, job) =>
  new Promise((resolve, reject) => {
    // console.log(names);
    let rs = [];
    Promise.all(
      names.map(async (name) => {
        // Find the document
        let obj = {};
        if (userId) {
          obj = {
            $addToSet: {
              users: userId,
            },
          };
        }
        if (job && job._id.toString()) {
          obj = {
            $addToSet: {
              jobs: job._id,
              parents: job.company.industry,
            },
          };
        }
        const category = await Category.findOneAndUpdate(
          { $or: [{ name }, { slug: convertToSlug(name) }] },
          { slug: convertToSlug(name), name, ...obj },
          { upsert: true, new: true }
        );
        return {
          _id: category._id,
          name: category.name,
        };
      })
    )
      .then((rs) => {
        // console.log(rs);
        resolve(rs);
      })
      .catch((error) => reject(error));
  });

exports.createJobCategories = (jobId, names, parentId) => {
  return Promise.all(
    names.map(async (name) => {
      const cat = await Category.findOneAndUpdate(
        {
          slug: convertToSlug(name),
        },
        {
          $addToSet: {
            jobs: jobId,
            parents: parentId,
          },
        }
      );
      if (!cat) {
        const newCat = await Category.create({
          name,
          jobs: [jobId],
          parents: [parentId],
        });
        return newCat._id;
      }
      return cat._id;
    })
  )
    .then((rs) => {
      return {
        status: 200,
        ids: rs,
      };
    })
    .catch((err) => {
      return {
        status: 500,
        message: err.message,
      };
    });
};

// add one job to category
exports.addJobToCategory = async (categoryId, jobId, parentCategory) => {
  const category = await Category.updateOne(
    { _id: categoryId },
    {
      $push: {
        jobs: jobId,
      },
      $addToSet: {
        parents: parentCategory,
      },
    }
  );
  return category;
};

exports.createUserCategories = (names, userId) => {
  return Promise.all(
    names.map(async (name) => {
      const cat = await Category.findOneAndUpdate(
        {
          slug: convertToSlug(name),
        },
        {
          $addToSet: {
            users: userId,
          },
        },
        {
          new: true,
        }
      );
      if (!cat) {
        const newCat = await Category.create({
          name,
          users: [userId],
        });
        return newCat._id;
      }
      return cat._id;
    })
  )
    .then((rs) => {
      return rs;
    })
    .catch((error) => {
      return error;
    });
};

exports.deleteUserJobCategories = async (names, userId, jobId) => {
  const objPull = userId
    ? {
        users: userId,
      }
    : {
        jobs: jobId,
      };

  return await Category.updateMany(
    {
      name: { $in: names },
    },
    {
      $pull: objPull,
    }
  );
};

exports.countJobByCategroy = async () => {
  const data = await Category.aggregate([
    {
      $set: {
        numJobs: { $size: "$jobs" },
      },
    },
    {
      $project: {
        _id: 1,
        name: 1,
        numJobs: 1,
      },
    },
    {
      $sort: {
        numJobs: -1,
      },
    },
    {
      $limit: 10,
    },
  ]);

  return {
    status: 200,
    data: data.reduce(
      (acc, cur) => {
        acc.categories.push(cur.name);
        acc.data.push(cur.numJobs);
        return acc;
      },
      {
        categories: [],
        data: [],
      }
    ),
  };
};

exports.deleteCategory = async (id) => {
  try {
    const category = await Category.findById(id);
    await Promise.all([
      User.updateMany(
        {
          _id: { $in: category.users },
        },
        {
          $pull: {
            skills: id,
          },
        },
        { multi: true }
      ),
      Job.updateMany(
        {
          _id: { $in: category.jobs },
        },
        {
          $pull: {
            categories: id,
          },
        },
        { multi: true }
      ),
    ]).then((rs) => {
      // console.log(rs);
      return Category.deleteOne({ _id: id });
    });

    return {
      status: 200,
      message: "Delete category success",
    };
  } catch (err) {
    return {
      status: 500,
      message: err.message,
    };
  }
};
