const Post = require("../models/PostModel");
const Reaction = require("../models/ReactionModel");
const Comment = require("../models/CommentModel");
const User = require("../models/UserModel");
const Company = require("../models/CompanyModel");
const { cloudDestroyFiles } = require("./CloudinaryStoreService");
const { getPublicId } = require("../utils/file");

exports.createPost = async (reqBody, reqUserId) => {
  const { type, ...info } = reqBody;
  const user = await User.findOne({ _id: reqUserId, active: true })
    .select("+activeCompany")
    .populate({
      path: "company",
    });
  if (!user) {
    return {
      status: 404,
      message: "Không tìm thấy tài khoản :(",
    };
  }
  if (type === "Company") {
    if (
      !(user.role === "manager" || (user.role === "HR" && user.activeCompany))
    ) {
      return {
        status: 404,
        message: "Bạn không đủ quyền hạn để tạo post cho công ty này",
      };
    }
    if (!user.company) {
      return {
        status: 404,
        message: "Không tìm thấy công ty :(",
      };
    }
  }

  const post = await Post.create({
    ...info,
    ownerId: type === "Company" ? user.company._id : reqUserId,
    onOwner: type === "Company" ? "Company" : "User",
  });
  if (type === "Company") {
    post.ownerId = user.company;
  } else {
    post.ownerId = user;
  }

  // console.log(post);

  return {
    status: 201,
    post,
  };
};

exports.findPost = async (postId) => {
  const post = await Post.findById(postId)
    .populate({
      path: "ownerId",
      match: { active: true },
    })
    .populate({
      path: "numComments numReactions",
    })
    .lean();
  if (!post) {
    return {
      status: 404,
      message: "Không tìm thấy bài viết",
    };
  }

  return {
    status: 200,
    post,
  };
};

exports.listPostAdmin = async (page, limit, active) => {
  const startIndex = (Number(page || 1) - 1) * limit; // get the starting index of every page
  total = await Post.countDocuments({});
  const posts = await Post.find({ active })
    .sort({ createdAt: -1 })
    .limit(limit)
    .skip(startIndex);
  return {
    status: 200,
    data: {
      posts,
      total,
      page,
    },
  };
};

exports.listPostByUser = async (userId, page, limit, active, role) => {
  const startIndex = (Number(page || 1) - 1) * limit; // get the starting index of every page
  const user = await User.findOne({ _id: userId, active });
  if (!user) {
    return {
      status: 404,
      message: "Không tìm thấy tài khoản :(",
    };
  }

  const userPosts = await User.findById(userId).populate({
    path: "posts",
    populate: {
      path: "ownerId",
      match: { active: true },
      select: "name avatar",
    },
    options: { sort: { createdAt: -1 }, limit: limit, skip: startIndex },
  });
  // const users = await User.findById(req.user.id).populate("posts");
  return {
    status: 200,
    data: {
      posts: userPosts.posts,
      page,
    },
  };
};

exports.listPostByCompany = async (companyId, page, limit) => {
  const startIndex = (Number(page || 1) - 1) * limit; // get the starting index of every page
  const company = await Company.findOne({
    _id: companyId,
    active: true,
  }).populate({
    path: "posts",
    options: { sort: { createdAt: -1 }, limit: limit, skip: startIndex },
    populate: { path: "ownerId", match: { active: true } },
  });
  if (!company) {
    return {
      status: 404,
      message: "Không tìm thấy công ty :(",
    };
  }
  // const users = await User.findById(req.user.id).populate("posts");
  return {
    status: 200,
    data: {
      posts: company.posts,
      page,
    },
  };
};

exports.listPostByFeed = async (userId, page, limit) => {
  // tim theo nguoi following va following company
  const startIndex = (Number(page || 1) - 1) * limit; // get the starting index of every page
  const user = await User.findOne({
    _id: userId,
    active: true,
  }).populate({
    path: "followingCompany following",
    match: { active: true },
    select: "name",
    options: { _recursed: true },
  });

  if (!user) {
    return {
      status: 404,
      message: "Không tìm thấy tài khoản :(",
    };
  }

  const { following, followingCompany } = user;
  const posts = await Post.find({
    $or: [
      {
        ownerId: {
          $in: following.map((user) => user._id),
        },
      },
      {
        ownerId: {
          $in: followingCompany.map((company) => company._id),
        },
      },
    ],
  })
    .populate({
      path: "ownerId",
      match: { active: true },
      select: "name avatar owner",
    })
    .sort({ createdAt: -1 })
    .limit(limit)
    .skip(startIndex)
    .lean();

  // console.log(posts);
  return {
    status: 200,
    data: {
      posts,
      page,
    },
  };
};

exports.searchPost = async (keywords, page, limit) => {
  const startIndex = (Number(page || 1) - 1) * limit; // get the starting index of every page
  const posts = await Post.find({
    content: { $regex: ".*" + keywords + ".*", $options: "i" },
  })
    .populate({
      path: "ownerId",
      match: { active: true },
    })
    .sort({ createdAt: -1 })
    .limit(limit)
    .skip(startIndex);
  return {
    status: 200,
    data: {
      posts,
      page,
    },
  };
};

exports.getPostStatsService = async () => {
  const today = new Date();
  const latYear = today.setFullYear(today.setFullYear() - 1);
  try {
    const data = await Post.aggregate([
      {
        $project: {
          month: { $month: "$createdAt" },
        },
      },
      {
        $group: {
          _id: "$month",
          total: { $sum: 1 },
        },
      },
      {
        $sort: {
          _id: 1,
        },
      },
    ]);
    const rs = {
      categories: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
      data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    };
    data.forEach((item) => {
      rs.data[item._id - 1] = item.total;
    });
    return { status: 200, data: rs };
  } catch (err) {
    return {
      status: 500,
      message: "Có lỗi xảy ra",
    };
  }
};

exports.getPostTypeService = async () => {
  try {
    const data = await Post.aggregate([
      {
        $facet: {
          user: [{ $match: { onOwner: "User" } }, { $count: "Total" }],
          company: [{ $match: { onOwner: "Company" } }, { $count: "Total" }],
        },
      },
      {
        $project: {
          "Người dùng": { $arrayElemAt: ["$user.Total", 0] },
          "Công ty": { $arrayElemAt: ["$company.Total", 0] },
        },
      },
    ]);
    // console.log(data);
    return {
      status: 200,
      data: {
        categories: Object.keys(data[0]),
        data: Object.values(data[0]),
      },
    };
  } catch (err) {
    return {
      status: 500,
      message: "Có lỗi xảy ra",
    };
  }
};

exports.deletePostService = async (postId, user) => {
  try {
    const post = await Post.findById(postId).populate("ownerId");
    if (user.role !== "admin") {
      if (
        post.onOwner === "User" &&
        post.ownerId._id.toString() !== user.id.toString()
      ) {
        return {
          status: 403,
          message: "Bạn không có quyền xóa bài viết này",
        };
      }
      if (
        post.onOwner === "Company" &&
        post.ownerId.owner._id.toString() !== user.id.toString()
      ) {
        return {
          status: 403,
          message: "Bạn không phải manager của công ty này không thể xóa",
        };
      }
    }
    const deletePromiseAll = [
      Reaction.deleteMany({ postId }),
      Comment.deleteMany({ postId }),
    ];

    if (post.files.length > 0) {
      deletePromiseAll.push(
        cloudDestroyFiles(post.files.map((file) => getPublicId(file.file)))
      );
    }
    await Promise.all(deletePromiseAll).then(() =>
      Post.deleteOne({ _id: postId })
    );
    return { status: 200, message: "Xóa thành công" };
  } catch (err) {
    return {
      status: 500,
      message: "Có lỗi xảy ra",
    };
  }
};
