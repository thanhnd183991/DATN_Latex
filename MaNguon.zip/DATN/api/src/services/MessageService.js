const Message = require("../models/MessageModel");
const Room = require("../models/RoomModel");
const ChatConstant = require("../constants/ChatConstant");
const { updateLastMessage } = require("./RoomService");

// cho ca reply va khong rep tin nhan
exports.createMessage = async (roomId, message) => {
  if (!message.sender) {
    return {
      status: 400,
      message: "Sender not found",
    };
  }

  if (!message.text && !message.attachment) {
    return {
      status: 400,
      message: "Message is empty",
    };
  }

  const room = await Room.findOne({
    _id: roomId,
    members: { $in: [message.sender] },
    blocked: { $exists: false },
  });

  if (!room) {
    return {
      status: 400,
      message: "Room not found",
    };
  }
  let replyMessageDB = null;

  if (message.replyingTo) {
    replyMessageDB = await Message.findById(message.replyingTo).select(
      "text attachment createdAt"
    );
    if (!replyMessageDB) {
      return {
        status: 400,
        message: "Reply message not found",
      };
    }
  }

  const newMessage = await Message.create({
    roomId,
    sender: message.sender,
    text: message.text,
    attachment: message.attachment,
    replyingTo: message.replyingTo,
  });
  if (replyMessageDB) {
    newMessage.replyingTo = replyMessageDB;
  }

  await updateLastMessage(roomId, newMessage);

  return {
    status: 200,
    data: newMessage,
    room,
  };
};

exports.getMessages = async (roomId, userId, page, limit) => {
  const messages = await Room.findOne({
    _id: roomId,
    members: { $in: [userId] },
  })
    .populate({
      path: "members",
      select: "name avatar",
    })
    .populate({
      path: "messages",
      populate: {
        path: "replyingTo",
        select: "text attachment createdAt",
        options: { _recursed: true },
      },
      options: {
        sort: { createdAt: -1 },
        skip: (page - 1) * limit,
        limit: limit,
      },
    })
    .select("messages");
  if (!messages) {
    return {
      status: 400,
      message: "Not permitted to open this room",
    };
  }
  return {
    status: 200,
    data: messages.messages,
  };
};

exports.reactionMessage = async (messageId, reaction) => {
  const message = await Message.findById(messageId).populate({
    path: "replyingTo",
    options: { _recursed: true },
  });
  if (!message) {
    return {
      status: 404,
      message: "Message not found",
    };
  }
  const room = await Room.findOne({
    _id: message.roomId,
    members: { $in: [reaction.userId] },
    blocked: { $exists: false },
  });
  if (!room) {
    return {
      status: 404,
      message: "Room not found",
    };
  }
  const reactionIndex = message.reactions.findIndex(
    (reactionItem) => reactionItem.userId.toString() === reaction.userId
  );
  if (reactionIndex === -1) {
    message.reactions.push(reaction);
  } else {
    if (message.reactions[reactionIndex].reaction === reaction.reaction) {
      message.reactions.splice(reactionIndex, 1);
    } else {
      message.reactions[reactionIndex] = reaction;
    }
  }
  await message.save();

  return {
    status: 200,
    data: message,
    room,
  };
};

exports.removeMessage = async (messageId, userId) => {
  const message = await Message.findById(messageId);
  if (!message) {
    return {
      status: 404,
      message: "Message not found",
    };
  }
  const room = await Room.findOne({
    _id: message.roomId,
    members: { $in: [userId] },
    blocked: { $exists: false },
  });
  if (!room) {
    return {
      status: 404,
      message: "Room not found",
    };
  }
  if (message.sender.toString() !== userId.toString()) {
    return {
      status: 403,
      message: "Not permitted to remove this message",
    };
  }
  message.isRemoved = true;
  await message.save();
  if (message._id === room.latestMessage._id) {
    await updateLastMessage(room._id, message);
  }

  return {
    status: 200,
    data: message,
    room,
  };
};
