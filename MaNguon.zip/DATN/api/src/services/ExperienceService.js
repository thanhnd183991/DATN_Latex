const Experience = require("../models/ExperienceModel");
const _ = require("lodash");
const User = require("../models/UserModel");
const { convertToSlug } = require("../utils/convertToSlug");

exports.createUserExperiences = (names, userId) => {
  return Promise.all(
    names.map(async (name) => {
      const exp = await Experience.findOne({
        slug: convertToSlug(name),
      });
      if (exp) {
        exp.users.push(userId);
        await exp.save();
        return {
          _id: exp._id,
          name: exp.name,
        };
      }
      const newExp = await Experience.create({
        name,
        slug: convertToSlug(name),
        users: [userId],
      });
      return {
        _id: newExp._id,
        name: newExp.name,
      };
    })
  )
    .then((rs) => {
      return rs;
    })
    .catch((error) => {
      return error;
    });
};

exports.deleteUserExps = (names, userId) => {
  return Promise.all(
    names.map(async (name) => {
      const exp = await Experience.findOne({
        slug: convertToSlug(name),
      });
      if (exp) {
        exp.users.pull(userId);
        await exp.save();
        return exp;
      }
      return null;
    })
  )
    .then((rs) => {
      return rs;
    })
    .catch((error) => {
      return error;
    });
};

exports.updateUserExps = async (newNames, userId) => {
  try {
    const user = await User.findById(userId).select("experiences");
    await Experience.updateMany(
      { _id: { $in: user.experiences.map((el) => el.name) } },
      { $pull: { users: userId } }
    );
    const newExps = await this.createUserExperiences(
      newNames.map((el) => el.name),
      userId
    );
    user.experiences = newExps.map((el, index) => {
      const { name, ...info } = newNames[index];
      // console.log(info);
      return {
        name: el._id,
        ...info,
      };
    });
    await user.save();
    return {
      status: 200,
      message: "Update experiences successfully",
    };
  } catch (err) {
    return {
      status: 500,
      message: err.message,
    };
  }
};

exports.searchExps = async ({ operatorValue, value: tmp, page, limit }) => {
  let myFilter = "";
  const PAGE = Number(page) || 1;
  const LIMIT = Number(limit) || 6;
  const startIndex = (Number(PAGE) - 1) * LIMIT; // get the starting index of every page
  const value = convertToSlug(tmp);
  if (operatorValue === "contains") {
    myFilter = { $regex: new RegExp(".*" + value + ".*", "i") };
  } else if (operatorValue === "equals") {
    myFilter = { $eq: value };
  } else if (operatorValue === "startsWith") {
    myFilter = { $regex: new RegExp("^" + value + ".*", "i") };
  } else if (operatorValue === "endsWith") {
    myFilter = { $regex: new RegExp(".*" + value + "$", "i") };
  } else if (operatorValue === "isEmpty") {
    myFilter = { $eq: null };
  } else if (operatorValue === "isNotEmpty") {
    myFilter = { $ne: null };
  } else if (operatorValue === "is" && value !== "") {
    myFilter = { $eq: value === "false" ? false : true };
  }
  let obj = {};
  Object.assign(obj, { slug: myFilter });
  // console.log(obj);
  const data = await Experience.find(obj)
    .select("_id name")
    .sort({ name: 1 })
    .skip(startIndex)
    .limit(LIMIT);
  return {
    status: 200,
    data: {
      data,
      currentPage: PAGE,
    },
  };
};
