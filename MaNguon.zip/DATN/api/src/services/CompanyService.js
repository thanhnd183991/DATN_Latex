const Company = require("../models/CompanyModel");
const User = require("../models/UserModel");
const CategoryService = require("./CategoryService");
const Category = require("../models/CategoryModel");
const NotificationService = require("./NotificationService");
const mongoose = require("mongoose");
const { activeRooms } = require("./RoomService");
const { deleteMembers } = require("./UserService");
const { updateActiveJobs } = require("./JobService");
const { cloudDestroyFile } = require("./CloudinaryStoreService");
const { getPublicId } = require("../utils/file");
const { convertToSlug } = require("../utils/convertToSlug");
const { filterRegex } = require("../utils/filter");

exports.createCompanyService = async (userId, reqBody) => {
  const { name, _id, avatar, email } = await User.findById(userId).select(
    "-__v"
  );
  const { industry, ...info } = reqBody;
  const category = await CategoryService.upsertCategory(industry);
  const companyAvatar = await Company.findOne({
    "owner._id": _id,
  });
  // console.log(companyAvatar);
  if (companyAvatar) {
    cloudDestroyFile(getPublicId(companyAvatar.avatar))
      .then((rs) => console.log(rs))
      .catch((err) => console.log("xoa avatar ", err));
  }
  let companyTmp = await Company.findOneAndUpdate(
    {
      "owner._id": _id,
    },
    {
      ...info,
      owner: { name, _id, avatar, email },
      industry: category._id,
    }
  );
  if (companyTmp && companyTmp.active) {
    return {
      status: 200,
      message: "Công ty đã được active",
    };
  }
  if (!companyTmp) {
    companyTmp = await Company.create({
      ...info,
      owner: { name, _id, avatar, email },
      industry: category._id,
    });
  }
  return {
    status: 201,
    data: companyTmp,
  };
};

exports.updateStatusCompanyService = async (companyId, user, status) => {
  // đặt trạng thái công ty là inactive
  const company = await Company.findById(companyId).populate("members");
  if (!company) {
    return {
      status: 404,
      message: "Không tìm thấy công ty",
    };
  }
  if (user.role !== "admin") {
    return {
      status: 403,
      message: "Bạn không đủ quyền xóa công ty",
    };
  }

  if (company.active) {
    // cong ty dang hoat dong
    //danh sach id nhân viên khỏi công ty
    // console.log(company.members);
    const members = company.members.map((mem) => mem._id);

    let arrayPromises = [
      updateActiveJobs(companyId, false),
      activeRooms(companyId, "Company", false),
    ];

    if (members.length > 0) {
      arrayPromises.push(deleteMembers(members, false, false));
    }

    const rs = await Promise.all(arrayPromises);
    // console.log("xoa nhan vien, inactive job, inactive room");
    rs.forEach((tmpRs) => {
      if (tmpRs.acknowledged === false || tmpRs.status !== 200)
        return {
          status: 500,
          message: "Có lỗi xảy ra",
        };
    });
  } else {
    // cong ty dang hoat dong
    //danh sach id nhân viên khỏi công ty
    // console.log(company.members);
    const members = company.members.map((mem) => mem._id);
    let arrayPromises = [
      updateActiveJobs(companyId, true),
      activeRooms(companyId, "Company", true),
    ];

    if (members.length > 0) {
      arrayPromises.push(deleteMembers(members, true));
    }

    const rs = await Promise.all(arrayPromises);
    // console.log("active nhan vien, active job, active room");
    rs.forEach((tmpRs) => {
      if (tmpRs.acknowledged === false || tmpRs.status !== 200)
        return {
          status: 500,
          message: "Có lỗi xảy ra",
        };
    });
  }

  await company.updateOne({
    $set: {
      active: status,
    },
  });
  // console.log("status", status);
  if (status == true) {
    const rs = await this.addEmployeesService(
      company._id,
      [company.owner._id.toString()],
      company.owner._id.toString(),
      "manager"
    );
    // console.log("add nhan vien", rs);
  }
  return {
    status: 200,
    message: `Công ty ${company.name} đã được ${
      !company.active ? "active" : "inactive"
    }`,
  };
};

exports.addEmployeesService = async (
  companyId,
  employees,
  userId,
  role = "employee"
) => {
  // console.log(companyId, employees);
  let obj = {
    _id: companyId,
  };
  if (role !== "manager") {
    active = true;
  }
  const company = await Company.findOne(obj);
  if (!company) {
    return {
      status: 404,
      message: "Không tìm thấy công ty",
    };
  }
  if (company.owner._id.toString() !== userId.toString()) {
    return {
      status: 403,
      message: "Bạn không đủ quyền thêm nhân viên",
    };
  }
  if (employees.length === 0) {
    return {
      status: 400,
      message: "Không có nhân viên nào được thêm mảng trống",
    };
  }

  const emp = await User.findById(employees[0]);
  if (emp.role !== "employee")
    return {
      status: 403,
      message: "Không phải là nhân viên",
    };

  if (role === "manager") {
    let rs = await User.updateMany(
      {
        _id: { $in: employees },
        role: "employee",
      },
      {
        $set: {
          company: company._id,
          role,
          activeCompany: role === "manager" ? true : false,
        },
      }
    );
    // console.log(rs);
    if (rs.acknowledged === false || rs.modifiedCount !== employees.length) {
      await User.updateMany(
        {
          _id: { $in: employees },
        },
        {
          $set: {
            role: "employee",
            activeCompany: false,
          },
          $unset: {
            company: "",
          },
        }
      );
      return {
        status: 500,
        message: "Có lỗi xảy ra",
      };
    }
  }

  let tmp = {
    status: 200,
    message: "Thêm nhân viên thành công",
    notify: null,
  };

  if (role !== "manager") {
    tmp = await NotificationService.addEmployeeNotify(company, employees);
    if (tmp.status !== 200) return tmp;
  }
  return tmp;
};

exports.removeEmployeesService = async (companyId, employees, userId) => {
  const company = await Company.findById(companyId);
  if (!company) {
    return {
      status: 404,
      message: "Không tìm thấy công ty",
    };
  }
  if (company.owner._id.toString() !== userId && role !== "manager") {
    return {
      status: 403,
      message: "Bạn không đủ quyền xóa nhân viên",
    };
  }
  if (employees.length === 0) {
    return {
      status: 400,
      message: "Không có nhân viên nào được xóa mảng trống",
    };
  }

  const rs = await deleteMembers(employees, false, true);
  if (rs.status !== 200) return rs;
  if (rs.acknowledged === false)
    return {
      status: 500,
      message: "Có lỗi xảy ra",
    };

  return {
    status: 200,
    message: `${rs.modifiedCount} nhân viên được xóa khỏi công ty`,
  };
};

exports.infoCompanyService = async ({ companyId, user }) => {
  let obj = {
    _id: companyId,
  };
  if (user.role !== "admin") {
    active = true;
  }
  const company = await Company.findOne(obj)
    .populate({
      path: "numMembers numJobs numFollowers",
    })
    .populate({
      path: "industry",
      select: "name",
    });
  if (!company) {
    return {
      status: 404,
      message: "Không tìm thấy công ty",
    };
  }
  return {
    status: 200,
    data: company,
  };
};

exports.suggestionCompanyService = async ({ userId, limit, page }) => {
  const temp = await User.findById(userId)
    .select("+skills +followingCompany")
    .populate({
      path: "skills",
      select: "parents",
      populate: {
        path: "parents",
        options: { _recursed: true },
        select: "_id",
      },
    })
    .transform((user) => {
      const tmp = user.skills.reduce(
        (acc, cur) => [...acc, ...cur.parents.map((el) => el._id)],
        []
      );
      // console.log(tmp);
      return {
        followingCompany: user.followingCompany,
        idCategories: [...new Set(tmp)],
      };
    })
    .lean();
  // console.log(temp);

  const companies = await Company.find({
    active: true,
    _id: {
      $nin: temp.followingCompany,
    },
    industry: { $in: temp.idCategories },
  })
    .select("name email avatar  industry")
    .populate({
      path: "industry",
      select: "name",
    })
    .populate({
      path: "numFollowers numMembers",
    })
    .sort({
      createdAt: -1,
    })
    .skip((page - 1) * limit)
    .limit(limit + 1);

  return {
    status: 200,
    data: {
      data: companies.slice(
        0,
        companies.length > limit ? limit : companies.length
      ),
      hasMore: companies.length > limit,
      page,
    },
  };
};

exports.listUserFollowCompany = async ({ companyId, value, limit, page }) => {
  const filter = filterRegex(value, "startsWith", false, "name");
  // console.log(filter);
  const company = await Company.findOne({
    _id: companyId,
    active: true,
  })
    .select("+followers")
    .populate({
      path: "followers",
      match: { active: true, ...filter },
      select: "name email avatar followers",
      options: {
        sort: {
          name: 1,
        },
        limit,
        skip: (page - 1) * limit,
      },
    })
    .transform((doc) => {
      // console.log("name", doc);
      return {
        followers: doc.followers.map(({ followers, ...info }) => ({
          ...info,
          numFollowers: followers.length,
        })),
      };
    })
    .lean();
  // console.log(company);

  return {
    status: 200,
    data: company.followers,
  };
};

exports.countJobByCompany = async () => {
  const companies = await Company.find()
    .populate({
      path: "numJobs",
    })
    .sort({
      numJobs: -1,
    })
    .limit(10)
    .select("name numJobs")
    .transform((rs) =>
      rs.reduce(
        (acc, cur) => {
          acc.categories.push(cur.name);
          acc.data.push(cur.numJobs);
          return acc;
        },
        {
          categories: [],
          data: [],
        }
      )
    )
    .lean();

  return {
    status: 200,
    data: companies,
  };
};

exports.getCompanyStatusService = async () => {
  try {
    const data = await Company.aggregate([
      {
        $facet: {
          Active: [{ $match: { active: true } }, { $count: "Total" }],
          Inactive: [{ $match: { active: false } }, { $count: "Total" }],
        },
      },
      {
        $project: {
          Active: { $arrayElemAt: ["$Active.Total", 0] },
          Inactive: { $arrayElemAt: ["$Inactive.Total", 0] },
        },
      },
    ]);
    return {
      status: 200,
      data: {
        categories: Object.keys(data[0]),
        data: Object.values(data[0]),
      },
    };
  } catch (err) {
    return {
      status: 500,
      message: "Có lỗi xảy ra",
    };
  }
};

exports.getCompanyStatsService = async () => {
  const today = new Date();
  const latYear = today.setFullYear(today.setFullYear() - 1);
  try {
    const data = await Company.aggregate([
      {
        $project: {
          month: { $month: "$createdAt" },
        },
      },
      {
        $group: {
          _id: "$month",
          total: { $sum: 1 },
        },
      },
      {
        $sort: {
          _id: 1,
        },
      },
    ]);
    const rs = {
      categories: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
      data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    };
    data.forEach((item) => {
      rs.data[item._id - 1] = item.total;
    });
    return { status: 200, data: rs };
  } catch (err) {
    return {
      status: 500,
      message: "Có lỗi xảy ra",
    };
  }
};

exports.getCompanyBySkill = async (skill, page, limit) => {
  const ids = await Category.findOne({ slug: convertToSlug(skill) }).select(
    "parents"
  );
  // console.log(ids);
  const companies = await Company.find({
    industry: { $in: ids.parents },
    active: true,
  })
    .sort({ name: 1 })
    .skip((page - 1) * limit)
    .limit(limit + 1)
    .populate({
      path: "industry",
      select: "name",
    });
  // console.log(companies);
  return {
    status: 200,
    data: {
      data: companies.slice(0, Math.min(limit, companies.length)),
      hasMore: companies.length > limit,
      page,
    },
  };
};
