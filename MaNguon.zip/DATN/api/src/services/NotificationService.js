const Notification = require("../models/NotificationModel");
const User = require("../models/UserModel");
const Room = require("../models/RoomModel");
const Post = require("../models/PostModel");
const Job = require("../models/JobModel");
const Company = require("../models/CompanyModel");
const RoomService = require("./RoomService");
const {
  findSocketFromUserSockets,
  findUserFromUserSockets,
  findUsersFromUserSockets,
} = require("../sockets/userSocket");
const io = require("../sockets/index");
const NotifyConstant = require("../constants/NotifyConstant");
const CloudStore = require("../services/CloudinaryStoreService");

exports.followingUserNotify = async (sender, receiver) => {
  // đã kiểm tra tính hợp lệ từ lúc tạo follow nếu chưa cần thêm vào đây
  let checkNotify = await Notification.findOne({
    sender: sender._id,
    onSender: "User",
    onReceiver: "User",
    receiver: { $elemMatch: { user: receiver._id } },
    type: NotifyConstant.FOLLOW_USER,
    onAccess: "User",
    access: sender._id,
  });

  if (checkNotify) {
    checkNotify.receiver[0].status = NotifyConstant.PENDING;
    await checkNotify.save();
  } else {
    checkNotify = new Notification({
      sender: sender._id,
      onSender: "User",
      onReceiver: "User",
      receiver: [
        {
          user: receiver._id,
          status: NotifyConstant.PENDING,
        },
      ],
      onAccess: "User",
      access: sender._id,
      message: `<strong>${sender.name}</strong> đã theo dõi bạn`,
      type: NotifyConstant.FOLLOW_USER,
    });
    await checkNotify.save();
  }

  checkNotify.sender = sender;
  checkNotify.receiver[0].user = receiver;

  // //socket
  // const sendToUsers = findUserFromUserSockets(receiver._id.toString());
  // console.log(sendToUsers);
  // if (sendToUsers.length > 0) {
  //   console.log("vao");
  //   sendToUsers.forEach((item) => {
  //     // console.log(item);
  //     // console.log(io());
  //     io().to(item.socketId).emit(NotifyConstant.FollowUser, {
  //       data: checkNotify,
  //     });
  //   });
  // }
  return {
    status: 200,
    message: "Theo dõi người dùng thành công",
    notify: checkNotify,
  };
};

exports.followingCompanyNotify = async (sender, company) => {
  // đã kiểm tra tính hợp lệ từ lúc tạo follow nếu chưa cần thêm vào đây
  let notification = await Notification.findOne({
    sender: sender._id,
    onSender: "User",
    onReceiver: "User",
    receiver: { $elemMatch: { user: company.owner._id } },
    type: NotifyConstant.FOLLOW_COMPANY,
    onAccess: "User",
    access: sender._id,
  });

  if (notification) {
    notification.receiver[0].status = NotifyConstant.PENDING;
    await notification.save();
  } else {
    notification = new Notification({
      sender: sender._id,
      onSender: "User",
      onReceiver: "User",
      receiver: [
        {
          user: company.owner._id,
          status: NotifyConstant.PENDING,
        },
      ],
      message: `<strong>${sender.name}</strong> đã theo dõi công ty <strong>${company.name}</strong>`,
      onAccess: "User",
      access: sender._id,
      type: NotifyConstant.FOLLOW_COMPANY,
    });
    await notification.save();
  }

  notification.sender = sender;
  notification.receiver[0].user = company.owner;
  // //socket
  // const sendToUsers = findUserFromUserSockets(company.owner._id.toString());
  // console.log(sendToUsers);
  // if (sendToUsers.length > 0) {
  //   console.log("vao");
  //   sendToUsers.forEach((item) => {
  //     // console.log(item);
  //     // console.log(io());
  //     io().to(item.socketId).emit(NotifyConstant.FollowCompany, {
  //       data: notification,
  //     });
  //   });
  // }

  return {
    status: 200,
    message: "Theo dõi công ty thành công",
    notify: notification,
  };
};

exports.followingJobNotify = async (sender, job) => {
  // đã kiểm tra tính hợp lệ từ lúc tạo follow nếu chưa cần thêm vào đây
  let notification = await Notification.findOne({
    sender: sender._id,
    onSender: "User",
    onReceiver: "User",
    receiver: { $elemMatch: { user: job.owner } },
    type: NotifyConstant.FOLLOW_JOB,
    onAccess: "Job",
    access: job._id,
  });

  if (notification) {
    notification.receiver[0].status = "pending";
    await notification.save();
  } else {
    notification = new Notification({
      sender: sender._id,
      onSender: "User",
      onReceiver: "User",
      receiver: [{ user: job.owner, status: "pending" }],
      onAccess: "Job",
      access: job._id,
      message: `<strong>${sender.name}</strong> đã theo dõi công việc <strong>${job.title}</strong>`,
      type: NotifyConstant.FOLLOW_JOB,
    });
    await notification.save();
  }

  notification.sender = sender;

  //socket
  const sendToUsers = findUserFromUserSockets(job.owner.toString());
  if (sendToUsers.length > 0) {
    sendToUsers.forEach((item) => {
      io().to(item.socketId).emit(NotifyConstant.FOLLOW_JOB, {
        data: notification,
      });
    });
  }

  return {
    status: 200,
    message: "Theo dõi công việc thành công",
    notify: notification,
  };
};

exports.changeOwnerJobNotify = async (oldId, newId, jobId) => {
  const job = await Job.findById(jobId).populate("owner").populate("company");
  const oldUser = await User.findById(oldId);
  const newUser = await User.findById(newId);

  if (!job || !oldUser || !newUser) {
    return {
      status: 400,
      message: "Công việc hoặc người dùng không tồn tại",
    };
  }

  if (job.owner._id.toString() !== newId) {
    return {
      status: 400,
      message: "Công việc không phải của newId",
    };
  }

  let notification = await Notification.findOne({
    sender: job.company._id.toString(),
    onSender: "Company",
    onReceiver: "User",
    receiver: {
      $size: 2,
      $elemMatch: {
        user: {
          $in: [oldId, newId],
        },
      },
    },
    type: NotifyConstant.CHANGE_OWNER,
    onAccess: "Job",
    access: job._id,
  });

  if (notification) {
    notification.receiver[0].status = NotifyConstant.PENDING;
    notification.receiver[1].status = NotifyConstant.PENDING;
    notification.message = `<strong>${job.company.owner.name}</strong> đã chuyển công việc <strong>${job.title}</strong> từ <strong>${oldUser.name}</strong> sang <strong>${newUser.name}</strong>`;
    await notification.save();
  } else {
    notification = new Notification({
      sender: job.company._id.toString(),
      onSender: "Company",
      onReceiver: "User",
      receiver: [
        { user: oldId, status: NotifyConstant.PENDING },
        { user: newId, status: NotifyConstant.PENDING },
      ],
      onAccess: "Job",
      access: job._id,
      message: `<strong>${job.company.owner.name}</strong> đã chuyển công việc <strong>${job.title}</strong> từ <strong>${oldUser.name}</strong> sang <strong>${newUser.name}</strong>`,
      type: NotifyConstant.CHANGE_OWNER,
    });
    await notification.save();
  }

  notification = {
    ...notification._doc,
    sender: job.company,
  };

  //socket
  const sendToUsers = findUsersFromUserSockets([oldId, newId]);

  return {
    status: 200,
    message: "Chuyển công việc thành công",
    notify: notification,
    sendToUsers,
  };
};

exports.applyJobNotify = async (jobId, applicantId) => {
  const job = await Job.findById(jobId).populate("owner");
  const applicant = await User.findById(applicantId);
  if (!job || !applicant) {
    return {
      status: 400,
      message: "Công việc hoặc người dùng không tồn tại",
    };
  }

  const isApply = job.applicants.some((item) => {
    return item.user.toString() === applicantId.toString();
  });

  if (!isApply) {
    return {
      status: 400,
      message: "Người dùng chưa ứng tuyển vào công việc này",
    };
  }

  let notification = await Notification.findOne({
    sender: applicantId,
    onSender: "User",
    onReceiver: "User",
    receiver: { $elemMatch: { user: job.owner._id.toString() } },
    $or: [
      {
        type: NotifyConstant.APPLY_JOB,
      },
      {
        type: NotifyConstant.CONFIRM_APPLY_JOB,
      },
    ],
    onAccess: "Job",
    access: job._id,
  });

  if (notification) {
    if (notification.type === NotifyConstant.APPLY_JOB) {
      return {
        status: 400,
        message: "Người dùng đã ứng tuyển vào công việc này",
      };
    }
    notification.receiver[0].status = NotifyConstant.PENDING;
    notification.type = NotifyConstant.APPLY_JOB;
    notification.message = `<strong>${applicant.name}</strong> đã ứng tuyển công việc <strong>${job.title}</strong>`;
    notification.desc = "";
    await notification.save();
  } else {
    notification = new Notification({
      sender: applicantId,
      onSender: "User",
      onReceiver: "User",
      receiver: [
        { user: job.owner._id.toString(), status: NotifyConstant.PENDING },
      ],
      onAccess: "Job",
      access: job._id,
      message: `<strong>${applicant.name}</strong> đã ứng tuyển công việc <strong>${job.title}</strong>`,
      type: NotifyConstant.APPLY_JOB,
    });
    await notification.save();
  }

  notification = {
    ...notification._doc,
    sender: applicant,
  };

  //socket
  const sendToUsers = findUserFromUserSockets(job.owner._id.toString());

  return {
    status: 200,
    message: "Ứng tuyển công việc thành công",
    notify: notification,
    sendToUsers,
  };
};

exports.addEmployeeNotify = async (company, userIds) => {
  // gửi thông báo đến toàn bộ mảng nhân viên được thêm vào công ty
  // đã kiểm tra tính hợp lệ khi thêm vào DB nếu chưa cần thêm ở đây
  let notification = await Notification.findOne({
    onSender: "Company",
    onReceiver: "User",
    sender: company._id,
    receiver: { $elemMatch: { user: userIds[0] } },
    onAccess: "Company",
    $or: [
      { type: NotifyConstant.ADD_MEMBER },
      { type: NotifyConstant.CONFIRM_ADD_MEMBER },
    ],
    access: company._id,
  });

  if (notification) {
    if (notification.type === NotifyConstant.ADD_MEMBER) {
      return {
        status: 400,
        message: "Đã gửi xin chờ người dùng duyệt tin nhắn trước khi gửi thêm",
      };
    } else {
      notification.receiver[0].status = NotifyConstant.PENDING;
      notification.message = `<strong>${company.name}</strong> đã muốn thêm bạn vào công ty`;
      notification.type = NotifyConstant.ADD_MEMBER;
      await notification.save();
    }
  } else {
    notification = new Notification({
      sender: company._id,
      onSender: "Company",
      onReceiver: "User",
      onAccess: "Company",
      access: company._id,
      message: `<strong>${company.name}</strong> đã muốn thêm bạn vào công ty`,
      type: NotifyConstant.ADD_MEMBER,
    });
    notification.receiver = userIds.map((el) => ({
      user: el,
      status: NotifyConstant.PENDING,
    }));
    await notification.save();
  }

  notification.sender = company;

  //socket
  // const sendToUsers = findUsersFromUserSockets(userIds);
  // console.log(sendToUsers);
  // if (sendToUsers.length > 0) {
  //   console.log("vao");
  //   sendToUsers.forEach((item) => {
  //     // console.log(item);
  //     // console.log(io());
  //     io().to(item.socketId).emit(NotifyConstant.AddMember, {
  //       data: notification,
  //     });
  //   });
  // }

  return {
    status: 200,
    message: "Chờ người dùng duyệt tin",
    notify: notification,
  };
};

exports.confirmAddEmployeeNotify = async (notifyId, userId, status) => {
  const notification = await Notification.findOne({
    _id: notifyId,
    receiver: { $elemMatch: { user: userId } },
    type: NotifyConstant.ADD_MEMBER,
  })
    .populate("sender", "name avatar owner")
    .populate("receiver.user", "name avatar");
  if (!notification) {
    return {
      status: 400,
      message: "Không tìm thấy thông báo hoặc thông báo đã được duyệt",
    };
  }
  notification.receiver[0].status = status;
  notification.message = `<strong>${
    notification.receiver[0].user.name
  }</strong> đã ${
    status === NotifyConstant.ACCEPTED ? "đồng ý" : "từ chối"
  } yêu cầu vào công ty <strong>${notification.sender.name}</strong>`;
  notification.type = NotifyConstant.CONFIRM_ADD_MEMBER;

  if (status === NotifyConstant.ACCEPTED) {
    const user = await User.findOneAndUpdate(
      { _id: userId, active: true },
      {
        activeCompany: true,
        role: "HR",
        $set: {
          company: notification.sender._id,
        },
      },
      { new: true }
    );
    if (user.jobs && user.jobs.length > 0) {
      await Job.updateMany(
        { _id: { $in: user.jobs } },
        { $pull: { applicants: { user: userId } } }
      );
    }
    if (!user) {
      return {
        status: 400,
        message: "Không tìm thấy người dùng",
      };
    }
  }
  await notification.save();

  return {
    status: 200,
    notify: notification,
    message: ` ${
      status === NotifyConstant.ACCEPTED ? "Đã chấp nhận" : "Đã từ chối"
    } yêu cầu thêm bạn vào công ty`,
  };
};

exports.removeEmployeeNotify = async (companyId, employees) => {
  const user = await User.findById(employees[0]).select("name avatar");
  const company = await Company.findById(companyId).select("name avatar");

  if (!user || !company) {
    return {
      status: 400,
      message: "Không tìm thấy người dùng hoặc công ty",
    };
  }

  let obj = {
    onSender: "Company",
    sender: company._id.toString(),
    onReceiver: "User",
    receiver: { $elemMatch: { user: employees[0] } },
    onAccess: "Company",
    type: NotifyConstant.CONFIRM_DELETE_MEMBER,
    access: company._id,
  };
  let notification = await Notification.findOne(obj);

  if (!notification) {
    obj.receiver = [
      {
        user: employees[0],
        status: NotifyConstant.PENDING,
      },
    ];
    obj.message = `<strong>${company.name}</strong> xóa <strong>${user.name}</strong> khỏi công ty`;
    notification = new Notification(obj);
  } else {
    notification.receiver = [
      {
        user: employees[0],
        status: NotifyConstant.PENDING,
      },
    ];
  }
  await notification.save();

  notification = {
    ...notification._doc,
    sender: company,
    receiver: [
      {
        user: user,
        status: NotifyConstant.PENDING,
      },
    ],
  };

  const sendToUsers = findUsersFromUserSockets([
    company.owner._id.toString(),
    employees[0],
  ]);

  return {
    status: 200,
    message: "Đã xóa nhân viên khỏi công ty",
    sendToUsers,
    notify: notification,
  };
};

exports.createPostNotify = async (postId) => {
  // gửi thông báo đến toàn bộ người following owner
  // đã kiểm tra tính hợp lệ khi thêm vào DB nếu chưa cần thêm ở đây

  const post = await Post.findById(postId).populate({
    path: "ownerId",
    match: { active: true },
    select: "+followers",
  });

  if (!post) {
    return {
      status: 400,
      message: "Không tìm thấy bài viết",
    };
  }

  // console.log(post);
  const notification = new Notification({
    sender: post.ownerId._id,
    onSender: post.onOwner,
    onReceiver: "User",
    receiver: post.ownerId.followers.map((el) => ({
      user: el,
      status: NotifyConstant.PENDING,
    })),
    onAccess: "Post",
    access: postId,
    message: `<strong>${post.ownerId.name}</strong> đã đăng bài mới ${
      post.content ? `:${post.content}` : ""
    }`,
    type: NotifyConstant.CREATE_POST,
    // post.onOwner === "User"
    //   ? NotifyConstant.CreateUserPost
    //   : NotifyConstant.CreateCompanyPost,
  });
  await notification.save();

  notification.sender = post.ownerId;

  const sendToUsers = findUsersFromUserSockets(
    post.ownerId.followers.map((el) => el.toString())
  );
  // console.log(sendToUsers);
  // if (sendToUsers.length > 0) {
  //   console.log("vao");
  //   sendToUsers.forEach((item) => {
  //     // console.log(item);
  //     // console.log(io());
  //     io().to(item.socketId).emit(NotifyConstant.CREATE_POST, {
  //       data: notification,
  //     });
  //   });
  // }

  return {
    status: 200,
    message: "Tạo notify post thành công",
    notify: notification,
    sendToUsers,
  };
};

exports.createJobForAdminNotify = async (jobId) => {
  // gửi thông báo đến toàn bộ người following công ty có công việc mới được thêm
  // đã kiểm tra tính hợp lệ khi thêm vào DB nếu chưa cần thêm ở đây

  const job = await Job.findOne({ _id: jobId, active: false })
    .populate({
      path: "company owner",
      match: { active: true },
      select: "_id name avatar",
    })
    .lean();
  // console.log(job);
  if (!job) {
    return {
      status: 400,
      message: "Công việc không tồn tại hoặc đã được duyệt",
    };
  }

  if (!job.owner) {
    return {
      status: 400,
      message: "HR đang bị vô hiệu hóa",
    };
  }

  const admins = await User.find({
    role: "admin",
  });

  let obj = {
    sender: job.owner?._id,
    onSender: "User",
    onReceiver: "User",
    onAccess: "Job",
    access: jobId,
    $or: [
      {
        type: NotifyConstant.CREATE_JOB_FOR_ADMIN,
      },
      {
        type: NotifyConstant.CONFIRM_JOB,
      },
    ],
  };
  const { company } = job;

  let notification = await Notification.findOne(obj);
  if (notification) {
    notification.message = `<strong>${job.company.name}</strong> chờ xác nhận công việc <strong>${job.title}</strong>`;
    notification.receiver = admins.map((el) => ({
      user: el._id,
      status: NotifyConstant.PENDING,
    }));
    notification.type = NotifyConstant.CREATE_JOB_FOR_ADMIN;
  } else {
    notification = new Notification({
      sender: job.owner._id,
      onSender: "User",
      onReceiver: "User",
      receiver: admins.map((el) => ({
        user: el._id,
        status: NotifyConstant.PENDING,
      })),
      onAccess: "Job",
      access: jobId,
      message: `<strong>${job.company.name}</strong> đã đăng việc mới ${
        job.title ? `:<strong>${job.title}</strong>` : ""
      }`,
      type: NotifyConstant.CREATE_JOB_FOR_ADMIN,
    });
  }

  await notification.save();
  notification = {
    ...notification._doc,
    sender: job.owner,
  };
  const sendToUsers = findUsersFromUserSockets(
    admins.map((el) => el._id.toString())
  );

  return {
    status: 200,
    message: "Chờ quản trị viên duyệt",
    sendToUsers,
    notify: notification,
  };
};

exports.createJobForUserNotify = async (jobId) => {
  const job = await Job.findOne({ _id: jobId, active: true })
    .populate({
      path: "company",
      match: { active: true },
      select: "+followers",
    })
    .lean();
  if (!job) {
    return {
      status: 400,
      message: "Công việc không tồn tại",
    };
  }
  let notification = new Notification({
    sender: job.company._id,
    onSender: "Company",
    onReceiver: "User",
    receiver: job.company.followers.map((el) => ({
      user: el,
      status: NotifyConstant.PENDING,
    })),
    onAccess: "Job",
    access: jobId,
    message: `<strong>${job.company.name}</strong> đã đăng việc mới ${
      job.title ? `:<strong>${job.title}</strong>` : ""
    }`,
    type: NotifyConstant.CREATE_JOB_FOR_USER,
  });
  await notification.save();

  const { followers, ...infoSender } = job.company;

  notification = {
    ...notification._doc,
    sender: infoSender,
    receiver: {
      user: "a",
      status: NotifyConstant.PENDING,
    },
  };

  const sendToUsers = findUsersFromUserSockets(
    job.company.followers.map((el) => el.toString())
  );
  // console.log(sendToUsers);
  // if (sendToUsers.length > 0) {
  //   console.log("vao");
  //   sendToUsers.forEach((item) => {
  //     // console.log(item);
  //     // console.log(io());
  //     io().to(item.socketId).emit(NotifyConstant.CREATE_JOB_FOR_USER, {
  //       data: notification,
  //     });
  //   });
  // }

  return {
    status: 200,
    message: "Gửi thông báo công việc đến toàn bộ người dùng theo dõi công ty",
    notify: notification,
    sendToUsers,
  };
};

exports.confirmJobByAdminNotify = async (notifyId, userId, status) => {
  let notification = await Notification.findOne({
    _id: notifyId,
    $or: [
      {
        type: NotifyConstant.CREATE_JOB_FOR_ADMIN,
      },
      {
        type: NotifyConstant.CONFIRM_JOB,
      },
    ],
  })
    .populate("sender", "name avatar")
    .populate("access", "title")
    .populate("receiver.user", "name avatar");

  if (!notification) {
    //neu chua tao tin xac nhan
    return {
      status: 404,
      message: "Không tìm thấy thông báo",
    };
  } else {
    if (notification.type === NotifyConstant.CONFIRM_JOB) {
      return {
        status: 400,
        message: "Thông báo đã được xác nhận",
      };
    } else {
      //neu da tao tin xac nhan roi
      notification.receiver = notification.receiver.map((el) => ({
        ...el,
        status,
      }));
      notification.type = NotifyConstant.CONFIRM_JOB;
      notification.message = `<strong>Quản trị viên</strong> đã ${
        status === NotifyConstant.ACCEPTED ? "chấp nhận" : "từ chối"
      } công việc: <strong>${notification.access.title}</strong>`;
    }
    await notification.save();
  }

  const sendToUsers = findUserFromUserSockets(
    notification.sender._id.toString()
  );

  return {
    status: 200,
    notify: notification,
    sendToUsers,
    message: "Đã phê duyệt công việc",
  };
};

exports.createCompanyNotify = async (companyId) => {
  const company = await Company.findById(companyId).lean();
  const admins = await User.find({ role: "admin", active: true });

  let notification = await Notification.findOne({
    sender: company.owner._id,
    onSender: "User",
    onReceiver: "User",
    $or: [
      {
        type: NotifyConstant.CREATE_COMPANY,
      },
      {
        type: NotifyConstant.CONFIRM_COMPANY,
      },
    ],
  });
  if (notification) {
    if (notification.type === NotifyConstant.CREATE_COMPANY) {
      return {
        status: 400,
        message: "Chờ quản trị viên phê duyệt",
      };
    } else {
      notification.message = `<strong>${company.owner.name}</strong> muốn tạo công ty: <strong>${company.name}</strong>`;
      notification.type = NotifyConstant.CREATE_COMPANY;
      notification.receiver = admins.map((admin) => {
        return {
          user: admin._id,
          status: NotifyConstant.PENDING,
        };
      });
    }
  } else {
    notification = new Notification({
      sender: company.owner._id,
      onSender: "User",
      onReceiver: "User",
      receiver: admins.map((admin) => {
        return {
          user: admin._id,
          status: NotifyConstant.PENDING,
        };
      }),
      message: `<strong>${company.owner.name}</strong> muốn tạo công ty: <strong>${company.name}</strong>`,
      type: NotifyConstant.CREATE_COMPANY,
      onAccess: "Company",
      access: company._id,
    });
  }

  await notification.save();

  notification = {
    ...notification._doc,
    sender: company.owner,
  };

  const sendToUsers = findUsersFromUserSockets(
    admins.map((el) => el._id.toString())
  );

  return {
    status: 200,
    message: "Đã gửi yêu cầu tạo công ty",
    notify: notification,
    sendToUsers,
  };
};

exports.confirmCompanyNotify = async (notifyId, companyId, adminId, status) => {
  const company = await Company.findById(companyId);
  if (!company) {
    return {
      status: 404,
      message: "Không tìm thấy công ty",
    };
  }
  let notification = await Notification.findOne({
    _id: notifyId,
    type: NotifyConstant.CREATE_COMPANY,
  })
    .populate("access")
    .populate("sender", "name avatar")
    .populate("receiver.user", "name avatar");

  // console.log(notification);

  if (!notification) {
    return {
      status: 400,
      message: "Không tìm thấy thông báo hoặc thông báo đã được xác nhận",
    };
  } else {
    notification.receiver = notification.receiver.map((el) => ({
      ...el,
      status,
    }));
    notification.type = NotifyConstant.CONFIRM_COMPANY;
    (notification.message = `<strong>Quản trị viên</strong> đã ${
      notification.access.active ? "chấp nhận" : "từ chối"
    } công ty: <strong>${notification.access.name}</strong>`),
      await notification.save();
  }

  const sendToUsers = findUserFromUserSockets(
    notification.access.owner._id.toString()
  );

  return {
    status: 200,
    message: "Đã phê duyệt công ty",
    notify: notification,
    sendToUsers,
  };
};

exports.connectJobNotify = async (jobId, userId, reqUserId) => {
  const job = await Job.findOne({ _id: jobId, active: true }).populate({
    path: "company owner",
    match: { active: true },
    select: "name avatar",
  });
  if (!job)
    return {
      status: 400,
      message: "Công việc không tồn tại",
    };

  let notification = null;
  let sender = null;
  let receiver = null;
  //nếu userId tồn tại thì là HR chủ động liên hệ với ứng viên
  // nếu userId mà trống thì là ứng viên liên hệ với công việc có jobId
  if (userId) {
    receiver = await User.findById(userId);
    sender = job.owner;
  } else {
    sender = await User.findById(reqUserId);
    receiver = job.owner;
  }

  let query = {
    sender: sender._id.toString(),
    receiver: {
      $elemMatch: {
        user: receiver._id.toString(),
      },
    },
    $or: [
      {
        type: NotifyConstant.CONNECT_JOB,
      },
      {
        type: NotifyConstant.CONFIRM_CONNECT_JOB,
      },
    ],
    onAccess: "Job",
    access: jobId,
  };

  notification = await Notification.findOne(query)
    .populate("sender", "name avatar")
    .populate("receiver.user", "name avatar");
  if (notification) {
    if (notification.type === NotifyConstant.CONNECT_JOB) {
      return {
        status: 400,
        message: "Chờ duyệt",
      };
    } else {
      notification.message = `<strong>${sender.name}</strong> muốn liên hệ với bạn trao đổi công việc <strong>${job.title}</strong>`;
      notification.type = NotifyConstant.CONNECT_JOB;
      notification.receiver[0].status = NotifyConstant.PENDING;
      await notification.save();
      return {
        status: 200,
        message: "Đã gửi yêu cầu kết nối",
        notify: notification,
      };
    }
  } else {
    notification = new Notification({
      sender: query.sender,
      onSender: "User",
      onReceiver: "User",
      receiver: [
        {
          user: userId ? userId : job.owner._id.toString(),
          status: NotifyConstant.PENDING,
        },
      ],
      message: `<strong>${sender.name}</strong> đang cố kết nối với bạn để trao đổi công việc: <strong>${job.title}</strong>`,
      type: NotifyConstant.CONNECT_JOB,
      onAccess: "Job",
      access: jobId,
    });

    await notification.save();
    notification = {
      ...notification._doc,
      sender,
      receiver: [{ user: receiver }],
    };
    return {
      status: 200,
      message: "Đã gửi yêu cầu kết nối",
      notify: notification,
    };
  }
};

exports.connectUserNotify = async (senderId, receiverId) => {
  if (senderId === receiverId) {
    return {
      status: 400,
      message: "Không thể kết nối với chính mình",
    };
  }
  const sender = await User.findOne({ _id: senderId, active: true });
  const receiver = await User.findOne({ _id: receiverId, active: true });
  if (!sender && !receiver)
    return {
      status: 400,
      message: "Không thể kết nối",
    };

  let notification = await Notification.findOne({
    sender: senderId,
    receiver: {
      $elemMatch: {
        user: receiverId,
      },
    },
    $or: [
      {
        type: NotifyConstant.CONNECT_USER,
      },
      {
        type: NotifyConstant.CONFIRM_CONNECT_USER,
      },
    ],
  });
  if (!notification) {
    notification = new Notification({
      sender: senderId,
      onSender: "User",
      onReceiver: "User",
      receiver: [{ user: receiverId, status: "pending" }],
      onAccess: "User",
      access: senderId,
      message: `<strong>${sender.name}</strong> đang muốn trao đổi với bạn`,
      type: NotifyConstant.CONNECT_USER,
    });
    await notification.save();
  } else {
    if (notification.type === NotifyConstant.CONNECT_USER) {
      return {
        status: 400,
        message: "Chờ người dùng duyệt",
      };
    } else if (notification.type === NotifyConstant.CONFIRM_CONNECT_USER) {
      notification.receiver[0].status = NotifyConstant.PENDING;
      notification.type = NotifyConstant.CONNECT_USER;
      notification.message = `<strong>${sender.name}</strong> đang muốn trao đổi với bạn`;
      await notification.save();
    } else {
      return {
        status: 400,
        message: "something wrong",
      };
    }
  }

  notification = {
    ...notification._doc,
    sender,
    receiver: [{ user: receiver }],
  };

  return {
    status: 200,
    message: "Đã gửi yêu cầu kết nối",
    notify: notification,
  };
};

exports.confirmConnectJobNotify = async (notificationId, userReqId, status) => {
  const notification = await Notification.findOne({
    _id: notificationId,
    type: NotifyConstant.CONNECT_JOB,
    receiver: {
      $elemMatch: {
        user: userReqId,
      },
    },
  })
    .populate("access", "title")
    .populate("sender", "role name avatar")
    .populate("receiver.user", "role name avatar");

  if (!notification) {
    return {
      status: 400,
      message: "Không tìm thấy thông báo",
    };
  }

  const isHR = notification.sender.role === "HR";

  notification.receiver[0].status = status;
  notification.type = NotifyConstant.CONFIRM_CONNECT_JOB;
  notification.message = `<strong>${
    notification.receiver[0].user.name
  }</strong> đã ${
    status === NotifyConstant.ACCEPTED ? "chấp nhận" : "từ chối"
  } yêu cầu kết nối công việc <strong>${
    notification.access.title
  }</strong> của <strong>${notification.sender.name}</strong>`;

  let rs;
  if (status === NotifyConstant.ACCEPTED) {
    rs = await RoomService.upsertCompanyRoom(
      notification.receiver[0].user._id.toString(),
      notification.sender._id.toString(),
      notification.access._id.toString()
    );
    if (rs.status !== 200) return rs;
    notification.onAccess = "Room";
    notification.access = rs.room._id;
  }

  await notification.save();

  return {
    status: 200,
    message: "Đã xác nhận",
    notify: notification,
    room: rs ? rs.room : null,
  };
};

exports.confirmConnectUser = async (notificationId, status, userId) => {
  const notification = await Notification.findOne({
    _id: notificationId,
    type: NotifyConstant.CONNECT_USER,
    receiver: {
      $elemMatch: {
        user: userId,
      },
    },
  })
    .populate("sender", "name avatar")
    .populate("receiver.user", "name avatar");
  if (!notification) {
    return {
      status: 400,
      message: "Không tìm thấy thông báo",
    };
  }

  notification.receiver[0].status = status;
  notification.type = NotifyConstant.CONFIRM_CONNECT_USER;
  notification.message = `<strong>${
    notification.receiver[0].user.name
  }</strong> đã ${
    status === NotifyConstant.ACCEPTED ? "chấp nhận" : "từ chối"
  } yêu cầu kết nối <strong>${notification.sender.name}</strong>`;

  if (status === NotifyConstant.ACCEPTED) {
    const rs = await RoomService.upsertPersonalRoom(
      notification.sender._id,
      notification.receiver[0].user._id
    );
    if (rs.status !== 200) {
      return rs;
    }
    notification.onAccess = "Room";
    notification.access = rs.room._id;
  }
  await notification.save();
  return {
    status: 200,
    message:
      status === NotifyConstant.ACCEPTED ? "Đã xác nhận" : "Đã từ chối kết nối",
    notify: notification,
  };
};

exports.confirmApplyJob = async (ownerId, userId, jobId, desc) => {
  const notification = await Notification.findOne({
    sender: userId,
    type: NotifyConstant.APPLY_JOB,
    receiver: {
      $elemMatch: {
        user: ownerId,
      },
    },
    access: jobId,
    onAccess: "Job",
  })
    .populate("sender", "name avatar")
    .populate("access", "_id title")
    .populate("receiver.user", "name avatar");
  if (!notification) {
    return {
      status: 400,
      message: "Không tìm thấy thông báo",
    };
  }

  notification.receiver[0].status = NotifyConstant.REJECTED;
  notification.type = NotifyConstant.CONFIRM_APPLY_JOB;
  notification.message = `<strong>${notification.receiver[0].user.name}</strong> đã từ chối yêu cầu ứng tuyển công việc <strong>${notification.access.title}</strong> của bạn`;
  notification.desc = desc;

  await notification.save();
  return {
    status: 200,
    message: "Đã gửi lời từ chối",
    notify: notification,
  };
};
exports.getListNotifications = async (userId, type, page, limit) => {
  const user = await User.findById(userId).select("company");
  let obj = {
    $or: [
      {
        "receiver.user": userId,
      },
      {
        sender: userId,
        type: { $regex: new RegExp(".*" + NotifyConstant.CONFIRM + ".*") },
      },
    ],
  };
  if (
    user.company &&
    user.company?.owner?._id?.toString() === userId.toString()
  ) {
    let obj = {
      $or: [
        {
          "receiver.user": userId,
        },
        {
          sender: { $in: [userId, user.company.toString()] },
          type: { $regex: new RegExp(".*" + NotifyConstant.CONFIRM + ".*") },
        },
      ],
    };
  }
  if (type !== "All") {
    obj.type = type;
  }
  const notifications = await Notification.find(obj)
    .sort({ updatedAt: -1 })
    .skip((page - 1) * limit)
    .limit(limit)
    .populate("sender", "name avatar")
    .populate("receiver.user", "name avatar")
    .lean()
    .transform((docs) => {
      return docs.map((item) => {
        return {
          ...item,
          receiver: item.type.includes(NotifyConstant.CONFIRM)
            ? item.receiver
            : item.receiver.filter((el) => el.user._id.toString() === userId),
        };
      });
    });
  await Notification.updateMany(
    {
      _id: { $in: notifications.map((noti) => noti._id) },
      "receiver.status": NotifyConstant.PENDING,
      type: {
        $nin: [NotifyConstant.CREATE_POST, NotifyConstant.CREATE_JOB_FOR_USER],
      },
    },
    { "receiver.$.status": NotifyConstant.VIEWED }
  );
  return {
    status: 200,
    data: {
      data: notifications,
      page,
    },
  };
};

exports.getNotifyWhenOffline = async (userId) => {
  const user = await User.findById(userId).select("company lastActivity");
  if (!user) {
    return {
      status: 400,
      message: "Không tìm thấy người dùng",
    };
  }
  let obj = {
    $or: [
      {
        "receiver.user": userId,
      },
      {
        sender: userId,
        type: { $regex: new RegExp(".*" + NotifyConstant.CONFIRM + ".*") },
      },
    ],
    updatedAt: {
      $gt: user.lastActivity,
    },
  };
  if (
    user.company &&
    user.company?.owner?._id?.toString() === userId.toString()
  ) {
    obj = {
      $or: [
        {
          "receiver.user": userId,
        },
        {
          sender: { $in: [userId, user.company.toString()] },
          type: { $regex: new RegExp(".*" + NotifyConstant.CONFIRM + ".*") },
        },
      ],
      updatedAt: {
        $gt: user.lastActivity,
      },
    };
  }

  const notifications = await Notification.find(obj).countDocuments();

  return {
    status: 200,
    countNotify: notifications,
  };
};

exports.createReport = async (access, onAccess, message, desc, userId) => {
  const user = await User.findById(userId).select("name avatar");
  const admins = await User.find({
    role: "admin",
    active: true,
  });

  let obj = {
    sender: userId,
    onSender: "User",
    onReceiver: "User",
    onAccess,
    access,
    type:
      onAccess === "Post"
        ? NotifyConstant.CREATE_REPORT_POST
        : NotifyConstant.CREATE_REPORT_JOB,
  };

  let notification = await Notification.findOne(obj);
  if (notification) {
    return {
      status: 400,
      message: "Báo cáo đang được xem xét",
    };
  } else {
    notification = new Notification({
      receiver: admins.map((el) => ({
        user: el._id,
        status: NotifyConstant.PENDING,
      })),
      ...obj,
      message,
      desc,
    });
  }

  await notification.save();
  notification = {
    ...notification._doc,
    sender: user,
  };
  const sendToUsers = findUsersFromUserSockets(
    admins.map((el) => el._id.toString())
  );

  return {
    status: 200,
    message: "Chờ quản trị viên duyệt",
    sendToUsers,
    notify: notification,
  };
};

exports.confirmReport = async (notifyId, status) => {
  let notification = await Notification.findOne({
    _id: notifyId,
  })
    .populate("sender", "name avatar")
    .populate("access", "title content")
    .populate("receiver.user", "name avatar");

  if (!notification) {
    //neu chua tao tin xac nhan
    return {
      status: 404,
      message: "Không tìm thấy thông báo",
    };
  } else {
    if (
      notification.type === NotifyConstant.CONFIRM_REPORT_POST ||
      notification.type === NotifyConstant.CONFIRM_REPORT_JOB
    ) {
      return {
        status: 400,
        message: "Thông báo đã được xác nhận",
      };
    } else {
      //neu da tao tin xac nhan roi
      notification.receiver = notification.receiver.map((el) => ({
        ...el,
        status,
      }));
      notification.type =
        notification.type === NotifyConstant.CREATE_REPORT_POST
          ? NotifyConstant.CONFIRM_REPORT_POST
          : NotifyConstant.CONFIRM_REPORT_JOB;
      notification.message = `<strong>Quản trị viên</strong> đã ${
        status === NotifyConstant.ACCEPTED ? "chấp nhận" : "từ chối"
      } báo cáo: <strong>${
        notification.access.title || notification.access.content
      }</strong>`;
    }
    await notification.save();
  }

  const sendToUsers = findUsersFromUserSockets([
    notification.sender._id.toString(),
    ...notification.receiver.map((el) => el.user._id.toString()),
  ]);

  return {
    status: 200,
    notify: notification,
    sendToUsers,
    message: "Đã phê duyệt công việc",
  };
};
