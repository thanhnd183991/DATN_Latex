const Education = require("../models/EducationModel");
const { filterRegex } = require("../utils/filter");

exports.upsertArrayEducation = (schools, userId) =>
  new Promise((resolve, reject) => {
    // console.log(schools);
    let rs = [];
    Promise.all(
      schools.map(async (school) => {
        const rs = await this.upsertEducation(school);
        rs.students.push(userId);
        await rs.save();
        return {
          _id: rs._id,
          school: rs.school,
        };
      })
    )
      .then((rs) => {
        // console.log(rs);
        resolve(rs);
      })
      .catch((error) => reject(error));
  });

exports.upsertEducation = (school) =>
  new Promise((resolve, reject) => {
    // cập nhật công việc là false
    // bảng người dùng khi lọc thì chỉ lọc công viec là true
    const query = { school },
      update = { school, expire: new Date() },
      options = { upsert: true, new: true, setDefaultsOnInsert: true };

    // Find the document
    Education.findOneAndUpdate(query, update, options)
      .then((result) => {
        // console.log(result);
        resolve(result);
      })
      .catch((err) => {
        reject(err);
      });
  });

exports.searchEducation = async ({ operatorValue, value, page, limit }) => {
  const PAGE = Number(page) || 1;
  const LIMIT = Number(limit) || 6;
  const startIndex = (Number(PAGE) - 1) * LIMIT; // get the starting index of every page
  const obj = filterRegex(value, operatorValue, true);
  const data = await Education.find(obj)
    .select("_id school")
    .sort({ school: 1 })
    .skip(startIndex)
    .limit(LIMIT)
    .transform((rs) => {
      // console.log(rs);
      return rs.map((el) => ({
        _id: el._id,
        name: el.school,
      }));
    });
  return {
    status: 200,
    data: {
      data,
      currentPage: PAGE,
    },
  };
};
