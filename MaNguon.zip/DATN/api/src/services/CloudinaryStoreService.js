const cloudinary = require("cloudinary").v2;
const streamifier = require("streamifier");
const { v4 } = require("uuid");
const { convertToSlug } = require("../utils/convertToSlug");

const publicId = (filename, folderFile) => {
  return `${convertToSlug(
    filename.split(".").slice(0, -1).join(".")
  )}-${new Date().getTime()}${
    folderFile === "file" ? filename.match(/\.[0-9a-z]+$/i)[0] : ""
  }`;
};

const folder = (mimeType) => {
  if (mimeType.includes("video")) return "video";
  else if (mimeType.includes("image")) return "image";
  else return "file";
};

const streamUpload = (file) => {
  cloudinary.config({
    cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
    api_key: process.env.CLOUDINARY_API_KEY,
    api_secret: process.env.CLOUDINARY_API_SECRET,
  });
  const folderFile = folder(file.mimetype);
  return new Promise((resolve, reject) => {
    let stream = cloudinary.uploader.upload_stream(
      {
        public_id: publicId(file.originalname, folderFile),
        folder: folderFile,
        resource_type: "auto",
        chunkSize: 2 * 1024 * 1024,
      },
      (error, result) => {
        if (result) {
          resolve(result);
        } else {
          reject(error);
        }
      }
    );

    streamifier.createReadStream(file.buffer).pipe(stream);
  });
};

exports.cloudUploadFile = async (file) => {
  let result = await streamUpload(file);
  // console.log(result);
  return {
    result,
  };
};

exports.cloudUploadFiles = (files) => {
  return Promise.all(files.map((file) => streamUpload(file)))
    .then((rs) => {
      // console.log(rs);
      return rs;
    })
    .catch((err) => err.message);
};

exports.cloudDestroyFile = async (public_id) => {
  cloudinary.config({
    cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
    api_key: process.env.CLOUDINARY_API_KEY,
    api_secret: process.env.CLOUDINARY_API_SECRET,
  });
  const rs = await cloudinary.uploader.destroy(public_id, {
    resource_type: public_id.split("/")[0],
  });
  return rs;
};

exports.cloudDestroyFiles = (public_ids) => {
  return Promise.all(
    public_ids.map((public_id) => this.cloudDestroyFile(public_id))
  )
    .then((rs) => {
      // console.log("delete files success", rs);
      return rs;
    })
    .catch((err) => {
      // console.log("delete files error", err);
      return err;
    });
};

exports.signPresignedURL = async () => {
  const timestamp = new Date().getTime();
  const signature = await cloudinary.utils.api_sign_request(
    {
      timestamp,
    },
    process.env.CLOUDINARY_API_SECRET
  );
  return {
    timestamp,
    signature,
    cloudname: process.env.CLOUDINARY_CLOUD_NAME,
    apikey: process.env.CLOUDINARY_API_KEY,
  };
};
