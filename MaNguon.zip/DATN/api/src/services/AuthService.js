const User = require("../models/UserModel");
const Token = require("../models/TokenModel");
const Category = require("../models/CategoryModel");
const Job = require("../models/JobModel");
const Post = require("../models/PostModel");
const Company = require("../models/CompanyModel");
const AppError = require("../utils/appError");
const catchAsync = require("../utils/catchAsync");
const signToken = require("../utils/jwtProvider");
const { v4: uuidv4 } = require("uuid");
const argon2 = require("argon2");
const { sendMail, content } = require("../utils/sendMail");
const { sendMailInBlue } = require("../utils/sendMailInBlue");

const createSendToken = (user, statusCode, res) => {
  const token = signToken(user._id, user.role);
  const cookieOptions = {
    expires: new Date(Date.now() + 60 * 1000),
    httpOnly: true,
  };

  if (process.env.NODE_ENV === "production") cookieOptions.secure = true;

  res.cookie("jwt", token, cookieOptions);

  user.password = undefined;

  res.status(statusCode).json({
    status: "success",
    token,
    user,
  });
};

exports.signup = async ({ email, name, password }, res) => {
  //   console.log(req.body);
  const user = await User.create({
    name: name,
    email: email,
    password: await argon2.hash(password),
    role:
      name === "Admin"
        ? "admin"
        : name === "HR"
        ? "HR"
        : name === "Manager"
        ? "manager"
        : "employee",
  });

  createSendToken(user, 201, res);
};

exports.login = async ({ email, password }, res) => {
  //1 chekc if email and password exist
  if (!email || !password) {
    return res
      .status(404)
      .json({ message: "please provide email and password" });
    // return next(new AppError(`please provide email and password`, 404));
  }
  //2 check if user exists && password is legit
  const user = await User.findOne({ email }).select("+password +company");
  if (!user || !(await user.correctPassword(password, user.password))) {
    return res.status(404).json({ message: "incorrect email or password" });

    // return next(new AppError("inccorect email or password", 401));
  }
  if (!user.active) {
    return res.status(404).json({ message: "user not active" });
  }
  //3 send token if ok
  createSendToken(user, 200, res);
};

exports.updatePassword = async (reqUserId, newPassword, oldPassword, res) => {
  // 1) Get user from collection
  const user = await User.findById(reqUserId).select("+password");

  // 2) Check if POSTed current password is correct
  if (!(await user.correctPassword(oldPassword, user.password))) {
    return res.status(404).json({ message: "incorrect old password" });
  }
  // 3) If so, update password
  user.password = await argon2.hash(newPassword);
  await user.save();

  // 4) Log user in, send JWT
  createSendToken(user, 200, res);
};

exports.forgotPassword = async (email) => {
  const user = await User.findOne({ email }).select("+password");
  if (!user) {
    return {
      status: 404,
      message: "No user found with this email",
    };
  }

  // Generate the token
  const resetToken = uuidv4();
  return Token.create({
    userId: user._id,
    token: resetToken,
  })
    .then(() => sendMail(user.email, content(resetToken)))
    .then((result) =>
      result === "Ok"
        ? {
            status: 200,
            message: "Kiểm tra email của bạn",
          }
        : {
            status: 500,
            message: "Something went wrong",
          }
    )
    .catch((err) => {
      return {
        status: 500,
        message: "Something went wrong",
      };
    });
};

exports.changePassword = async (token, password) => {
  const tokenM = await Token.findOne({ token });
  // console.log(tokenM);
  if (!tokenM) {
    return {
      status: 404,
      message: "Token không tồn tại",
    };
  }
  return User.updateOne(
    {
      _id: tokenM.userId,
    },
    {
      $set: {
        password: await argon2.hash(password),
      },
    }
  )
    .then(() => tokenM.delete())
    .then(() => ({ status: 200, message: "ok" }));
};

exports.resetDB = async () => {
  await Promise.all([
    // User.deleteMany(),
    Post.deleteMany(),
    Token.deleteMany(),
    Company.deleteMany(),
    Job.deleteMany(),
    Category.deleteMany(),
  ]);
  return {
    status: 200,
    message: "ok",
  };
};
