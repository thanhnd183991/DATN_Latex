const Category = require("../models/CategoryModel");
const Company = require("../models/CompanyModel");
const Job = require("../models/JobModel");
const User = require("../models/UserModel");
const { convertToSlug } = require("../utils/convertToSlug");
const Mongoose = require("mongoose");
const {
  upsertArrayCategory,
  createJobCategories,
} = require("./CategoryService");
const RoomService = require("./RoomService");

// add one job to category
exports.createJob = async (body, userId) => {
  // console.log("parent ", parentCategory);
  const job = body;
  const owner = await User.findById(userId)
    .select("+activeCompany +company")
    .populate("company");

  if (!owner.activeCompany) {
    return {
      status: 404,
      message: "Bạn chưa chính thức vào công ty",
    };
  }
  const company = owner.company;
  if (!company) {
    return {
      status: 404,
      message: "Không tìm thấy công ty",
    };
  }
  const parentCategory = company.industry;
  job.owner = owner._id;
  job.company = company._id;
  const { categories, ...info } = job;

  const { _id: jobId } = await Job.create(info);

  const cats = await createJobCategories(jobId, categories, company.industry);

  if (cats.status !== 200) {
    return cats;
  }

  // add categories to job
  const newJob = await Job.findByIdAndUpdate(
    jobId,
    {
      $set: {
        categories: cats.ids,
      },
    },
    {
      new: true,
      runValidators: true,
    }
  );
  return {
    status: 200,
    newJob,
  };
};

exports.updateActiveJobs = (companyId, active) =>
  new Promise((resolve, reject) => {
    // cập nhật công việc là false
    // bảng người dùng khi lọc thì chỉ lọc công viec là true
    Job.updateMany(
      { company: companyId },
      {
        $set: {
          active,
        },
      }
    )
      .then((res) => resolve(res))
      .catch((err) => reject(err));
  });

exports.updateApplicantJob = async (jobId, { userId, phone, email, CV }) => {
  const job = await Job.findOne({ _id: jobId, active: true }).select(
    "+applicant +followers"
  );
  if (!job) {
    return {
      status: 404,
      message: "Không tìm thấy công việc :(",
    };
  }
  if (Date.now() > job.deadline.getTime()) {
    return {
      status: 400,
      message: "Hết hạn ứng tuyển",
    };
  }
  if (job.closed) {
    return {
      status: 400,
      message: "Tin tuyển dụng đã được đóng lại",
    };
  }
  const applicant = await User.findOne({
    _id: userId,
    active: true,
  }).select("+saveJobs +jobs");
  if (!applicant) {
    return {
      status: 404,
      message: "Không tìm thấy ứng viên",
    };
  }

  if (job.applicants.some((el) => el.user?.toString() === userId)) {
    return {
      status: 400,
      message: "Bạn đã ứng tuyển rồi",
    };
  }
  job.applicants.push({ user: applicant._id, phone, email, CV });
  applicant.jobs.push(job._id);
  if (applicant.saveJobs.some((el) => el.toString() === job._id.toString())) {
    applicant.saveJobs.pull(job._id);
    job.followers.pull(applicant._id);
  }
  const rs = await Promise.all([await applicant.save(), await job.save()]);
  if (rs[0].acknowledged === false || rs[1].acknowledged === false) {
    return {
      status: 500,
      message: "Có lỗi xảy ra",
    };
  }
  // console.log("vao update applicant job");
  return {
    status: 200,
    message: "Đăng ký thành công",
  };
};

exports.deleteApplicantJob = async (jobId, ownerIdJob, applicantId) => {
  const job = await Job.findOne({ _id: jobId, active: true }).select(
    "+applicants +followers"
  );
  if (!job) {
    return {
      status: 404,
      message: "Không tìm thấy công việc",
    };
  }
  if (job.owner.toString() !== ownerIdJob) {
    return {
      status: 403,
      message: "Bạn không có quyền xóa ứng viên",
    };
  }
  const applicant = await User.findOne({
    _id: applicantId,
    active: true,
  }).select("+saveJobs +jobs");
  if (!applicant) {
    return {
      status: 404,
      message: "Không tìm thấy ứng viên",
    };
  }
  const index = job.applicants.findIndex(
    (el) => el.user?.toString() === applicantId
  );
  if (index === -1) {
    return {
      status: 404,
      message: "Không tìm thấy ứng viên",
    };
  }
  job.applicants.splice(index, 1);
  applicant.jobs.pull(job._id);
  if (applicant.saveJobs.some((el) => el.toString() === job._id.toString())) {
    applicant.saveJobs.pull(job._id);
    job.followers.pull(applicant._id);
  }
  const rs = await Promise.all([await applicant.save(), await job.save()]);
  if (rs[0].acknowledged === false || rs[1].acknowledged === false) {
    return {
      status: 500,
      message: "Có lỗi xảy ra",
    };
  }
  return {
    status: 200,
    message: `Xóa đơn ứng tuyển của ${applicant.name} thành công`,
  };
};

exports.updateJob = async (jobId, info, user) => {
  const job = await Job.findById(jobId).populate("company");
  if (!job) {
    return {
      status: 404,
      message: "Không tìm thấy công việc",
    };
  }
  if (job.active) {
    return {
      status: 403,
      message: "Công việc đã được active không thể cập nhật",
    };
  }

  if (!(job.owner.toString() === user.id || user.role === "admin")) {
    return {
      status: 403,
      message: "Bạn không có quyền cập nhật công việc",
    };
  }

  if (!info.note) {
    await Category.updateMany(
      {
        _id: { $in: job.categories },
      },
      {
        $pull: {
          jobs: jobId,
        },
      }
    );

    const rs = await upsertArrayCategory(info.categories, null, job);
    info.categories = rs.map((el) => el._id);
  }
  // console.log(info);

  const updateJob = await Job.findByIdAndUpdate(jobId, info, {
    new: true,
    runValidators: true,
  });
  return {
    status: 200,
    data: updateJob,
  };
};

exports.confirmJob = async (jobId, adminId, status) => {
  const job = await Job.findById(jobId);
  if (!job) {
    return {
      status: 404,
      message: "Không tìm thấy công việc",
    };
  }
  const company = await Company.findById(job.company);
  if (!company) {
    return {
      status: 404,
      message: "Không tìm thấy công ty",
    };
  }

  let updateJob = null;
  let obj = {
    active: status,
  };
  if (status === true) {
    obj.note = "";
  }

  updateJob = await Job.findByIdAndUpdate(jobId, obj, {
    new: true,
    runValidators: true,
  });
  return {
    status: 200,
    data: updateJob,
  };
};

exports.listJobByCategory = async (keywords, page, limit, active) => {
  const startIndex = (Number(page || 1) - 1) * limit; // get the starting index of every page
  const jobs = await Category.find({
    $or: [
      {
        slug: { $regex: ".*" + keywords + ".*", $options: "i" },
      },
    ],
  }).populate({
    path: "jobs",
    match: { active, closed: false },
    populate: {
      path: "categories",
      select: "name",
    },
    options: { sort: { createdAt: -1 }, limit: limit, skip: startIndex },
  });
  return {
    status: 200,
    data: {
      jobs: jobs || [],
      page,
    },
  };
};

exports.listJobRelateCurrentJob = async ({ jobId, userId, page, limit }) => {
  const startIndex = (Number(page || 1) - 1) * limit; // get the starting index of every page
  const currentJob = await Job.findOne({ _id: jobId, active: true });
  if (!currentJob) {
    return {
      status: 200,
      data: [],
    };
  }
  const user = await User.findById(userId).select("saveJobs jobs");
  const jobs = await Job.find({
    categories: { $in: currentJob.categories },
    _id: { $nin: [currentJob._id, ...user.jobs, ...user.saveJobs] },
    active: true,
    closed: false,
  })
    .populate({
      path: "company",
      select: "name avatar industry",
      populate: {
        path: "industry",
        select: "name",
      },
    })
    .populate({
      path: "categories",
      select: "name ",
    })
    .sort({ createdAt: -1 })
    .limit(limit + 1)
    .skip(startIndex);
  return {
    status: 200,
    data: {
      data: jobs.slice(0, jobs.length > limit ? limit : jobs.length),
      hasMore: jobs.length > limit,
      page,
    },
  };
};

exports.infoJob = async (jobId, userId) => {
  let obj = {
    _id: jobId,
  };
  const user = await User.findById(userId).select("saveJobs jobs role").lean();

  const job = await Job.findById(jobId)
    .select("+applicants +followers")
    .populate({
      path: "company owner applicants.user",
      select: "name avatar owner",
    })
    .populate({
      path: "followers",
      select: "name avatar followers",
    })
    .populate({
      path: "categories",
      select: "name",
    })
    .lean();
  if (!job) {
    return {
      status: 404,
      message: "Không tìm thấy công việc",
    };
  }

  if (!job.active) {
    // console.log(userId, job.owner);
    if (
      user.role !== "admin" &&
      userId.toString() !== job.owner._id.toString()
    ) {
      return {
        status: 404,
        message: "Không tìm thấy công việc",
      };
    }
  }

  job.isApply = user.jobs.some((el) => el.toString() === job._id.toString());
  job.isSave = user.saveJobs.some((el) => el.toString() === job._id.toString());
  job.numApplicants = job.applicants.length;
  job.numFollowers = job.followers.length;
  job.followers = job.followers.map((el) => {
    const { followers, ...info } = el;
    return { ...info, numFollowers: followers.length };
  });
  if (
    !(
      user._id.toString() === job.owner._id.toString() ||
      user._id.toString() === job.company.owner._id.toString()
    )
  ) {
    delete job.applicants;
    delete job.followers;
  }

  // console.log(job);

  return {
    status: 200,
    data: job,
  };
};

exports.recommendJobByUser = async (userId, page, limit) => {
  const user = await User.findById(userId).select(
    "+skills +followingCompany +saveJobs + jobs"
  );
  // console.log(user);
  // tim cong viec theo cong ty va ky nang
  const jobs = await Job.find({
    company: { $in: user.followingCompany },
    categories: { $in: user.skills },
    _id: { $nin: [...user.saveJobs, ...user.jobs] },
    active: true,
    closed: false,
    deadline: { $gt: new Date() },
  })
    .select("title location deadline company categories")
    .sort({ createdAt: -1 })
    .limit(limit + 1)
    .skip((page - 1) * limit)
    .populate("company categories", "name avatar")
    .lean();

  // console.log(jobs.map((job) => job._id));

  if (jobs.length < limit) {
    const jobsBySkill = await Job.find({
      categories: { $in: user.skills },
      company: { $nin: user.followingCompany },
      _id: { $nin: [...user.saveJobs, ...user.jobs] },
      active: true,
      closed: false,
      deadline: { $gt: new Date() },
    })
      .sort({ createdAt: -1 })
      .limit(Number(limit) - jobs.length + 1)
      .skip((page - 1) * limit)
      .select("title location deadline company categories")
      .populate("company categories", "name avatar")
      .lean();
    jobs.push(...jobsBySkill);
  }

  return {
    status: 200,
    data: {
      data: jobs.slice(0, Math.min(limit, jobs.length)),
      hasMore: jobs.length > limit,
    },
  };
};

exports.viewApplyJobService = async (jobId, userId, reqUserId) => {
  const job = await Job.findById(jobId).lean();
  if (!job) {
    return {
      status: 404,
      message: "Không tìm thấy công việc",
    };
  }
  if (!userId) {
    // tuc la chinh ban employee
    const findIndex = job.applicants.findIndex(
      (applicant) => applicant.user?.toString() === reqUserId
    );
    if (findIndex === -1) {
      return {
        status: 404,
        message: "You have no apply this job",
      };
    }
    return {
      status: 200,
      data: job.applicants[findIndex],
    };
  } else {
    // la HR lay thong tin cua job
    if (job.owner.toString() !== reqUserId) {
      return {
        status: 404,
        message: "You have no permission",
      };
    }
    // console.log(job);
    const findIndex = job.applicants.findIndex(
      (applicant) => applicant.user?.toString() === userId
    );
    if (findIndex === -1) {
      return {
        status: 404,
        message: "You have no apply this job",
      };
    }
    return {
      status: 200,
      data: job.applicants[findIndex],
    };
  }
  // console.log(job.applicants, userId);
};

exports.suggestionJobService = async ({ userId, limit, page }) => {
  const temp = await User.findById(userId)
    .select("+skills +saveJobs +jobs")
    .lean();
  // console.log(temp);
  const jobs = await Job.find({
    categories: { $in: temp.skills },
    _id: { $nin: [...temp.saveJobs, ...temp.jobs] },
    active: true,
    closed: false,
  })
    .select("title location deadline")
    .sort({ createdAt: -1 })
    .limit(limit + 1)
    .skip((page - 1) * limit)
    .populate("company categories", "name avatar")
    .lean();

  return {
    status: 200,
    data: {
      data: jobs.slice(0, Math.min(limit, jobs.length)),
      hasMore: jobs.length > limit,
      page,
    },
  };
};

exports.listJobByCompanyService = async (
  companyId,
  page,
  limit,
  active,
  user
) => {
  const startIndex = (Number(page || 1) - 1) * limit; // get the starting index of every page
  const company = await Company.findById(companyId);
  if (!company) {
    return {
      status: 404,
      message: "Không tìm thấy công ty",
    };
  }
  const jobs = await Job.find({ company: companyId, active })
    .sort({ createdAt: -1 })
    .limit(limit + 1)
    .skip(startIndex)
    .populate("company categories", "name avatar owner")
    .lean()
    .transform((payload) => {
      return payload.map((data) => {
        data.numApplicants = data.applicants.length;
        data.numFollowers = data.followers.length;
        // console.log(data);
        if (
          !(
            user.id.toString() === data.owner.toString() ||
            user.id.toString() === data.company.owner._id.toString()
          )
        ) {
          delete data.applicants;
          delete data.followers;
        }
        return data;
      });
    });
  return {
    status: 200,
    data: {
      data: jobs.slice(0, jobs.length > limit ? limit : jobs.length),
      hasMore: jobs.length > limit,
      page,
    },
  };
};

exports.listMyJobHR = async ({ userId, page, limit, active, HRId = null }) => {
  // console.log(userId, page, limit);
  const user = await User.findById(userId).select("company role");
  if (!user.company) {
    return {
      status: 404,
      message: "Không tìm thấy công ty",
    };
  }

  let acceptedRead = true;

  if (HRId) {
    const hr = await User.findById(HRId).select("company role");
    if (
      !(
        hr.role === "HR" &&
        user.role === "manager" &&
        hr?.company?.toString() === user?.company?.toString()
      )
    ) {
      acceptedRead = false;
    }
  }

  if (!acceptedRead) {
    return {
      status: 400,
      message: "You have no permission",
    };
  }

  let obj = {
    company: user.company,
    owner: HRId || userId,
  };
  if (active) {
    obj.active = active;
  }
  if (user.role === "manager") {
    obj.deadline = { $gt: new Date() };
  }

  const jobs = await Job.find(obj)
    .select(
      "title location deadline company owner numbers applicants followers"
    )
    .populate("company owner", "avatar name")
    .populate("categories", "avatar name")
    .populate("applicants.user", "avatar name email")
    .sort({ createdAt: -1 })
    .limit(limit + 1)
    .skip((page - 1) * limit)
    .transform((data) => {
      return data.map((job) => {
        const { applicants, followers, ...info } = job;
        info.numApplicants = job.applicants.length;
        info.numFollowers = job.followers.length;
        info.applicants = job.applicants.map((applicant) => {
          return {
            ...applicant.user,
          };
        });
        return { ...info };
      });
    })
    .lean();

  return {
    status: 200,
    data: {
      data: jobs.slice(0, jobs.length > limit ? limit : jobs.length),
      hasMore: jobs.length > limit,
    },
  };
};

exports.getJobStatsService = async () => {
  const today = new Date();
  const latYear = today.setFullYear(today.setFullYear() - 1);
  try {
    const data = await Job.aggregate([
      {
        $project: {
          month: { $month: "$createdAt" },
        },
      },
      {
        $group: {
          _id: "$month",

          total: { $sum: 1 },
        },
      },
      {
        $sort: {
          _id: 1,
        },
      },
    ]);
    const rs = {
      categories: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
      data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    };
    data.forEach((item) => {
      rs.data[item._id - 1] = item.total;
    });
    return { status: 200, data: rs };
  } catch (err) {
    return {
      status: 500,
      message: "Có lỗi xảy ra",
    };
  }
};

exports.getJobStatusService = async () => {
  try {
    const data = await Job.aggregate([
      {
        $facet: {
          Active: [{ $match: { active: true } }, { $count: "Total" }],
          Inactive: [{ $match: { active: false } }, { $count: "Total" }],
        },
      },
      {
        $project: {
          Active: { $arrayElemAt: ["$Active.Total", 0] },
          Inactive: { $arrayElemAt: ["$Inactive.Total", 0] },
        },
      },
    ]);
    return {
      status: 200,
      data: {
        categories: Object.keys(data[0]),
        data: Object.values(data[0]),
      },
    };
  } catch (err) {
    return {
      status: 500,
      message: "Có lỗi xảy ra",
    };
  }
};

exports.getJobByCategoryService = async (skill, page, limit, userReq) => {
  let obj = {
    active: true,
    closed: false,

    deadline: { $gt: new Date() },
    owner: { $exists: true },
  };

  const jobs = await Category.findOne({ slug: convertToSlug(skill) })
    .select("jobs")
    .populate({
      path: "jobs",
      match: obj,
      populate: {
        path: "company applicants.user categories",
        select: "name avatar",
      },
      options: {
        sort: { createdAt: -1 },
        limit: limit + 1,
        skip: (page - 1) * limit,
      },
    });
  // console.log(jobs);
  const rsJobs = jobs?.jobs
    ?.slice(0, Math.min(limit, jobs.jobs.length))
    .map((el) => {
      const {
        _id,
        title,
        location,
        deadline,
        company,
        owner,
        categories,
        applicants,
        followers,
        numbers,
      } = el;
      let obj = {
        _id,
        title,
        location,
        deadline,
        company,
        numbers,
        categories,
      };
      if (owner.toString() === userReq.id) {
        obj.numApplicants = applicants.length;
        obj.numFollowers = followers.length;
        obj.applicants = applicants;
        obj.followers = followers;
        obj.owner = owner;
      }
      return obj;
    });

  return {
    status: 200,
    data: {
      data: rsJobs || [],
      hasMore: jobs?.jobs?.length > limit || false,
    },
  };
};

exports.changeOwnerJob = async (jobId, newOwnerId, userReqId) => {
  const job = await Job.findById(jobId).populate("owner company");
  if (!job) {
    return {
      status: 404,
      message: "Không tìm thấy công việc",
    };
  }
  if (job.company.owner._id.toString() !== userReqId.toString()) {
    return {
      status: 400,
      message: "Bạn không có quyền thay đổi công việc này",
    };
  }

  const newOwner = await User.findById(newOwnerId).select(
    "role company activeCompany name"
  );
  if (!newOwner) {
    return {
      status: 404,
      message: "Không tìm thấy người dùng",
    };
  }
  if (newOwner.role !== "HR") {
    return {
      status: 400,
      message: "new owner is not HR",
    };
  }

  if (job.owner._id.toString() === newOwnerId.toString()) {
    return {
      status: 400,
      message: "new owner is the same as old owner",
    };
  }

  if (job.company?._id.toString() !== newOwner.company.toString()) {
    return {
      status: 400,
      message: "Bạn không có quyền thay đổi chủ sở hữu công việc",
    };
  }
  if (newOwner.activeCompany === false) {
    return {
      status: 400,
      message: "Người dùng không còn công ty",
    };
  }

  const rs = await RoomService.updateRoomWhenChangeOwner(
    job,
    job.owner,
    newOwner
  );

  job.owner = newOwnerId;
  // console.log(rs);
  await job.save();
  return {
    status: 200,
    message: "Thay đổi thành công",
  };
};

exports.closeJob = async (jobId, userId, close) => {
  const job = await Job.findById(jobId);
  if (!job) {
    return {
      status: 404,
      message: "Không tìm thấy công việc",
    };
  }
  if (job.owner.toString() !== userId.toString()) {
    return {
      status: 400,
      message: "Bạn không có quyền thay đổi công việc này",
    };
  }
  if (!job.active) {
    return {
      status: 400,
      message: "Công việc đã bị khóa bởi quản trị viên",
    };
  }

  job.closed = close;

  await job.save();
  return {
    status: 200,
    message: "Thay đổi thành công",
  };
};
