const Room = require("../models/RoomModel");
const Job = require("../models/JobModel");
const User = require("../models/UserModel");
const Message = require("../models/MessageModel");

exports.findPersonalRoom = async (sourceId, destId) => {
  if (sourceId === destId) {
    return {
      status: 400,
      message: "Không thể kết nối với chính mình",
    };
  }
  const sender = await User.findOne({ _id: sourceId, active: true });
  const receiver = await User.findOne({ _id: destId, active: true });
  if (!sender && !receiver) {
    return {
      status: 400,
      message: "Không thể kết nối",
    };
  }

  let room = await Room.findOne({
    members: {
      $size: 2,
      $all: [sender._id.toString(), receiver._id.toString()],
    },
    roomType: "Personal",
  });

  if (!room) {
    return {
      status: 200,
      needCreate: true,
      queryCreate: {
        members: [sender._id.toString(), receiver._id.toString()],
        roomType: "Personal",
      },
    };
  }

  if (room.active) {
    return {
      status: 200,
      room,
      isConnected: true,
    };
  } else {
    return {
      status: 200,
      room,
      isConnected: false,
    };
  }
};

exports.upsertPersonalRoom = async (reqUserId, destUserId) => {
  const findRoom = await this.findPersonalRoom(reqUserId, destUserId);
  if (findRoom.status !== 200) {
    return findRoom;
  }
  if (findRoom.needCreate) {
    const room = await Room.create(findRoom.queryCreate);
    return {
      status: 200,
      room,
      isConnected: true,
    };
  }
  if (!findRoom.isConnected) {
    const rs = await this.unBlockRoom(findRoom.room._id, reqUserId, true);
    if (rs.status !== 200) {
      return rs;
    }

    return {
      status: 200,
      room: rs.room,
    };
  }
  return findRoom;
};

exports.findCompanyRoom = async (userId, userReqId, jobId) => {
  const job = await Job.findOne({ _id: jobId, active: true })
    .populate({
      path: "company",
      match: { active: true },
    })
    .populate({
      path: "owner",
      select: "name avatar activeCompany company",
    });

  if (!job) {
    return {
      status: 400,
      message: "Cannot create room, cause not found job",
    };
  }

  if (
    !(
      job?.company?._id?.toString() === job?.owner?.company?.toString() &&
      job?.owner?.activeCompany
    )
  ) {
    return {
      status: 400,
      message: "Công việc này hiện không ai phụ trách",
    };
  }

  const isHR = userReqId === job.owner._id.toString();

  let query = {
    members: {
      $size: 2,
      $all: isHR
        ? [userId, job.owner._id.toString()]
        : [userReqId, job.owner._id.toString()],
    },
    roomType: "Company",
    company: job.company._id,
  };

  let room = await Room.findOne(query);

  if (!room) {
    const queryCreate = {
      ...query,
      members: isHR
        ? [userId, job.owner._id.toString()]
        : [userReqId, job.owner._id.toString()],
      jobs: [jobId],
      roomName: `${job.company.name}-${job.owner.name}`,
    };
    const newMessageObj = {
      sender: isHR ? job.owner._id : userReqId,
      text: isHR
        ? `Chào bạn mình là HR của công ty ${job.company.name} mà bạn đã quan tâm job ${job.title}`
        : `Chào công ty ${job.company.name} tôi có vài điều muốn trao đổi về công việc ${job.title}`,
    };
    return {
      status: 200,
      message: "not found room",
      queryCreate,
      newMessageObj,
      needCreate: true,
    };
  } else {
    if (
      room.jobs &&
      room.jobs.some((el) => el.toString() === job._id.toString())
    ) {
      if (room.active) {
        return {
          status: 200,
          isConnected: true,
          room,
          active: true,
        };
      } else {
        return {
          status: 200,
          isConnected: true,
          room,
          active: false,
        };
      }
    } else {
      const newMessageObj = {
        roomId: room._id,
        sender: isHR ? job.owner._id : userReqId,
        text: isHR
          ? `Chào bạn mình là HR của công ty ${job.company.name} mà bạn đã quan tâm job ${job.title}`
          : `Chào công ty ${job.company.name} tôi có vài điều muốn trao đổi về công việc ${job.title}`,
      };

      return {
        status: 200,
        isConnected: false,
        queryFind: query,
        newMessageObj,
        room,
      };
    }
  }
};

exports.upsertCompanyRoom = async (userId, userReqId, jobId) => {
  // console.log("upsertCompanyRoom", userId, userReqId, jobId);
  let findRoom = await this.findCompanyRoom(userId, userReqId, jobId);

  if (findRoom.status !== 200) {
    return findRoom;
  }

  let room;
  let lastMessage;

  if (findRoom.needCreate) {
    room = await Room.create(findRoom.queryCreate);
    lastMessage = await Message.create({
      ...findRoom.newMessageObj,
      roomId: room._id,
    });
    return await this.updateLastMessage(room._id, lastMessage);
  }

  if (findRoom.isConnected) {
    if (findRoom.active) {
      return findRoom;
    } else {
      return await this.unBlockRoom(
        findRoom.room._id,
        findRoom.userReqId,
        true
      );
    }
  }

  if (!findRoom.isConnected) {
    lastMessage = await Message.create(findRoom.newMessageObj);
    await this.updateLastMessage(findRoom.room._id, lastMessage);
    room = await Room.findOneAndUpdate(
      findRoom.queryFind,
      {
        $push: { jobs: jobId },
        $set: {
          latestMessage: lastMessage,
          active: true,
        },
        $unset: {
          blocked: "",
        },
      },
      {
        new: true,
      }
    );
  }
  return {
    status: 200,
    room,
  };
};

exports.blockRoom = async (roomId, userReqId) => {
  const query = {
      _id: roomId,
      blocked: { $exists: false },
      members: { $in: [userReqId] },
    },
    update = { $set: { blocked: userReqId, active: false } },
    options = { new: true };

  const room = await Room.findOneAndUpdate(query, update, options);
  if (!room) {
    return {
      status: 400,
      message: "Room not found",
    };
  }
  return await this.getRoom(roomId, userReqId);
};

exports.unBlockRoom = async (roomId, reqUserId, isNotify = false) => {
  const query = {
    _id: roomId,
    members: { $in: [reqUserId] },
  };
  if (!isNotify) {
    query.blocked = reqUserId;
  }
  const room = await Room.findOneAndUpdate(
    query,
    {
      $unset: {
        blocked: "",
      },
      $set: {
        active: true,
      },
    },
    { new: true }
  );

  if (!room) {
    return {
      status: 400,
      message: "Phòng đã bị khóa bởi ai đó",
    };
  }
  const rs = await this.getRoom(roomId, reqUserId);
  return {
    ...rs,
    room: rs.data,
  };
};

exports.updateLastSeenMessage = async (roomId, lastSeenMessage) => {
  const update = { $set: { lastSeenMessage } },
    options = { new: true };

  const room = await Room.findOneAndUpdate(roomId, update, options);
  return {
    status: 200,
    room,
  };
};

exports.updateLastMessage = async (roomId, latestMessage) => {
  const update = { $set: { latestMessage } },
    options = { new: true };

  const room = await Room.findByIdAndUpdate(roomId, update, options);
  return {
    status: 200,
    room,
  };
};

exports.getListRoom = async (reqUserId, type, page, limit) => {
  // console.log(reqUserId, type, page, limit);
  const query = {
    members: { $in: [reqUserId] },
    // $or: [{ blocked: { $exists: false } }, { blocked: null }],
    roomType: type,
  };
  const rooms = await Room.find(query)
    .select(type === "Company" && "+company")
    .populate({
      path: "members company",
      select: "name avatar",
    })
    .sort({ updatedAt: -1 })
    .skip((page - 1) * limit)
    .limit(limit);
  return {
    status: 200,
    data: rooms,
  };
};

exports.getRoom = async (roomId, userId, page, limit) => {
  const messages = await Room.findOne({
    _id: roomId,
    members: { $in: [userId] },
  })
    .populate({
      path: "company",
      select: "name avatar",
    })
    .populate({
      path: "members",
      select: "name avatar",
    });

  if (!messages) {
    return {
      status: 400,
      message: "Not permitted to open this room",
    };
  }
  return {
    status: 200,
    data: messages,
  };
};

exports.activeRoom = async (roomId, userId, active) => {
  const query = {
    _id: roomId,
    members: { $in: [userId] },
  };
  const update = { $set: { active } };
  const options = { new: true };
  const room = await Room.findOneAndUpdate(query, update, options);
  if (!room) {
    return {
      status: 400,
      message: "Not permitted to open this room",
    };
  }
  return {
    status: 200,
    room,
  };
};

exports.activeRooms = async (ownerId, roomType, active) => {
  let rs = null;
  if (roomType === "Company") {
    const query = {
      roomType,
      company: ownerId,
      active: true,
    };
    const update = {
      $set: {
        active,
      },
    };
    const options = {
      new: true,
    };
    rs = await Room.updateMany(query, update, options);
  } else if (roomType === "Personal") {
    const query = {
      roomType,
      members: { $in: [ownerId] },
      active: true,
    };
    const update = {
      $set: {
        active,
      },
    };
    const options = {
      new: true,
    };
    rs = await Room.updateMany(query, update, options);
  }
  if (!rs) {
    return {
      status: 400,
      message: "Not found room",
    };
  }
  return rs;
};

exports.updateRoomWhenChangeOwner = async (job, oldOwner, newOwner) => {
  const findOldRooms = await Room.find({
    roomType: "Company",
    members: { $in: [oldOwner._id.toString()] },
    company: job.company._id.toString(),
    jobs: { $in: [job._id.toString()] },
  });

  if (!findOldRooms || findOldRooms.length === 0) {
    return {
      status: 200,
      message: "room not create",
    };
  }

  const findUsers = findOldRooms.reduce((acc, cur) => {
    const findUser = cur.members.find(
      (item) => item.toString() != oldOwner._id.toString()
    );
    return acc.concat(findUser.toString());
  }, []);

  // check if in findUsers one part have with newOwnerId one part has not created room with newOwner yet

  const rs = await Promise.all(
    findUsers.map(async (user) => {
      let room = await Room.findOne({
        roomType: "Company",
        members: {
          $size: 2,
          $all: [newOwner._id.toString(), user],
        },
        company: job.company._id.toString(),
      });
      if (!room) {
        room = new Room({
          roomType: "Company",
          members: [newOwner._id.toString(), user],
          company: job.company._id,
          jobs: [job._id.toString()],
          roomName: `${job.company.name} - ${newOwner?.name}`,
        });
        await room.save();
      } else {
        room.jobs.push(job._id.toString());
        await room.save();
      }
      // new message
      // console.log("create messaage chnage owner");
      const newMessage = await Message.create({
        roomId: room._id.toString(),
        sender: newOwner._id.toString(),
        text: `Chào bạn, tôi là ${newOwner?.name} sẽ trao đổi công việc ${job.title} với bạn thay thế cho ${oldOwner.name}`,
      });
      await this.updateLastMessage(room._id, newMessage);
    })
  );

  const updateOldRooms = await Room.updateMany(
    {
      _id: { $in: findOldRooms.map((r) => r._id.toString()) },
    },
    {
      $pull: {
        jobs: job._id.toString(),
      },
    }
  );

  return {
    status: 200,
    message: `change owner ${findOldRooms.length} rooms`,
  };
};

exports.getNotifyRoomWhenOffline = async (userId) => {
  const user = await User.findById(userId);
  if (!user) {
    return {
      status: 400,
      message: "Not found user",
    };
  }
  const rooms = await Room.find({
    members: { $in: [userId] },
    active: true,
    updatedAt: { $gt: user.lastActivity },
  });
  return { status: 200, data: rooms.map((item) => item._id.toString()) };
};
