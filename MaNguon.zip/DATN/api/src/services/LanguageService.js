const Language = require("../models/LanguageModel");
const _ = require("lodash");
const User = require("../models/UserModel");
const { convertToSlug } = require("../utils/convertToSlug");

exports.createUserLanguages = (names, userId) => {
  return Promise.all(
    names.map(async (name) => {
      const language = await Language.findOne({
        slug: convertToSlug(name),
      });
      if (language) {
        language.users.push(userId);
        await language.save();
        return language._id;
      }
      const newLanguage = await Language.create({
        name,
        slug: convertToSlug(name),
        users: [userId],
      });
      return newLanguage._id;
    })
  )
    .then((rs) => {
      return rs;
    })
    .catch((error) => {
      return error;
    });
};

exports.deleteUserLanguages = (names, userId) => {
  return Promise.all(
    names.map(async (name) => {
      const language = await Language.findOne({
        slug: convertToSlug(name),
      });
      if (language) {
        language.users.pull(userId);
        await language.save();
        return language;
      }
      return null;
    })
  )
    .then((rs) => {
      return rs;
    })
    .catch((error) => {
      return error;
    });
};

exports.updateLanguages = async (newNames, userId) => {
  const user = await User.findById(userId)
    .select("languages")
    .populate("languages");

  const oldNames = user.languages.map((lan) => lan.name);

  const newLangs = _.difference(newNames, oldNames);
  const deleteLangs = _.difference(oldNames, newNames);

  return Promise.all([
    this.createUserLanguages(newLangs, userId),
    this.deleteUserLanguages(deleteLangs, userId),
  ])
    .then(async (rs) => {
      user.languages = user.languages.concat(rs[0]);
      await user.save();

      return {
        status: 200,
        message: "update languages success",
      };
    })
    .catch((error) => {
      return {
        status: 500,
        message: error.message,
      };
    });
};

exports.searchLanguages = async ({
  operatorValue,
  value: tmp,
  page,
  limit,
}) => {
  let myFilter = "";
  const PAGE = Number(page) || 1;
  const LIMIT = Number(limit) || 6;
  const startIndex = (Number(PAGE) - 1) * LIMIT; // get the starting index of every page
  const value = convertToSlug(tmp);
  if (operatorValue === "contains") {
    myFilter = { $regex: new RegExp(".*" + value + ".*", "i") };
  } else if (operatorValue === "equals") {
    myFilter = { $eq: value };
  } else if (operatorValue === "startsWith") {
    myFilter = { $regex: new RegExp("^" + value + ".*", "i") };
  } else if (operatorValue === "endsWith") {
    myFilter = { $regex: new RegExp(".*" + value + "$", "i") };
  } else if (operatorValue === "isEmpty") {
    myFilter = { $eq: null };
  } else if (operatorValue === "isNotEmpty") {
    myFilter = { $ne: null };
  } else if (operatorValue === "is" && value !== "") {
    myFilter = { $eq: value === "false" ? false : true };
  }
  let obj = {};
  Object.assign(obj, { slug: myFilter });
  // console.log(obj);
  const data = await Language.find(obj)
    .select("_id name")
    .sort({ name: 1 })
    .skip(startIndex)
    .limit(LIMIT);
  return {
    status: 200,
    data: {
      data,
      currentPage: PAGE,
    },
  };
};
