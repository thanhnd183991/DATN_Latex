const Comment = require("../models/CommentModel");
const Post = require("../models/PostModel");

exports.createCommentService = async (comment, userId, postId) => {
  const { content, file } = comment;
  if (!content && !file) {
    return {
      status: 400,
      message: "Content or file is required",
    };
  }
  const post = await Post.findById(postId);
  if (!post) {
    return { status: 404, message: "Post not found" };
  }

  const newComment = await Comment.create({
    postId,
    userId,
    content,
    file,
  });

  return { newComment, status: 201 };
};

exports.replyCommentService = async (root, inputComment, userId) => {
  const { content, file } = inputComment;
  // console.log(root);
  if (!content && !file) {
    return {
      status: 400,
      message: "Content or file is required",
    };
  }
  const comment = await Comment.findById(root);
  if (!comment) {
    return { status: 404, message: "Comment not found" };
  }
  const replyComment = await Comment.create({
    postId: comment.postId,
    userId,
    content,
    file,
    root,
  });
  comment.children.push(replyComment._id);
  await comment.save();
  return { replyComment, status: 201 };
};

exports.reactionCommentService = async (commentId, userId, reaction) => {
  const comment = await Comment.findById(commentId);
  if (!comment) {
    return {
      status: 404,
      message: "Comment not found",
    };
  }
  // console.log(comment);
  const reactionExist = comment.reactions.find(
    (item) => item.userId.toString() === userId.toString()
  );
  if (reactionExist) {
    comment.reactions.pull(reactionExist);
  } else {
    comment.reactions.push({
      reaction,
      userId,
    });
  }
  await comment.save();
  return {
    status: 200,
    data: comment.reactions,
  };
};

exports.infoPostRootCommentService = async (postId) => {
  const comments = await Comment.find({
    postId,
    root: { $exists: false },
  })
    .populate({
      path: "userId reactions.userId",
      match: { active: true },
      select: "name avatar",
      options: { _recursed: true },
    })
    .lean();

  return {
    status: 200,
    data: comments,
  };
};

exports.infoPostChildrenCommentService = async (commentId) => {
  const comments = await Comment.findById(commentId).populate({
    path: "children",
    populate: {
      path: "userId reactions.userId",
      match: { active: true },
      select: "name avatar",
      options: { _recursed: true },
    },
  });

  return {
    status: 200,
    data: comments.children,
  };
};

exports.infoCountCommentPostService = async (postId) => {
  const countComment = await Comment.find({ postId }).countDocuments();

  return {
    status: 200,
    data: countComment,
  };
};
