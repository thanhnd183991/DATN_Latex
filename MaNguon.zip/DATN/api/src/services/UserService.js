const User = require("../models/UserModel");
const Job = require("../models/JobModel");
const Company = require("../models/CompanyModel");
const Mongoose = require("mongoose");
const NotificationService = require("./NotificationService");
const CategoryService = require("./CategoryService");
const EducationService = require("./EducationService");
const LanguageService = require("./LanguageService");
const ExperienceService = require("./ExperienceService");

const Catergory = require("../models/CategoryModel");
const Education = require("../models/EducationModel");
const _ = require("lodash");
const { convertToSlug } = require("../utils/convertToSlug");
const { filterRegex } = require("../utils/filter");

exports.updateSkillService = async (userId, skills) => {
  const user = await User.findOne({ _id: userId, active: true })
    .populate("skills", "name")
    .select("+skills");
  if (!user) {
    return {
      status: 404,
      message: "User not found",
    };
  }

  const userOldSkills = user.skills.map((skill) => skill.name);

  const newSkills = _.difference(skills, userOldSkills);
  const oldSkills = _.intersection(skills, userOldSkills);
  const removeSkills = _.difference(userOldSkills, skills);

  const oldSkillIds = user.skills
    .filter((skill) => oldSkills.includes(skill.name))
    .map((skill) => skill.id);
  // console.log(oldSkillIds);

  await Catergory.updateMany(
    { name: { $in: removeSkills } },
    { $pull: { users: userId } }
  );
  user.skills = oldSkillIds;
  if (newSkills.length > 0) {
    const rs = await CategoryService.upsertArrayCategory(newSkills, userId);
    rs.forEach(({ _id, name }) => {
      user.skills.push(_id);
    });
  }

  await user.save();

  const updateUser = await User.findOne({ _id: userId, active: true })
    .populate("skills", "name")
    .select("+skills");
  return {
    status: 200,
    data: updateUser.skills,
  };
};

exports.updateExperienceService = async (userId, exps) => {
  return await ExperienceService.updateUserExps(exps, userId);
};

exports.updateLanguageService = async (userId, languages) => {
  return await LanguageService.updateLanguages(languages, userId);
};

exports.updateEducationService = async (userId, edus) => {
  const user = await User.findOne({ _id: userId, active: true })
    .populate("educations.school", "school")
    .select("+educations");
  if (!user) {
    return {
      status: 404,
      message: "User not found",
    };
  }

  const dictionaryEdus = {};
  edus.forEach((edu) => {
    dictionaryEdus[edu.school] = edu;
  });
  const dictionaryUserEdus = {};
  user.educations.forEach((edu) => {
    dictionaryUserEdus[edu.school.school] = edu;
  });
  // console.log("loc", dictionaryUserEdus);
  const newEdus = _.difference(
    Object.keys(dictionaryEdus),
    Object.keys(dictionaryUserEdus)
  );
  const holdEdus = _.intersection(
    Object.keys(dictionaryEdus),
    Object.keys(dictionaryUserEdus)
  ).map((el) => ({
    school: dictionaryUserEdus[el].school._id,
    degree: dictionaryEdus[el].degree,
    field_of_study: dictionaryEdus[el].field_of_study,
    start_date: dictionaryEdus[el].start_date,
    end_date: dictionaryEdus[el].end_date,
  }));
  const removeEdus = _.difference(
    Object.keys(dictionaryUserEdus),
    Object.keys(dictionaryEdus)
  );

  user.educations = holdEdus;

  await Education.updateMany(
    { school: { $in: removeEdus } },
    { $pull: { students: userId } }
  );

  if (newEdus.length > 0) {
    const rs = EducationService.upsertArrayEducation(newEdus, userId)
      .then(async (rs) => {
        rs.forEach(({ _id, school: edu }) => {
          user.educations.push({
            school: _id,
            degree: dictionaryEdus[edu].degree,
            field_of_study: dictionaryEdus[edu].field_of_study,
            start_date: dictionaryEdus[edu].start_date,
            end_date: dictionaryEdus[edu].end_date,
          });
        });

        await user.save();
        return {
          status: 200,
          data: user.educations,
        };
      })
      .catch((err) => {
        console.log(err);
        return {
          status: 500,
          message: "Internal server error",
        };
      });
    return rs;
  }

  await user.save();
  return {
    status: 200,
    data: edus,
  };
};
exports.followCompany = async (companyId, userRequest) => {
  const checkUser = await User.findOne({
    _id: userRequest.id,
    active: true,
  }).select("+followingCompany");
  if (!checkUser) {
    return {
      status: 404,
      message: "User not found",
    };
  }
  // console.log(checkUser);
  const checkCompany = await Company.findOne({
    _id: companyId,
    active: true,
  }).select("+followers");
  if (!checkCompany) {
    return {
      status: 404,
      message: "Company not found",
    };
  }
  let followedCompany = false;
  if (checkUser.followingCompany.some((el) => el.toString() === companyId)) {
    followedCompany = true;
  }
  let rs = null;

  if (followedCompany) {
    // xoa theo doi cong ty nay
    checkUser.followingCompany.pull(checkCompany._id);
    checkCompany.followers.pull(checkUser._id);
  } else {
    checkUser.followingCompany.push(checkCompany._id);
    checkCompany.followers.push(checkUser._id);
  }
  rs = await Promise.all([await checkUser.save(), await checkCompany.save()]);

  if (rs[0].acknowledged === false || rs[1].acknowledged === false) {
    return {
      status: 500,
      message: "Có lỗi xảy ra",
    };
  }

  let tmp = null;
  if (!followedCompany) {
    tmp = await NotificationService.followingCompanyNotify(
      checkUser,
      checkCompany
    );
    if (tmp.status !== 200) return tmp;
  }

  return {
    status: 200,
    message: `${followedCompany ? `unfollowing` : "follow"} ${
      checkCompany.name
    }`,
    isFollowed: followedCompany,
    notify: followedCompany ? null : tmp.notify,
  };
};

exports.followJob = async (jobId, userRequest) => {
  const checkUser = await User.findOne({
    _id: userRequest.id,
    active: true,
  }).select("+jobs +saveJobs");
  const checkJob = await Job.findOne({
    _id: jobId,
    active: true,
  }).select("+followers +applicants");

  if (!checkUser) {
    return {
      status: 404,
      message: "User not found",
    };
  }
  if (!checkJob) {
    return {
      status: 404,
      message: "Job not found",
    };
  }
  // check job have in saveJobs and jobs(appliedJobs)
  let checkJobInSaveJobs = false;
  let checkJobInJobs = false;
  if (checkUser.saveJobs.includes(checkJob._id)) {
    checkJobInSaveJobs = true;
  }

  if (checkUser.jobs.includes(checkJob._id)) {
    checkJobInJobs = true;
  }

  if (checkJobInJobs) {
    return {
      status: 400,
      message: "Bạn đã apply công việc này vui lòng chờ phản hồi",
    };
  }

  let rs = null;
  if (checkJobInSaveJobs) {
    // nếu có trong save jobs xóa thì công việc này đi
    checkUser.saveJobs.pull(checkJob._id);
    checkJob.followers.pull(checkUser._id);

    rs = await Promise.all([await checkUser.save(), await checkJob.save()]);
  } else {
    // lưu job vào xem sau
    checkUser.saveJobs.push(checkJob._id);
    checkJob.followers.push(checkUser._id);

    rs = await Promise.all([await checkUser.save(), await checkJob.save()]);
  }

  if (rs[0].acknowledged === false || rs[1].acknowledged === false) {
    return {
      status: 500,
      message: "Có lỗi xảy ra",
    };
  }

  let tmp = null;
  if (!checkJobInSaveJobs) {
    tmp = await NotificationService.followingJobNotify(checkUser, checkJob);
    if (tmp.status !== 200) return tmp;
  }

  return {
    status: 200,
    message: `${checkJobInSaveJobs ? `unfollowing` : "follow"} công việc ${
      checkJob.title
    }`,
    isFollowed: checkJobInSaveJobs,
    notify: checkJobInSaveJobs ? null : tmp.notify,
  };
};

exports.followUser = async (userId, userRequest) => {
  const checkUser = await User.findOne({ _id: userId, active: true }).select(
    "+following +followers"
  );
  const checkUserRequest = await User.findOne({
    _id: userRequest.id,
    active: true,
  }).select("+following +followers");
  if (!checkUser || !checkUserRequest) {
    return {
      status: 404,
      message: "User not found",
    };
  }

  if (String(userRequest.id) === String(userId))
    return {
      status: 404,
      message: "You can not follow yourself",
    };
  let followedUser = false;
  if (checkUserRequest.following.includes(checkUser._id)) {
    followedUser = true;
  }
  let rs = null;
  if (followedUser) {
    // xoa theo doi nguoi dung nay
    checkUserRequest.following.pull(checkUser._id);
    checkUser.followers.pull(checkUserRequest._id);
    rs = await Promise.all([
      await checkUser.save(),
      await checkUserRequest.save(),
    ]);
  } else {
    checkUserRequest.following.push(checkUser._id);
    checkUser.followers.push(checkUserRequest._id);
    rs = await Promise.all([
      await checkUser.save(),
      await checkUserRequest.save(),
    ]);
  }
  if (rs[0].acknowledged === false || rs[1].acknowledged === false) {
    return {
      status: 500,
      message: "Có lỗi xảy ra",
    };
  }

  let tmp = null;

  if (!followedUser) {
    tmp = await NotificationService.followingUserNotify(
      checkUserRequest,
      checkUser
    );
    if (tmp.status !== 200) return tmp;
  }
  return {
    status: 200,
    message: `${followedUser ? `unfollowing` : "follow"} ${checkUser.name}`,
    isFollowed: followedUser,
    notify: followedUser ? null : tmp.notify,
  };
};

exports.deleteMembers = async (members, active, durable = false) => {
  // nếu active là true thì khôi phục lại nhân viên
  // nếu active là false và durable là false thì xóa soft nhân viên có thể khôi phục dduowcj
  // nếu active là false và durable là true thì xóa hard nhân viên không thể khôi phục
  let obj = {
    $set: {
      role: active === true ? "HR" : "employee",
      activeCompany: active,
    },
  };
  if (!active) {
    if (durable) {
      // console.log("vao durabable");
      const job = await Job.findOne(
        {
          owner: members[0],
          deadline: { $gt: new Date() },
        },
        { _id: 1 }
      );

      // console.log(job);

      if (job) {
        return {
          status: 400,
          message: "Nhân viên này đang có công việc đang chạy, không thể xóa",
        };
      }

      obj = {
        $set: {
          role: "employee",
          activeCompany: active,
        },
        $unset: {
          company: "",
        },
      };
    }
  }
  // console.log(obj);
  const rs = await User.updateMany({ _id: { $in: members } }, obj);
  if (rs.acknowledged === false) {
    return {
      status: 500,
      message: "Có lỗi xảy ra",
    };
  }
  return {
    status: 200,
    message: "Xóa thành công",
  };
};

exports.searchUserService = async (query, limit, page) => {
  const users = await User.find({
    $or: [
      { name: { $regex: ".*" + query + ".*" } },
      { email: { $regex: ".*" + query + ".*" } },
    ],
  })
    .populate({
      path: "followers following followingCompany",
      match: { active: true },
      select: "name email avatar",
      options: { _recursed: true },
    })
    .populate("saveJobs jobs")
    .sort({ createdAt: -1 })
    .skip((page - 1) * limit)
    .limit(limit);
  return {
    status: 200,
    users,
  };
};

exports.getListFollowByUser = async (
  userId,
  type = "followers",
  value,
  limit,
  page
) => {
  // const tmp = await User.findOne({
  //   _id: userId,
  //   active: true,
  // }).populate({
  //   path: "numFollowers numFollowingCompany",
  // });
  // console.log(tmp);

  const filter = filterRegex(value, "startsWith", false, "name");
  // console.log(filter);
  if (type === "followingCompany") {
    const user = await User.findOne({
      _id: userId,
      active: true,
    })
      .select(type)
      .populate({
        path: type,
        match: { active: true, ...filter },
        select: "name email avatar followers industry",

        options: {
          limit: limit,
          skip: (page - 1) * limit,
          sort: { name: 1 },
        },
        populate: {
          path: "industry",
          select: "name",
        },
      })
      .transform((doc) => {
        const rs = doc[type].map(({ followers, ...item }) => ({
          ...item,
          numFollowers: followers?.length,
        }));
        return {
          [type]: rs,
        };
      })
      .lean();

    return {
      status: 200,
      data: user[type],
    };
  }

  const user = await User.findOne({
    _id: userId,
    active: true,
  })
    .select(type)
    .populate({
      path: type,
      match: { active: true, ...filter },
      select: "name avatar followers",
      options: {
        _recursed: true,
        limit: limit,
        skip: (page - 1) * limit,
        sort: { name: 1 },
      },
    })
    .transform((doc) => {
      const rs = doc[type].map(({ followers, ...item }) => ({
        ...item,
        numFollowers: followers?.length,
      }));
      return {
        [type]: rs,
      };
    })
    .lean();
  // console.log(user);

  return {
    status: 200,
    data: user[type],
  };
};
exports.infoUserService = async (userId, roleReqUserId) => {
  const query = {
    _id: userId,
  };
  if (roleReqUserId !== "admin") {
    query.active = true;
  }
  const user = await User.findOne(query)
    .select(
      "+name +email +avatar +company +role +about +activeCompany +educations +skills +experiences +projects +languages +social +followers +following +followingCompany"
    )
    .populate({
      path: "educations.school",
      select: "school",
    })
    .populate({
      path: "skills languages experiences.name",
      select: "name",
    })
    .lean();
  if (!user) {
    return {
      status: 404,
      message: "User not found",
    };
  }
  user.educations =
    user?.educations?.map((education) => {
      const { school, id, ...info } = education;
      // console.log(school);
      return {
        ...info,
        school: school.school,
      };
    }) || [];
  user.experiences =
    user?.experiences?.map((exp) => {
      const { name, id, ...info } = exp;
      // console.log(school);
      return {
        ...info,
        name: name.name,
      };
    }) || [];
  user.skills = user.skills || [];
  return {
    status: 200,
    user,
  };
};

exports.acceptCompanyService = async (reqUserId) => {
  const user = await User.findOneAndUpdate(
    { _id: reqUserId, active: true, company: { $exists: true } },
    {
      activeCompany: true,
    },
    { new: true }
  ).select("+activeCompany");
  if (!user) {
    return {
      status: 404,
      message: "User not found",
    };
  }

  return {
    status: 200,
    user,
  };
};

exports.deleteUserService = async (userId, reqUserId) => {
  if (userId === reqUserId) {
    return {
      status: 400,
      message: "You can not delete yourself",
    };
  }
  const user = await User.findOne({ _id: userId });

  if (!user) {
    return {
      status: 404,
      message: "User not found",
    };
  }
  await user.update({ active: !user.active });
  return {
    status: 200,
    message: "Delete user success",
  };
};

exports.activeUserService = async (userId) => {
  const user = await User.findOne({ _id: userId, active: false });

  if (!user) {
    return {
      status: 404,
      message: "User not found",
    };
  }
  await user.update({ active: true });
  return {
    status: 200,
    message: "Active user success",
  };
};

exports.suggestionUserService = async ({ userId, limit, page }) => {
  const user = await User.findById(userId).select("+following");
  const userArray = [user._id, ...user.following];
  const users = await User.aggregate([
    {
      $match: {
        _id: { $nin: userArray },
        role: { $ne: "admin" },
        active: true,
      },
    },
    {
      $project: {
        name: 1,
        avatar: 1,
        numFollowers: { $size: "$followers" },
      },
    },
    { $skip: (page - 1) * limit },
    { $limit: Number(limit) + 1 },
  ]);
  return {
    status: 200,
    data: {
      data: users.slice(0, users.length > limit ? limit : users.length),
      hasMore: users.length > limit,
      page,
    },
  };
};

exports.applyJobCartUserService = async ({ userId, limit, page }) => {
  const user = await User.findById(userId).populate({
    path: "jobs",
    select: "title location deadline",
    populate: {
      path: "company categories",
      select: "name avatar",
    },
    match: { active: true },
    options: {
      sort: { createdAt: -1 },
    },
  });

  return {
    status: 200,
    data: {
      data: user.jobs,
      hasMore: false,
      numberOfPages: Math.max(Math.ceil(user.jobs.length / limit), 1),
    },
  };
};

exports.saveJobCartUserService = async ({ userId, limit, page }) => {
  const user = await User.findById(userId).populate({
    path: "saveJobs",
    select: "title location deadline",
    populate: {
      path: "company categories",
      select: "name avatar",
    },
    match: { active: true },
    options: {
      sort: { createdAt: -1 },
    },
  });

  return {
    status: 200,
    data: {
      data: user.saveJobs,
      hasMore: false,
      numberOfPages: Math.max(Math.ceil(user.saveJobs.length / limit), 1),
    },
  };
};

exports.updateFieldStringObjectUserService = async (userId, body) => {
  const user = await User.findOneAndUpdate(
    {
      _id: userId,
      active: true,
    },
    body,
    {
      new: true,
    }
  );
  if (!user) {
    return {
      status: 404,
      message: "User not found",
    };
  }
  return {
    status: 200,
    data: user,
  };
};

exports.listEmployeeService = async (userId, value, limit, page) => {
  const filter = filterRegex(value, "startsWith", false, "name");
  const user = await User.findById(userId).select("+company");
  if (!user) {
    return {
      status: 404,
      message: "User not found",
    };
  }
  const users = await User.aggregate([
    {
      $match: {
        _id: { $ne: userId },
        role: "employee",
        active: true,
        ...filter,
      },
    },
    {
      $project: {
        name: 1,
        avatar: 1,
        numFollowers: { $size: "$followers" },
      },
    },
    { $skip: (page - 1) * limit },
    { $limit: Number(limit) },
  ]);
  return {
    status: 200,
    data: users,
  };
};

exports.getUserStatsService = async () => {
  const today = new Date();
  const latYear = today.setFullYear(today.setFullYear() - 1);
  try {
    const data = await User.aggregate([
      {
        $match: {
          role: { $ne: "admin" },
        },
      },
      {
        $project: {
          month: { $month: "$createdAt" },
        },
      },
      {
        $group: {
          _id: "$month",

          total: { $sum: 1 },
        },
      },
      {
        $sort: {
          _id: 1,
        },
      },
    ]);
    const rs = {
      categories: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
      data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    };
    data.forEach((item) => {
      rs.data[item._id - 1] = item.total;
    });
    return { status: 200, data: rs };
  } catch (err) {
    return {
      status: 500,
      message: "Có lỗi xảy ra",
    };
  }
};

exports.getUserStatusService = async () => {
  try {
    const data = await User.aggregate([
      {
        $match: {
          role: { $ne: "admin" },
        },
      },
      {
        $facet: {
          Active: [{ $match: { active: true } }, { $count: "Total" }],
          Inactive: [{ $match: { active: false } }, { $count: "Total" }],
        },
      },
      {
        $project: {
          Active: { $arrayElemAt: ["$Active.Total", 0] },
          Inactive: { $arrayElemAt: ["$Inactive.Total", 0] },
        },
      },
    ]);
    return {
      status: 200,
      data: {
        categories: Object.keys(data[0]),
        data: Object.values(data[0]),
      },
    };
  } catch (err) {
    return {
      status: 500,
      message: "Có lỗi xảy ra",
    };
  }
};

exports.updateStatusUserService = async (userId, { status, lastActivity }) => {
  const rs = await User.updateOne(
    { _id: userId },
    { active: status, lastActivity }
  );
  // console.log(rs);
  return rs;
};

exports.searchUserBySkill = async (skill, page, limit) => {
  // console.log(skill, page);
  // find users by slug field in categroy collection
  const users = await Catergory.aggregate([
    {
      $match: {
        slug: convertToSlug(skill),
      },
    },
    {
      $unwind: "$users",
    },
    {
      $lookup: {
        from: "users",
        localField: "users",
        foreignField: "_id",
        as: "users",
      },
    },
    {
      $sort: {
        "users.name": -1,
      },
    },
    {
      $skip: (Number(page) - 1) * Number(limit),
    },
    {
      $limit: Number(limit) + 1,
    },
    {
      $set: {
        numFollowers: { $size: "$users.followers" },
        name: { $first: "$users.name" },
        avatar: { $first: "$users.avatar" },
        _id: { $first: "$users._id" },
      },
    },
    {
      $project: {
        name: 1,
        avatar: 1,
        numFollowers: 1,
        _id: 1,
      },
    },
  ]);
  // console.log(users);
  return {
    status: 200,
    data: {
      data: users.slice(0, users.length > limit ? limit : users.length),
      hasMore: users.length > limit,
      page,
    },
  };
};
