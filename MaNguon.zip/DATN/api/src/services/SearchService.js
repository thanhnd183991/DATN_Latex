const User = require("../models/UserModel");
const Job = require("../models/JobModel");
const Company = require("../models/CompanyModel");
const Mongoose = require("mongoose");
const NotificationService = require("./NotificationService");
const CategoryService = require("./CategoryService");
const EducationService = require("./EducationService");
const Catergory = require("../models/CategoryModel");
const Education = require("../models/EducationModel");
const _ = require("lodash");
const Category = require("../models/CategoryModel");
const Post = require("../models/PostModel");
const { convertToSlug } = require("../utils/convertToSlug");
const { filterRegex } = require("../utils/filter");

exports.searchModelService = async ({
  model,
  columnField,
  operatorValue,
  value,
  page,
  sort = "asc",
  limit,
  userId,
  active,
}) => {
  let myFilter = "";
  const PAGE = Number(page) || 1;
  const LIMIT = Number(limit) || 6;
  const startIndex = (Number(PAGE) - 1) * LIMIT; // get the starting index of every page
  let total = 0;
  let obj = filterRegex(value, operatorValue, false, columnField);
  if (active) {
    obj = { ...obj, active: true };
  }
  // console.log("res", obj);

  let sortBy = {};
  Object.assign(sortBy, { [columnField]: sort === "asc" ? 1 : -1 });
  // console.log(obj, sortBy);
  if (
    columnField !== "name" &&
    !columnField.includes("num") &&
    columnField !== "title"
  ) {
    sortBy =
      model === "user"
        ? {
            name: 1,
          }
        : model === "post"
        ? {
            content: 1,
          }
        : { createdAt: 1 };
    if (columnField === "active" && value === "" && operatorValue === "is") {
      obj = {};
    }
  }
  let filterNum = null;
  if (columnField.includes("num")) {
    obj = {};
  }
  if (columnField === "createdAt") {
    obj = {};
    sortBy = { createdAt: sort === "asc" ? 1 : -1 };
  }
  // console.log(obj, sortBy);
  let data = null;
  if (model === "user") {
    if (!obj.role) {
      obj.role = { $ne: "admin" };
    }
    obj = {
      ...obj,
      _id: { $ne: Mongoose.Types.ObjectId(userId) },
    };

    total = await User.find(obj).countDocuments();
    data = await User.aggregate([
      {
        $match: obj,
      },
      {
        $set: {
          numFollowing: { $size: "$following" },
          numFollowingCompany: { $size: "$followingCompany" },
          numFollowers: { $size: "$followers" },
          numJobs: { $size: "$jobs" },
          numSaveJobs: { $size: "$saveJobs" },
        },
      },
      {
        $project: {
          name: 1,
          avatar: 1,
          numSaveJobs: 1,
          numJobs: 1,
          numFollowers: 1,
          numFollowing: 1,
          numFollowingCompany: 1,
          createdAt: 1,
          role: 1,
          active: 1,
        },
      },
      {
        $sort: sortBy,
      },
      {
        $skip: startIndex,
      },
      {
        $limit: LIMIT,
      },
    ]);
  } else if (model === "post") {
    if (obj.name) {
      const rs = await Promise.all([
        User.find(obj).select("_id"),
        Company.find(obj).select("_id"),
      ]).then((rs) => rs);
      const ownerIds = rs.reduce((acc, cur) => {
        acc.push(
          ...cur.reduce((acc2, cur2) => {
            acc2.push(cur2._id);
            return acc2;
          }, [])
        );
        return acc;
      }, []);
      console.log(ownerIds);
      total = await Post.find({ ownerId: { $in: ownerIds } }).countDocuments();
      data = await Post.find({ ownerId: { $in: ownerIds } })
        .populate("numComments numReactions")
        .populate({
          path: "ownerId",
          select: "name avatar",
        })
        // .sort(sortBy)
        .skip(startIndex)
        .limit(LIMIT)
        .transform((doc) => {
          return doc.map((el) => {
            const { files, ...info } = el;
            let numImages = 0,
              numVideos = 0,
              numFiles = 0;
            files.forEach((file) => {
              if (file.resource_type === "image") {
                numImages++;
              } else if (file.resource_type === "video") {
                numVideos++;
              } else {
                numFiles++;
              }
            });
            return {
              ...info,
              numImages,
              numVideos,
              numFiles,
            };
          });
        })
        .lean();
    } else {
      total = await Post.find(obj).countDocuments();
      data = await Post.find(obj)
        .populate("numComments numReactions")
        .populate("ownerId", "name avatar")
        .sort(sortBy)
        .skip(startIndex)
        .limit(LIMIT)
        .transform((doc) => {
          return doc.map((el) => {
            const { files, ...info } = el;
            let numImages = 0,
              numVideos = 0,
              numFiles = 0;
            files.forEach((file) => {
              if (file.resource_type === "image") {
                numImages++;
              } else if (file.resource_type === "video") {
                numVideos++;
              } else {
                numFiles++;
              }
            });
            return {
              ...info,
              numImages,
              numVideos,
              numFiles,
            };
          });
        })
        .lean();
    }
  } else if (model === "job") {
    if (obj.company) {
      const tmp = await Company.find({
        name: obj.company,
      }).select("_id");
      obj = {
        ...obj,
        company: { $in: tmp.map((el) => el._id) },
      };
    }
    obj.deadline = {
      $gte: new Date(),
    };
    total = await Job.find(obj).countDocuments();
    data = await Job.aggregate([
      {
        $match: obj,
      },
      {
        $sort: sortBy,
      },
      {
        $skip: startIndex,
      },
      {
        $limit: LIMIT,
      },
      {
        $set: {
          numFollowers: { $size: "$followers" },
          numApplicants: { $size: "$applicants" },
        },
      },
      {
        $lookup: {
          from: "companies",
          localField: "company",
          foreignField: "_id",
          as: "arrCompany",
        },
      },
      {
        $lookup: {
          from: "categories",
          localField: "categories",
          foreignField: "_id",
          as: "categories",
        },
      },
      { $addFields: { company: { $first: "$arrCompany" } } },
      {
        $lookup: {
          from: "users",
          localField: "owner",
          foreignField: "_id",
          as: "arrOwner",
        },
      },
      { $addFields: { owner: { $first: "$arrOwner" } } },
      {
        $project: {
          _id: 1,
          title: 1,
          slug: 1,
          salary: 1,
          job_type: 1,
          numbers: 1,
          location: 1,
          numFollowers: 1,
          active: 1,
          numApplicants: 1,
          deadline: 1,
          "company.name": 1,
          "company.avatar": 1,
          "company._id": 1,
          "categories.name": 1,
          "owner.name": 1,
          "owner._id": 1,
          createdAt: 1,
          applicants: {
            $cond: {
              if: { $eq: ["$owner._id", Mongoose.Types.ObjectId(userId)] },
              then: "$applicants",
              else: [],
            },
          },
        },
      },
    ]);
  } else if (model === "company") {
    if (obj.industry) {
      const tmp = await Category.find({
        name: obj.industry,
      }).select("_id");
      obj = {
        ...obj,
        industry: { $in: tmp.map((el) => el._id) },
      };
    }
    total = await Company.find(obj).countDocuments();
    data = await Company.aggregate([
      {
        $match: obj,
      },
      {
        $set: {
          numFollowers: { $size: "$followers" },
        },
      },
      {
        $lookup: {
          from: "categories",
          localField: "industry",
          foreignField: "_id",
          as: "arrIndustry",
        },
      },
      { $addFields: { industry: { $first: "$arrIndustry" } } },
      {
        $project: {
          _id: 1,
          name: 1,
          owner: 1,
          avatar: 1,
          website: 1,
          overview: 1,
          active: 1,
          headquarters: 1,
          numFollowers: 1,
          "industry._id": 1,
          "industry.name": 1,
          createdAt: 1,
        },
      },
      {
        $sort: sortBy,
      },
      {
        $skip: startIndex,
      },
      {
        $limit: LIMIT,
      },
    ]);
  } else if (model === "category") {
    await Category.updateMany(
      {
        users: { $exists: false },
      },
      {
        $set: {
          users: [],
        },
      }
    );
    total = await Category.find(obj).countDocuments();
    data = await Category.aggregate([
      {
        $match: obj,
      },

      {
        $set: {
          numJobs: { $size: "$jobs" },
          numUsers: {
            $size: "$users",
          },
          numParents: {
            $size: "$parents",
          },
        },
      },
      {
        $lookup: {
          from: "categories",
          localField: "parents",
          foreignField: "_id",
          as: "arrParents",
        },
      },
      {
        $project: {
          name: 1,
          numJobs: 1,
          numUsers: 1,
          numParents: 1,
          "arrParents.name": 1,
          createdAt: 1,
        },
      },
      {
        $sort: sortBy,
      },
      {
        $skip: startIndex,
      },
      {
        $limit: LIMIT,
      },
    ]);
  }

  // console.log("rs", obj, sortBy);
  return {
    status: 200,
    data: {
      total,
      data,
      currentPage: PAGE,
      numberOfPages: Math.ceil(total / LIMIT),
    },
  };
};

exports.searchInputService = ({
  value,
  page,
  limit,
  operatorValue = "startsWith",
}) => {
  return Promise.all([
    this.searchModelService({
      model: "user",
      columnField: "name",
      operatorValue,
      value,
      page,
      limit,
      active: true,
    }),
    this.searchModelService({
      model: "job",
      columnField: "slug",
      operatorValue,
      value: convertToSlug(value),
      page,
      limit,
      active: true,
    }),
    this.searchModelService({
      model: "company",
      columnField: "name",
      operatorValue,
      value,
      page,
      limit,
      active: true,
    }),
    this.searchModelService({
      model: "category",
      columnField: "slug",
      operatorValue,
      value: convertToSlug(value),
      page,
      limit,
    }),
  ])
    .then((rs) => {
      return {
        status: 200,
        data: rs.reduce(
          (acc, cur) => {
            // console.log(cur);
            return {
              total: acc.total + cur.data.total,
              data: cur.data.data ? [...acc.data, ...cur.data.data] : acc.data,
            };
          },
          { total: 0, data: [] }
        ),
      };
    })
    .catch((err) => {
      console.log(err);
      return {
        status: 500,
        data: {
          message: "Internal Server Error",
        },
      };
    });
};

exports.totalModel = () => {
  return Promise.all([
    User.find({ role: { $ne: "admin" } }).countDocuments(),
    Post.countDocuments(),
    Job.countDocuments(),
    Company.countDocuments(),
  ])
    .then((rs) => {
      return {
        status: 200,
        data: rs,
      };
    })
    .catch((err) => {
      console.log(err);
      return {
        status: 500,
        data: {
          message: "Internal Server Error",
        },
      };
    });
};
