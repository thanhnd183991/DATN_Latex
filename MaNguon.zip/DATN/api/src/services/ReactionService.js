const Post = require("../models/PostModel");
const Reaction = require("../models/ReactionModel");
const PostService = require("../services/PostService");

exports.reactPostService = async (postId, reactionPost, userId) => {
  const cpost = await Post.findById(postId).populate({
    path: "ownerId",
    match: { active: true },
  });
  if (!cpost) {
    return {
      message: "Không tìm thấy bài viết",
      status: 404,
    };
  }
  const reaction = await Reaction.findOne({ postId: cpost._id, userId });
  if (!reaction) {
    const newReaction = new Reaction({
      postId: cpost._id,
      userId,
      reaction: reactionPost,
    });
    await newReaction.save();
  } else {
    if (reaction?.reaction === reactionPost) {
      await reaction.remove();
    } else {
      reaction.reaction = reactionPost;
      await reaction.save();
    }
  }
  const rs = await PostService.findPost(postId);
  return {
    data: rs.post,
    status: 200,
  };
};

exports.infoReactionPostService = async (postId, userId) => {
  const post = await Post.findById(postId).populate({
    path: "ownerId",
    match: { active: true },
  });
  if (!post) {
    return {
      message: "Không tìm thấy bài viết",
      status: 404,
    };
  }
  const reaction = await Reaction.find({ postId: post._id }).lean();
  const hasReaction = reaction.some((item) => String(item.userId) === userId);
  // console.log(userId, hasReaction);

  return {
    data: {
      countReaction: reaction.length,
      hasReaction,
    },
    status: 200,
  };
};

exports.numberOfReationService = async (postId) => {
  // console.log(postId);
  const rs = await Reaction.find({ postId });
  return {
    status: 200,
    numReaction: rs.length,
  };
};
