const User = require("../models/UserModel");
const MessageService = require("../services/MessageService");
const RoomService = require("../services/RoomService");
const PostConstant = require("../constants/PostConstant");
const { findUsersFromUserSockets } = require("./userSocket");

exports.postSocket = (io) => {
  io.on("connection", async (socket) => {
    // join post
    // console.log("post socket", socket.id);

    socket.on(PostConstant.JOIN_POST, async ({ posts, post }) => {
      // console.log(post, posts);
      if (posts) {
        posts.forEach((post) => {
          socket.join(post);
        });
      }
      if (post) {
        socket.join(post);
      }
    });

    // comment post
    socket.on(PostConstant.COMMENT_POST, ({ postId, rootId }, cb) => {
      // console.log("comment post");
      io.in(postId).emit(PostConstant.COMMENT_POST, { postId, rootId });
    });

    // reaction post
    socket.on(PostConstant.REACTION_POST, ({ postId }, cb) => {
      // console.log("reaction post");
      io.in(postId).emit(PostConstant.REACTION_POST, { postId });
    });

    // reaction comment post
    socket.on(PostConstant.REACTION_COMMENT_POST, ({ root, postId }, cb) => {
      // console.log("reaction comment post");
      io.in(postId).emit(PostConstant.REACTION_COMMENT_POST, {
        postId,
        root,
      });
    });

    // disconnect
    socket.on("disconnecting", () => {
      // console.log("post socket disconnecting");
      socket.leave();
    });
  });
};
