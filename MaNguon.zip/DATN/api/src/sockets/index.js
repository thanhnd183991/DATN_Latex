const { Server } = require("socket.io");
var globalIo;
const io = (server) => {
  if (server) {
    globalIo = new Server(server, {
      cors: {
        origin: "*",
      },
    });

    require("../middlewares/checkTokenInSocket")(globalIo);

    //user
    const { userSocket } = require("./userSocket");
    userSocket(globalIo);

    //chat
    const { chatSocket } = require("./chatSocket");
    chatSocket(globalIo);

    // notify
    const { notifySocket } = require("./notifySocket");
    notifySocket(globalIo);

    //post
    const { postSocket } = require("./postSocket");
    postSocket(globalIo.of("/post"));
  } else {
    return globalIo;
  }
};

module.exports = io;
