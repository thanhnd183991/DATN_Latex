const User = require("../models/UserModel");
const UserService = require("../services/UserService");
const NotificationService = require("../services/NotificationService");
const RoomService = require("../services/RoomService");
const _ = require("lodash");
// not ideal
const userSockets = [];

const pushUser = (userId, socketId) => {
  if (
    userSockets.some((el) => el.userId === userId && el.socketId === socketId)
  ) {
    return;
  }
  userSockets.push({
    userId,
    socketId,
  });
  console.log(userSockets);
};

exports.findUsersFromUserSockets = (userIds) => {
  let rs = [];
  userIds.forEach((userId) => {
    rs = [...rs, ...this.findUserFromUserSockets(userId)];
  });
  return rs;
};

exports.findUserFromUserSockets = (userId) => {
  // console.log(userId);
  return userSockets.filter((el) => el.userId === userId);
};

exports.findSocketFromUserSockets = (socketId) => {
  return userSockets.some((el) => el.socketId === socketId);
};

const deleteUserSocket = (socketId) => {
  const index = userSockets.findIndex((el) => el.socketId === socketId);
  if (index !== -1) {
    userSockets.splice(index, 1);
  }
  console.log(userSockets);
};

exports.userSocket = (io) => {
  io.on("connection", async (socket) => {
    // console.log("hi", socket.user, socket.id);
    pushUser(socket.user.id, socket.id);
    socket.on("user-init", async (cb) => {
      console.log("user-init");

      const countNotify = await NotificationService.getNotifyWhenOffline(
        socket.user.id
      );
      const chatNotify = await RoomService.getNotifyRoomWhenOffline(
        socket.user.id
      );

      if (socket.user.id) {
        await User.findByIdAndUpdate(socket.user.id, {
          status: "online",
        });
      }

      return cb({
        countNotify,
        chatNotify,
      });
    });

    socket.on("sign-in", async (userId) => {
      UserService.updateStatusUserService(socket.user.id, {
        status: "online",
        lastActivity: Date.now(),
      })
        .then(() => {
          userSockets.push({
            userId: socket.user.id,
            socketId: socket.id,
          });
        })
        .catch((err) => console.log(err));
    });

    // socket.on("sign-out", async (userId) => {
    //   const rooms = [...socket.rooms];
    //   rooms.forEach((roomId) => {
    //     socket.in(roomId).emit(ACTIONS.DISCONNECTED, {
    //       socketId: socket.id,
    //       username: userSocketMap[socket.id],
    //     });
    //   });
    //   delete userSocketMap[socket.id];
    //   await UserService.updateStatusUserService(socket.user.id, {
    //     status: "offline",
    //     lastActivity: Date.now(),
    //   });
    //   socket.leave();
    // });

    socket.on("disconnecting", async () => {
      // const rooms = [...socket.rooms];
      // rooms.forEach((roomId) => {
      //   socket.in(roomId).emit(ACTIONS.DISCONNECTED, {
      //     socketId: socket.id,
      //     username: userSocketMap[socket.id],
      //   });
      // });
      // delete userSocketMap[socket.id];
      await User.findByIdAndUpdate(socket.user.id, {
        status: "offline",
        lastActivity: Date.now(),
      });

      console.log("disconnecting");
      deleteUserSocket(socket.id);
      socket.leave();
    });
  });
};
