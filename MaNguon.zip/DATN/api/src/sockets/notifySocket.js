const User = require("../models/UserModel");
const NotificationService = require("../services/NotificationService");
const UserService = require("../services/UserService");
const PostService = require("../services/PostService");
const RoomService = require("../services/RoomService");
const CompanyService = require("../services/CompanyService");
const JobService = require("../services/JobService");
const NotifyConstant = require("../constants/NotifyConstant");
const {
  findUsersFromUserSockets,
  findUserFromUserSockets,
} = require("./userSocket");

exports.notifySocket = (io) => {
  io.on("connection", async (socket) => {
    // follow user
    socket.on(NotifyConstant.FOLLOW_USER, async ({ otherId }, cb) => {
      const rs = await UserService.followUser(otherId, socket.user);
      if (rs.status === 200) {
        let sendToUsers;
        if (rs.isFollowed) {
          // đã follow trước đó
          sendToUsers = findUserFromUserSockets(socket.user.id);
        } else {
          sendToUsers = findUsersFromUserSockets([otherId, socket.user.id]);
        }
        if (sendToUsers.length > 0) {
          sendToUsers.forEach((item) => {
            // console.log(item);
            // console.log(io());
            io.to(item.socketId).emit(
              NotifyConstant.FOLLOW_USER,
              item.userId === socket.user.id
                ? {
                    // nếu là mình thì gửi rs follow
                    message: rs.message,
                  }
                : {
                    // là người dùng khác thì gửi thông báo có người vừa theo dõi
                    data: rs.notify,
                  }
            );
          });
        }
      } else {
        console.log(rs.message);
        cb({ error: rs.message });
      }
    });

    // follow company
    socket.on(NotifyConstant.FOLLOW_COMPANY, async ({ companyId }, cb) => {
      console.log("follow company");
      const rs = await UserService.followCompany(companyId, socket.user);
      if (rs.status === 200) {
        let sendToUsers;
        if (rs.isFollowed) {
          // đã follow trước đó
          sendToUsers = findUserFromUserSockets(socket.user.id);
        } else {
          sendToUsers = findUsersFromUserSockets([
            rs.notify.receiver[0].user?._id.toString() ||
              rs.notify.receiver[0].user?.toString(),
            socket.user.id,
          ]);
        }
        console.log(sendToUsers);
        if (sendToUsers.length > 0) {
          sendToUsers.forEach((item) => {
            io.to(item.socketId).emit(
              NotifyConstant.FOLLOW_COMPANY,
              item.userId === socket.user.id
                ? {
                    // nếu là mình thì gửi rs follow
                    message: rs.message,
                  }
                : {
                    // là người dùng khác thì gửi thông báo có người vừa theo dõi
                    data: rs.notify,
                  }
            );
          });
        }
      } else {
        console.log(rs.message);
        cb({ error: rs.message });
      }
    });

    // follow job sorry func cancel not active in fe
    socket.on(NotifyConstant.FOLLOW_JOB, async ({ jobId }, cb) => {
      const rs = await UserService.followJob(jobId, socket.user);
      if (rs.status === 200) {
        let sendToUsers;
        if (rs.isFollowed) {
          // đã follow trước đó
          sendToUsers = findUserFromUserSockets(socket.user.id);
        } else {
          sendToUsers = findUsersFromUserSockets([
            rs.notify.receiver[0].user?._id.toString() ||
              rs.notify.receiver[0].user?.toString(),
            socket.user.id,
          ]);
        }
        console.log(sendToUsers);
        if (sendToUsers.length > 0) {
          sendToUsers.forEach((item) => {
            io.to(item.socketId).emit(
              NotifyConstant.FOLLOW_JOB,
              item.userId === socket.user.id
                ? {
                    // nếu là mình thì gửi rs follow
                    message: rs.message,
                  }
                : {
                    // là người dùng khác thì gửi thông báo có người vừa theo dõi
                    data: rs.notify,
                  }
            );
          });
        }
      } else {
        console.log(rs.message);
        cb({ error: rs.message });
      }
    });

    // change owner job
    socket.on(
      NotifyConstant.CHANGE_OWNER,
      async ({ oldId, newId, jobId }, cb) => {
        const rs = await NotificationService.changeOwnerJobNotify(
          oldId,
          newId,
          jobId
        );
        if (rs.status === 200) {
          if (rs.sendToUsers.length > 0) {
            rs.sendToUsers.forEach((item) => {
              io.to(item.socketId).emit(NotifyConstant.CHANGE_OWNER, {
                data: rs.notify,
              });
            });
          }
        } else {
          cb({ error: rs.message });
        }
      }
    );

    // apply job
    socket.on(NotifyConstant.APPLY_JOB, async ({ jobId, applicantId }, cb) => {
      const rs = await NotificationService.applyJobNotify(jobId, applicantId);
      if (rs.status === 200) {
        if (rs.sendToUsers.length > 0) {
          rs.sendToUsers.forEach((item) => {
            io.to(item.socketId).emit(NotifyConstant.APPLY_JOB, {
              data: rs.notify,
            });
          });
        }
      } else {
        cb({ error: rs.message });
      }
    });

    // confirm apply job
    socket.on(
      NotifyConstant.CONFIRM_APPLY_JOB,
      async ({ ownerId, userId, jobId, desc }, cb) => {
        const rs = await NotificationService.confirmApplyJob(
          ownerId,
          userId,
          jobId,
          desc
        );

        if (rs.status === 200) {
          let sendToUsers;
          sendToUsers = findUserFromUserSockets(userId);
          if (sendToUsers.length > 0) {
            sendToUsers.forEach((item) => {
              io.to(item.socketId).emit(NotifyConstant.CONFIRM_APPLY_JOB, {
                data: rs.notify,
              });
            });
          }
          cb({ success: rs.message });
        } else {
          cb({ error: rs.message });
        }
      }
    );

    // add member
    socket.on(
      NotifyConstant.ADD_MEMBER,
      async ({ companyId, employees }, cb) => {
        const rs = await CompanyService.addEmployeesService(
          companyId,
          employees,
          socket.user.id
        );
        if (rs.status === 200) {
          let sendToUsers;
          sendToUsers = findUserFromUserSockets(
            rs.notify.receiver[0].user?.toString() ||
              rs.notify.receiver[0].user?._id.toString()
          );
          console.log(sendToUsers);
          if (sendToUsers.length > 0) {
            sendToUsers.forEach((item) => {
              io.to(item.socketId).emit(NotifyConstant.ADD_MEMBER, {
                // là người dùng khác thì gửi thông báo có người vừa theo dõi
                data: rs.notify,
              });
            });
          }
          cb({ success: rs.message });
        } else {
          console.log(rs.message);
          cb({ error: rs.message });
        }
      }
    );

    // confirm add member
    socket.on(
      NotifyConstant.CONFIRM_ADD_MEMBER,
      async ({ notifyId, status }, cb) => {
        if (
          !(
            status === NotifyConstant.ACCEPTED ||
            status === NotifyConstant.REJECTED
          )
        ) {
          return cb({ error: "status invalid" });
        }

        const rs = await NotificationService.confirmAddEmployeeNotify(
          notifyId,
          socket.user.id,
          status
        );
        if (rs.status === 200) {
          let sendToUsers;
          sendToUsers = findUsersFromUserSockets([
            rs.notify.receiver[0].user?._id?.toString() ||
              rs.notify.receiver[0].user?.toString(),
            rs.notify.sender.owner._id.toString(),
          ]);
          console.log("confirm add member", sendToUsers);
          if (sendToUsers.length > 0) {
            sendToUsers.forEach((item) => {
              io.to(item.socketId).emit(NotifyConstant.CONFIRM_ADD_MEMBER, {
                // nếu là người dùng thì hiển thị thông báo kết quả
                data: rs.notify,
              });
            });
          }
        } else {
          console.log(rs.message);
          return cb({ error: rs.message });
        }
      }
    );

    // confirm delete member
    socket.on(
      NotifyConstant.CONFIRM_DELETE_MEMBER,
      async ({ companyId, employees }, cb) => {
        const rs = await NotificationService.removeEmployeeNotify(
          companyId,
          employees
        );
        if (rs.status === 200) {
          if (rs.sendToUsers.length > 0) {
            rs.sendToUsers.forEach((item) => {
              io.to(item.socketId).emit(NotifyConstant.CONFIRM_DELETE_MEMBER, {
                // nếu là người dùng thì hiển thị thông báo kết quả
                data: rs.notify,
              });
            });
          }
        } else {
          console.log(rs.message);
          return cb({ error: rs.message });
        }
      }
    );

    // connect job
    socket.on(NotifyConstant.CONNECT_JOB, async ({ jobId, userId }, cb) => {
      const findRoom = await RoomService.findCompanyRoom(
        userId,
        socket.user.id,
        jobId
      );

      if (findRoom.status !== 200) {
        return cb({ error: findRoom.message });
      }

      if (findRoom.active && findRoom.isConnected) {
        return cb({
          data: findRoom.room,
        });
      }

      // else create notify

      const rs = await NotificationService.connectJobNotify(
        jobId,
        userId,
        socket.user.id
      );

      if (rs.status !== 200) {
        return cb({ error: rs.message });
      }

      sendToUsers = findUserFromUserSockets(
        rs.notify.receiver[0].user?._id.toString() ||
          rs.notify.receiver[0].user?.toString()
      );
      console.log(sendToUsers);
      if (sendToUsers.length > 0) {
        sendToUsers.forEach((item) => {
          io.to(item.socketId).emit(NotifyConstant.CONNECT_JOB, {
            // nếu là người dùng thì hiển thị thông báo kết quả
            data: rs.notify,
          });
        });
      }
      return cb({ success: rs.message });
    });

    // connect user
    socket.on(NotifyConstant.CONNECT_USER, async ({ receiverId }, cb) => {
      const findRoom = await RoomService.findPersonalRoom(
        socket.user.id,
        receiverId
      );

      if (findRoom.status !== 200) {
        return cb({ error: findRoom.message });
      }

      if (findRoom.isConnected) {
        return cb({
          data: findRoom.room,
        });
      }

      // else create notify

      const rs = await NotificationService.connectUserNotify(
        socket.user.id,
        receiverId
      );

      if (rs.status !== 200) {
        return cb({ error: rs.message });
      }

      const sendToUsers = findUserFromUserSockets(
        rs.notify.receiver[0].user?._id.toString() ||
          rs.notify.receiver[0].user?.toString()
      );
      console.log(sendToUsers);
      if (sendToUsers.length > 0) {
        sendToUsers.forEach((item) => {
          io.to(item.socketId).emit(NotifyConstant.CONNECT_USER, {
            data: rs.notify,
          });
        });
      }

      return cb({ success: rs.message });
    });

    // confirm connect job
    socket.on(
      NotifyConstant.CONFIRM_CONNECT_JOB,
      async ({ notifyId, status }, cb) => {
        if (
          status === NotifyConstant.ACCEPTED ||
          status === NotifyConstant.REJECTED
        ) {
          const rs = await NotificationService.confirmConnectJobNotify(
            notifyId,
            socket.user.id,
            status
          );
          if (rs.status === 200) {
            let sendToUsers;
            sendToUsers = findUsersFromUserSockets([
              rs.notify.receiver[0].user?._id.toString() ||
                rs.notify.receiver[0].user?.toString(),
              rs.notify.sender?._id.toString() || rs.notify.sender?.toString(),
            ]);
            console.log(sendToUsers);
            const payload =
              status === NotifyConstant.ACCEPTED
                ? {
                    data: rs.notify,
                    dataMessage: {
                      typeRoom: rs.room.roomType,
                      data: rs.room.latestMessage,
                      roomId: rs.room._id,
                    },
                  }
                : {
                    data: rs.notify,
                  };
            if (sendToUsers.length > 0) {
              sendToUsers.forEach((item) => {
                io.to(item.socketId).emit(
                  NotifyConstant.CONFIRM_CONNECT_JOB,
                  payload
                );
              });
            }
          } else {
            console.log(rs.message);
            return cb({ error: rs.message });
          }
        } else {
          return cb({ error: "status invalid" });
        }
      }
    );

    // confirm connect user
    socket.on(
      NotifyConstant.CONFIRM_CONNECT_USER,
      async ({ notifyId, status }, cb) => {
        if (
          status === NotifyConstant.ACCEPTED ||
          status === NotifyConstant.REJECTED
        ) {
          const rs = await NotificationService.confirmConnectUser(
            notifyId,
            status,
            socket.user.id
          );
          if (rs.status === 200) {
            console.log("confirm connect user", rs);
            let sendToUsers;
            sendToUsers = findUsersFromUserSockets([
              rs.notify.receiver[0].user?._id.toString() ||
                rs.notify.receiver[0].user?.toString(),
              rs.notify.sender?._id.toString() || rs.notify.sender?.toString(),
            ]);
            console.log(
              "sendtouser confirm connect user",
              sendToUsers,
              rs.notify.receiver[0].user?._id.toString() ||
                rs.notify.receiver[0].user?.toString(),
              rs.notify.sender?._id.toString() || rs.notify.sender?.toString()
            );
            if (sendToUsers.length > 0) {
              sendToUsers.forEach((item) => {
                io.to(item.socketId).emit(NotifyConstant.CONFIRM_CONNECT_USER, {
                  data: rs.notify,
                });
              });
            }
            return cb({ success: rs.message });
          } else {
            console.log(rs.message);
            return cb({ error: rs.message });
          }
        } else {
          return cb({ error: "status invalid" });
        }
      }
    );

    // these are the events called when call api before after call socket notify
    // create post
    socket.on(NotifyConstant.CREATE_POST, async ({ postId }, cb) => {
      const rs = await NotificationService.createPostNotify(postId);
      if (rs.status === 200) {
        if (rs.sendToUsers.length > 0) {
          rs.sendToUsers.forEach((item) => {
            io.to(item.socketId).emit(NotifyConstant.CREATE_POST, {
              // nếu là người dùng thì hiển thị thông báo kết quả
              data: rs.notify,
            });
          });
        }
        cb({ success: rs.message });
      } else {
        cb({ error: rs.message });
      }
    });

    // create job for admin,
    socket.on(NotifyConstant.CREATE_JOB_FOR_ADMIN, async ({ jobId }, cb) => {
      const rs = await NotificationService.createJobForAdminNotify(jobId);
      if (rs.status === 200) {
        if (rs.sendToUsers.length > 0) {
          rs.sendToUsers.forEach((item) => {
            io.to(item.socketId).emit(NotifyConstant.CREATE_JOB_FOR_ADMIN, {
              // nếu là người dùng thì hiển thị thông báo kết quả
              data: rs.notify,
            });
          });
        }
        cb({ success: rs.message });
      } else {
        cb({ error: rs.message });
      }
    });

    // create job for user
    socket.on(NotifyConstant.CREATE_JOB_FOR_USER, async ({ jobId }, cb) => {
      const rs = await NotificationService.createJobForUserNotify(jobId);
      if (rs.status === 200) {
        if (rs.sendToUsers.length > 0) {
          rs.sendToUsers.forEach((item) => {
            io.to(item.socketId).emit(NotifyConstant.CREATE_JOB_FOR_USER, {
              // nếu là người dùng thì hiển thị thông báo kết quả
              data: rs.notify,
            });
          });
        }
        cb({ success: rs.message });
      } else {
        cb({ error: rs.message });
      }
    });

    // confirm job by admin,
    socket.on(NotifyConstant.CONFIRM_JOB, async ({ notifyId, status }, cb) => {
      if (
        status === NotifyConstant.ACCEPTED ||
        status === NotifyConstant.REJECTED
      ) {
        const rs = await NotificationService.confirmJobByAdminNotify(
          notifyId,
          socket.user.id,
          status
        );
        if (rs.status === 200) {
          if (rs.sendToUsers.length > 0) {
            rs.sendToUsers.forEach((item) => {
              io.to(item.socketId).emit(NotifyConstant.CONFIRM_JOB, {
                // nếu là người dùng thì hiển thị thông báo kết quả
                data: rs.notify,
              });
            });
          }
          cb({ success: rs.message, data: rs.notify });
        } else {
          cb({ error: rs.message });
        }
      } else {
        cb({ error: "status invalid" });
      }
    });

    // create company,
    socket.on(NotifyConstant.CREATE_COMPANY, async ({ companyId }, cb) => {
      console.log("socket create company", companyId);
      const rs = await NotificationService.createCompanyNotify(companyId);
      if (rs.status === 200) {
        console.log("socket create rs ", rs);
        if (rs.sendToUsers.length > 0) {
          rs.sendToUsers.forEach((item) => {
            io.to(item.socketId).emit(NotifyConstant.CREATE_COMPANY, {
              // nếu là người dùng thì hiển thị thông báo kết quả
              data: rs.notify,
            });
          });
        }
        cb({ success: rs.message });
      } else {
        cb({ error: rs.message });
      }
    });

    // confirm company notify
    socket.on(
      NotifyConstant.CONFIRM_COMPANY,
      async ({ notifyId, companyId, status }, cb) => {
        if (socket.user.role !== "admin") {
          return cb({ error: "you are not admin" });
        }
        const rs = await NotificationService.confirmCompanyNotify(
          notifyId,
          companyId,
          socket.user.id,
          status
        );
        if (rs.status === 200) {
          if (rs.sendToUsers.length > 0) {
            rs.sendToUsers.forEach((item) => {
              io.to(item.socketId).emit(NotifyConstant.CONFIRM_COMPANY, {
                // nếu là người dùng thì hiển thị thông báo kết quả
                data: rs.notify,
              });
            });
          }
          cb({ success: rs.message, data: rs.notify });
        } else {
          cb({ error: rs.message });
        }
      }
    );

    // create report notify post
    socket.on(
      NotifyConstant.CREATE_REPORT_POST,
      async ({ access, onAccess, message, desc }, cb) => {
        const rs = await NotificationService.createReport(
          access,
          onAccess,
          message,
          desc,
          socket.user.id
        );
        if (rs.status === 200) {
          if (rs.sendToUsers.length > 0) {
            rs.sendToUsers.forEach((item) => {
              io.to(item.socketId).emit(
                onAccess === "Post"
                  ? NotifyConstant.CREATE_REPORT_POST
                  : NotifyConstant.CREATE_REPORT_JOB,
                {
                  data: rs.notify,
                }
              );
            });
          }
          cb({ success: rs.message, data: rs.notify });
        } else {
          cb({ error: rs.message });
        }
      }
    );

    // create report notify job
    socket.on(
      NotifyConstant.CREATE_REPORT_JOB,
      async ({ access, onAccess, message, desc }, cb) => {
        const rs = await NotificationService.createReport(
          access,
          onAccess,
          message,
          desc,
          socket.user.id
        );
        if (rs.status === 200) {
          if (rs.sendToUsers.length > 0) {
            rs.sendToUsers.forEach((item) => {
              io.to(item.socketId).emit(
                onAccess === "Post"
                  ? NotifyConstant.CREATE_REPORT_POST
                  : NotifyConstant.CREATE_REPORT_JOB,
                {
                  data: rs.notify,
                }
              );
            });
          }
          cb({ success: rs.message, data: rs.notify });
        } else {
          cb({ error: rs.message });
        }
      }
    );

    // confirm report post
    socket.on(
      NotifyConstant.CONFIRM_REPORT_POST,
      async ({ notifyId, status }, cb) => {
        if (socket.user.role !== "admin") {
          return cb({ error: "you are not admin" });
        }
        if (
          status === NotifyConstant.ACCEPTED ||
          status === NotifyConstant.REJECTED
        ) {
          const rs = await NotificationService.confirmReport(notifyId, status);
          if (rs.status === 200) {
            if (status === NotifyConstant.ACCEPTED) {
              const tmp = await PostService.deletePostService(
                rs.notify.access._id || rs.notify.access,
                { role: "admin" }
              );
              if (tmp.status !== 200) {
                return cb({ error: tmp.message });
              }
            }
            if (rs.sendToUsers.length > 0) {
              rs.sendToUsers.forEach((item) => {
                io.to(item.socketId).emit(
                  rs.notify.onAccess === "Post"
                    ? NotifyConstant.CONFIRM_REPORT_POST
                    : NotifyConstant.CONFIRM_REPORT_JOB,
                  {
                    // nếu là người dùng thì hiển thị thông báo kết quả
                    data: rs.notify,
                  }
                );
              });
            }
            cb({ success: rs.message });
          } else {
            cb({ error: rs.message });
          }
        } else {
          cb({ error: "status invalid" });
        }
      }
    );

    // confirm report job
    socket.on(
      NotifyConstant.CONFIRM_REPORT_JOB,
      async ({ notifyId, status }, cb) => {
        if (socket.user.role !== "admin") {
          return cb({ error: "you are not admin" });
        }
        if (
          status === NotifyConstant.ACCEPTED ||
          status === NotifyConstant.REJECTED
        ) {
          const rs = await NotificationService.confirmReport(notifyId, status);
          if (rs.status === 200) {
            if (status === NotifyConstant.ACCEPTED) {
              const tmp = await JobService.confirmJob(
                rs.notify.access._id || rs.notify.access,
                socket.user.id,
                false
              );
              if (tmp.status !== 200) {
                return cb({ error: tmp.message });
              }
            }
            if (rs.sendToUsers.length > 0) {
              rs.sendToUsers.forEach((item) => {
                io.to(item.socketId).emit(
                  rs.notify.onAccess === "Post"
                    ? NotifyConstant.CONFIRM_REPORT_POST
                    : NotifyConstant.CONFIRM_REPORT_JOB,
                  {
                    // nếu là người dùng thì hiển thị thông báo kết quả
                    data: rs.notify,
                  }
                );
              });
            }
            cb({ success: rs.message });
          } else {
            cb({ error: rs.message });
          }
        } else {
          cb({ error: "status invalid" });
        }
      }
    );
  });
};
