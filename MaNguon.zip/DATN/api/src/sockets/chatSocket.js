const User = require("../models/UserModel");
const MessageService = require("../services/MessageService");
const RoomService = require("../services/RoomService");
const ChatConstant = require("../constants/ChatConstant");
const { findUsersFromUserSockets } = require("./userSocket");

exports.chatSocket = (io) => {
  io.on("connection", async (socket) => {
    // join room
    socket.on(ChatConstant.JOIN_ROOM, async ({ rooms, room }) => {
      if (rooms) {
        rooms.forEach((room) => {
          socket.join(room);
        });
      }
      if (room) {
        socket.join(room);
      }
    });

    // block room
    socket.on(ChatConstant.BLOCK_ROOOM, async ({ roomId, active }, cb) => {
      let rs;
      if (active) {
        rs = await RoomService.unBlockRoom(roomId, socket.user.id, false);
      } else {
        rs = await RoomService.blockRoom(roomId, socket.user.id);
      }
      if (rs.status !== 200) {
        return cb({ error: rs.message });
      }

      const sendToUsers = findUsersFromUserSockets(
        rs.data.members.map((el) => el._id.toString())
      );
      if (sendToUsers.length > 0) {
        sendToUsers.forEach((item) => {
          // console.log(item);
          // console.log(io());
          io.to(item.socketId).emit(ChatConstant.BLOCK_ROOOM, {
            data: rs.data,
          });
        });
      }
    });

    // create message
    socket.on(ChatConstant.CREATE_MESSAGE, async ({ roomId, message }, cb) => {
      const rs = await MessageService.createMessage(roomId, {
        ...message,
        sender: socket.user.id,
      });
      if (rs.status === 200) {
        // gửi đến tất cả các user trong phòng
        const sendToUsers = findUsersFromUserSockets(
          rs.room.members.map((el) => el.toString())
        );
        if (sendToUsers.length > 0) {
          sendToUsers.forEach((item) => {
            // console.log(item);
            // console.log(io());
            io.to(item.socketId).emit(ChatConstant.CREATE_MESSAGE, {
              data: rs.data,
              typeRoom: rs.room.roomType,
            });
          });
        }
        cb({});
      } else {
        cb({
          error: rs.message,
        });
      }
    });

    // reaction message
    socket.on(
      ChatConstant.REACTION_MESSAGE,
      async ({ messageId, reaction }, cb) => {
        const rs = await MessageService.reactionMessage(messageId, {
          ...reaction,
          userId: socket.user.id,
        });

        if (rs.status === 200) {
          // gửi đến tất cả các user trong phòng
          const sendToUsers = findUsersFromUserSockets(
            rs.room.members.map((el) => el.toString())
          );
          if (sendToUsers.length > 0) {
            sendToUsers.forEach((item) => {
              // console.log(item);
              // console.log(io());
              io.to(item.socketId).emit(ChatConstant.REACTION_MESSAGE, {
                data: rs.data,
              });
            });
          }
        } else {
          console.log(rs.message);
          cb({ error: rs.message });
        }
      }
    );

    // remove message
    socket.on(ChatConstant.REMOVE_MESSAGE, async ({ messageId }) => {
      const rs = await MessageService.removeMessage(messageId, socket.user.id);

      if (rs.status === 200) {
        // gửi đến tất cả các user trong phòng
        const sendToUsers = findUsersFromUserSockets(
          rs.room.members.map((el) => el.toString())
        );
        if (sendToUsers.length > 0) {
          sendToUsers.forEach((item) => {
            // console.log(item);
            // console.log(io());
            io.to(item.socketId).emit(ChatConstant.REACTION_MESSAGE, {
              data: rs.data,
            });
          });
        }
      } else {
      }
    });
  });
};
