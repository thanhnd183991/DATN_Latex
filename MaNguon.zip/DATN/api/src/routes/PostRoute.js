const router = require("express").Router();
const { isAuth, isAdmin } = require("../middlewares/verifyId");
const {
  findPost,
  createPost,
  listPost,
  listPostByUser,
  listPostByCompany,
  listPostByFeed,
  searchPost,
  countPostType,
  postStats,
  deletePost,
} = require("../controllers/PostController");

const {
  reactPost,
  infoReactionPost,
  numberOfReaction,
} = require("../controllers/ReactionController");

const {
  createComment,
  reactionComment,
  replyComment,
  infoRootComment,
  infoChildrenComment,
  infoCountComment,
} = require("../controllers/CommentController");

const { validateREST } = require("../middlewares/yup_validation/index");
const CommentValidation = require("../middlewares/yup_validation/CommentValidation");
const PostValidation = require("../middlewares/yup_validation/PostValidation");

//post

//admin
router.get("/admin/countType", isAuth, isAdmin, countPostType);
router.get("/admin/stats", isAuth, isAdmin, postStats);

router.delete("/delete/:postId", isAuth, deletePost);
//user
router.post(
  "/create",
  isAuth,
  validateREST(PostValidation.formCreatePostSchema),
  createPost
);
router.get("/find/:postId", isAuth, findPost);
router.get("/list", isAuth, listPost);
router.get("/search", isAuth, searchPost);
router.get("/list-user", isAuth, listPostByUser);
router.get("/list-company/:companyId", isAuth, listPostByCompany);
router.get("/list-feed", isAuth, listPostByFeed);

//reaction
router.post("/reaction/:postId", isAuth, reactPost);
router.get("/info-reaction/:postId", isAuth, infoReactionPost);
router.get("/reaction/numbers/:postId", isAuth, numberOfReaction);

//comment
router.get(
  "/root-comment/:postId",
  isAuth,
  validateREST(CommentValidation.formInfoRootCommentSchema),
  infoRootComment
);
router.get(
  "/children-comment/:commentId",
  isAuth,
  validateREST(CommentValidation.formInfoChildrenCommentSchema),
  infoChildrenComment
);
router.get(
  "/count-comment/:postId",
  isAuth,
  validateREST(CommentValidation.formInfoCountCommentSchema),
  infoCountComment
);

router.post(
  "/comment/create/:postId",
  isAuth,
  validateREST(CommentValidation.formCreateCommentSchema),
  createComment
);
router.post(
  "/comment/reply",
  isAuth,
  validateREST(CommentValidation.formReplyCommentSchema),
  replyComment
);
router.post(
  "/comment/reaction",
  isAuth,
  validateREST(CommentValidation.formReactionCommentSchema),
  reactionComment
);

module.exports = router;
