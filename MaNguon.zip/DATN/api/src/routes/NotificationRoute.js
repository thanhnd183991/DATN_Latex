const router = require("express").Router();
const { isAuth } = require("../middlewares/verifyId");
const {
  getListNotifications,
  confirmAddMember,
  connectUser,
  confirmConnectUser,
  confirmConnectJob,
  connectJob,
} = require("../controllers/NotificationController");

const { validateREST } = require("../middlewares/yup_validation/index");
const NotificationValidation = require("../middlewares/yup_validation/NotificationValidation");

router.put(
  "/confirm-add-member/:notifyId",
  isAuth,
  validateREST(NotificationValidation.formConfirmAddMemberSchema),
  confirmAddMember
);

router.post(
  "/connect-user",
  isAuth,
  validateREST(NotificationValidation.formConnectUserSchema),
  connectUser
);

router.put(
  "/confirm-connect-user/:notifyId",
  isAuth,
  validateREST(NotificationValidation.formConfirmConnectUserSchema),
  confirmConnectUser
);

router.post(
  "/connect-job",
  isAuth,
  validateREST(NotificationValidation.formConnectJobSchema),
  connectJob
);

router.put(
  "/confirm-connect-job/:notifyId",
  isAuth,
  validateREST(NotificationValidation.formConfirmConnectJobSchema),
  confirmConnectJob
);

router.get(
  "/",
  isAuth,
  validateREST(NotificationValidation.formListNotificationSchema),
  getListNotifications
);

module.exports = router;
