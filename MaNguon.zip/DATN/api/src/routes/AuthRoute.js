const router = require("express").Router();
const {
  signup,
  login,
  forgotPassword,
  changePassword,
  updatePassword,
  resetDB,
} = require("../controllers/AuthController.js");

const {
  formLoginSchema,
  formSignupSchema,
  formForgotPasswordSchema,
  formChangePasswordSchema,
  formUpdatePasswordSchema,
} = require("../middlewares/yup_validation/AuthValidation");
const {
  validateREST: validate,
} = require("../middlewares/yup_validation/index");

//REGISTER
router.post("/signup", signup);

//LOGIN
router.post("/login", validate(formLoginSchema), login);

//FORGOT-PASSWORD
router.post(
  "/forgot-password",
  validate(formForgotPasswordSchema),
  forgotPassword
);

//CHANGE-PASSWORD
router.post(
  "/change-password",
  validate(formChangePasswordSchema),
  changePassword
);

//UPDATE-PASSWORD
router.post(
  "/update-password",
  validate(formUpdatePasswordSchema),
  updatePassword
);

//RESET-DB
router.get("/reset", resetDB);

module.exports = router;
