const router = require("express").Router();
const { isAuth, isAdmin } = require("../middlewares/verifyId");
const { searchExperience } = require("../controllers/ExperienceController");

const { validateREST } = require("../middlewares/yup_validation/index");
const SearchValidation = require("../middlewares/yup_validation/SearchValidation");

router.get(
  "/search",
  isAuth,
  validateREST(SearchValidation.formSearchSuggestionSchema),
  searchExperience
);

module.exports = router;
