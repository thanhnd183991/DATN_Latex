const router = require("express").Router();
const { isAuth, isAdmin } = require("../middlewares/verifyId");
const {
  searchUser,
  infoUser,
  followingUser,
  acceptCompany,
  deleteUser,
  activeUser,
  followingCompany,
  followingJob,
  updateSkills,
  updateLanguages,
  updateEducations,
  suggestionUser,
  applyJobCartUser,
  saveJobCartUser,
  updateFieldStringObjectUser,
  listFollowByUser,
  listEmployee,
  userStats,
  userStatus,
  searchUserBySkill,
  updateExperience,
} = require("../controllers/UserController");

const { validateREST } = require("../middlewares/yup_validation/index");
const UserValidation = require("../middlewares/yup_validation/UserVadlidation");

router.get(
  "/search-by-skill",
  isAuth,
  validateREST(UserValidation.formSearchUserBySkillSchema),
  searchUserBySkill
);

router.get("/admin/status", isAuth, isAdmin, userStatus);

router.get("/admin/stats", isAuth, isAdmin, userStats);

router.get(
  "/search",
  isAuth,
  validateREST(UserValidation.formSearchUserSchema),
  searchUser
);

router.get("/list-employee", isAuth, listEmployee);

router.get("/suggestion", isAuth, suggestionUser);
router.get("/list-follow-by-user", isAuth, listFollowByUser);
router.get("/save-job-cart", isAuth, saveJobCartUser);
router.get("/apply-job-cart", isAuth, applyJobCartUser);
router.get(
  "/info/:userId",
  isAuth,
  validateREST(UserValidation.formInfoUserSchema),
  infoUser
);

router.put(
  "/following/",
  isAuth,
  validateREST(UserValidation.formFollowingUserSchema),
  followingUser
);
router.put(
  "/following-company/",
  isAuth,
  validateREST(UserValidation.formFollowingCompanySchema),
  followingCompany
);
router.put(
  "/following-job/",
  isAuth,
  validateREST(UserValidation.formFollowingJobSchema),
  followingJob
);
router.put(
  "/accept-company/",
  isAuth,
  validateREST(UserValidation.formAcceptCompanySchema),
  acceptCompany
);

router.put(
  "/update-string-object/",
  isAuth,
  validateREST(UserValidation.formUpdateFieldStringSchema),
  updateFieldStringObjectUser
);

router.put(
  "/active/:userId",
  isAuth,
  isAdmin,
  validateREST(UserValidation.formActiveUserSchema),
  activeUser
);
router.delete(
  "/delete/:userId",
  isAuth,
  isAdmin,
  validateREST(UserValidation.formDeleteUserSchema),
  deleteUser
);
router.put(
  "/update-skills",
  isAuth,
  validateREST(UserValidation.formUpdateSkillSchema),
  updateSkills
);
router.put(
  "/update-educations",
  isAuth,
  validateREST(UserValidation.formUpdateEducationSchema),
  updateEducations
);

router.put(
  "/update-languages",
  isAuth,
  validateREST(UserValidation.formUpdateLanguageSchema),
  updateLanguages
);

router.put(
  "/update-experiences",
  isAuth,
  validateREST(UserValidation.formUpdateExpSchema),
  updateExperience
);
module.exports = router;
