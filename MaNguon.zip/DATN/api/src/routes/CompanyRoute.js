const router = require("express").Router();
const {
  isAuth,
  isManager,
  isAdmin,
  isEmployee,
} = require("../middlewares/verifyId");
const {
  createCompany,
  updateCompany,
  listCompany,
  confirmCompany,
  addEmployees,
  removeEmployees,
  membersCompany,
  suggestionCompany,
  infoCompany,
  listUserFollowCompany,
  countJobByCompany,
  statsCompany,
  statusCompany,
  statusOneCompany,
  getCompanyBySkill,
} = require("../controllers/CompanyController");

const { validateREST } = require("../middlewares/yup_validation/index");
const CompanyValidation = require("../middlewares/yup_validation/CompanyValidation");

router.get("/admin/countJobByCompany", isAuth, isAdmin, countJobByCompany);
router.get("/admin/stats", isAuth, isAdmin, statsCompany);
router.get("/admin/status", isAuth, isAdmin, statusCompany);

router.get(
  "/search-by-skill",
  isAuth,
  validateREST(CompanyValidation.formSearchCompanyBySkillSchema),
  getCompanyBySkill
);

router.get(
  "/follower/:companyId",
  isAuth,
  validateREST(CompanyValidation.formInfoCompanySchema),
  listUserFollowCompany
);

router.get(
  "/info/:companyId",
  isAuth,
  validateREST(CompanyValidation.formInfoCompanySchema),
  infoCompany
);
router.get(
  "/list",
  isAuth,
  validateREST(CompanyValidation.formListCompanySchema),
  listCompany
);
router.get("/suggestion", isAuth, suggestionCompany);
router.get(
  "/members/:companyId",
  isAuth,
  validateREST(CompanyValidation.formCompanyMembersSchema),
  membersCompany
);
router.post(
  "/create",
  isAuth,
  isEmployee,
  validateREST(CompanyValidation.formCreateCompanySchema),
  createCompany
);
router.put(
  "/update/:companyId",
  isAuth,
  isManager,
  validateREST(CompanyValidation.formUpdateCompanySchema),
  updateCompany
);
router.put(
  "/add-human-resource/:companyId",
  isAuth,
  isManager,
  validateREST(CompanyValidation.formAddEmployeeSchema),
  addEmployees
);
router.put(
  "/update-status/:companyId",
  isAuth,
  isAdmin,
  validateREST(CompanyValidation.formUpdateStatusSchema),
  statusOneCompany
);
router.put(
  "/remove-human-resource/:companyId",
  isAuth,
  isManager,
  validateREST(CompanyValidation.formRemoveEmployeeSchema),
  removeEmployees
);

module.exports = router;
