const router = require("express").Router();
const { isAuth, isAdmin } = require("../middlewares/verifyId");
const { deleteCategory } = require("../controllers/CategoryController");

router.delete("/delete/:catId", isAuth, isAdmin, deleteCategory);

module.exports = router;
