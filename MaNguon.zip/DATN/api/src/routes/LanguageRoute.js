const router = require("express").Router();
const { isAuth, isAdmin } = require("../middlewares/verifyId");
const { searchLanguage } = require("../controllers/LanguageController");

const { validateREST } = require("../middlewares/yup_validation/index");
const SearchValidation = require("../middlewares/yup_validation/SearchValidation");

router.get(
  "/search",
  isAuth,
  validateREST(SearchValidation.formSearchSuggestionSchema),
  searchLanguage
);

module.exports = router;
