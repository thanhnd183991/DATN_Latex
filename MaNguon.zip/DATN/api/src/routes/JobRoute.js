const router = require("express").Router();
const {
  isAuth,
  isManager,
  isAdmin,
  isHR,
  isEmployee,
  isHRorManager,
  isHRorAdmin,
} = require("../middlewares/verifyId");
const {
  changeOwnerJob,
  createNewJob,
  confirmJob,
  updateJob,
  deleteApplicantJob,
  updateApplicantJob,
  listJobByCategory,
  listJobRelateCurrentJob,
  infoJob,
  recommendJobByUser,
  suggestionJob,
  viewApplyJob,
  listJobByCompany,
  listHRJob,
  countJobByCategory,
  statsJob,
  getJobByCategory,
  statusJob,
  closeJob,
} = require("../controllers/JobController");

const { validateREST } = require("../middlewares/yup_validation/index");
const JobValidation = require("../middlewares/yup_validation/JobValidation");

router.put("/change-owner/:jobId", isAuth, isManager, changeOwnerJob);

router.get("/suggestion", isAuth, suggestionJob);

router.get("/admin/status", isAuth, isAdmin, statusJob);

router.get("/admin/stats", isAuth, isAdmin, statsJob);

router.get("/count-job-by-category", isAuth, isAdmin, countJobByCategory);

router.get(
  "/job-by-category",
  isAuth,
  validateREST(JobValidation.formJobByCategorySchema),
  getJobByCategory
);

router.get("/list-by-company/:companyId", isAuth, listJobByCompany);

router.get(
  "/view-apply/:jobId",
  isAuth,
  validateREST(JobValidation.formViewApplyJobSchema),
  viewApplyJob
);
router.get(
  "/info/:jobId",
  isAuth,
  validateREST(JobValidation.formInfoJobSchema),
  infoJob
);
router.post(
  "/create",
  isAuth,
  isHR,
  validateREST(JobValidation.formCreateJobSchema),
  createNewJob
);
router.put(
  "/confirm",
  isAuth,
  isAdmin,
  validateREST(JobValidation.formConfirmJobSchema),
  confirmJob
);
router.put(
  "/update",
  isAuth,
  isHRorAdmin,
  validateREST(JobValidation.formUpdateJobSchema),
  updateJob
);
router.get(
  "/search",
  isAuth,
  validateREST(JobValidation.formListJobSchema),
  listJobByCategory
);
router.get(
  "/relate-job/:jobId",
  isAuth,
  validateREST(JobValidation.formJobRelateCurrenJobSchema),
  listJobRelateCurrentJob
);

router.get("/recommend-job", isAuth, recommendJobByUser);
router.get(
  "/job-by-hr/",
  isAuth,
  isHRorManager,
  validateREST(JobValidation.formListJobByHRSchema),
  listHRJob
);

router.put(
  "/update-applicant",
  isAuth,
  isEmployee,
  validateREST(JobValidation.formUpdateApplicantJobSchema),
  updateApplicantJob
);
router.put(
  "/delete-applicant",
  isAuth,
  validateREST(JobValidation.formDeleteApplicantJobSchema),
  deleteApplicantJob
);

router.put(
  "/close-job",
  isAuth,
  isHR,
  validateREST(JobValidation.formCloseJobSchema),
  closeJob
);

module.exports = router;
