const router = require("express").Router();
const { uploadCloudinary } = require("../utils/diskStorage");
const { getFile, uploadFile } = require("../controllers/StoreController");

const { validateREST } = require("../middlewares/yup_validation/index");
const { isAuth } = require("../middlewares/verifyId");
const {
  formDestroyFileSchema,
  formDestroyFilesSchema,
} = require("../middlewares/yup_validation/StoreValidation");
const CloudinaryStoreController = require("../controllers/CloudinaryStoreController");

router.get("/uploads/:folder/:fileId", getFile);
router.post("/upload/:folder", uploadFile);

// cloudinary
router.post(
  "/upload-cloud/",
  uploadCloudinary.single("file"),
  CloudinaryStoreController.uploadFile
);

router.post(
  "/upload-multiple-cloud/",
  uploadCloudinary.any(),
  CloudinaryStoreController.uploadFiles
);

router.delete(
  "/delete-cloud/",
  validateREST(formDestroyFileSchema),
  CloudinaryStoreController.destroyFile
);

router.delete(
  "/deletes-cloud/",
  validateREST(formDestroyFilesSchema),
  CloudinaryStoreController.destroyFiles
);

router.post("/sign-cloud/", isAuth, CloudinaryStoreController.signPresignedURL);
module.exports = router;
