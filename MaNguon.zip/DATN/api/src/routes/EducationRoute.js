const router = require("express").Router();
const { isAuth, isAdmin } = require("../middlewares/verifyId");
const { searchEducation } = require("../controllers/EducationController");

const { validateREST } = require("../middlewares/yup_validation/index");
const SearchValidation = require("../middlewares/yup_validation/SearchValidation");

router.get(
  "/search",
  isAuth,
  validateREST(SearchValidation.formSearchSuggestionSchema),
  searchEducation
);

module.exports = router;
