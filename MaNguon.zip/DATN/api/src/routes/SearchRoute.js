const router = require("express").Router();
const { isAuth, isAdmin } = require("../middlewares/verifyId");
const {
  searchModal,
  searchInput,
  transfer,
  totalModelByAdmin,
} = require("../controllers/SearchController");

const { validateREST } = require("../middlewares/yup_validation/index");
const SearchValidation = require("../middlewares/yup_validation/SearchValidation");

router.get("/admin/totalModel", isAuth, isAdmin, totalModelByAdmin);

router.get(
  "/",
  isAuth,
  validateREST(SearchValidation.formSearchModelSchema),
  searchModal
);
router.get(
  "/input",
  isAuth,
  validateREST(SearchValidation.formSearchInputSchema),
  searchInput
);
router.get("/transfer", isAuth, transfer);

module.exports = router;
