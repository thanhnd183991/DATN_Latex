const router = require("express").Router();
const { isAuth, isManager, isAdmin } = require("../middlewares/verifyId");
const {
  createRoom,
  blockRoom,
  unBlockRoom,
  getRoom,
  getListRoom,
} = require("../controllers/RoomController");

const {
  createMessage,
  reactionMessage,
  removeMessage,
  listMessages,
} = require("../controllers/MessageController");

const { validateREST } = require("../middlewares/yup_validation/index");
const MessageValidation = require("../middlewares/yup_validation/MessageValidation");
const RoomValidation = require("../middlewares/yup_validation/RoomValidation");
const ReactionValidation = require("../middlewares/yup_validation/ReactionValidation");

// room route
router.get(
  "/list",
  isAuth,
  validateREST(RoomValidation.formListRoomSchema),
  getListRoom
);
router.get(
  "/info/:roomId",
  isAuth,
  validateREST(RoomValidation.formGetRoomSchema),
  getRoom
);
router.post(
  "/create/",
  isAuth,
  validateREST(RoomValidation.formCreateRoomSchema),
  createRoom
);
router.put(
  "/block/",
  isAuth,
  validateREST(RoomValidation.formBlockRoomSchema),
  blockRoom
);
router.put(
  "/unblock",
  isAuth,
  validateREST(RoomValidation.formUnBlockRoomSchema),
  unBlockRoom
);

// message route
router.post(
  "/message/create",
  isAuth,
  validateREST(MessageValidation.formCreateMessageSchema),
  createMessage
);
router.put(
  "/message/react",
  isAuth,
  validateREST(MessageValidation.formReactionMessageSchema),
  reactionMessage
);
router.put(
  "/message/remove",
  isAuth,
  validateREST(MessageValidation.formRemoveMessageSchema),
  removeMessage
);
router.get(
  "/list-messages/:roomId",
  isAuth,
  validateREST(MessageValidation.formListMessageSchema),
  listMessages
);

module.exports = router;
