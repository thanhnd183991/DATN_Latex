const MONGO_IP = process.env.MONGO_IP || "mongo";
const MONGO_PORT = process.env.MONGO_PORT || 27017;
const MONGO_USER = process.env.MONGO_USER || "test";
const MONGO_PASSWORD = process.env.MONGO_PASSWORD || "test";
const REDIS_IP = process.env.REDIS_IP || "redis";
const REDIS_PORT = process.env.REDIS_PORT || 6379;
const SESSION_SECRET = process.env.SESSION_SECRET;
const mongoURLDocker = `mongodb://${MONGO_USER}:${MONGO_PASSWORD}@${MONGO_IP}:${MONGO_PORT}/?authSource=admin`;
const mongoURLLocal = process.env.MONGO_URL + "";
const mongoURLRemote = process.env.MONGO_URL_REMOTE;

module.exports = {
  mongoURL:
    process.env.NODE_ENV === "production" ? mongoURLRemote : mongoURLLocal,
};
