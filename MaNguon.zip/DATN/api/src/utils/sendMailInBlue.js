var SibApiV3Sdk = require("sib-api-v3-sdk");

exports.sendMailInBlue = (to, html) => {
  SibApiV3Sdk.ApiClient.instance.authentications["api-key"].apiKey =
    "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";
  new SibApiV3Sdk.TransactionalEmailsApi()
    .sendTransacEmail({
      subject: "reset password!",
      sender: { email: "api@sendinblue.com", name: "Sendinblue" },
      replyTo: { email: "api@sendinblue.com", name: "Sendinblue" },
      to: [{ name: "John Doe", email: "example@example.com" }],
      htmlContent: `<html><body>${html}</h1></body></html>`,
      params: { bodyMessage: "Made just for you!" },
    })
    .then(
      function (data) {
        console.log(data);
        return "Ok";
      },
      function (error) {
        console.error(error);
        return "Fail";
      }
    );
};
