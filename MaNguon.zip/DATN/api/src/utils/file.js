exports.getPublicId = (url) => {
  const tmp = url.split("/").slice(-2);
  if (tmp[0] !== "raw") {
    return [tmp[0], tmp[1].split(".").slice(0, -1).join(".")].join("/");
  }
  return tmp.join("/");
};
