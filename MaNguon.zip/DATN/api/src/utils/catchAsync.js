const AppError = require("./AppError");
const catchAsync = (fn) => {
  return (req, res, next) => {
    fn(req, res, next).catch((err) => {
      // console.log(err.errors);
      if (err?.errors) {
        res.status(400).json({
          ...err.errors,
        });
      } else if (err.name === "MongoServerError" && err.code === 11000) {
        res.status(400).json({
          message: `${Object.values(err.keyValue)[0]} đã tồn tại`,
          path: `${Object.keys(err.keyValue)[0]}`,
          type: "duplicate",
          value: Object.values(err.keyValue)[0],
        });
      } else next(err);
    });
  };
};

module.exports = catchAsync;
