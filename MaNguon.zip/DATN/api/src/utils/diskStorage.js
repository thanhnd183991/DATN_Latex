const multer = require("multer");
const { v4 } = require("uuid");
const fs = require("fs");

let storage = multer.diskStorage({
  destination: (req, file, cb) => {
    console.log(req.params);
    console.log;
    const dir = `./uploads/${req.params.folder}`;

    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    cb(null, dir);
    // if (file.mimetype.includes("image")) {
    //   cb(null, "./uploads/images");
    // } else if (file.mimetype.includes("video")) {
    //   cb(null, "./uploads/videos");
    // }
  },
  filename: (req, file, cb) => {
    // console.log("diskStorage name file: ", file);
    const uid = v4();
    const tailFile = file.originalname.match(/\.[0-9a-z]+$/i)[0];
    let filename = `${uid}${tailFile}`;
    // console.log("disk ", filename);
    cb(null, filename);
  },
});

let upload = multer({
  storage,
  limit: { fileSize: 1000000 * 100 },
}).single("file");

let uploadCloudinary = multer();

module.exports = { upload, uploadCloudinary };
