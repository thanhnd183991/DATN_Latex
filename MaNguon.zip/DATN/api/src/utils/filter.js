const { convertToSlug } = require("./convertToSlug");

exports.filterRegex = (
  valueRaw,
  operatorValue,
  isFilterBySlug = true,
  columnField
) => {
  let value = valueRaw;
  if (isFilterBySlug) {
    value = convertToSlug(valueRaw);
  }
  let myFilter = {};

  if (operatorValue === "contains") {
    myFilter = { $regex: new RegExp(".*" + value + ".*", "i") };
  } else if (operatorValue === "equals") {
    myFilter = { $eq: value };
  } else if (operatorValue === "startsWith") {
    myFilter = { $regex: new RegExp("^" + value + ".*", "i") };
  } else if (operatorValue === "endsWith") {
    myFilter = { $regex: new RegExp(".*" + value + "$", "i") };
  } else if (operatorValue === "isEmpty") {
    myFilter = { $eq: null };
  } else if (operatorValue === "isNotEmpty") {
    myFilter = { $ne: null };
  } else if (operatorValue === "is" && value !== "") {
    myFilter = { $eq: value === "false" ? false : true };
  }
  let obj = {};
  if (isFilterBySlug) {
    return { slug: myFilter };
  }
  Object.assign(obj, { [columnField]: myFilter });
  return obj;
};
