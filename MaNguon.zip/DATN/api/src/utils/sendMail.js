const nodemailer = require("nodemailer");
const PoolResource = require("nodemailer/lib/smtp-pool/pool-resource");

exports.content = (resetToken) => {
  return `<a href="${process.env.APP_CLIENT_URL}/change-password?token=${resetToken}">Click here to reset your password</a>`;
};

// async..await is not allowed in global scope, must use a wrapper
exports.sendMail = async (to, html) => {
  // Generate test SMTP service account from ethereal.email

  let testAccount = await nodemailer.createTestAccount();
  // create reusable transporter object using the default SMTP transport
  let transporter = nodemailer.createTransport({
    host: process.env.MAIL_TRAP_HOST,
    // host: process.env.SMTP_HOST,
    port: process.env.MAIL_TRAP_PORT,
    // port: process.env.SMTP_PORT,
    auth: {
      user: process.env.MAIL_TRAP_USER, // generated ethereal user
      pass: process.env.MAIL_TRAP_PASS, // generated ethereal password
      // user: process.env.SMTP_USER,
      // pass: process.env.SMTP_PASSWORD,
    },
    tls: {
      rejectUnauthorized: false, // avoid NodeJs self signed certificate error
    },
  });

  // send mail with defined transport object
  let info = await transporter.sendMail({
    from: '"Fred Foo 👻" <foo@example.com>', // sender address
    to, // list of receivers
    subject: "Change Password", // Subject line
    html, // html body
  });

  console.log("Message sent: %s", info.messageId);
  // Message sent: <b658f8ca-6296-ccf4-8306-87d57a0b4321@example.com>

  // Preview only available when sending through an Ethereal account
  console.log("Preview URL: %s", nodemailer.getTestMessageUrl(info));
  // Preview URL: https://ethereal.email/message/WaQKMgKddxQDoou...
  return "Ok";
};
