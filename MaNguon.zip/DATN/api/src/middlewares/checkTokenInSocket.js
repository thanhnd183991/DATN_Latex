const jwt = require("jsonwebtoken");

const checkTokenInSocket = (io) => {
  io.use((socket, next) => {
    // console.log(socket.handshake);
    const token = socket.handshake.query.token;
    // console.log("vao middleware check token id");
    if (!token) {
      return next(new Error("Authentication error"));
    }
    jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
      if (err) return next(new Error("Authentication error"));
      socket.user = decoded;
      return next();
    });
  });
};

module.exports = checkTokenInSocket;
