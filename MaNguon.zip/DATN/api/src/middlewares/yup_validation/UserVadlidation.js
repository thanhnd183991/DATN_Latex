const yup = require("yup");

exports.formSearchUserSchema = yup.object({
  query: yup.object({
    query: yup.string().required("từ khóa được yêu cầu"),
    page: yup
      .number()
      .required("trang được yêu cầu")
      .min(1, "trang phải lớn hơn 1"),
    limit: yup
      .number()
      .required("số lượng được yêu cầu")
      .min(1, "số lượng phải lớn hơn 1"),
  }),
});

exports.formSearchUserBySkillSchema = yup.object({
  query: yup.object({
    skill: yup.string().required("skill được yêu cầu"),
    page: yup
      .number()
      .required("trang được yêu cầu")
      .min(1, "trang phải lớn hơn 1"),
    limit: yup
      .number()
      .required("số lượng được yêu cầu")
      .min(1, "số lượng phải lớn hơn 1"),
  }),
});

exports.formInfoUserSchema = yup.object({
  params: yup.object({
    userId: yup.string().required("userId được yêu cầu"),
  }),
});

exports.formFollowingUserSchema = yup.object({
  body: yup.object({
    otherId: yup.string().required("userId được yêu cầu"),
  }),
});

exports.formFollowingCompanySchema = yup.object({
  body: yup.object({
    companyId: yup.string().required("userId được yêu cầu"),
  }),
});

exports.formFollowingJobSchema = yup.object({
  body: yup.object({
    jobId: yup.string().required("userId được yêu cầu"),
  }),
});

exports.formAcceptCompanySchema = yup.object({});

exports.formDeleteUserSchema = yup.object({
  params: yup.object({
    userId: yup.string().required("userId được yêu cầu"),
  }),
});

exports.formActiveUserSchema = yup.object({
  params: yup.object({
    userId: yup.string().required("userId được yêu cầu"),
  }),
});

exports.formUpdateSkillSchema = yup.object({
  body: yup.object({
    skills: yup.lazy((val) =>
      Array.isArray(val) ? yup.array().of(yup.string()) : yup.string()
    ),
  }),
});

exports.formUpdateLanguageSchema = yup.object({
  body: yup.object({
    languages: yup.lazy((val) =>
      Array.isArray(val) ? yup.array().of(yup.string()) : yup.string()
    ),
  }),
});

exports.formUpdateFieldStringSchema = yup.object({});

exports.formUpdateEducationSchema = yup.object({
  body: yup.object({
    educations: yup
      .array()
      .of(
        yup.object({
          school: yup.string().required("Trường được yêu cầu"),
          degree: yup.string().required("Bằng cấp được yêu cầu"),
          field_of_study: yup.string().required("Ngành học được yêu cầu"),
          start_date: yup.string().required("Từ năm được yêu cầu"),
          end_date: yup.string().required("Đến năm được yêu cầu"),
        })
      )
      .min(1, "Trình độ học vấn phải có ít nhất 1 phần tử"),
  }),
});

exports.formUpdateExpSchema = yup.object({
  body: yup.object({
    experiences: yup
      .array()
      .of(
        yup.object({
          name: yup.string().required("Kinh nhiệm việc làm được yêu cầu"),
          position: yup
            .string()
            .max(100, "Vui lòng nhập ít hơn 100 ký tự")
            .min(1, "Vui lòng nhập ít hơn 1 ký tự")
            .required("Vị trí được yêu cầu"),
          desc: yup.string().max(1000, "Vui lòng nhập ít hơn 1000 ký tự"),
          start_date: yup.string().required("Từ năm được yêu cầu"),
          end_date: yup.string().required("Đến năm được yêu cầu"),
        })
      )
      .min(1, "Kinh nhiệm việc làm phải có ít nhất 1 phần tử"),
  }),
});
