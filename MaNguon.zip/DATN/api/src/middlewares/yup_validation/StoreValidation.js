const yup = require("yup");

exports.formDestroyFileSchema = yup.object({
  body: yup.object({
    public_id: yup.string().required("public_id được yêu cầu"),
  }),
});

exports.formDestroyFilesSchema = yup.object({
  body: yup.object({
    public_ids: yup.array().required("public_ids được yêu cầu"),
  }),
});
