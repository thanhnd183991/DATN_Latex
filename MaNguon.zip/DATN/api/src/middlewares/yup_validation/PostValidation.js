const yup = require("yup");

exports.formCreatePostSchema = yup.object({
  body: yup.object({
    content: yup.string().required("nội dung được yêu cầu"),
  }),
});

exports.formFindPostSchema = yup.object({
  params: yup.object({
    postId: yup
      .string()
      .required("messageId được yêu cầu")
      .test(
        "len",
        "yêu cầu 24 ký tự cho messageId",
        (val) => val.length === 24
      ),
  }),
});

exports.formListPostSchema = yup.object({
  query: yup.object({
    page: yup.number().required("trang được yêu cầu"),
    limit: yup.number().required("number được yêu cầu"),
  }),
});

exports.formListPostByUserSchema = yup.object({
  query: yup.object({
    page: yup.number().required("trang được yêu cầu"),
    limit: yup.number().required("number được yêu cầu"),
  }),
});

exports.formListPostByCompanySchema = yup.object({
  params: yup.object({
    companyId: yup
      .string()
      .required("companyId được yêu cầu")
      .test(
        "len",
        "yêu cầu 24 ký tự cho companyId",
        (val) => val.length === 24
      ),
  }),
  query: yup.object({
    page: yup.number().required("trang được yêu cầu"),
    limit: yup.number().required("number được yêu cầu"),
  }),
});

exports.formListPostByFeedSchema = yup.object({
  query: yup.object({
    page: yup.number().required("trang được yêu cầu"),
    limit: yup.number().required("number được yêu cầu"),
  }),
});

exports.formSearchPostSchema = yup.object({
  query: yup.object({
    keywords: yup.string().required("keywords được yêu cầu"),
    page: yup.number().required("trang được yêu cầu"),
    limit: yup.number().required("number được yêu cầu"),
  }),
});
