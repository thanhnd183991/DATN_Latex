const yup = require("yup");

exports.formCreateRoomSchema = yup.object({
  body: yup.object({
    type: yup.mixed().oneOf(["Personal", "Company"]).defined(),
    destId: yup
      .string()
      .required("destId được yêu cầu")
      .test("len", "yêu cầu 24 ký tự cho destId", (val) => val.length === 24),
    userId: yup.string().nullable(true),
    jobId: yup.string().nullable(true),
  }),
});

exports.formBlockRoomSchema = yup.object({
  body: yup.object({
    roomId: yup
      .string()
      .required("roomId được yêu cầu")
      .test("len", "yêu cầu 24 ký tự cho roomId", (val) => val.length === 24),
  }),
});

exports.formListRoomSchema = yup.object({
  query: yup.object({
    page: yup.number().required("trang được yêu cầu"),
    limit: yup.number().required("number được yêu cầu"),
  }),
});
exports.formGetRoomSchema = yup.object({
  params: yup.object({
    roomId: yup
      .string()
      .required("roomId được yêu cầu")
      .test("len", "yêu cầu 24 ký tự cho roomId", (val) => val.length === 24),
  }),
});

exports.formUnBlockRoomSchema = yup.object({
  body: yup.object({
    roomId: yup
      .string()
      .required("roomId được yêu cầu")
      .test("len", "yêu cầu 24 ký tự cho roomId", (val) => val.length === 24),
  }),
});

exports.formNumberOfReactionSchema = yup.object({
  body: yup.object({
    postId: yup
      .string()
      .required("postId được yêu cầu")
      .test("len", "yêu cầu 24 ký tự cho postId", (val) => val.length === 24),
  }),
});
