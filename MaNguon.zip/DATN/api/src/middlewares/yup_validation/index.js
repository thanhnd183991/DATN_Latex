const yup = require("yup");
function getErrorsFromValidationError(validationError) {
  const FIRST_ERROR = 0;
  return validationError.inner.reduce((errors, error) => {
    return {
      ...errors,
      [error.path.split(".")[error.path.split(".").length - 1] || error.path]:
        error.errors[FIRST_ERROR],
    };
  }, {});
}

exports.validateREST = (schema) => async (req, res, next) => {
  try {
    await schema.validateSync(
      {
        body: req.body,
        query: req.query,
        params: req.params,
      },
      { abortEarly: false }
    );
    return next();
  } catch (err) {
    // console.log(err);
    return res.status(500).json(getErrorsFromValidationError(err));
  }
};
