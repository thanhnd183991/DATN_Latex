const yup = require("yup");

exports.formSearchModelSchema = yup.object({
  query: yup.object({
    model: yup.mixed().oneOf(["user", "category", "job", "company", "post"]),
    columnField: yup.string().required("field required"),
    operatorValue: yup
      .mixed()
      .oneOf([
        "contains",
        "equals",
        "startsWith",
        "endsWith",
        "isEmpty",
        "isNotEmpty",
        "is",
      ]),
    value: yup.string(),
    page: yup.string().required("field required"),
    limit: yup.string().required("field required"),
  }),
});

exports.formSearchInputSchema = yup.object({
  query: yup.object({
    value: yup.string().required("field required"),
    page: yup.number().required("field required"),
    limit: yup.number().required("field required"),
  }),
});

exports.formSearchSuggestionSchema = yup.object({
  query: yup.object({
    value: yup.string().required("value required"),
    page: yup.number().required("page required"),
    limit: yup.number().required("limit required"),
    operatorValue: yup
      .mixed()
      .oneOf([
        "contains",
        "equals",
        "startsWith",
        "endsWith",
        "isEmpty",
        "isNotEmpty",
        "is",
      ]),
  }),
});
