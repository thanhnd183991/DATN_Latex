const yup = require("yup");

exports.formCreateJobSchema = yup.object({
  body: yup.object({
    title: yup
      .string()
      .trim()
      .min(3, "nhan đề công việc phải có ít nhất 3 ký tự")
      .max(200, "nhan đề công việc phải có nhiều nhất 100 ký tự")
      .required("nhan đề công việc được yêu cầu"),
    salary: yup
      .string()
      .trim()
      .matches(
        /(^[0-9]+$)|(^[0-9]+-[0-9]+$)/,
        "Lương sai định dạng , vd: 1000 hoặc 1000-2000"
      )
      .required("lương được yêu cầu"),
    job_type: yup.mixed().oneOf(["fulltime", "parttime", "freelance"]),
    // job_type: yup.string().required("loại công việc được yêu cầu"),
    numbers: yup.number().required("số lượng công việc được yêu cầu"),
    categories: yup.array().of(yup.string().required()).defined(),
  }),
});

exports.formChangeOwnerJobSchema = yup.object({
  body: yup.object({
    newOwnerId: yup.string().required("ownerId được yêu cầu"),
  }),
  params: yup.object({
    jobId: yup.string().required("jobId được yêu cầu"),
  }),
});

exports.formUpdateApplicantJobSchema = yup.object({
  body: yup.object({
    jobId: yup.string().required("jobId được yêu cầu"),
    phone: yup
      .string()
      .matches(
        /^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/,
        "Số điện thoại không đúng định dạng"
      )
      .required("phone được yêu cầu"),
    email: yup.string().email().required("email được yêu cầu"),
    CV: yup
      .string()
      .url("Địa chỉ file CV không đúng định dạng")
      .required("CV được yêu cầu"),
  }),
});

exports.formDeleteApplicantJobSchema = yup.object({
  body: yup.object({
    jobId: yup.string().required("jobId được yêu cầu"),
    applicantId: yup.string().required("applicantId được yêu cầu"),
  }),
});

exports.formUpdateJobSchema = yup.object({
  body: yup.object({
    jobId: yup.string().required("jobId được yêu cầu"),
  }),
});

exports.formConfirmJobSchema = yup.object({
  body: yup.object({
    jobId: yup
      .string()
      .required("jobId được yêu cầu")
      .test("len", "yêu cầu 24 ký tự cho jobId", (val) => val.length === 24),
    status: yup.boolean().required("status được yêu cầu"),
  }),
});

exports.formJobByCategorySchema = yup.object({
  query: yup.object({
    page: yup.string().required("trang được yêu cầu"),
    limit: yup.number().required("số lượng được yêu cầu"),
    skill: yup.string().required("skill được yêu cầu"),
  }),
});

exports.formListJobSchema = yup.object({
  query: yup.object({
    page: yup.string().required("trang được yêu cầu"),
    active: yup.boolean().required("trạng thái được yêu cầu"),
    limit: yup.number().required("số lượng được yêu cầu"),
    keywords: yup.string().required("từ khóa được yêu cầu"),
  }),
});

exports.formViewApplyJobSchema = yup.object({
  params: yup.object({
    jobId: yup.string().required("jobId được yêu cầu"),
  }),
});

exports.formInfoJobSchema = yup.object({
  params: yup.object({
    jobId: yup.string().required("jobId được yêu cầu"),
  }),
});
exports.formJobRelateCurrenJobSchema = yup.object({
  params: yup.object({
    jobId: yup
      .string()
      .required("trường được yêu cầu")
      .test("len", "yêu cầu 24 ký tự cho trường", (val) => val.length === 24),
  }),
  query: yup.object({
    page: yup.string().required("trang được yêu cầu"),
    limit: yup.number().required("số lượng được yêu cầu"),
  }),
});

exports.formListJobByHRSchema = yup.object({
  query: yup.object({
    page: yup.number().required("trang được yêu cầu"),
    limit: yup.number().required("số lượng được yêu cầu"),
    userId: yup.string(),
    active: yup.boolean(),
  }),
});

exports.formCloseJobSchema = yup.object({
  body: yup.object({
    jobId: yup
      .string()
      .required("jobId được yêu cầu")
      .test("len", "yêu cầu 24 ký tự cho jobId", (val) => val.length === 24),
    close: yup.boolean(),
  }),
});
