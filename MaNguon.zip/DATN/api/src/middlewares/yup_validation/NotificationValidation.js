const yup = require("yup");
const NotifyConstant = require("../../constants/NotifyConstant");

exports.formConfirmConnectJobSchema = yup.object({
  params: yup.object({
    notifyId: yup.string().required("status được yêu cầu"),
  }),
  body: yup.object({
    status: yup
      .string()
      .oneOf([NotifyConstant.ACCEPTED, NotifyConstant.REJECTED])
      .required("status được yêu cầu"),
  }),
});

exports.formConnectJobSchema = yup.object({
  body: yup.object({
    jobId: yup.string().required("jobId được yêu cầu"),
    userId: yup.string(),
  }),
});

exports.formConfirmConnectUserSchema = yup.object({
  params: yup.object({
    notifyId: yup.string().required("status được yêu cầu"),
  }),
  body: yup.object({
    status: yup
      .string()
      .oneOf([NotifyConstant.ACCEPTED, NotifyConstant.REJECTED])
      .required("status được yêu cầu"),
  }),
});

exports.formConnectUserSchema = yup.object({
  body: yup.object({
    otherId: yup.string().required("status được yêu cầu"),
  }),
});
exports.formConfirmAddMemberSchema = yup.object({
  params: yup.object({
    notifyId: yup.string().required("notifyId được yêu cầu"),
  }),
  body: yup.object({
    status: yup
      .string()
      .oneOf([NotifyConstant.ACCEPTED, NotifyConstant.REJECTED])
      .required("status được yêu cầu"),
  }),
});

exports.formListNotificationSchema = yup.object({
  query: yup.object({
    type: yup.string().required("type được yêu cầu"),
    page: yup
      .number()
      .required("trang được yêu cầu")
      .min(1, "trang phải lớn hơn 1"),
    limit: yup
      .number()
      .required("số lượng được yêu cầu")
      .min(1, "số lượng phải lớn hơn 1"),
  }),
});
