const yup = require("yup");

exports.formCreateCommentSchema = yup.object({
  params: yup.object({
    postId: yup.string().required("postId được yêu cầu"),
  }),
});

exports.formReplyCommentSchema = yup.object({
  body: yup.object({
    root: yup.string().required("id message root được yêu cầu"),
  }),
});

exports.formReactionCommentSchema = yup.object({
  body: yup.object({
    commentId: yup.string().required("commentId được yêu cầu"),
    reaction: yup
      .mixed()
      .oneOf(["like", "love", "haha", "wow", "sad", "angry"])
      .required("reaction được yêu cầu"),
  }),
});

exports.formInfoRootCommentSchema = yup.object({
  params: yup.object({
    postId: yup.string().required("postId được yêu cầu"),
  }),
});

exports.formInfoChildrenCommentSchema = yup.object({
  params: yup.object({
    commentId: yup.string().required("commentId được yêu cầu"),
  }),
});

exports.formInfoCountCommentSchema = yup.object({
  params: yup.object({
    postId: yup.string().required("postId được yêu cầu"),
  }),
});
