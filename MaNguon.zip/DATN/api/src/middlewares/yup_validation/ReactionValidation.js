const yup = require("yup");

exports.formReactPostSchema = yup.object({
  body: yup.object({
    reaction: yup
      .mixed()
      .oneOf(["like", "love", "haha", "wow", "sad", "angry"])
      .defined(),
    postId: yup
      .string()
      .required("postId được yêu cầu")
      .test("len", "yêu cầu 24 ký tự cho postId", (val) => val.length === 24),
  }),
});

exports.formInfoReactionPostSchema = yup.object({
  body: yup.object({
    postId: yup
      .string()
      .required("postId được yêu cầu")
      .test("len", "yêu cầu 24 ký tự cho postId", (val) => val.length === 24),
  }),
});

exports.formNumberOfReactionSchema = yup.object({
  body: yup.object({
    postId: yup
      .string()
      .required("postId được yêu cầu")
      .test("len", "yêu cầu 24 ký tự cho postId", (val) => val.length === 24),
  }),
});
