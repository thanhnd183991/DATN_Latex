const jwt = require("jsonwebtoken");

exports.isAuth = (req, res, next) => {
  const authHeader = req.headers.authorization;
  // console.log(authHeader);
  if (authHeader) {
    const token = authHeader.split(" ")[1];

    jwt.verify(token, process.env.JWT_SECRET, (err, payload) => {
      if (err)
        return res.status(401).json({
          errors: [
            {
              field: "token",
              message: "Token has expired!",
            },
          ],
        });
      req.user = payload;
      next();
    });
  } else {
    return res.status(401).json({
      statusCode: 401,
      errors: [{ field: "token", message: "You are not authenticated!" }],
    });
  }
};

exports.isAdmin = (req, res, next) => {
  if (req.user.role === "admin") {
    next();
  } else {
    return res.status(403).json({
      message: "You are not the HRorManager",
    });
  }
};

exports.isEmployee = (req, res, next) => {
  if (req.user.role === "employee") {
    next();
  } else {
    return res.status(403).json({ message: "You are not the employee" });
  }
};

exports.isManager = (req, res, next) => {
  if (req.user.role === "manager") {
    next();
  } else {
    return res.status(403).json({ message: "You are not the manager" });
  }
};

exports.isHR = (req, res, next) => {
  if (req.user.role === "HR") {
    next();
  } else {
    return res.status(403).json({ message: "You are not the HR" });
  }
};

exports.isHRorManager = (req, res, next) => {
  if (req.user.role === "HR" || req.user.role === "manager") {
    next();
  } else {
    return res.status(403).json({
      message: "You are not the HRorManager",
    });
  }
};

exports.isHRorAdmin = (req, res, next) => {
  if (req.user.role === "HR" || req.user.role === "admin") {
    next();
  } else {
    return res.status(403).json({
      message: "You are not the HRorAdmin",
    });
  }
};
