const {
  infoReactionPostService,
  reactPostService,
  numberOfReationService,
} = require("../services/ReactionService");
const catchAsync = require("../utils/catchAsync");

exports.reactPost = catchAsync(async (req, res, next) => {
  const rs = await reactPostService(
    req.params.postId,
    req.body.reaction,
    req.user.id
  );
  return res.status(rs.status).json(rs.message || rs.data);
});

exports.infoReactionPost = catchAsync(async (req, res, next) => {
  const rs = await infoReactionPostService(req.params.postId, req.user.id);
  return res.status(rs.status).json(rs.data || rs.message);
});

exports.numberOfReaction = catchAsync(async (req, res, next) => {
  const rs = await numberOfReationService(req.params.postId);
  return res.status(rs.status).json({ data: rs.numReaction || rs.message });
});
