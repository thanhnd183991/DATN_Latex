const NotificationService = require("../services/NotificationService");
const catchAsync = require("../utils/catchAsync");

exports.getListNotifications = catchAsync(async (req, res, next) => {
  const rs = await NotificationService.getListNotifications(
    req.user.id,
    req.query.type,
    req.query.page,
    req.query.limit
  );
  return res.status(rs.status).json(rs.data);
});

exports.confirmAddMember = catchAsync(async (req, res, next) => {
  const rs = await NotificationService.confirmAddEmployeeNotify(
    req.params.notifyId,
    req.user.id,
    req.body.status
  );
  return res.status(rs.status).json(rs.data || rs.message);
});

exports.connectJob = catchAsync(async (req, res, next) => {
  const rs = await NotificationService.connectJobNotify(
    req.body.jobId,
    req.body.userId,
    req.user.id
  );
  return res.status(rs.status).json(rs.data || rs.message);
});

exports.connectUser = catchAsync(async (req, res, next) => {
  const rs = await NotificationService.connectUserNotify(
    req.user.id,
    req.body.otherId
  );
  return res.status(rs.status).json(rs.data || rs.message);
});

exports.confirmConnectUser = catchAsync(async (req, res, next) => {
  const rs = await NotificationService.confirmConnectUser(
    req.params.notifyId,
    req.body.status,
    req.user.id
  );
  return res.status(rs.status).json(rs.room || rs.message);
});

exports.confirmConnectJob = catchAsync(async (req, res, next) => {
  const rs = await NotificationService.confirmConnectJobNotify(
    req.params.notifyId,
    req.user.id,
    req.body.status
  );
  return res.status(rs.status).json(rs.room || rs.message);
});
