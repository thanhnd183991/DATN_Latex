const catchAsync = require("../utils/catchAsync");
const {
  searchInputService,
  searchModelService,
  totalModel,
} = require("../services/SearchService");
const { transferParentToArray } = require("../services/CategoryService");

exports.searchModal = catchAsync(async (req, res, next) => {
  const rs = await searchModelService({
    model: req.query.model,
    columnField: req.query.columnField,
    operatorValue: req.query.operatorValue,
    value: decodeURI(req.query.value),
    sort: req.query.sort,
    page: req.query.page,
    limit: req.query.limit,
    userId: req.user.id,
  });
  return res.status(rs.status).json(rs.data);
});

exports.searchInput = catchAsync(async (req, res, next) => {
  return searchInputService({
    value: req.query.value,
    operatorValue: req.query.operatorValue,
    page: req.query.page || 1,
    limit: req.query.limit || 2,
  })
    .then((rs) => {
      return res.status(rs.status).json(rs.data);
    })
    .catch((err) => {
      return res.status(err.status).json(err.data);
    });
});

exports.transfer = catchAsync(async (req, res, next) => {
  return transferParentToArray()
    .then((rs) => {
      return res.status(rs.status).json(rs.data);
    })
    .catch((err) => {
      return res.status(err.status).json(err.data);
    });
});

exports.totalModelByAdmin = catchAsync(async (req, res, next) => {
  return totalModel()
    .then((rs) => {
      return res.status(rs.status).json(rs.data);
    })
    .catch((err) => {
      return res.status(err.status).json(err.data);
    });
});
