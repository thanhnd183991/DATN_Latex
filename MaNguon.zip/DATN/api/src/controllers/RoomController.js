const RoomService = require("../services/RoomService");
const catchAsync = require("../utils/catchAsync");
const MessageService = require("../services/MessageService");

exports.createRoom = catchAsync(async (req, res, next) => {
  const { userId, destId, jobId, type } = req.body;
  const userReqId = req.user.id;
  let room;
  if (type === "personal") {
    if (userId !== userReqId && destId !== userReqId) {
      return res.status(400).json({
        status: 400,
        message: "You don't have permission to create this room",
      });
    }
    room = await RoomService.upsertPersonalRoom(userId, destId);
  } else if (type === "company") {
    if (!userId && !userReqId && !jobId) {
      return res.status(400).json({
        status: 400,
        message: "You don't have permission to create this room",
      });
    }
    room = await RoomService.upsertCompanyRoom(userId, userReqId, jobId);
  } else {
    return res.status(400).json({
      message: "You don't have permission to create this room",
    });
  }
  return res.status(room.status).json({
    room: room.room,
    message: room.message || null,
  });
});

exports.blockRoom = catchAsync(async (req, res, next) => {
  const { roomId } = req.body;
  const userReqId = req.user.id;
  const room = await RoomService.blockRoom(roomId, userReqId);
  res.status(room.status).json({
    data: room.room || room.message,
  });
});

exports.unBlockRoom = catchAsync(async (req, res, next) => {
  const { roomId } = req.body;
  const userReqId = req.user.id;
  const room = await RoomService.unBlockRoom(roomId, userReqId);
  return res.status(room.status).json({
    data: room.room || room.message,
  });
});

exports.getRoom = catchAsync(async (req, res, next) => {
  const { roomId } = req.params;
  const { page, limit } = req.query;
  const userReqId = req.user.id;
  const room = await RoomService.getRoom(
    roomId,
    userReqId,
    page || 1,
    limit || 10
  );
  return res.status(room.status).json(room.data || room.message);
});

exports.getListRoom = catchAsync(async (req, res, next) => {
  const { page, limit } = req.query;
  const userReqId = req.user.id;
  const rooms = await RoomService.getListRoom(
    userReqId,
    req.query.type,
    page || 1,
    limit || 10
  );
  return res.status(rooms.status).json(rooms.data || rooms.message);
});
