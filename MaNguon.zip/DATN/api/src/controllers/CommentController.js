const {
  createCommentService,
  replyCommentService,
  reactionCommentService,
  infoPostChildrenCommentService,
  infoPostRootCommentService,
  infoCountCommentPostService,
} = require("../services/CommentService");
const catchAsync = require("../utils/catchAsync");

exports.createComment = catchAsync(async (req, res, next) => {
  const rs = await createCommentService(
    { content: req.body.content, file: req.body.file },
    req.user.id,
    req.params.postId
  );
  return res.status(rs.status).json({ data: rs.newComment || rs.message });
});

exports.replyComment = catchAsync(async (req, res, next) => {
  const rs = await replyCommentService(
    req.body.root,
    { content: req.body.content, file: req.body.file },
    req.user.id
  );
  return res.status(rs.status).json({ data: rs.replyComment || rs.message });
});

exports.reactionComment = catchAsync(async (req, res, next) => {
  const rs = await reactionCommentService(
    req.body.commentId,
    req.user.id,
    req.body.reaction
  );
  return res.status(rs.status).json(rs.data || rs.message);
});

exports.infoRootComment = catchAsync(async (req, res, next) => {
  const rs = await infoPostRootCommentService(req.params.postId);
  return res.status(rs.status).json(rs.data);
});

exports.infoChildrenComment = catchAsync(async (req, res, next) => {
  const rs = await infoPostChildrenCommentService(req.params.commentId);
  return res.status(rs.status).json(rs.data);
});

exports.infoCountComment = catchAsync(async (req, res, next) => {
  const rs = await infoCountCommentPostService(req.params.postId);
  return res.status(rs.status).json(rs.data);
});
