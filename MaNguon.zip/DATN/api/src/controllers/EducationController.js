const EducationService = require("../services/EducationService");
const catchAsync = require("../utils/catchAsync");

exports.searchEducation = catchAsync(async (req, res, next) => {
  const rs = await EducationService.searchEducation({
    operatorValue: req.query.operatorValue,
    value: req.query.value,
    page: req.query.page,
    limit: req.query.limit,
  });
  return res.status(rs.status).json(rs.data);
});
