const User = require("../models/UserModel");
const Company = require("../models/CompanyModel");
const {
  updateStatusCompanyService,
  updateActiveCompanyService,
  addEmployeesService,
  removeEmployeesService,
  createCompanyService,
  suggestionCompanyService,
  infoCompanyService,
  listUserFollowCompany,
  countJobByCompany,
  getCompanyStatsService,
  getCompanyStatusService,
  getCompanyBySkill,
} = require("../services/CompanyService");
const catchAsync = require("../utils/catchAsync");
const mongoose = require("mongoose");
const Category = require("../models/CategoryModel");
const Job = require("../models/JobModel");

exports.statusCompany = catchAsync(async (req, res, next) => {
  const rs = await getCompanyStatusService();
  return res.status(rs.status).json(rs.data || rs.message);
});

exports.getCompanyBySkill = catchAsync(async (req, res, next) => {
  const rs = await getCompanyBySkill(
    req.query.skill,
    req.query.page,
    req.query.limit
  );
  return res.status(rs.status).json(rs.data || rs.message);
});

exports.statsCompany = catchAsync(async (req, res, next) => {
  const rs = await getCompanyStatsService();
  return res.status(rs.status).json(rs.data || rs.message);
});

exports.createCompany = catchAsync(async (req, res, next) => {
  const rs = await createCompanyService(req.user.id, req.body);
  return res.status(rs.status).json(rs.data || rs.message);
});

exports.updateCompany = catchAsync(async (req, res, next) => {
  const company = await Company.findById(req.params.companyId);
  if (!company) {
    return res.status(404).json({ message: "Company not found" });
  }
  if (company.owner._id.toString() !== req.user.id) {
    return res
      .status(401)
      .json({ message: "You are not permitted to update this company" });
  }
  if (Boolean(req.body.active) === true) {
    return res
      .status(401)
      .json({ message: "You are not permitted to accept this company" });
  }

  const updatedCompany = await Company.findByIdAndUpdate(
    req.params.companyId,
    req.body,
    {
      new: true,
      runValidators: true,
    }
  );
  return res.json(updatedCompany);
});

exports.statusOneCompany = catchAsync(async (req, res, next) => {
  const rs = await updateStatusCompanyService(
    req.params.companyId,
    req.user,
    req.body.status
  );
  return res.status(rs.status).json({ message: rs.message });
});

exports.listCompany = catchAsync(async (req, res, next) => {
  const { page, limit, active } = req.query;
  const startIndex = (Number(page || 1) - 1) * limit; // get the starting index of every page

  total = await Company.countDocuments(active ? { active: true } : {});
  const companies = await Company.find(active ? { active: true } : {})
    .populate("industry", "name")
    .sort({ createdAt: -1 })
    .limit(limit)
    .skip(startIndex);

  return res.json({ companies, page, total });
});

exports.addEmployees = catchAsync(async (req, res, next) => {
  const rs = await addEmployeesService(
    req.params.companyId,
    req.body.employees,
    req.user.id
  );
  return res.status(rs.status).json(rs.message);
});

exports.removeEmployees = catchAsync(async (req, res, next) => {
  const rs = await removeEmployeesService(
    req.params.companyId,
    req.body.employees,
    req.user.id
  );
  return res.status(rs.status).json(rs.message);
});

exports.membersCompany = catchAsync(async (req, res, next) => {
  // console.log(req.params.companyId);
  const members = await Company.findOne({
    _id: req.params.companyId,
    active: true,
  }).populate({
    path: "members",
    match: { active: true, activeCompany: true },
    select: "name avatar role",
  });
  if (!members) {
    return res.status(404).json({ message: "Company not found" });
  }
  return res.json(members.members);
});

exports.suggestionCompany = catchAsync(async (req, res, next) => {
  const rs = await suggestionCompanyService({
    userId: req.query.userId || req.user.id,
    limit: req.query.limit || 6,
    page: req.query.page || 1,
  });
  return res.status(rs.status).json(rs.data);
});

exports.infoCompany = catchAsync(async (req, res, next) => {
  const rs = await infoCompanyService({
    companyId: req.params.companyId,
    user: req.user,
  });
  return res.status(rs.status).json({
    data: rs.data,
    message: rs.message,
  });
});

exports.listUserFollowCompany = catchAsync(async (req, res, next) => {
  const rs = await listUserFollowCompany({
    companyId: req.params.companyId,
    value: req.query.value,
    limit: req.query.limit || 6,
    page: req.query.page || 1,
  });
  return res.status(rs.status).json(rs.data);
});

exports.countJobByCompany = catchAsync(async (req, res, next) => {
  const rs = await countJobByCompany();
  return res.status(rs.status).json(rs.data);
});
