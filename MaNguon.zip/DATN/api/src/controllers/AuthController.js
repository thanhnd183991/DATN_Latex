const catchAsync = require("../utils/catchAsync");
const AuthService = require("../services/AuthService");

exports.signup = catchAsync(async (req, res, next) => {
  return AuthService.signup(
    {
      email: req.body.email,
      name: req.body.name,
      password: req.body.password,
    },
    res
  );
});

exports.login = catchAsync(async (req, res, next) => {
  return AuthService.login(
    { email: req.body.email, password: req.body.password },
    res
  );
});

exports.updatePassword = catchAsync(async (req, res, next) => {
  return AuthService.updatePassword(
    req.user.id,
    req.body.newPassword,
    req.body.oldPassword,
    res
  );
});

exports.forgotPassword = catchAsync(async (req, res, next) => {
  const rs = await AuthService.forgotPassword(req.body.email);
  return res.status(rs.status).json({ message: rs.message });
});

exports.changePassword = catchAsync(async (req, res, next) => {
  const rs = await AuthService.changePassword(
    req.body.token,
    req.body.password
  );
  return res.status(rs.status).json({ message: rs.message });
});

exports.resetDB = catchAsync(async (req, res, next) => {
  const rs = await AuthService.resetDB();
  return res.status(rs.status).json({ message: rs.message });
});
