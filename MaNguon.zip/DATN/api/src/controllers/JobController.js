const User = require("../models/UserModel");
const Company = require("../models/CompanyModel");
const CategoryService = require("../services/CategoryService");
const Job = require("../models/JobModel");
const catchAsync = require("../utils/catchAsync");
const JobService = require("../services/JobService");

exports.statusJob = catchAsync(async (req, res, next) => {
  // bản thân người dùng tự đăng ký công việc cho mình
  const rs = await JobService.getJobStatusService();
  return res.status(rs.status).json(rs.data || rs.message);
});

exports.statsJob = catchAsync(async (req, res, next) => {
  // bản thân người dùng tự đăng ký công việc cho mình
  const rs = await JobService.getJobStatsService();
  return res.status(rs.status).json(rs.data || rs.message);
});

exports.createNewJob = catchAsync(async (req, res, next) => {
  const rs = await JobService.createJob(req.body, req.user.id);
  return res.status(rs.status).json({
    job: rs.newJob,
    message: rs.message,
  });
});

exports.updateApplicantJob = catchAsync(async (req, res, next) => {
  // bản thân người dùng tự đăng ký công việc cho mình
  // console.log("vao");
  const rs = await JobService.updateApplicantJob(req.body.jobId, {
    userId: req.user.id,
    phone: req.body.phone,
    email: req.body.email,
    CV: req.body.CV,
  });
  return res.status(rs.status).json(rs.message);
});

exports.deleteApplicantJob = catchAsync(async (req, res, next) => {
  // xóa người đăng ký với quyền là id của token hiện tại
  const rs = await JobService.deleteApplicantJob(
    req.body.jobId,
    req.user.id,
    req.body.applicantId
  );
  return res.status(rs.status).json(rs.message);
});

exports.updateJob = catchAsync(async (req, res, next) => {
  // cập nhật job với userId là của token hiện tại
  const { jobId, ...info } = req.body;
  const rs = await JobService.updateJob(req.body.jobId, info, req.user);
  return res.status(rs.status).json(rs.data || rs.message);
});

exports.confirmJob = catchAsync(async (req, res, next) => {
  const rs = await JobService.confirmJob(
    req.body.jobId,
    req.user.id,
    req.body.status
  );
  return res.status(rs.status).json(rs.data || rs.message);
});

exports.listJobByCategory = catchAsync(async (req, res, next) => {
  const { page, limit, keywords, active } = req.query;
  const rs = await JobService.listJobByCategory(
    keywords,
    page || 1,
    limit || 10,
    active || true
  );
  return res.status(rs.status).json(rs.data || rs.message);
});

exports.listJobRelateCurrentJob = catchAsync(async (req, res, next) => {
  const { page, limit } = req.query;
  const { jobId } = req.params;
  const rs = await JobService.listJobRelateCurrentJob({
    jobId,
    userId: req.user.id,
    page: page || 1,
    limit: limit || 10,
  });
  return res.status(rs.status).json(rs.data || rs.message);
});

exports.infoJob = catchAsync(async (req, res, next) => {
  const rs = await JobService.infoJob(req.params.jobId, req.user.id);
  return res.status(rs.status).json(rs.data || rs.message);
});

exports.recommendJobByUser = catchAsync(async (req, res, next) => {
  const rs = await JobService.recommendJobByUser(
    req.user.id,
    req.query.page || 1,
    req.query.limit || 6
  );
  return res.status(rs.status).json(rs.data || rs.message);
});

exports.viewApplyJob = catchAsync(async (req, res, next) => {
  // xóa người đăng ký với quyền là id của token hiện tại
  const rs = await JobService.viewApplyJobService(
    req.params.jobId,
    req.query.userId,
    req.user.id
  );
  return res.status(rs.status).json(rs.message || rs.data);
});

exports.suggestionJob = catchAsync(async (req, res, next) => {
  // bản thân người dùng tự đăng ký công việc cho mình
  const rs = await JobService.suggestionJobService({
    userId: req.query.userId || req.user.id,
    limit: req.query.limit || 6,
    page: req.query.page || 1,
  });
  return res.status(rs.status).json(rs.data);
});

exports.listJobByCompany = catchAsync(async (req, res, next) => {
  const { page, limit, keywords, active } = req.query;
  const rs = await JobService.listJobByCompanyService(
    req.params.companyId,
    req.query.page || 1,
    req.query.limit || 6,
    req.query.active || true,
    req.user
  );
  return res.status(rs.status).json(rs.data || rs.message);
});

exports.listHRJob = catchAsync(async (req, res, next) => {
  const rs = await JobService.listMyJobHR({
    userId: req.user.id,
    page: req.query.page || 1,
    limit: req.query.limit || 6,
    active: req.query.active,
    HRId: req.query.userId,
  });
  return res.status(rs.status).json(rs.data || rs.message);
});

exports.countJobByCategory = catchAsync(async (req, res, next) => {
  const rs = await CategoryService.countJobByCategroy();
  return res.status(rs.status).json(rs.data);
});

exports.getJobByCategory = catchAsync(async (req, res, next) => {
  const rs = await JobService.getJobByCategoryService(
    req.query.skill,
    req.query.page,
    req.query.limit,
    req.user
  );
  return res.status(rs.status).json(rs.data);
});

exports.changeOwnerJob = catchAsync(async (req, res, next) => {
  const rs = await JobService.changeOwnerJob(
    req.params.jobId,
    req.body.newOwnerId,
    req.user.id
  );
  return res.status(rs.status).json(rs.message);
});

exports.closeJob = catchAsync(async (req, res, next) => {
  const rs = await JobService.closeJob(
    req.body.jobId,
    req.user.id,
    req.body.close
  );
  return res.status(rs.status).json(rs.message);
});
