const MessageService = require("../services/MessageService");
const catchAsync = require("../utils/catchAsync");

exports.createMessage = catchAsync(async (req, res, next) => {
  const { roomId, message } = req.body;
  if (!message) {
    return res.status(400).json({ message: "Không có nội dung tin nhắn" });
  }
  message.sender = req.user.id;

  const newMessage = await MessageService.createMessage(roomId, message);
  return res
    .status(newMessage.status)
    .json(newMessage.data || newMessage.message);
});

exports.reactionMessage = catchAsync(async (req, res, next) => {
  const { messageId, reaction } = req.body;
  reaction.userId = req.user.id;
  const newMessage = await MessageService.reactionMessage(messageId, reaction);
  return res
    .status(newMessage.status)
    .json(newMessage.data || newMessage.message);
});

exports.removeMessage = catchAsync(async (req, res, next) => {
  const { messageId } = req.body;
  const newMessage = await MessageService.removeMessage(messageId, req.user.id);
  return res
    .status(newMessage.status)
    .json(newMessage.data || newMessage.message);
});
exports.listMessages = catchAsync(async (req, res, next) => {
  const rs = await MessageService.getMessages(
    req.params.roomId,
    req.user.id,
    req.query.page,
    req.query.limit
  );
  return res.status(rs.status).json(rs.data || rs.message);
});
