const PostService = require("../services/PostService");
const catchAsync = require("../utils/catchAsync");
const mongoose = require("mongoose");

exports.postStats = catchAsync(async (req, res, next) => {
  const rs = await PostService.getPostStatsService();
  return res.status(rs.status).json(rs.data || rs.message);
});

exports.countPostType = catchAsync(async (req, res, next) => {
  const rs = await PostService.getPostTypeService();
  return res.status(rs.status).json(rs.data || rs.message);
});

exports.createPost = catchAsync(async (req, res, next) => {
  const rs = await PostService.createPost(req.body, req.user.id);
  return res.status(rs.status).json({ data: rs.post || rs.message });
});

exports.findPost = catchAsync(async (req, res, next) => {
  const rs = await PostService.findPost(req.params.postId);
  return res.status(rs.status).json(rs.post || rs.message);
});

exports.listPost = catchAsync(async (req, res, next) => {
  const { page, limit } = req.query;
  const rs = await PostService.listPostAdmin(page || 1, limit || 10);

  return res.status(rs.status).json(rs.data);
});

exports.listPostByUser = catchAsync(async (req, res, next) => {
  const { userId, page, limit, active } = req.query;
  const rs = await PostService.listPostByUser(
    userId || req.user.id,
    page || 1,
    limit || 10,
    active || true,
    req.user.role
  );
  return res.status(rs.status).json(rs.data || rs.message);
});

exports.listPostByCompany = catchAsync(async (req, res, next) => {
  const { page, limit } = req.query;
  const { companyId } = req.params;
  const rs = await PostService.listPostByCompany(
    companyId,
    page || 1,
    limit || 10
  );
  return res.status(rs.status).json(rs.data || rs.message);
});

exports.listPostByFeed = catchAsync(async (req, res, next) => {
  // tim theo nguoi following va following company
  const { page, limit } = req.query;
  const rs = await PostService.listPostByFeed(
    req.user.id,
    page || 1,
    limit || 10
  );
  return res.status(rs.status).json(rs.data || rs.message);
});

exports.searchPost = catchAsync(async (req, res, next) => {
  const { keywords } = req.query;
  const { page, limit } = req.query;
  const rs = await PostService.searchPost(keywords, page || 1, limit || 10);
  return res.status(rs.status).json(rs.data);
});

exports.deletePost = catchAsync(async (req, res, next) => {
  const rs = await PostService.deletePostService(req.params.postId, req.user);
  return res.status(rs.status).json(rs.message);
});
