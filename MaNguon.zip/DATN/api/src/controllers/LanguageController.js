const LanguageService = require("../services/LanguageService");
const catchAsync = require("../utils/catchAsync");

exports.searchLanguage = catchAsync(async (req, res, next) => {
  const rs = await LanguageService.searchLanguages({
    operatorValue: req.query.operatorValue,
    value: req.query.value,
    page: req.query.page,
    limit: req.query.limit,
  });
  return res.status(rs.status).json(rs.data);
});
