const catchAsync = require("../utils/catchAsync");
const CloudinaryStoreService = require("../services/CloudinaryStoreService");

const testPath = "./uploads/users/33d81fd1-628d-4d00-b0be-8854fb60f7b0.jpg";

exports.getFile = async (req, res) => {};

exports.uploadFile = catchAsync(async (req, res) => {
  if (!req.file) {
    return res.status(500).json({ message: "File not exists." });
  }
  const rs = await CloudinaryStoreService.cloudUploadFile(req.file);
  return res.json(rs);
});

exports.uploadFiles = catchAsync((req, res) => {
  if (!req.files || req.files?.length === 0) {
    return res.status(500).json({ message: "Files not exists." });
  }
  // console.log(req.files);
  return CloudinaryStoreService.cloudUploadFiles(req.files)
    .then((rs) => {
      return res.json(rs);
    })
    .catch((err) => res.status(500).json({ message: err.message }));
});

exports.destroyFile = catchAsync(async (req, res) => {
  // console.log(req.body);
  const rs = await CloudinaryStoreService.cloudDestroyFile(req.body.public_id);
  return res.json(rs);
});

exports.destroyFiles = catchAsync(async (req, res) => {
  const rs = await CloudinaryStoreService.cloudDestroyFiles(
    req.body.public_ids
  );
  return res.json(rs);
});

exports.signPresignedURL = catchAsync(async (req, res, next) => {
  // console.log(req.body);
  const rs = await CloudinaryStoreService.signPresignedURL();
  return res.json(rs);
});
