const catchAsync = require("../utils/catchAsync");
const {
  followUser,
  followCompany,
  followJob,
  searchUserBySkill,
  infoUserService,
  acceptCompanyService,
  activeUserService,
  deleteUserService,
  searchUserService,
  updateEducationService,
  updateExperienceService,
  updateSkillService,
  suggestionUserService,
  applyJobCartUserService,
  saveJobCartUserService,
  updateFieldStringObjectUserService,
  getListFollowByUser,
  listEmployeeService,
  getUserStatsService,
  updateLanguageService,
  getUserStatusService,
} = require("../services/UserService");

exports.searchUserBySkill = catchAsync(async (req, res, next) => {
  const rs = await searchUserBySkill(
    req.query.skill,
    req.query.page,
    req.query.limit
  );
  return res.status(rs.status).json(rs.data || rs.message);
});

exports.userStats = catchAsync(async (req, res, next) => {
  const rs = await getUserStatsService();
  return res.status(rs.status).json(rs.data || rs.message);
});

exports.userStatus = catchAsync(async (req, res, next) => {
  const rs = await getUserStatusService();
  return res.status(rs.status).json(rs.data || rs.message);
});

exports.searchUser = catchAsync(async (req, res, next) => {
  const { query, limit, page } = req.query;
  const rs = await searchUserService(query, limit || 10, page || 1);
  return res.status(rs.status).json(rs.users);
});

exports.listFollowByUser = catchAsync(async (req, res, next) => {
  const { limit, page, type, userId } = req.query;
  const rs = await getListFollowByUser(
    userId || req.user.id,
    type,
    req.query.value,
    limit || 6,
    page || 1
  );
  return res.status(rs.status).json(rs.data);
});

exports.infoUser = catchAsync(async (req, res, next) => {
  const rs = await infoUserService(req.params.userId, req.user.role);
  return res.status(rs.status).json({ data: rs.user || rs.message });
});

exports.followingUser = catchAsync(async (req, res, next) => {
  const rs = await followUser(req.body.otherId, req.user);
  return res.status(rs.status).json({ data: rs.rs || rs.message });
});

exports.followingCompany = catchAsync(async (req, res, next) => {
  const rs = await followCompany(req.body.companyId, req.user);
  return res.status(rs.status).json({ data: rs.message });
});

exports.followingJob = catchAsync(async (req, res, next) => {
  const rs = await followJob(req.body.jobId, req.user);
  return res.status(rs.status).json({ data: rs.message });
});

exports.acceptCompany = catchAsync(async (req, res, next) => {
  const rs = await acceptCompanyService(req.user.id);

  return res.status(rs.status).json({ data: rs.user || rs.message });
});

exports.deleteUser = catchAsync(async (req, res, next) => {
  const rs = await deleteUserService(req.params.userId, req.user.id);
  return res.status(rs.status).json(rs.message);
});

exports.activeUser = catchAsync(async (req, res, next) => {
  const rs = await activeUserService(req.params.userId);
  return res.status(rs.status).json(rs.message);
});

exports.updateSkills = catchAsync(async (req, res, next) => {
  const rs = await updateSkillService(req.user.id, req.body.skills);

  return res.status(rs.status).json(rs.data || rs.message);
});

exports.updateLanguages = catchAsync(async (req, res, next) => {
  const rs = await updateLanguageService(req.user.id, req.body.languages);
  return res.status(rs.status).json(rs.data || rs.message);
});

exports.updateExperience = catchAsync(async (req, res, next) => {
  const rs = await updateExperienceService(req.user.id, req.body.experiences);
  return res.status(rs.status).json(rs.data || rs.message);
});

exports.updateEducations = catchAsync(async (req, res, next) => {
  const rs = await updateEducationService(req.user.id, req.body.educations);

  return res.status(rs.status).json(rs.data || rs.message);
});

exports.suggestionUser = catchAsync(async (req, res, next) => {
  const rs = await suggestionUserService({
    userId: req.user.id,
    limit: req.query.limit || 3,
    page: req.query.page || 1,
  });

  return res.status(rs.status).json(rs.data || rs.message);
});

exports.applyJobCartUser = catchAsync(async (req, res, next) => {
  const rs = await applyJobCartUserService({
    userId: req.user.id,
    limit: req.query.limit || 6,
  });

  return res.status(rs.status).json(rs.data);
});

exports.saveJobCartUser = catchAsync(async (req, res, next) => {
  const rs = await saveJobCartUserService({
    userId: req.user.id,
    limit: req.query.limit || 6,
  });

  return res.status(rs.status).json(rs.data);
});

exports.updateFieldStringObjectUser = catchAsync(async (req, res, next) => {
  const rs = await updateFieldStringObjectUserService(req.user.id, req.body);

  return res.status(rs.status).json(rs.data || rs.message);
});

exports.listEmployee = catchAsync(async (req, res, next) => {
  const rs = await listEmployeeService(
    req.user.id,
    req.query.value,
    req.query.limit || 6,
    req.query.page || 1
  );

  return res.status(rs.status).json(rs.data || rs.message);
});
