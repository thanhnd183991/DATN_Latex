const CategoryService = require("../services/CategoryService");
const catchAsync = require("../utils/catchAsync");

exports.deleteCategory = catchAsync(async (req, res, next) => {
  const rs = await CategoryService.deleteCategory(req.params.catId);
  return res.status(rs.status).json(rs.message);
});
