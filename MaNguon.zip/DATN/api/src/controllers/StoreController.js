const fs = require("fs");
const path = require("path");
const { upload } = require("../utils/diskStorage");
const stream = require("stream");
const { sendImage, sendVideo } = require("../services/StoreService");

exports.getFile = async (req, res) => {
  const { folder, fileId } = req.params;
  // console.log("vao");
  if (!fileId || !folder) {
    return res.status(400).json({
      message: "Missing params",
    });
  }
  const tailFile = fileId.match(/\.[0-9a-z]+$/i)[0];
  // console.log(tailFile);
  if (tailFile === ".mp4") {
    sendVideo(req, res, folder, fileId);
  } else if (tailFile === ".jpg" || tailFile === ".png") {
    sendImage(req, res, `./uploads/${folder}`, fileId);
  } else {
    res.status(400).json({
      message: "Invalid file type",
    });
  }
};

exports.uploadFile = async (req, res) => {
  upload(req, res, (err) => {
    if (err) {
      return res.json({ errors: [{ field: "server", message: err.message }] });
    }
    // console.log(req.file);
    const url = `${process.env.APP_API_URL}/api/store/uploads/${req.params.folder}/${req.file.filename}`;
    return res.json({
      url,
    });
  });
};
