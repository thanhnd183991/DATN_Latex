// const url =
//   "https://res.cloudinary.com/drk3mkssy/raw/upload/v1657247442/raw/m4gfake7t3nm3zs4gcpv.txt";
const url =
  "https://res.cloudinary.com/drk3mkssy/image/upload/v1657247727/image/nnzcdgi5brydphu4nebk.jpg";

const getPublicId = (url) => {
  const tmp = url.split("/").slice(-2);
  if (tmp[0] !== "raw") {
    return [tmp[0], tmp[1].split(".").slice(0, -1).join(".")].join("/");
  }
  return tmp.join("/");
};

console.log(getPublicId(url));
