export const findInInfiniteQuery = (list, id) => {
  // console.log(list, id);
  const { pages } = list;
  let pageIndex = null,
    index = null;
  const page = pages.find((page, indexPage) => {
    const tmp = page.data.find((item) => item._id === id);
    if (tmp) {
      pageIndex = indexPage;
      index = page.data.indexOf(tmp);
    }
  });
  return {
    pageIndex,
    index,
  };
};
