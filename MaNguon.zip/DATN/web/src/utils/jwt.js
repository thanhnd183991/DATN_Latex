import jwtDecode from "jwt-decode";
// import { verify, sign } from "jsonwebtoken";
import axios from "./axios";

const isValidToken = (accessToken) => {
  if (!accessToken) {
    return false;
  }

  const { exp } = jwtDecode(accessToken);

  const currentTime = Date.now() / 1000;
  // console.log(exp > currentTime ? "true" : "false");
  const timeLeft = (exp - currentTime) * 1000;
  return { isValid: exp > currentTime, timeLeft };
};

const setSession = (accessToken) => {
  if (accessToken) {
    axios.defaults.headers.common.Authorization = `Bearer ${accessToken}`;
  } else {
    delete axios.defaults.headers.common.Authorization;
  }
};

export { isValidToken, setSession };
