import dayjs from "dayjs";
import "dayjs/locale/vi";
import relativeTime from "dayjs/plugin/relativeTime";
import localizedFormat from "dayjs/plugin/localizedFormat";
export const getDateOfMonth = (d) => {
  return dayjs(d).date();
};

export const getMonth = (d) => {
  return dayjs(d).month();
};

export const getYear = (d) => {
  return dayjs(d).year();
};

export const fromNow = (d) => {
  dayjs.extend(relativeTime);
  return dayjs(d).locale("vi").fromNow();
};

export const dateFormat = (d, format) => {
  dayjs.extend(localizedFormat);
  dayjs.extend(relativeTime);
  return dayjs(d).locale("vi").format(format);
};
