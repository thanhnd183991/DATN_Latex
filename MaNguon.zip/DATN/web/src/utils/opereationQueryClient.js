import { findInInfiniteQuery } from "./find";

export const deleteInInfiniteQuery = async (queryClient, key, id) => {
  await queryClient.cancelQueries(key);
  const list = queryClient.getQueryData(key);

  if (!list) return;

  const { pages, ...info } = list;
  const { pageIndex, index } = findInInfiniteQuery(list, id);
  if (typeof pageIndex === "number" && typeof index === "number") {
    // console.log("co trong list de xoa");
    pages[pageIndex].data.splice(index, 1);
    queryClient.setQueryData(key, {
      pages,
      ...info,
    });
  }
  return;
};

export const addToInfiniteQuery = async (queryClient, key, data) => {
  await queryClient.cancelQueries(key);
  const list = queryClient.getQueryData(key);

  if (!list) return;

  const { pages, ...info } = list;
  const { pageIndex, index } = findInInfiniteQuery(list, data.data._id);
  if (typeof pageIndex === "number" && typeof index === "number") {
    // console.log("co trong list de xoa");
    pages[pageIndex].data.splice(index, 1);
  }
  pages[0].data.unshift(data.data);
  queryClient.setQueryData(key, {
    pages,
    ...info,
  });
  return;
};
