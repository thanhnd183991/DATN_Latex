import { useEffect } from "react";
import { useQueryClient } from "react-query";
import { useDispatch } from "react-redux";
import {
  BrowserRouter as Router,
  Link,
  Navigate,
  Route,
  Routes,
} from "react-router-dom";
import { Layout } from "./components/";
import { useAuth } from "./hooks/useAuth";
import AdminCategoryPage from "./pages/admin/AdminCategoryPage";
import AdminCompanyPage from "./pages/admin/AdminCompanyPage";
import AdminHomePage from "./pages/admin/AdminHomePage";
import AdminJobPage from "./pages/admin/AdminJobPage";
import AdminPostPage from "./pages/admin/AdminPostPage";
import AdminUserPage from "./pages/admin/AdminUserPage";
import AuthPage from "./pages/AuthPage";
import ChatPage from "./pages/ChatPage";
import CompanyPage from "./pages/CompanyPage";
import CVPage from "./pages/CVPage";
import HomePage from "./pages/HomePage";
import DetailJobPage from "./pages/job/DetailJobPage";
import JobPage from "./pages/job/JobPage";
import NotificationPage from "./pages/NotificationPage";
import PasswordPage from "./pages/PasswordPage";
import ProfilePage from "./pages/ProfilePage";
import SearchPage from "./pages/SearchPage";
import { cleanSocket, initSocket, socketOnListenters } from "./socket";

function PrivateUserRoute({ children }) {
  const { isAuth } = useAuth("employee-HR-manager");
  return isAuth ? children : <Navigate to="/login" />;
}

function AuthRoute({ children }) {
  const { isAuth } = useAuth();
  return isAuth ? children : <Navigate to="/login" />;
}

function PrivateAdminRoute({ children }) {
  const { isAuth } = useAuth("admin");
  return isAuth ? children : <Navigate to="/login" />;
}

export default function MyRoutes() {
  const { isAuth, user } = useAuth();
  const queryClient = useQueryClient();
  const dispatch = useDispatch();

  useEffect(() => {
    if (isAuth) {
      initSocket(dispatch);
      socketOnListenters(queryClient, dispatch, user);
    } else {
      cleanSocket();
    }
    return () => {
      cleanSocket();
    };
  }, [isAuth]);

  return (
    <Router>
      <Routes>
        <Route path="/login" element={<AuthPage isLogin />} />
        <Route path="/CV" element={<CVPage />} />
        <Route path="/signup" element={<AuthPage />} />
        <Route path="/logout" element={<Navigate replace to="/login" />} />
        <Route path="/forgot-password" element={<PasswordPage isForgot />} />
        <Route path="/change-password" element={<PasswordPage />} />
        <Route
          path="/"
          element={
            <AuthRoute>
              <Layout />
            </AuthRoute>
          }
        >
          <Route path="/notification" element={<NotificationPage />} />
        </Route>
        <Route
          path="/"
          element={
            <PrivateUserRoute>
              <Layout />
            </PrivateUserRoute>
          }
        >
          <Route index element={<HomePage />} />
          <Route path="job/*">
            <Route index element={<JobPage />} />
            <Route path=":jobId" element={<DetailJobPage />} />
          </Route>
          <Route path="search/*">
            <Route index element={<SearchPage />} />
          </Route>
          <Route path="company/*">
            <Route index element={<CompanyPage />} />
            <Route path=":companyId" element={<CompanyPage />} />
          </Route>
          <Route path="chat/*">
            <Route index element={<ChatPage />} />
            <Route path=":roomId" element={<ChatPage />} />
          </Route>
          <Route path="profile/*">
            <Route index element={<ProfilePage />} />
            <Route path=":userId" element={<ProfilePage />} />
          </Route>
          <Route path="*" element={<NoMatch />} />
        </Route>
        <Route
          path="/admin"
          element={
            <PrivateAdminRoute>
              <Layout />
            </PrivateAdminRoute>
          }
        >
          <Route path="/admin/home" element={<AdminHomePage />} />
          <Route path="/admin/user" element={<AdminUserPage />} />
          <Route path="/admin/post" element={<AdminPostPage />} />
          <Route path="/admin/job" element={<AdminJobPage />} />
          <Route path="/admin/company" element={<AdminCompanyPage />} />
          <Route path="/admin/category" element={<AdminCategoryPage />} />
          <Route
            path="/admin/logout"
            element={<Navigate replace to="/login" />}
          />
        </Route>
        <Route path="*" element={<NoMatch />} />
      </Routes>
    </Router>
  );
}

function NoMatch() {
  return (
    <div>
      <h1>Nothing to see here!</h1>
      <p>
        <Link to="/">Go to the home page</Link>
      </p>
    </div>
  );
}
