//follow
export const FOLLOW_USER = "FOLLOW:USER";
export const FOLLOW_COMPANY = "FOLLOW:COMPANY";
export const FOLLOW_JOB = "FOLLOW:JOB";

//apply job
export const APPLY_JOB = "APPLY:JOB";

// change owner
export const CHANGE_OWNER = "CHANGE:OWNER";

// member
export const ADD_MEMBER = "ADD:MEMBER";
export const DELETE_MEMBER = "DELETE:MEMBER";

// create
export const CREATE_POST = "Create:Post";
export const CREATE_USER_POST = "Create:UserPost";
export const CREATE_COMPANY_POST = "Create:CompanyPost";
export const CREATE_JOB_FOR_USER = "Create:JobForUser";
export const CREATE_JOB_FOR_ADMIN = "Create:JobForAdmin";
export const CREATE_COMPANY = "Create:Company";
export const CREATE_REPORT_JOB = "Create:ReportJob";
export const CREATE_REPORT_POST = "Create:ReportPost";

//connect
export const CONNECT_USER = "Connect:User";
export const CONNECT_JOB = "Connect:Job";

// confirm
export const CONFIRM_COMPANY = "Confirm:Company";
export const CONFIRM_CONNECT_USER = "Confirm:ConnectUser";
export const CONFIRM_CONNECT_JOB = "Confirm:ConnectJob";
export const CONFIRM_JOB = "Confirm:Job";
export const CONFIRM_ADD_MEMBER = "Confirm:AddMember";
export const CONFIRM_APPLY_JOB = "Confirm:ApplyJob";
export const CONFIRM_DELETE_MEMBER = "Confirm:DeleteMember";
export const CONFIRM_REPORT_JOB = "Confirm:ReportJob";
export const CONFIRM_REPORT_POST = "Confirm:ReportPost";

// can action at notification page
export const canAction = [
  ADD_MEMBER,
  CREATE_JOB_FOR_ADMIN,
  CREATE_COMPANY,
  CONNECT_USER,
  CONNECT_JOB,
  CREATE_REPORT_JOB,
  CREATE_REPORT_POST,
];

//status
export const PENDING = "pending";
export const VIEWED = "viewed";
export const ACCEPTED = "accepted";
export const REJECTED = "rejected";

//action
export const FOLLOW = "FOLLOW";
export const CONNECT = "Connect";

//confirm
export const CONFIRM = "Confirm";
