export const XL_RESPONSIVE_WIDTH = "(min-width:1300px)";
export const LG_RESPONSIVE_WIDTH = (theme) => theme.breakpoints.up("lg");
export const MD_RESPONSIVE_WIDTH = (theme) => theme.breakpoints.up("md");
export const SM_RESPONSIVE_WIDTH = (theme) => theme.breakpoints.up("sm");
export const XS_RESPONSIVE_WIDTH = (theme) => theme.breakpoints.up("xs");
