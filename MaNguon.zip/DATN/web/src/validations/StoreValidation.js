const yup = require("yup");

exports.formDestroyFileSchema = yup.object({
  body: yup.object({
    publicId: yup.string().required("publicId được yêu cầu"),
    type: yup
      .mixed()
      .oneOf(["image", "video", "raw"])
      .required("type được yêu cầu"),
  }),
});
