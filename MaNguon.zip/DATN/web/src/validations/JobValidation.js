import * as yup from "yup";

export const formCreateJobSchema = yup.object({
  title: yup
    .string()
    .trim()
    .min(3, "nhan đề công việc phải có ít nhất 3 ký tự")
    .max(200, "nhan đề công việc phải có nhiều nhất 100 ký tự")
    .required("nhan đề công việc được yêu cầu"),
  salary: yup
    .string()
    .trim()
    .matches(
      /(^[0-9]+$)|(^[0-9]+-[0-9]+$)/,
      "Lương sai định dạng , vd: 1000 hoặc 1000-2000"
    )
    .required("lương được yêu cầu"),
  job_type: yup.mixed().oneOf(["fulltime", "parttime", "freelance"]),
  // job_type: yup.string().required("loại công việc được yêu cầu"),
  numbers: yup
    .number()
    .typeError("số lượng tuyển phải là một số")
    .min(1, "số lượng tuyển phải lớn hơn 0")
    .max(100, "số lượng tuyển phải nhỏ hơn 100")
    .required("số lượng công việc được yêu cầu"),
  categories: yup.string().required("kỹ năng được yêu cầu"),
  location: yup
    .string()
    .min(3, "địa điểm công việc phải có ít nhất 3 ký tự")
    .required("kỹ năng được yêu cầu"),
  requirements: yup
    .string()
    .required("yêu cầu không được để trống")
    .min(10, "hãy mô tả thêm"),
  responsibilities: yup
    .string()
    .required("nhiệm vụ không được để trống")
    .min(10, "hãy mô tả thêm"),
  deadline: yup.string().required("hạn nộp hồ sơ không được để trống"),
});

export const formUpdateApplicantJobSchema = yup.object({
  phone: yup
    .string()
    .matches(
      /^((\\+[1-9]{1,4}[ \\-]*)|(\\([0-9]{2,3}\\)[ \\-]*)|([0-9]{2,4})[ \\-]*)*?[0-9]{3,4}?[ \\-]*[0-9]{3,4}?$/,
      "Số điện thoại không đúng định dạng"
    )
    .required("phone được yêu cầu"),
  email: yup
    .string()
    .email("email sai định dạng")
    .required("email được yêu cầu"),
});

export const formDeleteApplicantJobSchema = yup.object({
  body: yup.object({
    jobId: yup.string().required("jobId được yêu cầu"),
  }),
});

export const formUpdateJobSchema = yup.object({
  body: yup.object({
    jobId: yup.string().required("jobId được yêu cầu"),
  }),
});

export const formConfirmJobSchema = yup.object({
  body: yup.object({
    jobId: yup
      .string()
      .required("jobId được yêu cầu")
      .test("len", "yêu cầu 24 ký tự cho jobId", (val) => val.length === 24),
    active: yup.boolean().required("trạng thái được yêu cầu"),
  }),
});

export const formListJobSchema = yup.object({
  query: yup.object({
    page: yup.string().required("trang được yêu cầu"),
    active: yup.boolean().required("trạng thái được yêu cầu"),
    limit: yup.number().required("số lượng được yêu cầu"),
    keywords: yup.string().required("từ khóa được yêu cầu"),
  }),
});

export const formInfoJobSchema = yup.object({
  query: yup.object({
    jobId: yup.string().required("jobId được yêu cầu"),
  }),
});
export const formJobRelateCurrenJobSchema = yup.object({
  query: yup.object({
    page: yup.string().required("trang được yêu cầu"),
    jobId: yup.string().required("jobId được yêu cầu"),
    limit: yup.number().required("số lượng được yêu cầu"),
  }),
});
