const yup = require("yup");

exports.formCreateMessageSchema = yup.object({
  body: yup.object({
    roomId: yup
      .string()
      .required("roomId được yêu cầu")
      .test("len", "yêu cầu 24 ký tự cho jobId", (val) => val.length === 24),
    message: yup.object().defined(),
  }),
});

exports.formReactionMessageSchema = yup.object({
  body: yup.object({
    messageId: yup
      .string()
      .required("messageId được yêu cầu")
      .test(
        "len",
        "yêu cầu 24 ký tự cho messageId",
        (val) => val.length === 24
      ),
    reaction: yup.object().shape({
      reaction: yup
        .mixed()
        .oneOf(["like", "love", "haha", "wow", "sad", "angry"]),
    }),
  }),
});

exports.formRemoveMessageSchema = yup.object({
  body: yup.object({
    messageId: yup
      .string()
      .required("messageId được yêu cầu")
      .test(
        "len",
        "yêu cầu 24 ký tự cho messageId",
        (val) => val.length === 24
      ),
  }),
});
