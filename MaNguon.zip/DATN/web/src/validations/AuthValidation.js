import * as yup from "yup";

export const formLoginSchema = yup.object({
  email: yup.string().required("email được yêu cầu"),
  password: yup
    .string()
    .required("mật khẩu được yêu cầu")
    .min(6, "mật khẩu phải có ít nhất 6 ký tự")
    .max(20, "mật khẩu không được quá 20 ký tự"),
});

export const formSignupSchema = yup.object({
  name: yup
    .string()
    .min(2, "Tên tài khoản phải có ít nhất 2 ký tự")
    .max(30, "Tên tài khoản không được vượt quá 30 ký tự")
    .required("tên được yêu cầu"),
  email: yup.string().required("email được yêu cầu"),
  password: yup
    .string()
    .required("mật khẩu được yêu cầu")
    .min(6, "mật khẩu phải có ít nhất 6 ký tự")
    .max(20, "mật khẩu không được quá 20 ký tự"),
  confirmPassword: yup
    .string()
    .required("xác thực mật khẩu được yêu cầu")
    .oneOf([yup.ref("password"), null], "phải khớp với mật khẩu"),
});

export const formForgotPasswordSchema = yup.object({
  email: yup.string().required("email được yêu cầu"),
});

export const formChangePasswordSchema = yup.object({
  password: yup
    .string()
    .required("mật khẩu được yêu cầu")
    .min(6, "mật khẩu phải có ít nhất 6 ký tự")
    .max(20, "mật khẩu không được quá 20 ký tự"),
  confirmPassword: yup
    .string()
    .required("xác thực mật khẩu được yêu cầu")
    .oneOf([yup.ref("password"), null], "phải khớp với mật khẩu"),
});

export const formUpdatePasswordSchema = yup.object({
  newPassword: yup
    .string()
    .required("mật khẩu mới được yêu cầu")
    .min(6, "mật khẩu mới phải có ít nhất 6 ký tự")
    .max(20, "mật khẩu mới không được quá 20 ký tự"),
  oldPassword: yup
    .string()
    .required("mật khẩu cũ được yêu cầu")
    .min(6, "mật khẩu cũ phải có ít nhất 6 ký tự")
    .max(20, "mật khẩu cũ không được quá 20 ký tự"),
});
