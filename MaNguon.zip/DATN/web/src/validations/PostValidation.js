import * as yup from "yup";

export const formCreatePostSchema = yup.object({
  content: yup.string().required("nội dung được yêu cầu"),
});

export const formFindPostSchema = yup.object({
  params: yup.object({
    postId: yup
      .string()
      .required("messageId được yêu cầu")
      .test(
        "len",
        "yêu cầu 24 ký tự cho messageId",
        (val) => val.length === 24
      ),
  }),
});

export const formListPostSchema = yup.object({
  query: yup.object({
    page: yup.number().required("trang được yêu cầu"),
    limit: yup.number().required("number được yêu cầu"),
  }),
});

export const formListPostByUserSchema = yup.object({
  query: yup.object({
    page: yup.number().required("trang được yêu cầu"),
    limit: yup.number().required("number được yêu cầu"),
  }),
});

export const formListPostByCompanySchema = yup.object({
  params: yup.object({
    companyId: yup
      .string()
      .required("companyId được yêu cầu")
      .test(
        "len",
        "yêu cầu 24 ký tự cho companyId",
        (val) => val.length === 24
      ),
  }),
  page: yup.number().required("trang được yêu cầu"),
  limit: yup.number().required("number được yêu cầu"),
});

export const formListPostByFeedSchema = yup.object({
  page: yup.number().required("trang được yêu cầu"),
  limit: yup.number().required("number được yêu cầu"),
});

export const formSearchPostSchema = yup.object({
  keywords: yup.string().required("keywords được yêu cầu"),
  page: yup.number().required("trang được yêu cầu"),
  limit: yup.number().required("number được yêu cầu"),
});

export const formReportSchema = yup.object({
  access: yup
    .string()
    .required("jobId được yêu cầu")
    .test("len", "yêu cầu 24 ký tự cho jobId", (val) => val.length === 24),
  onAccess: yup.mixed().oneOf(["Post", "Job"]),
  message: yup.string().required("message được yêu cầu"),
});
