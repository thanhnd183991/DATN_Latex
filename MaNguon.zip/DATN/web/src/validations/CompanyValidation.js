import * as yup from "yup";

export const formCreateCompanySchema = yup.object({
  name: yup
    .string()
    .trim()
    .min(3, "tên công ty phải có ít nhất 3 ký tự")
    .max(100, "tên công ty phải có tối đa 100 ký tự")
    .required("tên công ty được yêu cầu"),
  overview: yup
    .string()
    .min(3, "tổng quan công ty phải có ít nhất 3 ký tự")
    .required("tổng quan công ty được yêu cầu"),
  website: yup
    .string()
    .trim()
    .url("địa chỉ website không hợp lệ")
    .required("địa chỉ website được yêu cầu"),
  industry: yup.string().required("ngành nghề công ty được yêu cầu"),
  headquarters: yup.string().required("địa chỉ công ty được yêu cầu"),
});

export const formDeleteCompanySchema = yup.object({
  companyId: yup.string().required("companyId được yêu cầu"),
});

export const formConfirmCompanySchema = yup.object({
  companyId: yup.string().required("companyId được yêu cầu"),
});

export const formCompanyMembersSchema = yup.object({
  companyId: yup.string().required("companyId được yêu cầu"),
});

export const formRemoveEmployeeSchema = yup.object({
  companyId: yup.string().required("companyId được yêu cầu"),
  emmployees: yup
    .array()
    .of(yup.string().required("employeeId được yêu cầu"))
    .min(1, "danh sách nhân viên được yêu cầu"),
});

export const formAddEmployeeSchema = yup.object({
  companyId: yup.string().required("companyId được yêu cầu"),
  emmployees: yup
    .array()
    .of(yup.string())
    .min(1, "danh sách nhân viên được yêu cầu"),
});

export const formListCompanySchema = yup.object({
  page: yup.string().required("trang được yêu cầu"),
  limit: yup.string().required("số lượng được yêu cầu"),
  active: yup.string().required("trạng thái được yêu cầu"),
});
export const formUpdateCompanySchema = yup.object({
  companyId: yup.string().required("companyId được yêu cầu"),
  name: yup.string().required("tên công ty được yêu cầu"),
  overview: yup.string().required("tổng quan công ty được yêu cầu"),
  industry: yup.string().required("ngành nghề công ty được yêu cầu"),
  headquaters: yup.string().required("địa chỉ công ty được yêu cầu"),
});
