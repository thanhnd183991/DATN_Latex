import { Box, Grid, useMediaQuery } from "@mui/material";
import { useState } from "react";
import { BarChart, Widgets } from "../../components";
import { LG_RESPONSIVE_WIDTH } from "../../constants/Responsive";
import {
  useChartJobCatergory,
  useChartJobCompany,
} from "../../hooks/admin/useAdminHome";

const AdminHomePage = () => {
  console.log("render AdminHomePage");
  const [page, setPage] = useState(1);
  const LG_RESPONSIVE = useMediaQuery(LG_RESPONSIVE_WIDTH);
  const { dataChartJobCategory, statusChartJobCategory } =
    useChartJobCatergory();
  const { dataChartJobCompany, statusChartJobCompany } = useChartJobCompany();

  const handleChange = (event, value) => {
    setPage(value);
  };
  return (
    <Box flex={LG_RESPONSIVE ? 7 : 5} p={2}>
      <Widgets />
      <Grid container spacing={2}>
        <Grid item xs={12} sm={12} md={6}>
          <BarChart
            status={statusChartJobCompany}
            payload={dataChartJobCompany}
            name="Công việc"
            label="Công ty - Công việc (đang hoạt động)"
            width="100%"
          />
        </Grid>
        <Grid item xs={12} sm={12} md={6}>
          <BarChart
            status={statusChartJobCategory}
            payload={dataChartJobCategory}
            name="Công việc"
            label="Kỹ năng - Công việc"
            width="100%"
          />
        </Grid>
      </Grid>
    </Box>
  );
};

export default AdminHomePage;
