import { Box, Grid, useMediaQuery } from "@mui/material";
import { BarChart, DonutChart, MyPostTableGrid } from "../../components";
import { LG_RESPONSIVE_WIDTH } from "../../constants/Responsive";
import {
  useAdminCountTypePost,
  useAdminPostStats,
} from "../../hooks/admin/useAdminPost";

const AdminPostPage = () => {
  const { dataCountTypePost, statusContType } = useAdminCountTypePost();
  const LG_RESPONSIVE = useMediaQuery(LG_RESPONSIVE_WIDTH);
  const { dataPostStats, statusStatsPost } = useAdminPostStats();
  return (
    <Box flex={LG_RESPONSIVE ? 7 : 5} p={2}>
      <Grid container spacing={2}>
        <Grid item xs={12} sm={12} md={6}>
          <BarChart
            status={statusStatsPost}
            payload={dataPostStats}
            name="Bài viết"
            label="Bài viết theo năm"
            width="100%"
          />
        </Grid>
        <Grid item xs={12} sm={12} md={6}>
          <DonutChart
            status={statusContType}
            payload={dataCountTypePost}
            label="Loại bài viết"
            width="100%"
          />
        </Grid>
      </Grid>
      <MyPostTableGrid />
    </Box>
  );
};

export default AdminPostPage;
