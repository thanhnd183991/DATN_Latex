import { Box, Grid } from "@mui/material";
import { BarChart, DonutChart, MyUserTableGrid } from "../../components";
import {
  useAdminUserStats,
  useAdminUserStatus,
} from "../../hooks/admin/useAdminUser";

const AdminUserPage = () => {
  const { dataUserStats, statusUserStats } = useAdminUserStats();
  const { dataUserStatus, statusUserStatus } = useAdminUserStatus();

  return (
    <Box flex={7} p={2}>
      <Grid container spacing={2}>
        <Grid item xs={12} sm={12} md={6}>
          <BarChart
            status={statusUserStats}
            payload={dataUserStats}
            name="Người dùng"
            label="Người dùng theo năm"
            width="100%"
          />
        </Grid>
        <Grid item xs={12} sm={12} md={6}>
          <DonutChart
            status={statusUserStatus}
            payload={dataUserStatus}
            label="Trạng thái người dùng"
            width="100%"
          />
        </Grid>
      </Grid>
      <MyUserTableGrid />
    </Box>
  );
};

export default AdminUserPage;
