import { Box, useMediaQuery } from "@mui/material";
import { MyCategoryTableGrid } from "../../components";
import { LG_RESPONSIVE_WIDTH } from "../../constants/Responsive";
import {
  useAdminCompanyStats,
  useAdminCompanyStatus,
} from "../../hooks/admin/useAdminCompany";

const AdminCompanyPage = () => {
  const LG_RESPONSIVE = useMediaQuery(LG_RESPONSIVE_WIDTH);
  const { dataCompanyStats, statusCompanyStats } = useAdminCompanyStats();
  const { dataCompanyStatus, statusCompanyStatus } = useAdminCompanyStatus();
  return (
    <Box flex={LG_RESPONSIVE ? 7 : 5} p={2}>
      <MyCategoryTableGrid />
    </Box>
  );
};

export default AdminCompanyPage;
