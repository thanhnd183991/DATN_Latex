import { Box, Grid, useMediaQuery } from "@mui/material";
import { BarChart, DonutChart, MyJobTableGrid } from "../../components";
import { LG_RESPONSIVE_WIDTH } from "../../constants/Responsive";
import {
  useAdminJobStats,
  useAdminJobStatus,
} from "../../hooks/admin/useAdminJob";

const AdminJobPage = () => {
  const LG_RESPONSIVE = useMediaQuery(LG_RESPONSIVE_WIDTH);
  const { dataJobStats, statusJobStats } = useAdminJobStats();
  const { dataJobStatus, statusJobStatus } = useAdminJobStatus();
  return (
    <Box flex={LG_RESPONSIVE ? 7 : 5} p={2}>
      <Grid container spacing={2}>
        <Grid item xs={12} sm={12} md={6}>
          <BarChart
            status={statusJobStats}
            payload={dataJobStats}
            name="Công việc"
            label="Công việc theo tháng"
            width="100%"
          />
        </Grid>
        <Grid item xs={12} sm={12} md={6}>
          <DonutChart
            status={statusJobStatus}
            payload={dataJobStatus}
            label="Trạng thái công việc"
            width="100%"
          />
        </Grid>
      </Grid>
      <MyJobTableGrid />
    </Box>
  );
};

export default AdminJobPage;
