import { Box, Grid, useMediaQuery } from "@mui/material";
import { BarChart, DonutChart, MyCompanyTableGrid } from "../../components";
import { LG_RESPONSIVE_WIDTH } from "../../constants/Responsive";
import {
  useAdminCompanyStats,
  useAdminCompanyStatus,
} from "../../hooks/admin/useAdminCompany";

const AdminCompanyPage = () => {
  const LG_RESPONSIVE = useMediaQuery(LG_RESPONSIVE_WIDTH);
  const { dataCompanyStats, statusCompanyStats } = useAdminCompanyStats();
  const { dataCompanyStatus, statusCompanyStatus } = useAdminCompanyStatus();
  return (
    <Box flex={LG_RESPONSIVE ? 7 : 5} p={2}>
      <Grid container spacing={2}>
        <Grid item xs={12} sm={12} md={6}>
          <BarChart
            status={statusCompanyStats}
            payload={dataCompanyStats}
            name="Công ty"
            label="Công ty theo tháng"
            width="100%"
          />
        </Grid>
        <Grid item xs={12} sm={12} md={6}>
          <DonutChart
            status={statusCompanyStatus}
            payload={dataCompanyStatus}
            label="Trạng thái công ty"
            width="100%"
          />
        </Grid>
      </Grid>
      <MyCompanyTableGrid />
    </Box>
  );
};

export default AdminCompanyPage;
