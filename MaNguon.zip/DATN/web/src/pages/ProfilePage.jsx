import { useParams } from "react-router-dom";
import { Profile, Rightbar } from "../components";
import { useUser } from "../hooks/useUsers";

const ProfilePage = () => {
  const { userId } = useParams();
  // console.log(userId);
  const { data, isLoading, error, status } = useUser(userId);
  if (status === "error") {
    return <div>Not found user</div>;
  }

  return (
    <>
      <Profile user={data} isLoading={isLoading} />
      <Rightbar type="user" />
    </>
  );
};

export default ProfilePage;
