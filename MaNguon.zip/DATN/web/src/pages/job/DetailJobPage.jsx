import { Box } from "@mui/material";
import { useParams } from "react-router-dom";
import { DetailJob, Rightbar } from "../../components";
import { useJob } from "../../hooks/useJobs";

const JobPage = () => {
  const { jobId } = useParams();
  const { job, status } = useJob(jobId);
  return (
    <>
      <Box flex={4} p={{ xs: 2, md: 2 }}>
        {status === "loading" ? (
          <p>Loading...</p>
        ) : status === "error" ? (
          <p>Job not found</p>
        ) : (
          <DetailJob job={job} />
        )}
      </Box>
      <Rightbar type="job" relate={jobId} />
    </>
  );
};

export default JobPage;
