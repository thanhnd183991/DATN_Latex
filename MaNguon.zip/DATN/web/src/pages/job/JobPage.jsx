import { JobTabs, Rightbar } from "../../components";

const JobPage = () => {
  return (
    <>
      <JobTabs />
      <Rightbar type="company" />
    </>
  );
};

export default JobPage;
