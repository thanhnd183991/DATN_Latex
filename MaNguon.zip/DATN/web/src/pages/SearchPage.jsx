import { useSearchParams } from "react-router-dom";
import { SearchTabs } from "../components";

const SearchPage = () => {
  const [searchParams] = useSearchParams();

  return (
    <>
      <SearchTabs params={Object.fromEntries([...searchParams])} />
    </>
  );
};

export default SearchPage;
