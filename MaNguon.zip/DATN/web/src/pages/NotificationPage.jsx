import { useEffect } from "react";
import { useDispatch } from "react-redux";
import { ListNotification, Rightbar } from "../components";
import { resetNotify } from "../redux/features/badgeSlice";

const NotificationPage = () => {
  const dispatch = useDispatch();

  useEffect(() => {
    console.log("reset notify");
    dispatch(resetNotify());
  }, []);
  return (
    <>
      <ListNotification />
      <Rightbar type="user" />
    </>
  );
};

export default NotificationPage;
