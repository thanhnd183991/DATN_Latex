import { Box, Paper } from "@mui/material";
import { useEffect } from "react";
import { useDispatch } from "react-redux";
import { useParams } from "react-router-dom";
import { ChatRoom, ListChat } from "../components";
import { useMe } from "../hooks/useAuth";
import { resetChat } from "../redux/features/badgeSlice";

const ChatPage = () => {
  const { roomId } = useParams();
  const { me, isLoadingMe } = useMe();
  const dispatch = useDispatch();

  useEffect(() => {
    console.log("reset chat");
    dispatch(resetChat());
  }, []);

  return (
    <>
      <Box flex={3} p={2}>
        <Paper sx={{ py: 1 }}>
          <ListChat roomId={roomId} isLoadingMe={isLoadingMe} me={me} />
        </Paper>
      </Box>
      <ChatRoom roomId={roomId} isLoadingMe={isLoadingMe} me={me} />
    </>
  );
};

export default ChatPage;
