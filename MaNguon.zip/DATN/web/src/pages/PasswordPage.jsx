import { Box } from "@mui/material";
import { useSearchParams } from "react-router-dom";
import { Password } from "../components";

export default function PasswordPage({ isForgot }) {
  console.log("PasswordPage.isForgot", isForgot);
  const [searchParams] = useSearchParams();
  return (
    <Box
      sx={{
        position: "absolute",
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        background:
          "linear-gradient(to bottom, rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), url('https://mangthuvien.net/Uploads/Post/thanhhuong-185031115026-work.jpg') top left / cover  no-repeat",
      }}
    >
      {isForgot ? (
        <Password isForgot />
      ) : (
        <Password params={Object.fromEntries([...searchParams])} />
      )}
    </Box>
  );
}
