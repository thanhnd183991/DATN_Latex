import { useParams } from "react-router-dom";
import { Company, Rightbar } from "../components";

const CompanyPage = () => {
  const { companyId } = useParams();
  return (
    <>
      <Company companyId={companyId} />
      <Rightbar type="company" />
    </>
  );
};

export default CompanyPage;
