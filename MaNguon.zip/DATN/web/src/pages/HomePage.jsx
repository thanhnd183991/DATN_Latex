import { Feed, Rightbar } from "../components";

const HomePage = () => {
  return (
    <>
      <Feed isFeed />
      <Rightbar type="user" />
    </>
  );
};

export default HomePage;
