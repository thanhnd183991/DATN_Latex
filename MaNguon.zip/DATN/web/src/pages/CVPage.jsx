import { CV } from "../components";
import { PDFDownloadLink, PDFViewer } from "@react-pdf/renderer";
import { useMe } from "../hooks/useAuth";
import RichText from "../components/RichText";
import { Link } from "react-router-dom";

export default function CVPage() {
  const { me, statusMe } = useMe();
  return (
    <>
      {statusMe === "loading" ? (
        <div>Loading...</div>
      ) : statusMe === "error" ? (
        <div>Error</div>
      ) : (
        <>
          <div id="profile-about">
            <RichText text={me.about} />
          </div>
          <div id="profile-experience">
            <RichText text={me.experience} />
          </div>
          <Link to={`/profile/${me._id}/`}>Download PDF</Link>
          <PDFViewer style={{ width: "100%", height: "100vh" }}>
            <CV user={me} />
          </PDFViewer>
        </>
      )}
    </>
  );
}
