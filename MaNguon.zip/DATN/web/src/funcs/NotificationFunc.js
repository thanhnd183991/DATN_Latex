import { toast } from "react-toastify";
import {
  ACCEPTED,
  CONFIRM_COMPANY,
  CONNECT_USER,
  DELETE_MEMBER,
  FOLLOW_USER,
  CONFIRM_CONNECT_USER,
  CONFIRM_CONNECT_JOB,
  CONNECT_JOB,
  CONFIRM_ADD_MEMBER,
  ADD_MEMBER,
  CREATE_COMPANY_POST,
  FOLLOW_COMPANY,
  CREATE_COMPANY,
  CONFIRM_JOB,
  CREATE_JOB_FOR_ADMIN,
  CONFIRM_APPLY_JOB,
  CHANGE_OWNER,
  CREATE_POST,
  CONFIRM_REPORT_POST,
  CONFIRM_REPORT_JOB,
  CREATE_REPORT_POST,
  CREATE_REPORT_JOB,
} from "../constants/NotifyConstant";
import { keys } from "../hooks/queryKeys";
import { logout } from "../redux/features/authSlice";
import {
  addChat,
  addNotify,
  resetChat,
  resetNotify,
} from "../redux/features/badgeSlice";
import { findInInfiniteQuery } from "../utils/find";
import {
  addToInfiniteQuery,
  deleteInInfiniteQuery,
} from "../utils/opereationQueryClient";
import { newMessageFunc } from "./ChatFunc";

export const newFollowNotifyFunc = async (
  queryClient,
  data,
  meId,
  dispatch,
  type
) => {
  if (!data) return;
  await queryClient.cancelQueries(keys.user(meId));
  queryClient.invalidateQueries(keys.user(meId));

  if (type === FOLLOW_USER) {
    queryClient.refetchQueries(keys.followingUser(meId, ""));
    queryClient.invalidateQueries(keys.suggestionUser(0));

    const listPosts = queryClient.getQueryData(keys.infinitePosts(null));
    if (listPosts) {
      if (listPosts.pages.length <= 1) {
        queryClient.invalidateQueries(keys.infinitePosts(null));
      }
    }
  } else if (type == FOLLOW_COMPANY) {
    queryClient.refetchQueries(keys.followingCompanyUser(meId, ""));
    queryClient.invalidateQueries(keys.suggestionCompany(0));
  }
  if (data.message) {
    return;
  }

  addNotifyFunc(queryClient, data, dispatch);
};

export const addNotifyFunc = async (queryClient, data, dispatch) => {
  const isChatHref = window.location.href.includes("/notification");
  if (!isChatHref) {
    // nếu không phải ở chat page thì tăng badge notify
    dispatch(addNotify());
  }

  await addToInfiniteQuery(queryClient, keys.notifications("All"), data);
  await addToInfiniteQuery(
    queryClient,
    keys.notifications(data.data.type),
    data
  );

  if (data.data.type === CONFIRM_CONNECT_USER) {
    if (data?.data?.receiver[0]?.status === ACCEPTED) {
      queryClient.invalidateQueries(
        keys.chatRoom(data?.data?.access?._id || data.data.access)
      );
    }
    await deleteInInfiniteQuery(
      queryClient,
      keys.notifications(CONNECT_USER),
      data.data._id
    );
  }

  if (data.data.type === CONFIRM_CONNECT_JOB) {
    if (data?.data?.receiver[0]?.status === ACCEPTED) {
      queryClient.invalidateQueries(
        keys.chatRoom(data?.data?.access?._id || data.data.access)
      );
    }
    await deleteInInfiniteQuery(
      queryClient,
      keys.notifications(CONNECT_JOB),
      data.data._id
    );
  }

  if (data.data.type === CONFIRM_ADD_MEMBER) {
    await deleteInInfiniteQuery(
      queryClient,
      keys.notifications(ADD_MEMBER),
      data.data._id
    );
    queryClient.invalidateQueries(
      keys.companyMember(data.data.access?.id || data.data.access)
    );
  }

  if (data.data.type === CONFIRM_APPLY_JOB) {
    queryClient.invalidateQueries(keys.job(data.data.access));
    queryClient.invalidateQueries(keys.userSaveJobCart);
    queryClient.invalidateQueries(keys.userApplyJobCart);
    queryClient.invalidateQueries(keys.jobRecommend(null));
  }

  if (data.data.type === CREATE_POST) {
    // queryClient.invalidateQueries(keys.infinitePosts(null));
  }

  if (data.data.type === CONFIRM_COMPANY) {
    await deleteInInfiniteQuery(
      queryClient,
      keys.notifications(CREATE_COMPANY),
      data.data._id
    );
  }

  if (data.data.type === CHANGE_OWNER) {
    queryClient.invalidateQueries(
      keys.jobByHR(
        null,
        data.data.receiver[0]?.user?._id || data.data.receiver[0]?.user
      )
    );
    queryClient.invalidateQueries(
      keys.jobByHR(
        null,
        data.data.receiver[1]?.user?._id || data.data.receiver[1]?.user
      )
    );
    queryClient.invalidateQueries(keys.listChatCompany);
  }

  if (data.data.type === CONFIRM_JOB) {
    await deleteInInfiniteQuery(
      queryClient,
      keys.notifications(CREATE_JOB_FOR_ADMIN),
      data.data._id
    );
    queryClient.invalidateQueries(
      keys.job(data.data?.access?._id || data.data?.access)
    );
  }

  if (data.data.type === CONFIRM_REPORT_POST) {
    await deleteInInfiniteQuery(
      queryClient,
      keys.notifications(CREATE_REPORT_POST),
      data.data._id
    );
  }

  if (data.data.type === CONFIRM_REPORT_JOB) {
    if (data?.data?.receiver[0]?.status === ACCEPTED) {
      queryClient.invalidateQueries(
        keys.job(data?.data?.access?._id || data.data.access)
      );
    }
    await deleteInInfiniteQuery(
      queryClient,
      keys.notifications(CREATE_REPORT_JOB),
      data.data._id
    );
  }
};

export const canLoginNotifyFunc = async (queryClient, data, meId, dispatch) => {
  if (
    data?.data?.receiver[0].status === ACCEPTED &&
    data?.data?.type === CONFIRM_COMPANY &&
    data?.data?.sender._id === meId
  ) {
    queryClient.clear();
    dispatch(resetChat());
    dispatch(resetNotify());
    dispatch(logout());
    toast.success("Hãy đăng nhập lại để thay đổi quyền hạn");
    return;
  }

  if (
    data?.data?.type === DELETE_MEMBER &&
    data?.data?.receiver[0].user === meId
  ) {
    queryClient.clear();
    dispatch(resetChat());
    dispatch(resetNotify());
    dispatch(logout());
    toast.success("Hãy đăng nhập lại để thay đổi quyền hạn");
    return;
  }
  if (
    data?.data?.receiver[0].status === ACCEPTED &&
    data?.data?.receiver[0].user._id === meId
  ) {
    queryClient.clear();
    dispatch(resetChat());
    dispatch(resetNotify());
    dispatch(logout());
    toast.success("Hãy đăng nhập lại để thay đổi quyền hạn");
    return;
  } else if (
    data?.data?.receiver[0].status === ACCEPTED &&
    data?.data?.receiver[0].user._id !== meId
  ) {
    queryClient.invalidateQueries(keys.companyMember(data?.data?.sender._id));
    queryClient.invalidateQueries(keys.listEmployees);
  }
  await addNotifyFunc(queryClient, data, dispatch);
  return;
};

export const confirmConnectJobNotifyFunc = async (
  queryClient,
  data,
  dispatch
) => {
  if (data.dataMessage) {
    await newMessageFunc(
      queryClient,
      data.dataMessage,
      data.dataMessage.roomId,
      dispatch
    );
  }
  await addNotifyFunc(queryClient, data, dispatch);
};
