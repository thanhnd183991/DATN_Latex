import { keys } from "../hooks/queryKeys";

export const reactionPostFunc = (queryClient, postId) => {
  if (!postId) return;
  const post = queryClient.getQueryData(keys.reactionPost(postId));
  if (!post) {
    return;
  }
  queryClient.invalidateQueries(keys.reactionPost(postId));
};

export const commentPostFunc = (queryClient, data) => {
  if (!data) return;
  if (data.postId) {
    queryClient.invalidateQueries(keys.countCommentPost(data.postId));
    queryClient.invalidateQueries(keys.commentRootPost(data.postId));
  }
  if (data.rootId) {
    queryClient.invalidateQueries(keys.commentChildrenPost(data.rootId));
  }
};

export const reactionCommentPostFunc = (queryClient, data) => {
  if (!data) return;
  if (data.root !== null) {
    queryClient.invalidateQueries(keys.commentChildrenPost(data.root));
  } else {
    queryClient.invalidateQueries(keys.commentRootPost(data.postId));
  }
};
