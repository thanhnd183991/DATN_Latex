import { keys } from "../hooks/queryKeys";
import { addChat } from "../redux/features/badgeSlice";
import { findInInfiniteQuery } from "../utils/find";

export const newMessageFunc = async (queryClient, data, roomId, dispatch) => {
  if (!data && !roomId) return;
  const isChatHref = window.location.href.includes("/chat");
  if (!isChatHref) {
    // nếu không phải ở chat page thì tăng badge chat
    dispatch(addChat({ roomId }));
  }

  await queryClient.cancelQueries(keys.messages(roomId));
  const dataMessages = queryClient.getQueryData(keys.messages(roomId));
  if (dataMessages) {
    const { pages, ...info } = dataMessages;
    pages[0].data.unshift(data.data);
    queryClient.setQueryData(keys.messages(roomId), {
      pages,
      ...info,
    });
  }

  const rooms = queryClient.getQueryData(
    data.typeRoom === "Personal" ? keys.listChatPersonal : keys.listChatCompany
  );
  if (!rooms) return;

  // debugger;
  const { pageIndex, index } = findInInfiniteQuery(rooms, roomId);
  if (pageIndex === null || index === null) {
    return;
  } else {
    rooms.pages[pageIndex].data[index].latestMessage = data.data;
    queryClient.setQueryData(
      data.typeRoom === "Personal"
        ? keys.listChatPersonal
        : keys.listChatCompany,
      rooms
    );
  }
};

export const reactionMessageFunc = async (queryClient, roomId, data) => {
  await queryClient.cancelQueries(keys.messages(roomId));
  const dataMessages = queryClient.getQueryData(keys.messages(roomId));
  if (!dataMessages) return;
  const { pages, ...info } = dataMessages;
  const { pageIndex, index } = findInInfiniteQuery(dataMessages, data.data._id);
  if (typeof pageIndex === "number" && typeof index === "number") {
    pages[pageIndex].data[index] = data.data;
    queryClient.setQueryData(keys.messages(roomId), {
      pages,
      ...info,
    });
  }
};

export const blockRoomFunc = async (queryClient, roomId, data) => {
  await queryClient.cancelQueries(keys.chatRoom(roomId));
  const chatRoom = queryClient.getQueryData(keys.chatRoom(roomId));
  if (!chatRoom) return;
  queryClient.setQueryData(keys.chatRoom(roomId), data.data);
};
