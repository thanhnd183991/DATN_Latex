import { io } from "socket.io-client";
import { eventsForChat } from "./chatSocket";
import { eventsForNotify } from "./notifySocket";
import { setChat, setNotify } from "../redux/features/badgeSlice";

let socket = null;

export const initSocket = (dispatch) => {
  if (socket) return;
  socket = io(
    `${import.meta.env.PROD ? "/" : import.meta.env.VITE_APP_API_URL}`,
    {
      query: {
        token: localStorage.getItem("token"),
      },
      // "force new connection": true,
      // reconnectionAttempt: "Infinity",
      // timeout: 10000,
    }
  );
  socket.emit("user-init", (data) => {
    if (data?.chatNotify?.status === 200) {
      dispatch(setChat(data.chatNotify.data));
    }
    if (data?.countNotify?.status === 200) {
      dispatch(setNotify(data.countNotify.countNotify));
    }
  });
};

export const cleanSocket = () => {
  if (!socket) return;
  socket.disconnect();
  socket.off();
  socket = null;
};

export const resetSocket = (queryClient, dispatch, me) => {
  cleanSocket();
  initSocket(dispatch);
  socketOnListenters(queryClient, dispatch, me);
};

export const getSocket = () => {
  return socket;
};

export const socketOnListenters = (queryClient, dispatch, me) => {
  eventsForChat(queryClient, dispatch);
  eventsForNotify(queryClient, dispatch, me);
};
