import { io } from "socket.io-client";
import {
  COMMENT_POST,
  REACTION_COMMENT_POST,
  REACTION_POST,
} from "../constants/PostConstant";
import {
  commentPostFunc,
  reactionCommentPostFunc,
  reactionPostFunc,
} from "../funcs/PostFunc";

let postSocket = null;

export const initPostSocket = () => {
  if (postSocket) return;
  postSocket = io(
    import.meta.env.PROD ? "/post" : `${import.meta.env.VITE_APP_API_URL}/post`,
    {
      query: {
        token: localStorage.getItem("token"),
      },
      // "force new connection": true,
      // reconnectionAttempt: "Infinity",
      // timeout: 10000,
    }
  );
  postSocket.emit("user-init");
};

export const cleanPostSocket = () => {
  if (!postSocket) return;
  postSocket.disconnect();
  postSocket.off();
  postSocket = null;
};

export const getPostSocket = () => {
  return postSocket;
};

export const eventsForPost = (queryClient) => {
  // reaction post
  getPostSocket()
    .off(REACTION_POST)
    .on(REACTION_POST, (data) => {
      console.log(data);
      reactionPostFunc(queryClient, data.postId);
    });

  // comment post
  getPostSocket()
    .off(COMMENT_POST)
    .on(COMMENT_POST, (data) => {
      console.log(data);
      commentPostFunc(queryClient, data);
    });

  // reaction comment post
  getPostSocket()
    .off(REACTION_COMMENT_POST)
    .on(REACTION_COMMENT_POST, (data) => {
      console.log(data);
      reactionCommentPostFunc(queryClient, data);
    });
};
