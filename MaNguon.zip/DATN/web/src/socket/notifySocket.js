import { getSocket } from ".";
import {
  ADD_MEMBER,
  APPLY_JOB,
  CHANGE_OWNER,
  CONFIRM_ADD_MEMBER,
  CONFIRM_APPLY_JOB,
  CONFIRM_COMPANY,
  CONFIRM_CONNECT_JOB,
  CONFIRM_CONNECT_USER,
  CONFIRM_DELETE_MEMBER,
  CONFIRM_JOB,
  CONFIRM_REPORT_JOB,
  CONFIRM_REPORT_POST,
  CONNECT_JOB,
  CONNECT_USER,
  CREATE_COMPANY,
  CREATE_JOB_FOR_ADMIN,
  CREATE_JOB_FOR_USER,
  CREATE_POST,
  CREATE_REPORT_JOB,
  CREATE_REPORT_POST,
  DELETE_MEMBER,
  FOLLOW_COMPANY,
  FOLLOW_JOB,
  FOLLOW_USER,
} from "../constants/NotifyConstant";
import {
  addNotifyFunc,
  canLoginNotifyFunc,
  confirmConnectJobNotifyFunc,
  newFollowNotifyFunc,
} from "../funcs/NotificationFunc";

export const eventsForNotify = (queryClient, dispatch, me) => {
  getSocket()
    .off(FOLLOW_USER)
    .on(FOLLOW_USER, async (data) => {
      console.log(data);
      await newFollowNotifyFunc(
        queryClient,
        data,
        me._id,
        dispatch,
        FOLLOW_USER
      );
    });

  getSocket()
    .off(FOLLOW_COMPANY)
    .on(FOLLOW_COMPANY, async (data) => {
      console.log(data);
      await newFollowNotifyFunc(queryClient, data, me._id, dispatch);
    });

  // notify
  getSocket()
    .off(CONFIRM_CONNECT_JOB)
    .on(CONFIRM_CONNECT_JOB, async (data) => {
      console.log(data);
      await confirmConnectJobNotifyFunc(queryClient, data, dispatch);
    });

  const EVENT_CONSTANT_CAN_LOGIN_AGAIN = [CONFIRM_ADD_MEMBER];
  const EVENT_CONSTANT_ONLY_ADD = [
    ADD_MEMBER,
    CREATE_POST,
    CONNECT_USER,
    CONNECT_JOB,
    CONFIRM_CONNECT_USER,
    CONFIRM_REPORT_POST,
    CONFIRM_REPORT_JOB,
    CREATE_REPORT_JOB,
    CREATE_REPORT_POST,
  ];
  if (me.role === "employee") {
    EVENT_CONSTANT_ONLY_ADD.push(CREATE_JOB_FOR_USER);
    EVENT_CONSTANT_ONLY_ADD.push(CONFIRM_APPLY_JOB);
    EVENT_CONSTANT_CAN_LOGIN_AGAIN.push(CONFIRM_COMPANY);
  }
  if (me.role === "HR") {
    EVENT_CONSTANT_CAN_LOGIN_AGAIN.push(CONFIRM_DELETE_MEMBER);
    EVENT_CONSTANT_ONLY_ADD.push(FOLLOW_JOB);
    EVENT_CONSTANT_ONLY_ADD.push(CREATE_JOB_FOR_USER);
    EVENT_CONSTANT_ONLY_ADD.push(CONFIRM_JOB);
    EVENT_CONSTANT_ONLY_ADD.push(APPLY_JOB);
    EVENT_CONSTANT_ONLY_ADD.push(CHANGE_OWNER);
  }

  if (me.role === "manager") {
    EVENT_CONSTANT_CAN_LOGIN_AGAIN.push(CONFIRM_DELETE_MEMBER);
    EVENT_CONSTANT_ONLY_ADD.push(CREATE_JOB_FOR_USER);
    EVENT_CONSTANT_ONLY_ADD.push(CONFIRM_COMPANY);
    EVENT_CONSTANT_ONLY_ADD.push(CONFIRM_ADD_MEMBER);
  }

  if (me.role === "admin") {
    EVENT_CONSTANT_ONLY_ADD.push(CREATE_JOB_FOR_ADMIN);
    EVENT_CONSTANT_ONLY_ADD.push(CREATE_COMPANY);
  }

  EVENT_CONSTANT_CAN_LOGIN_AGAIN.forEach((EVENT) => {
    getSocket()
      .off(EVENT)
      .on(EVENT, async (data) => {
        console.log(data);
        await canLoginNotifyFunc(queryClient, data, me._id, dispatch);
      });
  });

  EVENT_CONSTANT_ONLY_ADD.forEach((EVENT) => {
    getSocket()
      .off(EVENT)
      .on(EVENT, async (data) => {
        console.log(data);
        await addNotifyFunc(queryClient, data, dispatch);
      });
  });
};
