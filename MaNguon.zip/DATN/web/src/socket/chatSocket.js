import { getSocket } from ".";
import {
  BLOCK_ROOM,
  CREATE_MESSAGE,
  REACTION_MESSAGE,
} from "../constants/ChatConstant";
import {
  blockRoomFunc,
  newMessageFunc,
  reactionMessageFunc,
} from "../funcs/ChatFunc";

export const eventsForChat = (queryClient, dispatch) => {
  if (!getSocket()) {
    return;
  }
  getSocket()
    .off(CREATE_MESSAGE)
    .on(CREATE_MESSAGE, async (data) => {
      await newMessageFunc(queryClient, data, data.data.roomId, dispatch);
    });

  getSocket()
    .off(REACTION_MESSAGE)
    .on(REACTION_MESSAGE, async (data) => {
      await reactionMessageFunc(queryClient, data.data.roomId, data);
    });

  getSocket()
    .off(BLOCK_ROOM)
    .on(BLOCK_ROOM, async (data) => {
      await blockRoomFunc(queryClient, data.data._id, data);
    });
};
