import axios from "../utils/axios";

export const getNotifications = async ({ type, pageParam = 1 }) => {
  // console.log("getPosts", pageParam);
  const pageSize = 10;
  try {
    const {
      data: { data, page },
    } = await axios.get(
      `/notify?page=${pageParam}&limit=${pageSize}&type=${type}`
    );

    const nextId = data.length === pageSize ? Number(page) + 1 : null;
    const previousId = pageParam > 0 ? Number(page) - 1 : null;

    return { data: data, nextId, previousId };
  } catch (err) {
    throw new Error(err);
  }
};
