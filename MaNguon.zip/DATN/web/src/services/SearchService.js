import axios from "../utils/axios";

export const getSearchModelService = async ({
  model,
  columnField,
  operatorValue,
  value,
  sort = "asc",
  page,
  limit,
}) => {
  try {
    const { data } = await axios.get(
      `search?model=${model}&limit=${limit}&page=${
        page + 1
      }&columnField=${columnField}&operatorValue=${operatorValue}&value=${value}&sort=${sort}`
    );
    return {
      data: data.data,
      hasMore: data.currentPage < data.numberOfPages,
      total: data.total,
      currentPage: data.currentPage,
      numberOfPages: data.numberOfPages,
    };
  } catch (err) {
    throw new Error(err);
  }
};

export const getSearchInputService = ({
  value,
  page = 1,
  limit = 4,
  operatorValue = "startsWith",
}) => {
  return axios.get(
    `/search/input?limit=${limit}&page=${page}&value=${value}&operatorValue=${operatorValue}`
  );
};

export const getCountAllService = async () => {
  try {
    const { data } = await axios.get(`search/admin/totalModel`);
    return data;
  } catch (err) {
    throw err.message || err;
  }
};

export const getSuggestion = async (model, value) => {
  try {
    let url = `search?model=${model}&limit=6&page=1&columnField=name&value=${value}&operatorValue=startsWith&sort=name`;
    if (model === "languages") {
      url = `/languages/search?limit=6&page=1&operatorValue=contains&value=${value}`;
    } else if (model === "experiences") {
      url = `/experiences/search?limit=6&page=1&operatorValue=contains&value=${value}`;
    } else if (model === "educations") {
      url = `/educations/search?limit=6&page=1&operatorValue=contains&value=${value}`;
    }

    const { data } = await axios.get(url);
    return data;
  } catch (err) {
    throw err.message || err;
  }
};
