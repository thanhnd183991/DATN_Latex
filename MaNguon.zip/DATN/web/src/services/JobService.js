import axios from "../utils/axios";

export const getJobByCategoryService = async (skill, page, limit, model) => {
  try {
    let url = `/jobs/job-by-category?page=${
      page + 1
    }&limit=${limit}&skill=${skill}`;
    if (model === "user") {
      url = `/users/search-by-skill?page=${
        page + 1
      }&limit=${limit}&skill=${skill}`;
    }
    if (model === "company") {
      url = `/companies/search-by-skill?page=${
        page + 1
      }&limit=${limit}&skill=${skill}`;
    }
    const { data } = await axios.get(url);
    return { ...data };
  } catch (err) {
    throw new Error(err);
  }
};

export const changeOnwerJobService = async (jobId, newOwnerId) => {
  try {
    const { data } = await axios.put(`/jobs/change-owner/${jobId}`, {
      newOwnerId,
    });
    return data;
  } catch (err) {
    throw new Error(err);
  }
};

export const getRecomJobService = async (page, limit) => {
  try {
    const { data } = await axios.get(
      `/jobs/recommend-job?page=${page}&limit=${limit}`
    );
    return { ...data };
  } catch (err) {
    throw new Error(err);
  }
};

export const getListJobService = async (page, limit, type) => {
  try {
    if (type.isRecom) {
      const { data } = await axios.get(
        `/jobs/recommend-job?page=${page}&limit=${limit}`
      );
      console.log(data);
      return { ...data };
    } else if (type.isSave) {
      const { data } = await axios.get(
        `/users/save-job-cart?page=${page}&limit=${limit}`
      );
      return { ...data };
    } else if (type.isApply) {
      const { data } = await axios.get(
        `/users/apply-job-cart?page=${page}&limit=${limit}`
      );
      return { ...data };
    }
  } catch (err) {
    throw new Error(err);
  }
};

export const createJobService = (job) => {
  return axios.post("/jobs/create", job);
};

export const putApplyJob = (job) => {
  return axios.put("/jobs/update-applicant", job);
};

export const getViewApplyJobService = (jobId, userId) => {
  return axios.get(
    `/jobs/view-apply/${jobId}${userId ? "?userId=" + userId : ""}`
  );
};

export const getListJobByCompanyService = async ({
  companyId,
  isHR,
  HRId,
  limit = 6,
  page = 1,
}) => {
  try {
    let url = `/jobs/list-by-company/${companyId}?page=${page}&limit=${limit}`;
    if (isHR) {
      url = `/jobs/job-by-hr?page=${page}&limit=${limit}${
        HRId ? `&userId=${HRId}` : ""
      }`;
    }
    const {
      data: { data, hasMore },
    } = await axios.get(url);
    return { data, hasMore };
  } catch (err) {
    throw new Error(err);
  }
};

export const infoJob = async (jobId) => {
  const { data } = await axios.get(`/jobs/info/${jobId}`);
  return data;
};

export const relateJobService = async (jobId, page, limit) => {
  const { data } = await axios.get(
    `/jobs/relate-job/${jobId}?page=${page + 1}&limit=${limit}`
  );
  return data;
};

export const deleteApplicantJobService = (jobId, applicantId) => {
  return axios.put(`/jobs/delete-applicant`, {
    jobId,
    applicantId,
  });
};

export const updateJobService = (data) => {
  return axios.put(`/jobs/update`, {
    ...data,
    jobId: data._id,
  });
};

export const closeJobService = (data) => {
  return axios.put(`/jobs/close-job`, data);
};

export const getCountJobByCategoryService = async () => {
  try {
    const { data } = await axios.get("/jobs/count-job-by-category");
    return data;
  } catch (err) {
    throw err.message || err;
  }
};

export const getAdminJobStatsService = async () => {
  try {
    const { data } = await axios.get("/jobs/admin/stats");
    return data;
  } catch (err) {
    throw new Error(err.message || err);
  }
};

export const getAdminJobStatusService = async () => {
  try {
    const { data } = await axios.get("/jobs/admin/status");
    return data;
  } catch (err) {
    throw new Error(err.message || err);
  }
};

export const putActiveJobService = async (jobId, status) => {
  try {
    const { data } = await axios.put(`/jobs/confirm`, { jobId, status });
    return data;
  } catch (err) {
    throw new Error(err.message || err);
  }
};
