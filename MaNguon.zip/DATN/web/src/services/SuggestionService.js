import axios from "../utils/axios";

export const getSuggestionByUser = async ({
  type = "user",
  page = 0,
  limit = 6,
}) => {
  let url = `/${type}s/suggestion?page=${page + 1}&limit=${limit}`;
  if (type === "company") {
    url = `/companies/suggestion?page=${page + 1}&limit=${limit}`;
  }
  const {
    data: { data, hasMore },
  } = await axios.get(url);

  return {
    data,
    hasMore: hasMore,
  };
};
