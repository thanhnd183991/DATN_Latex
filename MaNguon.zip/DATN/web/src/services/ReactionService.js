import axios from "../utils/axios";

export const infoReactionPost = async ({ postId }) => {
  const { data } = await axios.get(`/posts/info-reaction/${postId}`);
  return data;
};

export const addReaction = async ({ postId, reaction }) => {
  const { data } = await axios.post(`/posts/reaction/${postId}`, { reaction });
  return { data };
};
