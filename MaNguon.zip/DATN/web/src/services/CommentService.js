import axios from "../utils/axios";

export const createCommentService = async ({ postId, content, file }) => {
  try {
    const { data } = await axios.post(`posts/comment/create/${postId}`, {
      content,
      file,
    });
    return data;
  } catch (err) {
    throw new Error(err);
  }
};

export const replyCommentService = async ({ root, content, file }) => {
  try {
    const { data } = await axios.post(`/posts/comment/reply`, {
      root,
      content,
      file,
    });
    return { data };
  } catch (err) {
    throw new Error(err);
  }
};

export const reactionCommentService = async ({ commentId, reaction }) => {
  return await axios.post(`/posts/comment/reaction`, {
    commentId,
    reaction,
  });
};

export const infoRootCommentService = async ({ postId }) => {
  try {
    const { data } = await axios.get(`/posts/root-comment/${postId}`);
    return { data };
  } catch (err) {
    throw new Error(err);
  }
};

export const infoCountCommentService = async ({ postId }) => {
  try {
    const { data } = await axios.get(`/posts/count-comment/${postId}`);
    return { data };
  } catch (err) {
    throw new Error(err);
  }
};

export const infoChildrenCommentService = async ({ commentId }) => {
  try {
    const { data } = await axios.get(`/posts/children-comment/${commentId}`);
    return { data };
  } catch (err) {
    throw new Error(err);
  }
};
