import axios from "../utils/axios";

export const getCompanyPage = (page = 0, limit = 6) => {
  console.log("page ", page);
  const data = companies.slice(page * limit, page * limit + limit);
  return { data, hasMore: page < 5 };
};

export const getInfoCompany = async ({ companyId }) => {
  try {
    const { data } = await axios.get(`/companies/info/${companyId}`);
    return data;
  } catch (err) {
    throw err.message || err;
  }
};

export const getMembersCompany = async ({ companyId }) => {
  try {
    const { data } = await axios.get(`/companies/members/${companyId}`);
    return data;
  } catch (err) {
    throw err.message || err;
  }
};

export const updateCompanyService = (companyId, body) => {
  return axios.put(`/companies/update/${companyId}`, body);
};

export const addMember = (companyId, employees) => {
  try {
    const { data } = axios.put(`/companies/add-human-resource/${companyId}`, {
      employees,
    });
    return data;
  } catch (err) {
    throw err.message || err;
  }
};

export const deleteMember = async (companyId, employees) => {
  try {
    const { data } = await axios.put(
      `/companies/remove-human-resource/${companyId}`,
      {
        employees,
      }
    );
    return data;
  } catch (err) {
    throw err.message || err;
  }
};

export const getCountJobByCompanyService = async () => {
  try {
    const { data } = await axios.get("/companies/admin/countJobByCompany");
    return data;
  } catch (err) {
    throw err.message || err;
  }
};

export const getAdminCompanyStatsService = async () => {
  try {
    const { data } = await axios.get("/companies/admin/stats");
    return data;
  } catch (err) {
    throw new Error(err.message || err);
  }
};

export const getAdminCompanyStatusService = async () => {
  try {
    const { data } = await axios.get("/companies/admin/status");
    return data;
  } catch (err) {
    throw new Error(err.message || err);
  }
};

export const activeCompanyService = async (companyId, status) => {
  try {
    const { data } = await axios.put(`/companies/update-status/${companyId}`, {
      status,
    });
    return data;
  } catch (err) {
    throw new Error(err.message || err);
  }
};

export const createCompanyService = (body) => {
  return axios.post("/companies/create", body);
};
