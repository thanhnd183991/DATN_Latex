import axios from "../utils/axios";

export const getRoomService = async (roomId) => {
  // console.log("getChats", pageParam, type);

  // console.log(data);
  const { data } = await axios.get(`/rooms/info/${roomId}`);

  return data;
};

export const getChats = async ({ pageParam = 1, type }) => {
  // console.log("getChats", pageParam, type);
  const limit = 5;

  // console.log(data);
  const { data } = await axios.get(
    `/rooms/list?type=${type}&page=${pageParam}&limit=${limit}`
  );

  const nextId = data.length === limit ? Number(pageParam) + 1 : null;
  const previousId = pageParam > 0 ? Number(pageParam) - 1 : null;

  return { data, nextId, previousId };
};
