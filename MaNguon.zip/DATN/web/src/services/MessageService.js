import axios from "../utils/axios";

export const getMessages = async ({ pageParam = 1, roomId }) => {
  const limit = 10;

  const { data } = await axios.get(
    `rooms/list-messages/${roomId}?page=${pageParam}&limit=${limit}`
  );

  const nextId = data.length === limit ? Number(pageParam) + 1 : null;
  const previousId = pageParam > 0 ? Number(pageParam) - 1 : null;

  return { data, nextId, previousId };
};

export const createMessageService = (roomId, message) => {
  return axios.post(`rooms/message/create`, {
    roomId,
    message,
  });
};

export const reactMessageService = (messageId, reaction) => {
  return axios.put(`/rooms/message/react`, {
    messageId,
    reaction,
  });
};

export const removeMessageService = (messageId) => {
  return axios.put(`/rooms/message/remove`, {
    messageId,
  });
};
