import axios from "../utils/axios";

export const getPosts = async ({ userId, companyId, pageParam = 1 }) => {
  // console.log("getPosts", pageParam);
  const pageSize = 5;
  let url = null;
  if (userId) {
    url = `posts/list-user?page=${pageParam}&limit=${pageSize}&userId=${userId}`;
  } else if (companyId) {
    url = `/posts/list-company/${companyId}?page=${pageParam}&limit=${pageSize}`;
  } else {
    url = `/posts/list-feed?page=${pageParam}&limit=${pageSize}`;
  }

  const {
    data: { posts, page },
  } = await axios.get(url);

  const nextId = posts.length === pageSize ? Number(page) + 1 : null;
  const previousId = pageParam > 0 ? Number(page) - 1 : null;

  return { data: posts, nextId, previousId };
};

export const createPostService = async ({ content, files, type }) => {
  const pageSize = 5;

  const { data } = await axios.post(`/posts/create`, {
    content,
    files,
    type,
  });
  return data;
};

export const getAdminStatsService = async () => {
  try {
    const { data } = await axios.get("/posts/admin/stats");
    return data;
  } catch (err) {
    throw new Error(err.message || err);
  }
};

export const getAdminCountTypeService = async () => {
  try {
    const { data } = await axios.get(`/posts/admin/countType`);
    return data;
  } catch (err) {
    throw new Error(err.message || err);
  }
};

export const getPostService = async (postId) => {
  try {
    const { data } = await axios.get(`/posts/find/${postId}`);
    return data;
  } catch (err) {
    throw new Error(err.message || err);
  }
};

export const deletePostService = (postId) => {
  return axios.delete(`/posts/delete/${postId}`);
};
