import axios from "../utils/axios";
import { getPublicId } from "../utils/media/file";

// export const uploadFiles = (files) => {
//   const formData = new FormData();
//   files.forEach((file) => {
//     formData.append("files", file);
//   });
//   return axios.post(`/store/upload-multiple-cloud`, formData, {
//     headers: {
//       "Content-Type": "multipart/form-data",
//     },
//   });
// };

// export const uploadFile = (file) => {
//   const formData = new FormData();
//   formData.append("file", file);
//   return axios.post(`/store/upload-cloud`, formData, {
//     headers: {
//       "Content-Type": "multipart/form-data",
//     },
//   });
// };

const folder = (mimeType) => {
  if (mimeType.includes("video")) return "video";
  else if (mimeType.includes("image")) return "image";
  else return "raw";
};

export const uploadFiles = async (files) => {
  try {
    const { data: signData } = await axios.post("/store/sign-cloud");

    const formData = new FormData();

    return await Promise.all(
      files.map(async (file) => {
        const folderFile = folder(file.type);
        formData.append("file", file);
        formData.append("api_key", signData.apikey);
        formData.append("timestamp", signData.timestamp);
        formData.append("signature", signData.signature);

        const url =
          "https://api.cloudinary.com/v1_1/" +
          signData.cloudname +
          `/${folderFile}/upload`;

        const response = await fetch(url, {
          method: "POST",
          body: formData,
        });

        return await response.json();
      })
    );
  } catch (err) {
    console.log(err);
    throw new Error(err);
  }
};

export const uploadFile = async (file) => {
  try {
    const { data: signData } = await axios.post("/store/sign-cloud");

    const formData = new FormData();

    const folderFile = folder(file.type);
    formData.append("file", file);
    formData.append("api_key", signData.apikey);
    formData.append("timestamp", signData.timestamp);
    formData.append("signature", signData.signature);

    const url =
      "https://api.cloudinary.com/v1_1/" +
      signData.cloudname +
      `/${folderFile}/upload`;

    const response = await fetch(url, {
      method: "POST",
      body: formData,
    });

    return await response.json();
  } catch (err) {
    console.log(err);
    throw new Error(err);
  }
};

export const deleteFile = (url) => {
  if (
    url === "https://cdn-icons-png.flaticon.com/512/2083/2083417.png" ||
    url.includes("https://robohash.org")
  ) {
    return new Promise((resolve) => {
      resolve({
        data: {
          url: url,
        },
      });
    });
  }
  if (!url) return;
  return axios.delete(`/store/delete-cloud`, {
    data: {
      public_id: getPublicId(url),
    },
  });
};

export const deleteFiles = (urls) => {
  return axios.delete(`/store/deletes-cloud`, {
    data: {
      public_ids: urls
        .filter((url) => !url.includes("https://robohash.org"))
        .map((url) => getPublicId(url)),
    },
  });
};
