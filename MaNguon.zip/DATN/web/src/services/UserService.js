import axios from "../utils/axios";

export const getUserPage = (page = 0, limit = 6) => {
  // console.log("page ", page);
  const data = users.slice(page * limit, page * limit + limit);
  return { data, hasMore: page < 5 };
};

export const getListByUser = async ({
  id,
  companyId,
  action,
  debouncedValue,
  type = "followers",
  page = 1,
  limit = 6,
}) => {
  let url = `/users/list-follow-by-user?page=${page}&limit=${limit}&type=${type}&userId=${id}&value=${debouncedValue}`;
  if (companyId) {
    url = `/companies/follower/${companyId}?page=${page}&limit=${limit}&value=${debouncedValue}`;
  } else if (action) {
    url = `/users/list-employee?page=${page}&limit=${limit}&value=${debouncedValue}`;
  }
  const { data } = await axios.get(url);

  const nextId = data.length === limit ? Number(page) + 1 : null;
  const previousId = page > 0 ? Number(page) - 1 : null;

  return { data, nextId, previousId };
};

export const getInfoUser = async (userId) => {
  try {
    const { data } = await axios.get(`/users/info/${userId}`);
    return data;
  } catch (err) {
    console.log(err);
    throw new Error(JSON.stringify(err));
  }
};

export const getSuggestionUser = (page = 1, limit = 3) => {
  return axios.get(`/users/suggestion?page=${page}&limit=${limit}`);
};

export const putFollowingUserService = ({ otherId }) => {
  return axios.put(`/users/following`, { otherId });
};

export const putFollowingJobService = ({ jobId }) => {
  return axios.put(`users/following-job`, { jobId });
};

export const putFollowingCompanyService = ({ companyId }) => {
  return axios.put(`/users/following-company`, { companyId });
};

export const putUpdateArrayService = ({ type, data }) => {
  return axios.put(`/users/update-${type}`, { [type]: data });
};

export const putUpdateFieldService = (body) => {
  return axios.put(`/users/update-string-object`, body);
};

export const getAdminUserStatsService = async () => {
  try {
    const { data } = await axios.get("/users/admin/stats");
    return data;
  } catch (err) {
    throw new Error(err.message || err);
  }
};

export const getAdminUserStatusService = async () => {
  try {
    const { data } = await axios.get("/users/admin/status");
    return data;
  } catch (err) {
    throw new Error(err.message || err);
  }
};

export const deleteUserService = async (userId) => {
  try {
    const { data } = await axios.delete(`/users/delete/${userId}`);
    return data;
  } catch (err) {
    throw new Error(err.message || err);
  }
};

export const getSaveJobsOfUserService = async (limit) => {
  const page = 1;
  try {
    const { data } = await axios.get(
      `/users/save-job-cart?page=${page}&limit=${limit}`
    );
    return { ...data };
  } catch (err) {
    throw new Error(err.message || err);
  }
};

export const getApplyJobsOfUserService = async (limit) => {
  const page = 1;
  try {
    const { data } = await axios.get(
      `/users/apply-job-cart?page=${page}&limit=${limit}`
    );
    return { ...data };
  } catch (err) {
    throw new Error(err.message || err);
  }
};
