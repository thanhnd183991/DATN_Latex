import axios from "../utils/axios";

export const deleteCategory = async (catId) => {
  try {
    const { data } = await axios.delete(`/categories/delete/${catId}`);
    return data;
  } catch (err) {
    throw new Error(err);
  }
};
