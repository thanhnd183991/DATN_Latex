import axios from "../utils/axios";

export const loginUser = ({ email, password }) =>
  axios.post("/auth/login", { email, password });

export const signupUser = ({ name, email, password }) =>
  axios.post("/auth/signup", { name, email, password });

export const forgotPassword = ({ email }) =>
  axios.post("/auth/forgot-password", { email });

export const changePassword = ({ password, token }) =>
  axios.post("/auth/change-password", { password, token });
