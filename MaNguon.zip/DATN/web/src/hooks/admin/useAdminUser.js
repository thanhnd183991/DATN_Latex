import { useQuery } from "react-query";
import { toast } from "react-toastify";
import {
  getAdminUserStatsService,
  getAdminUserStatusService,
} from "../../services/UserService";
import { keys } from "../queryKeys";

export const useAdminUserStatus = () => {
  const { data, error, status } = useQuery(
    keys.adminStatusUser,
    () => getAdminUserStatusService(),
    {
      refetchOnWindowFocus: false,
      staleTime: 1000 * 60 * 5,
    }
  );
  if (error) {
    console.log(error);
    toast.error(error || "Something wrong");
  }
  // console.log(data);
  return { dataUserStatus: data, statusUserStatus: status };
};

export const useAdminUserStats = () => {
  const { data, error, status } = useQuery(
    keys.adminStatsUser,
    () => getAdminUserStatsService(),
    {
      refetchOnWindowFocus: false,
      staleTime: 1000 * 60 * 5,
    }
  );
  if (error) {
    console.log(error);
    toast.error(error || "Something wrong");
  }
  // console.log(data);
  return { dataUserStats: data, statusUserStats: status };
};
