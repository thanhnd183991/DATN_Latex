import { useQuery } from "react-query";
import { toast } from "react-toastify";
import {
  getAdminCompanyStatsService,
  getAdminCompanyStatusService,
} from "../../services/CompanyService";
import { keys } from "../queryKeys";

export const useAdminCompanyStatus = () => {
  const { data, error, status } = useQuery(
    keys.adminStatusCompany,
    () => getAdminCompanyStatusService(),
    {
      refetchOnWindowFocus: false,
      staleTime: 1000 * 60 * 5,
    }
  );
  if (error) {
    console.log(error);
    toast.error(error || "Something wrong");
  }
  // console.log(data);
  return { dataCompanyStatus: data, statusCompanyStatus: status };
};

export const useAdminCompanyStats = () => {
  const { data, error, status } = useQuery(
    keys.adminStatsCompany,
    () => getAdminCompanyStatsService(),
    {
      refetchOnWindowFocus: false,
      staleTime: 1000 * 60 * 5,
    }
  );
  if (error) {
    console.log(error);
    toast.error(error || "Something wrong");
  }
  // console.log(data);
  return { dataCompanyStats: data, statusCompanyStats: status };
};
