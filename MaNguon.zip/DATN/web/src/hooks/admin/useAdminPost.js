import { useQuery } from "react-query";
import { toast } from "react-toastify";
import {
  getAdminCountTypeService,
  getAdminStatsService,
} from "../../services/PostService";
import { keys } from "../queryKeys";

export const useAdminPostStats = () => {
  const { data, error, status } = useQuery(
    keys.adminStatsPost,
    () => getAdminStatsService(),
    {
      refetchOnWindowFocus: false,
      staleTime: 1000 * 60 * 5,
    }
  );
  if (error) {
    console.log(error);
    toast.error(error || "Something wrong");
  }
  // console.log(data);
  return { dataPostStats: data, statusStatsPost: status };
};

export const useAdminCountTypePost = () => {
  const { data, isLoading, error, status } = useQuery(
    keys.adminCountTypePost,
    () => getAdminCountTypeService(),
    {
      refetchOnWindowFocus: false,
      staleTime: 1000 * 60 * 5,
    }
  );
  if (error) {
    console.log(error);
    toast.error(error || "Something wrong");
  }
  // console.log(data);
  return { dataCountTypePost: data, statusContType: status };
};
