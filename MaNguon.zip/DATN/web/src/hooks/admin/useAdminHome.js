import { useQuery } from "react-query";
import { toast } from "react-toastify";
import { getCountJobByCompanyService } from "../../services/CompanyService";
import { getCountJobByCategoryService } from "../../services/JobService";
import { getCountAllService } from "../../services/SearchService";
import { keys } from "../queryKeys";

export const useTotalAll = () => {
  const { data, isLoading, error } = useQuery(
    keys.adminCountAll,
    () => getCountAllService(),
    {
      refetchOnWindowFocus: false,
      staleTime: 1000 * 60 * 5,
    }
  );
  if (error) {
    console.log(error);
    toast.error("Something wrong");
  }
  // console.log(data);
  return { data, isLoading };
};

export const useChartJobCatergory = () => {
  const { data, error, status } = useQuery(
    keys.adminCountJobByCategory,
    () => getCountJobByCategoryService(),
    {
      refetchOnWindowFocus: false,
      staleTime: 1000 * 60 * 5,
    }
  );
  if (error) {
    console.log(error);
  }
  return { dataChartJobCategory: data, statusChartJobCategory: status };
};

export const useChartJobCompany = () => {
  const { data, error, status } = useQuery(
    keys.adminCountJobByCompany,
    () => getCountJobByCompanyService(),
    {
      refetchOnWindowFocus: false,
      staleTime: 1000 * 60 * 5,
    }
  );
  if (error) {
    console.log(error);
  }
  return { dataChartJobCompany: data, statusChartJobCompany: status };
};
