import { useCallback, useEffect, useState } from "react";
import { useQuery, useQueryClient } from "react-query";
import { getSearchModelService } from "../../services/SearchService";
import { keys } from "../queryKeys";

export const useAdminTable = (model) => {
  const [queryOptions, setQueryOptions] = useState({
    columnField:
      model === "post" ? "content" : model === "job" ? "title" : "name",
    operatorValue: "contains",
    value: "",
    sort: "asc",
    page: 0,
  });
  // console.log(queryOptions);

  const onFilterChange = useCallback((filterModel) => {
    // console.log(filterModel.items[0]);
    if (filterModel.items[0]) {
      const { id, ...info } = filterModel.items[0];
      if (typeof info.value === "string")
        setQueryOptions({
          ...queryOptions,
          ...info,
        });
    }
  }, []);

  const handleSortModelChange = useCallback((sortModel) => {
    // Here you save the data you need from the sort model
    // console.log(sortModel[0]);
    if (sortModel[0]) {
      const { field, sort } = sortModel[0];
      setQueryOptions({
        ...queryOptions,
        columnField: field,
        sort: sort,
      });
    }
    // setQueryOptions({ sortModel: [...sortModel] });
  }, []);

  const queryClient = useQueryClient();
  const { status, data, error, isFetching, isPreviousData, refetch } = useQuery(
    model === "user"
      ? keys.adminListUser(queryOptions.page)
      : model === "company"
      ? keys.adminListCompany(queryOptions.page)
      : model === "job"
      ? keys.adminListJob(queryOptions.page)
      : model === "category"
      ? keys.adminListCategory(queryOptions.page)
      : keys.adminListPost(queryOptions.page),
    () =>
      getSearchModelService({
        model,
        columnField: queryOptions.columnField,
        operatorValue: queryOptions.operatorValue,
        value: queryOptions.value,
        page: queryOptions.page,
        sort: queryOptions.sort,
        limit: 6,
      }),
    {
      keepPreviousData: true,
      refetchOnWindowFocus: false,
      staleTime: Infinity,
      enabled: !!queryOptions.columnField,
    }
  );
  // Prefetch the next page!
  useEffect(() => {
    if (data?.hasMore) {
      queryClient.prefetchQuery(
        model === "user"
          ? keys.adminListUser(queryOptions.page + 1)
          : model === "company"
          ? keys.adminListCompany(queryOptions.page + 1)
          : model === "job"
          ? keys.adminListJob(queryOptions.page + 1)
          : model === "category"
          ? keys.adminListCategory(queryOptions.page + 1)
          : keys.adminListPost(queryOptions.page + 1),
        () =>
          getSearchModelService({
            model,
            columnField: queryOptions.columnField,
            operatorValue: queryOptions.operatorValue,
            value: queryOptions.value,
            sort: queryOptions.sort,
            page: queryOptions.page + 1,
            limit: 6,
          }),
        {
          enabled: !!queryOptions.columnField,
          refetchOnWindowFocus: false,
        }
      );
    }
  }, [data, queryOptions.page, queryClient]);

  useEffect(() => {
    // console.log("refetch");
    if (
      queryOptions.columnField !== null ||
      typeof queryOptions.columnField !== "undefined" ||
      queryOptions.value !== null ||
      typeof queryOptions.value !== "undefined" ||
      queryOptions.operatorValue !== null ||
      typeof queryOptions.operatorValue !== "undefined" ||
      queryOptions.sort === "asc" ||
      queryOptions.sort === "desc"
    ) {
      refetch();
    }
  }, [
    queryOptions.columnField,
    queryOptions.value,
    queryOptions.operatorValue,
    queryOptions.sort,
  ]);

  return {
    status,
    rows: data,
    error,
    isFetching,
    isPreviousData,
    queryOptions,
    setQueryOptions,
    onFilterChange,
    handleSortModelChange,
  };
};
