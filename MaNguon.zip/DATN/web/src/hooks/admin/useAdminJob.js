import { useQuery } from "react-query";
import { toast } from "react-toastify";
import {
  getAdminJobStatsService,
  getAdminJobStatusService,
} from "../../services/JobService";
import { keys } from "../queryKeys";

export const useAdminJobStatus = () => {
  const { data, error, status } = useQuery(
    keys.adminStatusJob,
    () => getAdminJobStatusService(),
    {
      refetchOnWindowFocus: false,
      staleTime: 1000 * 60 * 5,
    }
  );
  if (error) {
    console.log(error);
    toast.error(error || "Something wrong");
  }
  // console.log(data);
  return { dataJobStatus: data, statusJobStatus: status };
};

export const useAdminJobStats = () => {
  const { data, error, status } = useQuery(
    keys.adminStatsJob,
    () => getAdminJobStatsService(),
    {
      refetchOnWindowFocus: false,
      staleTime: 1000 * 60 * 5,
    }
  );
  if (error) {
    console.log(error);
    toast.error(error || "Something wrong");
  }
  // console.log(data);
  return { dataJobStats: data, statusJobStats: status };
};
