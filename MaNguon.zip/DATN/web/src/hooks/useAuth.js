import { useSelector } from "react-redux";
import { isValidToken } from "../utils/jwt";
import { useUser } from "./useUsers";

export const useAuth = (type) => {
  const { token, user } = useSelector((state) => state.auth);
  if (!isValidToken(token).isValid) {
    return { isAuth: false, user: null };
  }
  if (!type) {
    return { isAuth: true, user };
  }
  if (!type.includes(user.role)) {
    return { isAuth: false, user: null };
  }
  return { isAuth: true, user };
};

export const useMe = () => {
  const { token, user } = useSelector((state) => state.auth);
  const {
    data,
    isLoading,
    error: errorMe,
    status: statusMe,
  } = useUser(user._id);
  return { me: data, isLoadingMe: isLoading, errorMe, statusMe };
};
