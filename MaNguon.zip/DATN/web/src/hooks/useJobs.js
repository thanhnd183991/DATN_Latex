import { useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "react-query";
import { useDispatch } from "react-redux";
import { toast } from "react-toastify";
import {
  ACCEPTED,
  APPLY_JOB,
  CHANGE_OWNER,
  CONFIRM_APPLY_JOB,
  CONFIRM_JOB,
  CREATE_JOB_FOR_ADMIN,
  CREATE_JOB_FOR_USER,
  REJECTED,
} from "../constants/NotifyConstant";
import { addNotifyFunc } from "../funcs/NotificationFunc";
import {
  changeOnwerJobService,
  closeJobService,
  createJobService,
  deleteApplicantJobService,
  getListJobByCompanyService,
  getListJobService,
  getRecomJobService,
  infoJob,
  putActiveJobService,
  putApplyJob,
  updateJobService,
} from "../services/JobService";
import { deleteFile } from "../services/UploadService";
import {
  getApplyJobsOfUserService,
  getSaveJobsOfUserService,
  putFollowingJobService,
} from "../services/UserService";
import { getSocket } from "../socket";
import { keys } from "./queryKeys";

export const useJob = (jobId) => {
  const { data, status } = useQuery(keys.job(jobId), () => infoJob(jobId), {
    enabled: !!jobId,
    refetchOnWindowFocus: false,
  });
  // console.log("job", data);
  return { job: data, status };
};

export const useSaveOrApplyJobs = (limit, isSave, isApply) => {
  const { data, status, error, isFetching } = useQuery(
    isSave ? keys.userSaveJobCart : keys.userApplyJobCart,
    () =>
      isSave
        ? getSaveJobsOfUserService(limit)
        : getApplyJobsOfUserService(limit),
    {
      staleTime: Infinity,
      refetchOnWindowFocus: false,
      refetchOnMount: false,
      enabled: isSave || isApply,
    }
  );
  return {
    jobs: data,
    statusJobs: status,
    errorJobs: error,
    isFetchingJobs: isFetching,
  };
};

export const useRecomJobPage = (page = 1, limit = 6, enabled = false) => {
  const queryClient = useQueryClient();

  const { status, data, error, isFetching, isPreviousData } = useQuery(
    keys.jobRecommend(page),
    () => getRecomJobService(page, limit),
    {
      keepPreviousData: true,
      staleTime: 5000,
      enabled,
      refetchOnMount: false,
      refetchOnWindowFocus: false,
    }
  );
  // console.log(data);

  // Prefetch the next page!
  useEffect(() => {
    if (data?.hasMore) {
      queryClient.prefetchQuery(keys.jobRecommend(page + 1), () =>
        getRecomJobService(page + 1, limit)
      );
    }
  }, [data, page, queryClient]);

  return { status, data, error, isFetching, isPreviousData };
};

export const useListJobPage = (page = 1, limit = 6, type) => {
  const queryClient = useQueryClient();
  const myKey = (page) =>
    type.isRecom
      ? keys.jobRecommend(page)
      : type.isSave
      ? keys.userSaveJobCart
      : type.isApply
      ? keys.userApplyJobCart
      : ["fake", page];

  const { status, data, error, isFetching, isPreviousData } = useQuery(
    myKey(page),
    () => getListJobService(page, limit, type),
    { keepPreviousData: true, staleTime: 5000 }
  );
  // console.log(data);

  // Prefetch the next page!
  useEffect(() => {
    if (data?.hasMore) {
      queryClient.prefetchQuery(myKey(page + 1), () =>
        getListJobService(page + 1, limit, type)
      );
    }
  }, [data, page, queryClient]);

  return { status, data, error, isFetching, isPreviousData };
};

export const useListJobByHR = (page = 1, limit = 6, HRId) => {
  const queryClient = useQueryClient();
  const { status, data, error, isFetching, isPreviousData } = useQuery(
    keys.jobByHR(page, HRId),
    () => getListJobByCompanyService({ limit, page, isHR: true, HRId }),
    {
      keepPreviousData: true,
      refetchOnWindowFocus: false,
      refetchOnMount: true,

      staleTime: Infinity,
      enabled: !!HRId,
    }
  );

  // Prefetch the next page!
  useEffect(() => {
    if (data?.hasMore) {
      queryClient.prefetchQuery(keys.jobByHR(page + 1, HRId), () =>
        getListJobByCompanyService({
          limit,
          page: page + 1,
          isHR: true,
          HRId,
        })
      );
    }
  }, [data, page, queryClient]);

  return {
    status,
    data,
    error,
    isFetching,
    isPreviousData,
  };
};

export const useListJobByCompany = ({
  companyId,
  isHR,
  HRId,
  meId,
  page = 1,
  limit = 6,
}) => {
  const queryClient = useQueryClient();
  const myKey = (companyId, page) => {
    return isHR ? keys.jobByHR(page, meId) : keys.jobCompany(companyId, page);
  };
  const { status, data, error, isFetching, isPreviousData } = useQuery(
    myKey(companyId, page),
    () => getListJobByCompanyService({ companyId, limit, page, isHR, HRId }),
    { keepPreviousData: true, staleTime: Infinity }
  );
  // console.log(data);

  // Prefetch the next page!
  useEffect(() => {
    if (data?.hasMore) {
      queryClient.prefetchQuery(myKey(companyId, page + 1), () =>
        getListJobByCompanyService({
          companyId,
          limit,
          page: page + 1,
          isHR,
          HRId,
        })
      );
    }
  }, [data, page, queryClient]);

  return { status, data, error, isFetching, isPreviousData };
};

export const useCreateJobMutation = () => {
  const queryClient = useQueryClient();
  return useMutation((payload) => createJobService(payload.job), {
    // Optimistically update the cache value on mutate, but store
    // the old value and return it so that it's accessible in case of
    // an error
    onMutate: async (payload) => {
      // await queryClient.cancelQueries(keys.jobCompany(job.companyId));
      // const previousValue = queryClient.getQueryData(keys.infinitePosts());
      // return previousValue;
    },
    // On failure, roll back to the previous value
    onError: (err, variables, previousValue) => {
      console.log(err);
      const mess = Object.values(err)[0];
      const field = Object.keys(err)[0];
      toast.error(mess?.message || mess || JSON.stringify(err));
      variables.setError(field, {
        type: "custom",
        message: mess?.message || mess,
      });
    },
    onSuccess: (data, variables, previousValue) => {
      variables.onClose();
    },
    onSettled: (data, error, variables) => {
      if (data) {
        getSocket().emit(
          CREATE_JOB_FOR_ADMIN,
          { jobId: data.data.job._id },
          (data) => {
            if (data.success) {
              toast.success("Chờ quản trị viên duyệt");
            }
            if (data.error) {
              toast.error(data.error);
            }
          }
        );
      }
    },
  });
};

export const useApplyJobMutation = () => {
  const queryClient = useQueryClient();

  return useMutation(
    ({ jobId, phone, email, CV }) => putApplyJob({ jobId, phone, email, CV }),
    {
      // Optimistically update the cache value on mutate, but store
      // the old value and return it so that it's accessible in case of
      // an error
      onMutate: async ({ page, isSave, isRecom, onClose }) => {
        await queryClient.cancelQueries(keys.userSaveJobCart);
        await queryClient.cancelQueries(keys.jobRecommend(null));
        await queryClient.cancelQueries(keys.userApplyJobCart);
        let previousValueSaveJob, previousValueRecomJob;
        if (isSave) {
          previousValueSaveJob = queryClient.getQueryData(keys.userSaveJobCart);
        }
        if (isRecom) {
          // o trang recommend
          previousValueRecomJob = queryClient.getQueryData(
            keys.jobRecommend(page)
          );
        }
        return {
          previousValueSaveJob,
          previousValueRecomJob,
        };
      },
      // On failure, roll back to the previous value
      onError: (err, variables, context) => {
        console.log(err);
        toast.error(
          err.message || Object.values(err)[0] || "Something went wrong"
        );
        if (variables.isSave) {
          queryClient.setQueryData(
            keys.userSaveJobCart,
            context.previousValueSaveJob
          );
        }
        if (variables.isRecom) {
          queryClient.setQueryData(
            keys.jobRecommend(variables.page),
            context.previousValueRecomJob
          );
        }
      },
      onSuccess: (data, variables, context) => {
        if (variables.isSave) {
          queryClient.invalidateQueries(keys.userSaveJobCart);
        }
        queryClient.invalidateQueries(keys.jobRecommend(variables.page));

        queryClient.invalidateQueries(keys.userApplyJobCart);

        queryClient.invalidateQueries(keys.job(variables.jobId));
        toast.success("Apply thành công");
        getSocket().emit(
          APPLY_JOB,
          {
            jobId: variables.jobId,
            applicantId: variables.meId,
          },
          (data) => {
            if (data?.error) {
              toast.error(data.error);
            }
          }
        );
        variables.onClose();
      },
    }
  );
};

export const useFollowingJobMutation = () => {
  const queryClient = useQueryClient();

  return useMutation(({ job }) => putFollowingJobService({ jobId: job._id }), {
    // Optimistically update the cache value on mutate, but store
    // the old value and return it so that it's accessible in case of
    // an error
    onMutate: async ({ job, jobId, page, isSave, isInfo }) => {
      await queryClient.cancelQueries(keys.userSaveJobCart);
      let previousValueSaveJob, previousValueRecomJob, previousValueInfoJob;
      if (page) {
        // o trang recommend
        previousValueRecomJob = queryClient.getQueryData(
          keys.jobRecommend(page)
        );
      }
      if (isSave) {
        // o trang recommend
        previousValueSaveJob = queryClient.getQueryData(keys.userSaveJobCart);
      }
      if (isInfo) {
        //o trang detail job
        previousValueInfoJob = queryClient.getQueryData(keys.job(jobId));
      }
      return {
        previousValueRecomJob,
        previousValueInfoJob,
        previousValueSaveJob,
      };
    },
    // On failure, roll back to the previous value
    onError: (err, variables, context) => {
      if (variables.page) {
        queryClient.setQueryData(
          keys.jobRecommend(variables.page),
          context.previousValueRecomJob
        );
      }
      if (variables.isSave) {
        queryClient.setQueryData(
          keys.userSaveJobCart,
          context.previousValueSaveJob
        );
      }
      if (variables.isInfo) {
        queryClient.setQueryData(
          keys.job(variables.jobId),
          context.previousValueInfoJob
        );
      }
    },
    onSuccess: (data, variables, context) => {
      queryClient.invalidateQueries(keys.userSaveJobCart);
      if (variables.page) {
        queryClient.invalidateQueries(keys.jobRecommend(variables.page));
      }

      if (variables.isInfo) {
        queryClient.invalidateQueries(keys.job(variables.jobId));
      }
    },
  });
};

export const useDeleteApplicantMutation = () => {
  const queryClient = useQueryClient();
  return useMutation(
    ({ jobId, applicantId }) => deleteApplicantJobService(jobId, applicantId),
    {
      // Optimistically update the cache value on mutate, but store
      // the old value and return it so that it's accessible in case of
      // an error
      onMutate: async ({ page }) => {
        await queryClient.cancelQueries(keys.jobByHR(page));
        let previousValue;
        if (page) {
          previousValue = queryClient.getQueryData(keys.jobByHR(page));
        }
        return {
          previousValue,
        };
      },
      // On failure, roll back to the previous value
      onError: (err, variables, context) => {
        console.log(err);
        toast.error(
          Object.values(err)[0]?.message ||
            Object.values(err)[0] ||
            "Something went wrong"
        );
        if (variables.page) {
          queryClient.setQueryData(
            keys.jobByHR(variables.page),
            context.previousValue
          );
        }
      },
      onSuccess: (data, variables, context) => {
        queryClient.invalidateQueries(
          keys.jobByHR(variables.page, variables.ownerId)
        );
        queryClient.invalidateQueries(keys.job(variables.jobId));
        getSocket().emit(
          CONFIRM_APPLY_JOB,
          {
            jobId: variables.jobId,
            userId: variables.applicantId,
            ownerId: variables.ownerId,
            desc: variables.desc,
          },
          (data) => {
            if (data?.error) {
              toast.error(data.error);
            }

            if (data?.success) {
              toast.success(data.success);
            }
          }
        );
        variables.onClose();
      },
    }
  );
};

export const useActiveJobMutation = () => {
  const queryClient = useQueryClient();
  const dispatch = useDispatch();
  return useMutation(
    ({ jobId, status }) => putActiveJobService(jobId, status),
    {
      // Optimistically update the cache value on mutate, but store
      // the old value and return it so that it's accessible in case of
      // an error
      onMutate: async ({ page, isNotify }) => {
        if (isNotify) {
        } else {
          await queryClient.cancelQueries(keys.adminListJob(page));
          const previousValue = queryClient.getQueryData(
            keys.adminListJob(page)
          );
          return previousValue;
        }
      },
      // On failure, roll back to the previous value
      onError: (err, variables, previousValue) => {
        if (variables.isNotify) {
        } else {
          toast.error(err.message || "error");
          queryClient.setQueryData(
            keys.adminListJob(variables.page),
            previousValue
          );
        }
      },
      onSuccess: (data, variables, previousValue) => {
        if (variables.isNotify) {
          getSocket().emit(
            CONFIRM_JOB,
            {
              notifyId: variables.notifyId,
              status: variables.status === true ? ACCEPTED : REJECTED,
            },
            (data) => {
              if (data.error) {
                console.log(data.error);
                toast.error(data.error);
              }
              if (data.success) {
                addNotifyFunc(queryClient, data, dispatch);
                toast.success(data.success);
              }
            }
          );
        } else {
          queryClient.invalidateQueries(keys.adminListJob(variables.page));
          variables.onClose();
        }
        queryClient.invalidateQueries(keys.adminStatusJob);
        if (variables.status) {
          // chap thuan thi gui thong bao thanh cong cho nguoi dung
          getSocket().emit(
            CREATE_JOB_FOR_USER,
            { jobId: variables.jobId },
            (data) => {
              if (data.error) {
                console.log(data.error);
                toast.error(data.error);
              }
              if (data.success) {
                toast.success(data.success);
              }
            }
          );
        }
      },
    }
  );
};

export const useUpdateJobMutation = () => {
  const queryClient = useQueryClient();
  return useMutation(({ data }) => updateJobService(data), {
    // Optimistically update the cache value on mutate, but store
    // the old value and return it so that it's accessible in case of
    // an error
    onMutate: async ({ jobId }) => {
      await queryClient.cancelQueries(keys.job(jobId));
      const previousValue = queryClient.getQueryData(keys.job(jobId));
      return {
        previousValue,
      };
    },
    // On failure, roll back to the previous value
    onError: (err, variables, context) => {
      console.log(err);
      toast.error(
        err ||
          Object.values(err)[0]?.message ||
          Object.values(err)[0] ||
          "Something went wrong"
      );
      queryClient.setQueryData(
        keys.job(variables.jobId),
        context.previousValue
      );
    },
    onSuccess: (data, variables) => {
      queryClient.invalidateQueries(keys.job(variables.data._id));
      getSocket().emit(
        CREATE_JOB_FOR_ADMIN,
        { jobId: variables.data._id },
        (data) => {
          if (data.success && !variables?.data?.note) {
            toast.success("Chờ quản trị viên duyệt");
          }
          if (data.error) {
            toast.error(data.error);
          }
        }
      );
      variables.onClose();
    },
  });
};

export const useChangeOwnerJob = () => {
  const queryClient = useQueryClient();
  return useMutation(
    ({ jobId, newOwnerId }) => changeOnwerJobService(jobId, newOwnerId),
    {
      // Optimistically update the cache value on mutate, but store
      // the old value and return it so that it's accessible in case of
      // an error
      onMutate: async ({}) => {},
      // On failure, roll back to the previous value
      onError: (err) => {
        console.log(err);
        toast.error(
          err ||
            Object.values(err)[0]?.message ||
            Object.values(err)[0] ||
            "Something went wrong"
        );
      },
      onSuccess: (data, variables) => {
        queryClient.invalidateQueries(keys.jobByHR(null, variables.oldOwnerId));
        // queryClient.invalidateQueries(keys.jobByHR(null, variables.newOwnerId));
        getSocket().emit(
          CHANGE_OWNER,
          {
            oldId: variables.oldOwnerId,
            newId: variables.newOwnerId,
            jobId: variables.jobId,
          },
          (data) => {
            if (data?.error) {
              toast.error(data.error);
            }
          }
        );
        toast.success(data);
      },
    }
  );
};

export const useCloseJobMutation = () => {
  const queryClient = useQueryClient();
  return useMutation(({ jobId, close }) => closeJobService({ jobId, close }), {
    // Optimistically update the cache value on mutate, but store
    // the old value and return it so that it's accessible in case of
    // an error
    onMutate: async ({ jobId }) => {
      await queryClient.cancelQueries(keys.job(jobId));
      const previousValue = queryClient.getQueryData(keys.job(jobId));
      return {
        previousValue,
      };
    },
    // On failure, roll back to the previous value
    onError: (err, variables, context) => {
      console.log(err);
      toast.error(
        err ||
          Object.values(err)[0]?.message ||
          Object.values(err)[0] ||
          "Something went wrong"
      );
      queryClient.setQueryData(
        keys.job(variables.jobId),
        context.previousValue
      );
    },
    onSuccess: (data, variables) => {
      queryClient.invalidateQueries(keys.job(variables.jobId));
      variables.onClose();
    },
  });
};
