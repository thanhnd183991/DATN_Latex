import { useEffect } from "react";
import { useInView } from "react-intersection-observer";
import {
  useInfiniteQuery,
  useMutation,
  useQuery,
  useQueryClient,
} from "react-query";
import { toast } from "react-toastify";
import { useLocation } from "react-router-dom";

import { CREATE_POST } from "../../constants/NotifyConstant";
import {
  createPostService,
  deletePostService,
  getPosts,
  getPostService,
} from "../../services/PostService";
import { getSocket } from "../../socket";
import { keys } from "../queryKeys";
import {
  addToInfiniteQuery,
  deleteInInfiniteQuery,
} from "../../utils/opereationQueryClient";
import { deleteFiles } from "../../services/UploadService";

export const usePosts = ({ userId, companyId }) => {
  const { ref, inView } = useInView();

  const {
    status,
    data,
    error,
    isFetching,
    isFetchingNextPage,
    isFetchingPreviousPage,
    fetchNextPage,
    fetchPreviousPage,
    hasNextPage,
    hasPreviousPage,
  } = useInfiniteQuery(
    keys.infinitePosts(userId || companyId),
    ({ pageParam = 1 }) => getPosts({ userId, companyId, pageParam }),
    {
      refetchOnWindowFocus: false,
      staleTime: Infinity,
      getPreviousPageParam: (firstPage) => firstPage.previousId ?? undefined,
      getNextPageParam: (lastPage) => lastPage.nextId ?? undefined,
    }
  );

  useEffect(() => {
    if (inView) {
      fetchNextPage();
    }
  }, [inView]);

  return {
    status,
    data,
    error,
    isFetching,
    isFetchingNextPage,
    isFetchingPreviousPage,
    fetchNextPage,
    fetchPreviousPage,
    hasNextPage,
    hasPreviousPage,
    refViewPost: ref,
  };
};

export const useCreatePostMutation = () => {
  const queryClient = useQueryClient();
  return useMutation(
    ({ content, files, type }) => createPostService({ content, files, type }),
    {
      // Optimistically update the cache value on mutate, but store
      // the old value and return it so that it's accessible in case of
      // an error
      onMutate: async ({ id }) => {
        await queryClient.cancelQueries(keys.infinitePosts(id));
        const previousValue = queryClient.getQueryData(keys.infinitePosts(id));

        return previousValue;
      },
      // On failure, roll back to the previous value
      onError: async (err, variables, previousValue) => {
        try {
          toast.error(err.message || err.data || "error new post");
          if (variables.files.length > 0) {
            await deleteFiles(variables.files.map((file) => file.file));
          }

          queryClient.setQueryData(
            keys.infinitePosts(variables.id),
            previousValue
          );
        } catch (err) {
          console.log(err.message || err);
        }
      },
      onSuccess: async (data, variables, previousValue) => {
        await addToInfiniteQuery(queryClient, keys.infinitePosts(null), data);
        await addToInfiniteQuery(
          queryClient,
          keys.infinitePosts(data.data.ownerId?._id || data.data.ownerId),
          data
        );

        getSocket().emit(CREATE_POST, { postId: data.data._id }, (data) => {
          if (data.error) {
            toast.error(data.error);
          }
        });
        variables.onClose();
      },
    }
  );
};

export const usePost = (postId, options = {}) => {
  const { data, error, status } = useQuery(
    keys.post(postId),
    () => getPostService(postId),
    {
      ...options,
      refetchOnWindowFocus: false,
      staleTime: 1000 * 60 * 60,
    }
  );
  if (error) {
    console.log(error);
  }
  return { status, post: data, error };
};

export const useDeletePostMutation = () => {
  const queryClient = useQueryClient();
  const location = useLocation();
  return useMutation(({ postId }) => deletePostService(postId), {
    // Optimistically update the cache value on mutate, but store
    // the old value and return it so that it's accessible in case of
    // an error
    onMutate: async ({ pageAdmin }) => {
      let previousValue;
      if (typeof pageAdmin === "number") {
        await queryClient.cancelQueries(keys.adminListPost(pageAdmin));
        previousValue = queryClient.getQueryData(keys.adminListPost(pageAdmin));
      }
      return previousValue;
    },
    // On failure, roll back to the previous value
    onError: (err, variables, previousValue) => {
      toast.err(err?.data || "Xóa thất bại");
      if (typeof variables.pageAdmin === "number") {
        queryClient.setQueryData(
          keys.adminListPost(variables.pageAdmin),
          previousValue
        );
      }
    },
    onSuccess: async (data, variables, previousValue) => {
      if (typeof variables.pageAdmin === "number") {
        queryClient.invalidateQueries(keys.adminListPost(variables.pageAdmin));
      } else {
        await deleteInInfiniteQuery(
          queryClient,
          keys.infinitePosts(null),
          variables.postId
        );

        await deleteInInfiniteQuery(
          queryClient,
          keys.infinitePosts(variables.ownerId),
          variables.postId
        );
      }
      variables.onClose();
      toast.success("Xóa thành công");
    },
  });
};
