import { useMutation, useQuery, useQueryClient } from "react-query";
import { toast } from "react-toastify";
import {
  COMMENT_POST,
  REACTION_COMMENT_POST,
} from "../../constants/PostConstant";
import {
  createCommentService,
  infoChildrenCommentService,
  infoCountCommentService,
  infoRootCommentService,
  reactionCommentService,
  replyCommentService,
} from "../../services/CommentService";
import { deleteFile } from "../../services/UploadService";
import { getPostSocket } from "../../socket/postSocket";
import { keys } from "../queryKeys";

export const useInfoRootCommentPost = (postId, options = {}) => {
  const { data, isLoading, error } = useQuery(
    keys.commentRootPost(postId),
    () => infoRootCommentService({ postId }),
    {
      ...options,
      refetchOnWindowFocus: false,
      refetchOnMount: false,
      staleTime: Infinity,
    }
  );
  if (error) {
    toast.error(error.message || "Lỗi không xác định");
  }
  return { rootComment: data, isLoadingRootComment: isLoading };
};

export const useInfoChildrenCommentPost = (commentId, options = {}) => {
  const { data, isLoading, error, refetch } = useQuery(
    keys.commentChildrenPost(commentId),
    () => infoChildrenCommentService({ commentId }),
    {
      ...options,
      refetchOnWindowFocus: false,
      refetchOnMount: false,
      staleTime: Infinity,
    }
  );

  // console.log(options, commentId);

  if (error) {
    toast.error(error.message || "Lỗi không xác định");
  }
  return {
    childrenComment: data,
    isLoadingChildrenComment: isLoading,
    refetchChildrenComment: refetch,
  };
};

export const useInfoCountCommentPost = (postId, options = {}) => {
  const { data, error, isLoading } = useQuery(
    keys.countCommentPost(postId),
    () => infoCountCommentService({ postId }),
    {
      ...options,
      refetchOnWindowFocus: false,
      refetchOnMount: false,
      staleTime: Infinity,
    }
  );
  // console.log(data, error);
  return { countComment: data, isLoadingCountComment: isLoading };
};

export const useCommentPostMutation = () => {
  const queryClient = useQueryClient();
  return useMutation(
    ({ rootId, file, text, postId }) =>
      rootId
        ? replyCommentService({ root: rootId, file, content: text })
        : createCommentService({ file, content: text, postId }),
    {
      // Optimistically update the cache value on mutate, but store
      // the old value and return it so that it's accessible in case of
      // an error
      onMutate: async ({ rootId, text, postId }) => {
        let previousValue = null;
        if (!rootId) {
          previousValue = await queryClient.getQueryData(
            keys.commentRootPost(postId)
          );
        } else {
          previousValue = await queryClient.getQueryData(
            keys.commentChildrenPost(rootId)
          );
        }
        return previousValue;
      },
      // On failure, roll back to the previous value
      onError: async (err, variables, previousValue) => {
        try {
          toast.error(err.data || "Lỗi không xác định add comment");
          if (variables.file) {
            await deleteFile(variables.file.file);
          }
          if (variables.rootId) {
            queryClient.setQueryData(
              keys.commentRootPost(variables.rootId),
              previousValue
            );
          } else {
            queryClient.setQueryData(
              keys.commentRootPost(variables.postId),
              previousValue
            );
          }
        } catch (err) {
          console.log(err);
        }
      },
      onSuccess: (data, variables) => {
        // console.log("var", variables);
        // queryClient.invalidateQueries(keys.countCommentPost(variables.postId));
        getPostSocket().emit(COMMENT_POST, {
          postId: variables.postId,
          rootId: variables.rootId,
        });
      },
      // onSettled: (data, error, variables) => {
      //   if (variables.rootId) {
      //     queryClient.invalidateQueries(
      //       keys.commentChildrenPost(variables.rootId)
      //     );
      //   } else {
      //     queryClient.invalidateQueries(keys.commentRootPost(variables.postId));
      //   }
      // },
    }
  );
};

export const useReactionCommentPostMutation = () => {
  const queryClient = useQueryClient();
  return useMutation(
    ({ reaction, commentId, root, postId }) =>
      reactionCommentService({ reaction, commentId }),
    {
      onMutate: async ({ root, postId, commentId, reaction, userId }) => {
        let previousValue = null;
        if (!root) {
          previousValue = await queryClient.getQueryData(
            keys.commentRootPost(postId)
          );
        } else {
          previousValue = await queryClient.getQueryData(
            keys.commentChildrenPost(commentId)
          );
        }
        return previousValue;
      },
      // On failure, roll back to the previous value
      onError: (err, variables, previousValue) => {
        console.log(err);
        toast.error(err.data || "Lỗi không xác định reaction comment");
        if (!variables.root) {
          queryClient.setQueryData(
            keys.commentRootPost(variables.postId),
            previousValue
          );
        } else {
          queryClient.setQueryData(
            keys.commentChildrenPost(variables.commentId),
            previousValue
          );
        }
      },
      onSuccess: (data, variables) => {
        // if (variables.root !== null) {
        //   console.log("settled", variables);
        //   queryClient.invalidateQueries(
        //     keys.commentChildrenPost(variables.root)
        //   );
        // } else {
        //   queryClient.invalidateQueries(keys.commentRootPost(variables.postId));
        // }

        // socket
        getPostSocket().emit(REACTION_COMMENT_POST, {
          postId: variables.postId || null,
          root: variables.root,
        });
      },
    }
  );
};
