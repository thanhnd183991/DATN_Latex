import { useMutation, useQueries, useQuery, useQueryClient } from "react-query";
import { REACTION_POST } from "../../constants/PostConstant";
import { addReaction, infoReactionPost } from "../../services/ReactionService";
import { getPostSocket } from "../../socket/postSocket";
import { keys } from "../queryKeys";

export const useReactionPost = (postId, options = {}) => {
  return useQuery(
    keys.reactionPost(postId),
    () => infoReactionPost({ postId }),
    { ...options, refetchOnWindowFocus: false }
  );
};

export const useReactionListPost = (postIds, options = {}) => {
  return useQueries(
    postIds.map((postId) => {
      return {
        queryKey: keys.reactionPost(postId),
        queryFn: () => infoReactionPost(postId),
      };
    })
  );
};

export const useReactionPostMutation = () => {
  const queryClient = useQueryClient();
  return useMutation(
    ({ postId, reaction }) => addReaction({ postId, reaction }),
    {
      // Optimistically update the cache value on mutate, but store
      // the old value and return it so that it's accessible in case of
      // an error
      onMutate: async ({ postId, reaction }) => {
        await queryClient.cancelQueries(keys.reactionPost(postId));
        const previousValue = queryClient.getQueryData(
          keys.reactionPost(postId)
        );
        // console.log(previousValue);

        queryClient.setQueryData(keys.reactionPost(postId), {
          countReaction: previousValue.hasReaction
            ? previousValue.countReaction - 1
            : previousValue.countReaction + 1,
          hasReaction: !previousValue.hasReaction,
        });
        return previousValue;
      },
      // On failure, roll back to the previous value
      onError: (err, variables, previousValue) =>
        queryClient.setQueryData(
          keys.reactionPost(variables.postId),
          previousValue
        ),
      onSettled: (data, error, variables) => {
        // console.log(data, variables, error);
        getPostSocket().emit(
          REACTION_POST,
          { postId: variables.postId },
          (data) => {
            if (data?.error) {
              toast.error(data.error);
            }
          }
        );
      },
    }
  );
};
