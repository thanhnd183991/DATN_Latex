import { useEffect, useRef, useState } from "react";
import { useQuery, useQueryClient } from "react-query";
import { toast } from "react-toastify";
import {
  getJobByCategoryService,
  relateJobService,
} from "../services/JobService";
import {
  getSearchInputService,
  getSearchModelService,
  getSuggestion,
} from "../services/SearchService";
import { getSuggestionByUser } from "../services/SuggestionService";
import { keys } from "./queryKeys";
import { useDebounce } from "./useDebounce";

export const useSearchPage = ({
  model,
  columnField,
  operatorValue,
  value,
  setPage,
  params,
  page,
  limit,
}) => {
  const queryClient = useQueryClient();
  // console.log("page", page);
  const myKey = (page) => {
    if (params.relate) {
      return keys.relateJob(params.relate, page);
    } else if (params.suggestion) {
      return keys[
        `suggestion` +
          params.suggestion.charAt(0).toUpperCase() +
          params.suggestion.slice(1)
      ](page);
    } else {
      return model === "user"
        ? keys.userSearch(page)
        : model === "job"
        ? keys.jobSearch(page)
        : model === "company"
        ? keys.companySearch(page)
        : ["fake", page];
    }
  };

  const { status, data, error, isFetching, refetch, isPreviousData } = useQuery(
    myKey(page),
    () =>
      params.suggestion
        ? getSuggestionByUser({ page, limit, type: params.suggestion })
        : params.relate
        ? relateJobService(params.relate, page, limit)
        : params.category
        ? getJobByCategoryService(params.category, page, limit, model)
        : getSearchModelService({
            model,
            columnField,
            operatorValue,
            value: params.keyword,
            page,
            limit,
          }),
    { keepPreviousData: true, refetchOnWindowFocus: false, staleTime: Infinity }
  );
  // console.log(data);
  useEffect(() => {
    if (params.keyword || params.category) {
      // console.log("call refetch", params.category, params.keyword);
      setPage(0);
      refetch();
    }
  }, [params.keyword, params.category]);

  // Prefetch the next page!
  useEffect(() => {
    if (data?.hasMore) {
      queryClient.prefetchQuery(myKey(page + 1), () =>
        params.suggestion
          ? getSuggestionByUser({
              page: page + 1,
              limit,
              type: params.suggestion,
            })
          : params.relate
          ? relateJobService(params.relate, page + 1, limit)
          : params.category
          ? getJobByCategoryService(params.category, page + 1, limit, model)
          : getSearchModelService({
              model,
              columnField,
              operatorValue,
              value: params.keyword,
              page: page + 1,
              limit,
            })
      );
    }
  }, [
    data,
    page,
    queryClient,
    params.keyword,
    params.suggestion,
    params.relate,
  ]);

  return { status, data, error, isFetching, isPreviousData };
};

export const useSearchInput = () => {
  const [suggestions, setSuggestions] = useState([]);
  const queryClient = useQueryClient();
  const [suggestionIndex, setSuggestionIndex] = useState(-1);
  const [suggestionsActive, setSuggestionsActive] = useState(false);
  const [value, setValue] = useState("");
  const [isSearching, setIsSearching] = useState(false);
  const [isEnter, setIsEnter] = useState(false);
  const debouncedSearchTerm = useDebounce(value, 500);

  useEffect(
    () => {
      // console.log(isEnter, value);

      if (debouncedSearchTerm && !isEnter) {
        setIsSearching(true);
        console.log("searching...");
        handleChange(value);
        setIsSearching(false);
      } else {
        // setSuggestions([]);
        setIsSearching(false);
      }
    },
    [debouncedSearchTerm] // Only call effect if debounced search term changes
  );

  const handleChange = (text) => {
    const query = encodeURI(text.toLowerCase());
    // console.log(query);
    if (query.length > 0 && !isEnter) {
      const context = queryClient.getQueryData(keys.searchInput(query));
      // console.log(context);
      if (!context) {
        getSearchInputService({ value: query }).then((response) => {
          queryClient.setQueryData(
            keys.searchInput(query),
            response.data.data,
            { staleTime: 10000 }
          );
          setSuggestions(response.data.data);
          setSuggestionsActive(true);
        });
      } else {
        // console.log("from cache", context);
        setSuggestions(context);
        setSuggestionsActive(true);
      }
    } else {
      setSuggestionsActive(false);
    }
  };

  return {
    suggestions,
    suggestionsActive,
    setSuggestionsActive,
    suggestionIndex,
    setSuggestionIndex,
    value,
    setValue,
    isSearching,
    handleChange,
    setIsSearching,
    isEnter,
    setIsEnter,
  };
};

export const useSearchInputChipField = (model, onChange, value) => {
  const ref = useRef();
  const [text, setText] = useState("");
  const debouncedText = useDebounce(text, 500);
  const [isSearching, setIsSearching] = useState(false);
  const [results, setResults] = useState([]);
  const [suggestionIndex, setSuggestionIndex] = useState(-1);
  const [suggestionsActive, setSuggestionsActive] = useState(false);
  const [chipData, setChipData] = useState(value || []);
  const queryClient = useQueryClient();

  useEffect(() => {
    const handleClickOutside = (event) => {
      const isClickInsideElement = ref?.current?.contains(event.target);
      if (!isClickInsideElement) {
        //Do something click is outside specified element
        if (suggestionIndex !== -1) {
          setSuggestionIndex(-1);
        }
        setSuggestionsActive(false);
      }
    };

    document.body.addEventListener("click", handleClickOutside);
    // remove event listener when unmount
    return () => {
      document.body.removeEventListener("click", handleClickOutside);
    };
  }, []);

  // Effect for API call
  useEffect(
    () => {
      if (debouncedText) {
        const dataStore = queryClient.getQueryData(
          keys.searchInput(model + "-" + text)
        );
        if (dataStore) {
          console.log("from cache");
          setResults(dataStore);
        } else {
          setIsSearching(true);
          getSuggestion(model, text)
            .then((results) => {
              setIsSearching(false);
              queryClient.setQueryData(
                keys.searchInput(model + "-" + text),
                results.data,
                { staleTime: Infinity }
              );
              setResults(results.data || []);
            })
            .catch(() => {
              setResults([]);
              setIsSearching(false);
            });
        }
      } else {
        setResults([]);
        setIsSearching(false);
      }
    },
    [debouncedText] // Only call effect if debounced search term changes
  );

  const handleClick = (event) => {
    let tmp = chipData;
    if (
      chipData.some((el) => el === (results[suggestionIndex]?.name || text))
    ) {
      toast.error("Skill already added");
      return;
    }
    setChipData([...chipData, results[suggestionIndex]?.name || text]);
    onChange(tmp.concat([results[suggestionIndex]?.name || text]).join(","));
    setSuggestionIndex(-1);
    setText("");
    setSuggestionsActive(false);
  };

  const handleChange = (event) => {
    setSuggestionsActive(true);
    setSuggestionIndex(0);
    setText(event.target.value);
  };

  const handleKeyDown = (e) => {
    // UP ARROW
    if (e.keyCode === 38) {
      // console.log("key up arrow");
      if (suggestionIndex === -1) {
        return;
      }
      setSuggestionIndex(suggestionIndex - 1);
    }
    // DOWN ARROW
    else if (e.keyCode === 40) {
      // console.log("key down arrow");
      if (suggestionIndex + 1 === results.length) {
        setSuggestionIndex(-1);
        return;
      }
      setSuggestionIndex(suggestionIndex + 1);
    }
    // ENTER
    else if (e.keyCode === 13) {
      handleClick(e);
    }
  };

  const handleDelete = (chipToDelete) => () => {
    const chipTemp = chipData;
    setChipData((chips) => chips.filter((chip) => chip !== chipToDelete));
    onChange(chipTemp.filter((chip) => chip !== chipToDelete).join(","));
  };

  return {
    ref,
    text,
    handleChange,
    handleKeyDown,
    isSearching,
    suggestionsActive,
    handleClick,
    results,
    setSuggestionIndex,
    suggestionIndex,
    chipData,
    handleDelete,
  };
};

export const useSearchInputField = (model, value, onChange, ref) => {
  const debouncedValue = useDebounce(value, 500);
  const [isSearching, setIsSearching] = useState(false);
  const [results, setResults] = useState([]);
  const [suggestionIndex, setSuggestionIndex] = useState(-1);
  const [suggestionsActive, setSuggestionsActive] = useState(false);
  const queryClient = useQueryClient();

  useEffect(() => {
    const handleClickOutside = (event) => {
      const isClickInsideElement = ref?.current?.contains(event.target);
      if (!isClickInsideElement) {
        //Do something click is outside specified element
        // console.log("click outside input search");
        if (suggestionIndex !== -1) {
          setSuggestionIndex(-1);
        }
        setSuggestionsActive(false);
      }
    };

    document.body.addEventListener("click", handleClickOutside);
    // remove event listener when unmount
    return () => {
      document.body.removeEventListener("click", handleClickOutside);
    };
  }, []);

  // Effect for API call
  useEffect(
    () => {
      if (debouncedValue) {
        const dataStore = queryClient.getQueryData(
          keys.searchInput(model + "-" + value)
        );
        if (dataStore) {
          setResults(dataStore);
        } else {
          setIsSearching(true);
          getSuggestion(model, value)
            .then((results) => {
              setIsSearching(false);
              queryClient.setQueryData(
                keys.searchInput(model + "-" + value),
                results.data,
                { staleTime: Infinity }
              );
              setResults(results.data || []);
            })
            .catch(() => {
              setResults([]);
              setIsSearching(false);
            });
        }
      } else {
        setResults([]);
        setIsSearching(false);
      }
    },
    [debouncedValue] // Only call effect if debounced search term changes
  );

  const handleClick = (event) => {
    onChange(results[suggestionIndex]?.name || value);
    setSuggestionIndex(-1);
    setSuggestionsActive(false);
  };

  const handleChange = (event) => {
    setSuggestionsActive(true);
    setSuggestionIndex(0);
    onChange(event.target.value);
  };

  const handleKeyDown = (e) => {
    // UP ARROW
    if (e.keyCode === 38) {
      // console.log("key up arrow");
      if (suggestionIndex === -1) {
        return;
      }
      setSuggestionIndex(suggestionIndex - 1);
    }
    // DOWN ARROW
    else if (e.keyCode === 40) {
      // console.log("key down arrow");
      if (suggestionIndex + 1 === results.length) {
        setSuggestionIndex(-1);
        return;
      }
      setSuggestionIndex(suggestionIndex + 1);
    }
    // ENTER
    else if (e.keyCode === 13) {
      handleClick(e);
    }
  };

  return {
    handleChange,
    handleKeyDown,
    suggestionsActive,
    handleClick,
    results,
    setSuggestionIndex,
    suggestionIndex,
  };
};
