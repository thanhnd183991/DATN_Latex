import { useEffect, useState } from "react";
import { useInView } from "react-intersection-observer";
import {
  useInfiniteQuery,
  useMutation,
  useQuery,
  useQueryClient,
} from "react-query";
import { useDispatch } from "react-redux";
import { toast } from "react-toastify";
import { setAvatar } from "../redux/features/authSlice";
import {
  deleteUserService,
  getInfoUser,
  getListByUser,
  getUserPage,
  putFollowingCompanyService,
  putFollowingUserService,
  putUpdateArrayService,
  putUpdateFieldService,
} from "../services/UserService";
import { keys } from "./queryKeys";
import { useDebounce } from "./useDebounce";

export const useUserPage = (page = 0, limit = 6) => {
  const queryClient = useQueryClient();

  const { status, data, error, isFetching, isPreviousData } = useQuery(
    keys.userSearch(page),
    () => getUserPage(page, limit),
    { keepPreviousData: true, staleTime: 5000 }
  );

  // Prefetch the next page!
  useEffect(() => {
    if (data?.hasMore) {
      queryClient.prefetchQuery(keys.userSearch(page + 1), () =>
        getUserPage(page + 1, limit)
      );
    }
  }, [data, page, queryClient]);

  return { status, data, error, isFetching, isPreviousData };
};

export const useListUser = ({ type, id, companyId, action }) => {
  const { ref, inView } = useInView();
  const [value, setValue] = useState("");
  const debouncedValue = useDebounce(value, 500);
  const {
    status,
    data,
    error,
    isFetching,
    isFetchingNextPage,
    isFetchingPreviousPage,
    fetchNextPage,
    fetchPreviousPage,
    hasNextPage,
    hasPreviousPage,
  } = useInfiniteQuery(
    companyId
      ? keys.companyFollowers(companyId, debouncedValue)
      : action
      ? keys.listEmployees(debouncedValue)
      : type
      ? keys[type + "User"](id, debouncedValue)
      : ["fake"],
    ({ pageParam = 1 }) =>
      getListByUser({
        id,
        page: pageParam,
        type,
        debouncedValue,
        companyId,
        action,
      }),
    {
      refetchOnWindowFocus: false,
      refetchOnMount: false,
      staleTime: Infinity,
      getPreviousPageParam: (firstPage) => firstPage.previousId ?? undefined,
      getNextPageParam: (lastPage) => lastPage.nextId ?? undefined,
    }
  );

  useEffect(() => {
    if (inView) {
      fetchNextPage();
    }
  }, [inView]);

  return {
    status,
    data,
    error,
    isFetching,
    isFetchingNextPage,
    isFetchingPreviousPage,
    fetchNextPage,
    fetchPreviousPage,
    hasNextPage,
    hasPreviousPage,
    refInView: ref,
    value,
    handleChangeValue: (e) => setValue(e.target.value),
  };
};
export const useUser = (userId, options = {}) => {
  const { data, error, isSuccess, isLoading, status } = useQuery(
    keys.user(userId),
    () => getInfoUser(userId),
    {
      ...options,
      refetchOnWindowFocus: false,
      staleTime: 1000 * 60 * 60,
    }
  );
  if (error) {
    console.log(error);
  }
  return { isSuccess, data: data?.data, isLoading, error, status };
};

export const useFollowingCompanyMutation = () => {
  const queryClient = useQueryClient();

  return useMutation(
    ({ userId, companyId }) => putFollowingCompanyService({ companyId }),
    {
      // Optimistically update the cache value on mutate, but store
      // the old value and return it so that it's accessible in case of
      // an error
      onMutate: async ({ userId, companyId }) => {
        await queryClient.cancelQueries(keys.user(userId));
        const previousValue = queryClient.getQueryData(keys.user(userId));
        return previousValue;
      },
      // On failure, roll back to the previous value
      onError: (err, variables, previousValue) => {
        toast.error(err.message);
        queryClient.setQueryData(keys.user(variables.userId), previousValue);
      },
      onSuccess: (data, variables, previousValue) => {
        queryClient.invalidateQueries(keys.user(variables.userId));
      },
    }
  );
};

export const useFollowingUserMutation = () => {
  const queryClient = useQueryClient();

  return useMutation(
    ({ userId, otherId }) => putFollowingUserService({ otherId }),
    {
      // Optimistically update the cache value on mutate, but store
      // the old value and return it so that it's accessible in case of
      // an error
      onMutate: async ({ userId, otherId }) => {
        await queryClient.cancelQueries(keys.user(userId));
        const previousValue = queryClient.getQueryData(keys.user(userId));

        return previousValue;
      },
      // On failure, roll back to the previous value
      onError: (err, variables, previousValue) =>
        queryClient.setQueryData(keys.user(variables.userId), previousValue),
      onSuccess: (data, variables, previousValue) => {
        queryClient.invalidateQueries(keys.user(variables.userId));
        const { pages } = queryClient.getQueryData(keys.infinitePosts(null));
        if (pages.length <= 1) {
          queryClient.invalidateQueries(keys.infinitePosts(null));
        }
      },
    }
  );
};

export const useUpdateArrayMutation = () => {
  const queryClient = useQueryClient();

  return useMutation(
    ({ userId, type, data }) => putUpdateArrayService({ type, data }),
    {
      onMutate: async ({ userId }) => {
        await queryClient.cancelQueries(keys.user(userId));
        const previousValue = queryClient.getQueryData(keys.user(userId));
        return previousValue;
      },
      // On failure, roll back to the previous value
      onError: (err, variables, previousValue) => {
        console.log(err);
        toast.error(Object.values(err)[0] || "Điền thiếu trường");
        queryClient.setQueryData(keys.user(variables.userId), previousValue);
      },
      onSuccess: (data, variables, previousValue) => {
        queryClient.invalidateQueries(keys.user(variables.userId));

        if (variables.type === "skills") {
          queryClient.refetchQueries(keys.jobRecommend(null));
          queryClient.refetchQueries(keys.suggestionJob(null));
          queryClient.refetchQueries(keys.suggestionCompany(null));
        }

        variables.onClose();
      },
    }
  );
};

export const useUpdateFieldMutation = () => {
  const queryClient = useQueryClient();
  const dispatch = useDispatch();
  return useMutation(({ userId, body }) => putUpdateFieldService(body), {
    // Optimistically update the cache value on mutate, but store
    // the old value and return it so that it's accessible in case of
    // an error
    onMutate: async ({ userId, skills }) => {
      await queryClient.cancelQueries(keys.user(userId));
      const previousValue = queryClient.getQueryData(keys.user(userId));
      return previousValue;
    },
    // On failure, roll back to the previous value
    onError: (err, variables, previousValue) => {
      toast.error(err.message);
      queryClient.setQueryData(keys.user(variables.userId), previousValue);
    },
    onSuccess: (data, variables, previousValue) => {
      if (variables.avatar) {
        previousValue.data.avatar = variables.avatar;
        queryClient.setQueryData(keys.user(variables.userId), previousValue);
        dispatch(setAvatar(variables.avatar));
      } else {
        queryClient.invalidateQueries(keys.user(variables.userId));
      }
      variables.onClose();
    },
  });
};

export const useDeleteUserMutation = () => {
  const queryClient = useQueryClient();

  return useMutation(({ userId }) => deleteUserService(userId), {
    // Optimistically update the cache value on mutate, but store
    // the old value and return it so that it's accessible in case of
    // an error
    onMutate: async ({ userId, page }) => {
      await queryClient.cancelQueries(keys.adminListUser(page));
      const previousValue = queryClient.getQueryData(keys.adminListUser(page));
      return previousValue;
    },
    // On failure, roll back to the previous value
    onError: (err, variables, previousValue) => {
      toast.error(err.message || "error");
      queryClient.setQueryData(
        keys.adminListUser(variables.page),
        previousValue
      );
    },
    onSuccess: (data, variables, previousValue) => {
      queryClient.invalidateQueries(keys.adminListUser(variables.page));
      queryClient.invalidateQueries(keys.adminStatusUser);
      variables.onClose();
    },
  });
};
