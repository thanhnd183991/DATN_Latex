export const keys = {
  //user
  user: (user) => ["user", user],
  userSearch: (page, value) => (page ? ["users-search", page] : "users-search"),
  userSaveJobCart: "user-save-job-cart",
  userApplyJobCart: "user-apply-job-cart",
  followersUser: (id, value) => ["list-followers-user", id + value],
  followingUser: (id, value) => ["list-following-user", id + value],
  followingCompanyUser: (id, value) => [
    "list-following-company-user",
    id + value,
  ],
  suggestionUser: (page) => ["suggestion-user", page],
  listEmployees: (value) => ["list-employees", value],

  // post
  infinitePosts: (id) => (id ? ["posts", id] : "posts-feed"),
  reactionPost: (postId) => ["reaction-post", postId],
  commentRootPost: (postId) => ["comment-root-post", postId],
  commentChildrenPost: (commentId) => ["comment-children-post", commentId],
  countCommentPost: (postId) => ["count-comment-post", postId],
  post: (postId) => ["post", postId],

  //company
  companySearch: (page) =>
    page ? ["companies-search", page] : "companies-search",
  suggestionCompany: (page) =>
    typeof page === "number"
      ? ["suggestion-company", page]
      : ["suggestion-company"],
  company: (companyId) => ["company", companyId],
  companyFollowers: (companyId, value) => [
    "company-followers",
    companyId + value,
  ],
  companyMember: (companyId) => ["company-member", companyId],

  // job
  job: (jobId) => ["job", jobId],
  jobRecommend: (page) =>
    typeof page === "number"
      ? ["jobs-recommendation", page]
      : ["jobs-recommendation"],
  jobCompany: (companyId, page) => [`job-company-${companyId}`, page],
  jobByHR: (page, id) => (page ? [`job-HR-${id}`, page] : [`job-HR-${id}`]),
  jobSearch: (page) => (page ? ["jobs-search", page] : "jobs-search"),
  suggestionJob: (page) =>
    typeof page === "number" ? ["suggestion-job", page] : ["suggestion-job"],
  relateJob: (jobId, page) => [`relate-job-${jobId}`, page],

  //chat
  listChatPersonal: ["list-chat-personal"],
  listChatCompany: ["list-chat-company"],
  chatRoom: (id) => [`chat-room`, id],
  messages: (id) => [`messages-room`, id],

  //input
  searchInput: (value) => ["search-input", value],

  //notifications
  notifications: (value) => [`notifications-${value}`],

  //admin-home

  adminCountAll: ["admin-count-all"],
  adminCountJobByCategory: ["admin-count-job-by-category"],
  adminCountJobByCompany: ["admin-count-job-by-company"],
  //admin-user
  adminStatsUser: ["admin-stats-user"],
  adminStatusUser: ["admin-status-user"],
  adminListUser: (page) => ["admin-list-user", page],

  //admin-post
  adminStatsPost: ["admin-stats-post"],
  adminCountTypePost: ["admin-count-type-post"],
  adminListPost: (page) => ["admin-list-post", page],

  //admin-company
  adminStatsCompany: ["admin-stats-company"],
  adminStatusCompany: ["admin-status-company"],
  adminListCompany: (page) => ["admin-list-company", page],

  //admin-job
  adminStatsJob: ["admin-stats-job"],
  adminStatusJob: ["admin-status-job"],
  adminListJob: (page) => ["admin-list-job", page],

  //admin-category
  adminListCategory: (page) => ["admin-list-category", page],
};
