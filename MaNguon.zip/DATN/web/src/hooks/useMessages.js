import { useInfiniteQuery, useMutation, useQueryClient } from "react-query";
import {
  createMessageService,
  getMessages,
  reactMessageService,
} from "../services/MessageService";
import { findInInfiniteQuery } from "../utils/find";
import { keys } from "./queryKeys";

export const useMessages = (roomId) => {
  // console.log(options);
  return useInfiniteQuery(
    keys.messages(roomId),
    ({ pageParam = 1 }) => getMessages({ pageParam, roomId }),
    {
      staleTime: 1000 * 60,
      refetchOnWindowFocus: false,
      enabled: !!roomId,
      getPreviousPageParam: (firstPage) => firstPage.previousId ?? undefined,
      getNextPageParam: (lastPage) => lastPage.nextId ?? undefined,
    }
  );
};

export const useReactionMessageMutation = () => {
  const queryClient = useQueryClient();
  return useMutation(
    ({ messageId, reaction }) => reactMessageService(messageId, reaction),
    {
      // Optimistically update the cache value on mutate, but store
      // the old value and return it so that it's accessible in case of
      // an error
      onMutate: async ({ roomId }) => {
        await queryClient.cancelQueries(keys.messages(roomId));
        const previousValue = queryClient.getQueryData(keys.messages(roomId));
        return previousValue;
      },
      // On failure, roll back to the previous value
      onError: (err, variables, previousValue) => {
        toast.error(Object.values(err)[0] || "Something went wrong");
        queryClient.setQueryData(
          keys.messages(variables.roomId),
          previousValue
        );
      },
      onSuccess: (data, variables, previousValue) => {
        // console.log(data);
        // console.log(previousValue);
        const { pages, ...info } = previousValue;
        pages[variables.page].data[variables.index] = data.data;
        queryClient.setQueryData(keys.messages(variables.roomId), {
          pages,
          ...info,
        });
        // ariables.onClose();
      },
    }
  );
};

export const useCreateMessageMutation = () => {
  const queryClient = useQueryClient();
  return useMutation(
    ({ roomId, message }) => createMessageService(roomId, message),
    {
      // Optimistically update the cache value on mutate, but store
      // the old value and return it so that it's accessible in case of
      // an error
      onMutate: async ({ roomId }) => {
        await queryClient.cancelQueries(keys.messages(roomId));
        const previousValue = queryClient.getQueryData(keys.messages(roomId));
        return previousValue;
      },
      // On failure, roll back to the previous value
      onError: (err, variables, previousValue) => {
        toast.error(Object.values(err)[0] || "Something went wrong");
        queryClient.setQueryData(
          keys.messages(variables.roomId),
          previousValue
        );
        variables.onClose();
      },
      onSuccess: (data, variables, previousValue) => {
        // console.log(data);
        // console.log(previousValue);
        const { pages, ...info } = previousValue;
        pages[0].data.unshift(data.data);
        queryClient.setQueryData(keys.messages(variables.roomId), {
          pages,
          ...info,
        });
        const roomCurr = queryClient.getQueryData(
          keys.chatRoom(variables.roomId)
        );
        const rooms = queryClient.getQueryData(
          roomCurr.roomType === "Personal"
            ? keys.listChatPersonal
            : keys.listChatCompany
        );

        // debugger;
        const { pageIndex, index } = findInInfiniteQuery(
          rooms,
          variables.roomId
        );
        if (pageIndex === null || index === null) {
          variables.onClose();
        } else {
          // console.log(data.data);
          rooms.pages[pageIndex].data[index].latestMessage = data.data;
          console.log(rooms);
          queryClient.setQueryData(
            roomCurr.roomType === "Personal"
              ? keys.listChatPersonal
              : keys.listChatCompany,
            rooms
          );
          variables.onClose();
          // debugger;
        }
      },
    }
  );
};
