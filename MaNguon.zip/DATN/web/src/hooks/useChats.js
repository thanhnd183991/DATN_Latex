import { useInfiniteQuery, useQuery } from "react-query";
import { getChats, getRoomService } from "../services/ChatService";
import { keys } from "./queryKeys";

export const useRooms = (type) => {
  // console.log(options);
  return useInfiniteQuery(
    keys[`listChat${type}`],
    ({ pageParam = 1 }) => getChats({ pageParam, type }),
    {
      // staleTime: 1000 * 60 * 60,
      refetchOnWindowFocus: false,
      getPreviousPageParam: (firstPage) => firstPage.previousId ?? undefined,
      getNextPageParam: (lastPage) => lastPage.nextId ?? undefined,
    }
  );
};

export const useRoom = (roomId) => {
  const { data, error, isSuccess, isLoading } = useQuery(
    keys.chatRoom(roomId),
    () => getRoomService(roomId),
    {
      enabled: !!roomId,
      refetchOnWindowFocus: false,
      staleTime: 1000 * 60,
    }
  );
  if (error) {
    console.log(error);
  }
  // console.log(data);
  return { isSuccess, room: data, isLoadingRoom: isLoading };
};
