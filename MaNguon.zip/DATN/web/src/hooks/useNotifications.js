import { useEffect } from "react";
import { useInView } from "react-intersection-observer";
import { useInfiniteQuery } from "react-query";
import { useSelector } from "react-redux";
import { getNotifications } from "../services/NotificationService";
import { keys } from "./queryKeys";

export const useNotifications = () => {
  const { ref, inView } = useInView();
  const { typeNotifyFilter } = useSelector((state) => state.badge);
  const {
    status,
    data,
    error,
    isFetching,
    isFetchingNextPage,
    isFetchingPreviousPage,
    fetchNextPage,
    fetchPreviousPage,
    hasNextPage,
    hasPreviousPage,
  } = useInfiniteQuery(
    keys.notifications(typeNotifyFilter),
    ({ pageParam = 1 }) =>
      getNotifications({ pageParam, type: typeNotifyFilter }),
    {
      staleTime: Infinity,
      getPreviousPageParam: (firstPage) => firstPage.previousId ?? undefined,
      getNextPageParam: (lastPage) => lastPage.nextId ?? undefined,
    }
  );

  useEffect(() => {
    if (inView) {
      // console.log("vao 1");
      fetchNextPage();
    }
  }, [inView]);

  return {
    status,
    data,
    ref,
    error,
    isFetching,
    isFetchingNextPage,
    isFetchingPreviousPage,
    fetchNextPage,
    fetchPreviousPage,
    hasNextPage,
    hasPreviousPage,
  };
};
