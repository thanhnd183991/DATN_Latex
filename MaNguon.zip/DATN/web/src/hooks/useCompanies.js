import { useEffect } from "react";
import { useMutation, useQuery, useQueryClient } from "react-query";
import { useDispatch } from "react-redux";
import { toast } from "react-toastify";
import {
  ACCEPTED,
  CONFIRM_COMPANY,
  CONFIRM_DELETE_MEMBER,
  CREATE_COMPANY,
  REJECTED,
} from "../constants/NotifyConstant";
import { addNotifyFunc } from "../funcs/NotificationFunc";
import {
  activeCompanyService,
  addMember,
  createCompanyService,
  deleteMember,
  getCompanyPage,
  getInfoCompany,
  getMembersCompany,
  updateCompanyService,
} from "../services/CompanyService";
import { deleteFile } from "../services/UploadService";
import { getSocket } from "../socket";
import { deleteInInfiniteQuery } from "../utils/opereationQueryClient";
import { keys } from "./queryKeys";

export const useCompanyPage = (page = 0, limit = 6) => {
  const queryClient = useQueryClient();

  const { status, data, error, isFetching, isPreviousData } = useQuery(
    ["companies-search", page],
    () => getCompanyPage(page, limit),
    { keepPreviousData: true, staleTime: 5000 }
  );

  // Prefetch the next page!
  useEffect(() => {
    if (data?.hasMore) {
      queryClient.prefetchQuery(["companies-search", page + 1], () =>
        getCompanyPage(page + 1, limit)
      );
    }
  }, [data, page, queryClient]);

  return { status, data, error, isFetching, isPreviousData };
};

export const useMembersCompany = (companyId) => {
  const { data, error, isSuccess, isLoading, status } = useQuery(
    keys.companyMember(companyId),
    () => getMembersCompany({ companyId }),
    {
      refetchOnWindowFocus: false,
      staleTime: 1000 * 60 * 60,
      enabled: !!companyId,
    }
  );
  if (error) {
    console.log(error);
  }
  return { isSuccess, members: data, isLoading, status };
};

export const useCompany = (companyId) => {
  const { data, error, isSuccess, isLoading, status } = useQuery(
    keys.company(companyId),
    () => getInfoCompany({ companyId }),
    {
      refetchOnWindowFocus: false,
      staleTime: 1000 * 60 * 3,
      enabled: !!companyId,
    }
  );
  if (error) {
    console.log(error);
  }
  // console.log(data);
  return { isSuccess, data: data?.data, isLoading, status };
};

export const useUpdateCompanyMutation = () => {
  const queryClient = useQueryClient();
  return useMutation(
    ({ companyId, body }) => updateCompanyService(companyId, body),
    {
      // Optimistically update the cache value on mutate, but store
      // the old value and return it so that it's accessible in case of
      // an error
      onMutate: async ({ companyId }) => {
        await queryClient.cancelQueries(keys.company(companyId));
        const previousValue = queryClient.getQueryData(keys.company(companyId));
        return previousValue;
      },
      // On failure, roll back to the previous value
      onError: (err, variables, previousValue) => {
        toast.error(err.message || "error");
        queryClient.setQueryData(keys.user(variables.companyId), previousValue);
      },
      onSuccess: (data, variables, previousValue) => {
        if (variables.avatar) {
          previousValue.data.avatar = variables.avatar;
          queryClient.setQueryData(
            keys.company(variables.companyId),
            previousValue
          );
        } else {
          queryClient.invalidateQueries(keys.company(variables.companyId));
        }
        variables.onClose();
      },
    }
  );
};

export const useMemberCompanyMutation = () => {
  const queryClient = useQueryClient();
  return useMutation(
    ({ companyId, employees, action }) =>
      action === "delete"
        ? deleteMember(companyId, employees)
        : addMember(companyId, employees),
    {
      onMutate: async ({ companyId }) => {
        await queryClient.cancelQueries(keys.companyMember(companyId));
        const previousValue = queryClient.getQueryData(
          keys.companyMember(companyId)
        );
        return previousValue;
      },
      onError: (err, variables, previousValue) => {
        console.log(err);
        toast.error(err || Object.values(err)[0] || err.message || "error");
        queryClient.setQueryData(keys.user(variables.companyId), previousValue);
      },
      onSuccess: (data, variables, previousValue) => {
        queryClient.invalidateQueries(keys.companyMember(variables.companyId));
        queryClient.invalidateQueries(keys.listEmployees);
        if (variables.action === "delete") {
          getSocket().emit(
            CONFIRM_DELETE_MEMBER,
            {
              companyId: variables.companyId,
              employees: variables.employees,
            },
            (data) => {
              if (data.error) {
                toast.success(data.message);
              }
            }
          );
        }
        variables.onClose();
      },
    }
  );
};

export const useActiveCompanyMutation = () => {
  const queryClient = useQueryClient();
  const dispatch = useDispatch();
  return useMutation(
    ({ companyId, status }) => activeCompanyService(companyId, status),
    {
      onMutate: async ({ page, isNotify }) => {
        if (!isNotify) {
          await queryClient.cancelQueries(keys.adminListCompany(page));
          const previousValue = queryClient.getQueryData(
            keys.adminListCompany(page)
          );
          return previousValue;
        }
      },
      // On failure, roll back to the previous value
      onError: (err, variables, previousValue) => {
        if (!variables.isNotify) {
          toast.error(err.message || "error");
          queryClient.setQueryData(
            keys.adminListCompany(variables.page),
            previousValue
          );
        }
      },
      onSuccess: (data, variables, previousValue) => {
        if (variables.isNotify) {
          getSocket().emit(
            CONFIRM_COMPANY,
            {
              notifyId: variables.notifyId,
              companyId: variables.companyId,
              status: variables.status === true ? ACCEPTED : REJECTED,
            },
            async (data) => {
              if (data.error) {
                console.log(data.error);
                toast.error(data.error);
                queryClient.invalidateQueries(keys.notifications("All"));
                await deleteInInfiniteQuery(
                  queryClient,
                  keys.notifications(CREATE_COMPANY),
                  variables.notifyId
                );
              }
              if (data.success) {
                addNotifyFunc(queryClient, data, dispatch);
                toast.success(data.success);
              }
            }
          );
        } else {
          queryClient.invalidateQueries(keys.adminListCompany(variables.page));
          queryClient.invalidateQueries(keys.adminStatusCompany);
          variables.onClose();
        }
      },
    }
  );
};

export const useCreateCompanyMutation = () => {
  return useMutation(({ body }) => createCompanyService(body), {
    onMutate: async ({}) => {},
    // On failure, roll back to the previous value
    onError: async (err, variables, previousValue) => {
      if (variables?.body?.avatar) {
        const rs = await deleteFile(variables.body.avatar);
        console.log("xoa image company", rs);
      }
      toast.error(err.message || "error");
      variables.onClose();
    },
    onSuccess: (data, variables, previousValue) => {
      variables.onClose();
    },
    onSettled: (data, error, variables) => {
      if (data) {
        console.log("emit create company");
        getSocket().emit(
          CREATE_COMPANY,
          { companyId: data.data._id },
          (data) => {
            if (data.success) {
              toast.success(data.success);
            }
            if (data.error) {
              toast.error(data.error);
            }
          }
        );
      }
    },
  });
};
