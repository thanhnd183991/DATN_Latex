import { useMutation, useQueryClient } from "react-query";
import { deleteCategory } from "../services/CategoryService";
import { keys } from "./queryKeys";

export const useDeleteCategoryMutation = () => {
  const queryClient = useQueryClient();

  return useMutation(({ catId }) => deleteCategory(catId), {
    // Optimistically update the cache value on mutate, but store
    // the old value and return it so that it's accessible in case of
    // an error
    onMutate: async ({ page }) => {
      await queryClient.cancelQueries(keys.adminListCategory(page));
      const previousValue = queryClient.getQueryData(
        keys.adminListCategory(page)
      );
      return previousValue;
    },
    // On failure, roll back to the previous value
    onError: (err, variables, previousValue) => {
      toast.error(err.message);
      queryClient.setQueryData(
        keys.adminListCategory(variables.page),
        previousValue
      );
    },
    onSuccess: (data, variables, previousValue) => {
      queryClient.invalidateQueries(keys.adminListCategory(variables.page));
      variables.onClose();
    },
  });
};
