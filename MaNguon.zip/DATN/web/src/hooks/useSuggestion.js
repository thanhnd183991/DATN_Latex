import { useEffect } from "react";
import { useQuery, useQueryClient } from "react-query";
import { getSuggestionByUser } from "../services/SuggestionService";
import { keys } from "./queryKeys";

export const useSuggestionPage = (type, page = 1, limit = 6) => {
  const queryClient = useQueryClient();
  const myKey = (page) =>
    type === "user"
      ? keys.suggestionUser(page)
      : type === "company"
      ? keys.suggestionCompany(page)
      : type === "job"
      ? keys.suggestionJob(page)
      : ["fake", page];

  const { status, data, error, isFetching, isPreviousData } = useQuery(
    myKey(page),
    () => getSuggestionByUser({ page, limit, type }),
    { keepPreviousData: true, staleTime: 5000 }
  );
  // console.log(data);

  // Prefetch the next page!
  useEffect(() => {
    if (data?.hasMore) {
      queryClient.prefetchQuery(myKey(page + 1), () =>
        getSuggestionByUser({ page: page + 1, limit, type })
      );
    }
  }, [data, page, queryClient]);

  return { status, data, error, isFetching, isPreviousData };
};
