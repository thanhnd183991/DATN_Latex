import { createSlice } from "@reduxjs/toolkit";
// import { userSocket, socket } from "../App";
import { setSession } from "../../utils/jwt";
import { loginUser, signupUser } from "../../services/AuthService";
import { createAsyncThunk } from "@reduxjs/toolkit";
import { toast } from "react-toastify";

export const login = createAsyncThunk(
  "auth/login",
  async ({ email, password }, { rejectWithValue }) => {
    try {
      const response = await loginUser({ email, password });
      console.log("log", response.data.token);

      setSession(response.data.token);

      return response.data;
    } catch (err) {
      toast.error(err.message);
      return rejectWithValue(err);
    }
  }
);

export const signup = createAsyncThunk(
  "auth/signup",
  async ({ email, password, name }, { rejectWithValue }) => {
    try {
      const response = await signupUser({ name, email, password });

      setSession(response.data.token);

      return response.data;
    } catch (err) {
      toast.error(err.message);
      return rejectWithValue(err);
    }
  }
);

export const authSlice = createSlice({
  name: "auth",
  initialState: {
    pending: false,
    error: null,
    token: localStorage.getItem("token") || null,
    user: JSON.parse(localStorage.getItem("user")) || null,
  },
  reducers: {
    logout: (state) => {
      state.token = null;
      state.user = null;
      pending: false;
      error: null;
      localStorage.removeItem("token");
      localStorage.removeItem("user");
    },
    setAvatar: (state, action) => {
      state.user.avatar = action.payload;
      localStorage.setItem("user", JSON.stringify(state.user));
    },
  },
  extraReducers: {
    [login.pending]: (state) => {
      state.pending = true;
      state.error = false;
    },
    [login.fulfilled]: (state, action) => {
      state.user = action.payload.user;
      state.token = action.payload.token;
      localStorage.setItem("token", action.payload.token);
      localStorage.setItem("user", JSON.stringify(action.payload.user));
      state.pending = false;
    },
    [login.rejected]: (state, action) => {
      state.pending = false;
      state.error = true;
    },
    [signup.pending]: (state) => {
      state.pending = true;
      state.error = false;
    },
    [signup.fulfilled]: (state, action) => {
      state.user = action.payload.user;
      state.token = action.payload.token;
      localStorage.setItem("token", action.payload.token);
      localStorage.setItem("user", JSON.stringify(action.payload.user));
      state.pending = false;
    },
    [signup.rejected]: (state, action) => {
      state.pending = false;
      state.error = true;
    },
  },
});
export const { logout, setAvatar } = authSlice.actions;

export default authSlice.reducer;
