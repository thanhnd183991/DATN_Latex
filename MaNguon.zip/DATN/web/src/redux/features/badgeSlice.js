import { createSlice } from "@reduxjs/toolkit";

export const badgeSlice = createSlice({
  name: "room",
  initialState: {
    notify: 0,
    typeNotifyFilter: "All",
    chat: [],
  },
  reducers: {
    setNotify: (state, action) => {
      state.notify = action.payload;
    },
    addNotify: (state) => {
      state.notify += 1;
    },
    setChat: (state, action) => {
      state.chat = action.payload;
    },
    addChat: (state, action) => {
      const findIndex = state.chat.findIndex(
        (item) => item === action.payload.roomId
      );
      if (findIndex === -1) {
        state.chat.push(action.payload.roomId);
      }
    },
    resetNotify: (state) => {
      state.notify = 0;
    },
    resetChat: (state) => {
      state.chat = [];
    },
    setTypeNotifyFitler: (state, action) => {
      state.typeNotifyFilter = action.payload.type;
    },
  },
  extraReducers: {},
});
export const {
  addChat,
  addNotify,
  resetChat,
  resetNotify,
  setChat,
  setNotify,
  setTypeNotifyFitler,
} = badgeSlice.actions;

export default badgeSlice.reducer;
