import { createSlice } from "@reduxjs/toolkit";

export const roomSlice = createSlice({
  name: "room",
  initialState: {
    tabRoom: 0,
  },
  reducers: {
    setTabRoom: (state, action) => {
      console.log("roomSlice", action.payload);
      state.tabRoom = action.payload;
    },
  },
  extraReducers: {},
});
export const { setTabRoom } = roomSlice.actions;

export default roomSlice.reducer;
