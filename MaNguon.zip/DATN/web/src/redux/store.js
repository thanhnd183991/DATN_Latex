import { configureStore } from "@reduxjs/toolkit";
import authReducer from "./features/authSlice";
import roomReducer from "./features/roomSlice";
import badgeReducer from "./features/badgeSlice";
// import { postApi } from "../services/PostService";

export default configureStore({
  reducer: {
    auth: authReducer,
    room: roomReducer,
    badge: badgeReducer,
    // [postApi.reducerPath]: postApi.reducer,
  },
  // middleware: (getDefaultMiddleware) =>
  //   getDefaultMiddleware().concat(postApi.middleware),
});
