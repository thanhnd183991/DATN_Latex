import CssBaseline from "@mui/material/CssBaseline";
import "slick-carousel/slick/slick-theme.css";
import "slick-carousel/slick/slick.css";
import "react-quill/dist/quill.snow.css"; // ES6
import "react-medium-image-zoom/dist/styles.css";
// import "emoji-mart/css/emoji-mart.css";
import "./App.css";

import { ReactQueryDevtools } from "react-query/devtools";
import Routes from "./Routes";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

export let socket;

function App() {
  return (
    <>
      <CssBaseline />
      <Routes />
      <ToastContainer />
      <ReactQueryDevtools initialIsOpen />
    </>
  );
}

export default App;
