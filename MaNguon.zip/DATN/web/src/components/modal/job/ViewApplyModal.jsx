import { Box, CircularProgress, Typography } from "@mui/material";
import Backdrop from "@mui/material/Backdrop";
import Fade from "@mui/material/Fade";
import Modal from "@mui/material/Modal";
import { useEffect, useState } from "react";
import { toast } from "react-toastify";
import { getViewApplyJobService } from "../../../services/JobService";
import { style } from "../modal.style";

const ViewApplyModal = (props) => {
  const [isLoading, setIsLoading] = useState(false);
  const [data, setData] = useState(null);

  useEffect(() => {
    setIsLoading(true);
    getViewApplyJobService(props.jobId, props.userId || null)
      .then((rs) => {
        setIsLoading(false);
        setData(rs.data);
      })
      .catch((err) => {
        setIsLoading(false);
        toast.error(err.message);
      });
  }, []);

  return (
    <Modal
      aria-labelledby="transition-modal-title"
      aria-describedby="transition-modal-description"
      open={props.open}
      onClose={props.onClose}
      closeAfterTransition
      BackdropComponent={Backdrop}
      BackdropProps={{
        timeout: 500,
      }}
    >
      <Fade in={props.open}>
        <div>
          <Box sx={style(900)}>
            {isLoading ? (
              <Box
                sx={{
                  display: "flex",
                  height: "100%",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <CircularProgress />
              </Box>
            ) : (
              <>
                <Typography
                  sx={{ display: "block", textAlign: "center" }}
                  variant="h4"
                >
                  Đơn ứng tuyển
                </Typography>
                <Typography variant="body1">Email: {data?.email}</Typography>
                <Typography variant="body1">
                  Điện thoại: {data?.phone}
                </Typography>
                <Box sx={{ height: 390, mx: "auto" }}>
                  <object
                    data={data?.CV}
                    type="application/pdf"
                    width="100%"
                    height="100%"
                  >
                    <p>
                      Alternative text - include a link{" "}
                      <a href={data?.CV}>to the PDF!</a>
                    </p>
                  </object>
                </Box>
              </>
            )}
          </Box>
        </div>
      </Fade>
    </Modal>
  );
};

export default ViewApplyModal;
