import { Box, Button, CircularProgress, Typography } from "@mui/material";
import Backdrop from "@mui/material/Backdrop";
import Fade from "@mui/material/Fade";
import Modal from "@mui/material/Modal";
import { useForm } from "react-hook-form";
import { useDeleteApplicantMutation } from "../../../hooks/useJobs";
import { MyReactQuill } from "../../core-form";
import { style, styleIsLoading } from "../modal.style";

const defaultValues = {
  desc: "",
};

const DeleteApplyModal = (props) => {
  const { mutate, status } = useDeleteApplicantMutation();

  const {
    handleSubmit,
    formState: { errors, isSubmitting },
    reset,
    setValue,
    control,
  } = useForm({
    defaultValues,
    mode: "onChange",
  });

  const onSubmit = async (data) => {
    mutate({
      ownerId: props.job.owner._id || props.job.owner,
      page: props.page,
      applicantId: props.user._id,
      jobId: props.job._id,
      onClose: props.onClose,
      desc: data.desc,
    });
  };

  const checkKeyDown = (e) => {
    if (e.code === "Enter") e.preventDefault();
  };

  return (
    <Modal
      aria-labelledby="transition-modal-title"
      aria-describedby="transition-modal-description"
      open={props.open}
      onClose={props.onClose}
      closeAfterTransition
      BackdropComponent={Backdrop}
      BackdropProps={{
        timeout: 500,
      }}
    >
      <Fade in={props.open}>
        <div>
          {status === "loading" ? (
            <Box sx={styleIsLoading}>
              <CircularProgress />
            </Box>
          ) : (
            <Box sx={style(600)}>
              <Typography
                sx={{ display: "block", textAlign: "center" }}
                variant="h4"
              >
                Từ chối yêu cầu của {props.user.name}
              </Typography>
              <form
                onSubmit={handleSubmit(onSubmit)}
                onKeyDown={(e) => checkKeyDown(e)}
              >
                <MyReactQuill
                  control={control}
                  name="desc"
                  label="Nội dung"
                  errors={errors}
                />

                <Box
                  sx={{
                    display: "flex",
                    justifyContent: "space-around",
                    alignItems: "center",
                  }}
                >
                  <Button
                    onClick={props.onClose}
                    variant="outlined"
                    color="success"
                    sx={{ width: "30%" }}
                  >
                    Trở về
                  </Button>
                  <Button
                    type="submit"
                    variant="contained"
                    color="success"
                    sx={{ width: "30%" }}
                  >
                    Gửi lời từ chối
                  </Button>
                </Box>
              </form>
            </Box>
          )}
        </div>
      </Fade>
    </Modal>
  );
};

export default DeleteApplyModal;
