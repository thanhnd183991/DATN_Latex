import ArrowBackIosNewIcon from "@mui/icons-material/ArrowBackIosNew";
import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";
import {
  Box,
  CircularProgress,
  IconButton,
  Typography,
  Button,
} from "@mui/material";
import { useState } from "react";
import { useListJobByHR } from "../../../hooks/useJobs";
import LayoutModal from "../../layout/LayoutModal";
import ItemJob from "../../item/ItemJob";
import { style } from "../modal.style";
import { useMemberCompanyMutation } from "../../../hooks/useCompanies";
import { toast } from "react-toastify";

const ListJobByHRModal = (props) => {
  const [page, setPage] = useState(1);
  const { status, data, error, isFetching, isPreviousData } = useListJobByHR(
    page,
    4,
    props.HRId
  );
  const { mutate, status: statusDelete } = useMemberCompanyMutation();

  const handleDeleteMember = () => {
    mutate({
      companyId: props.companyId,
      action: "delete",
      employees: [props.HRId],
      onClose: () => {
        toast.success("Xóa thành công");
        props.onClose();
      },
    });
  };

  return (
    <LayoutModal open={props.open} onClose={props.onClose}>
      <Box sx={style(800)}>
        {status === "loading" ? (
          <div>Loading...</div>
        ) : status === "error" ? (
          <div>Error: {error.message}</div>
        ) : (
          // `data` will either resolve to the latest page's data
          // or if fetching a new page, the last successful page's data
          <div>
            <Typography variant="h6">
              {data.data.length === 0
                ? "Xác nhận xóa nhân viên"
                : "Giao việc nhân viên"}
            </Typography>
            {data.data.length === 0 ? (
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                }}
              >
                <Button
                  sx={{ mt: 8 }}
                  variant="contained"
                  color="success"
                  onClick={handleDeleteMember}
                  disabled={status !== "success"}
                >
                  Xóa nhân viên
                </Button>
              </Box>
            ) : (
              <>
                {data.data.map((job) => (
                  <ItemJob key={job._id} job={job} page={page} />
                ))}
                <Box
                  sx={{
                    display: "flex",
                    justifyContent: "center",
                    gap: 2,
                  }}
                >
                  <IconButton
                    onClick={() => setPage((old) => Math.max(old - 1, 1))}
                    disabled={page === 1}
                  >
                    <ArrowBackIosNewIcon />
                  </IconButton>
                  <IconButton
                    onClick={() => {
                      if (data?.numberOfPages) {
                        setPage((old) =>
                          data?.numberOfPages > old ? old + 1 : old
                        );
                      } else {
                        setPage((old) => (data?.hasMore ? old + 1 : old));
                      }
                    }}
                    disabled={
                      isPreviousData || data?.numberOfPages
                        ? data?.numberOfPages <= page
                        : !data?.hasMore
                    }
                  >
                    <ArrowForwardIosIcon />
                  </IconButton>
                </Box>
              </>
            )}
          </div>
        )}

        {
          // Since the last page's data potentially sticks around between page requests,
          // we can use `isFetching` to show a background loading
          // indicator since our `status === 'loading'` state won't be triggered
          isFetching ? (
            <Box sx={{ display: "flex" }}>
              <CircularProgress />
            </Box>
          ) : null
        }
      </Box>
    </LayoutModal>
  );
};

export default ListJobByHRModal;
