import { yupResolver } from "@hookform/resolvers/yup";
import { Box, Button, CircularProgress, Typography } from "@mui/material";
import Backdrop from "@mui/material/Backdrop";
import Fade from "@mui/material/Fade";
import Modal from "@mui/material/Modal";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { toast } from "react-toastify";
import { useAuth } from "../../../hooks/useAuth";
import { useApplyJobMutation } from "../../../hooks/useJobs";
import { uploadFile } from "../../../services/UploadService";
import { formUpdateApplicantJobSchema } from "../../../validations/JobValidation";
import { DropZoneField, MyTextField } from "../../core-form";
import { style, styleIsLoading } from "../modal.style";

const defaultValues = {
  email: "",
  phone: 0,
  CV: [],
};

const CreateApplyModal = (props) => {
  const { user: me } = useAuth();
  const { mutate, isLoading } = useApplyJobMutation();
  const {
    handleSubmit,
    formState: { errors },
    reset,
    setValue,
    control,
  } = useForm({
    defaultValues,
    resolver: yupResolver(formUpdateApplicantJobSchema),
    mode: "onChange",
  });
  const [isUploading, setIsUploading] = useState(false);

  const onSubmit = async (data) => {
    if (data.CV.length > 0) {
      setIsUploading(true);
      const result = await uploadFile(data.CV[0]);
      mutate({
        CV: result.secure_url,
        email: data.email,
        phone: data.phone,
        jobId: props.jobId,
        isSave: props.isSave,
        onClose: () => {
          setIsUploading(false);
          props.onClose();
        },
        meId: me._id,
      });
    } else {
      // mutate({
      //   CV: "https://www.orimi.com/pdf-test.pdf",
      //   email: data.email,
      //   phone: data.phone,
      //   jobId: props.jobId,
      //   isSave: props.isSave,
      //   onClose: props.onClose,
      //   meId: me._id,
      // });
      toast.error("Vui lòng chọn CV");
    }
  };

  const checkKeyDown = (e) => {
    if (e.code === "Enter") e.preventDefault();
  };

  return (
    <Modal
      aria-labelledby="transition-modal-title"
      aria-describedby="transition-modal-description"
      open={props.open}
      onClose={props.onClose}
      closeAfterTransition
      BackdropComponent={Backdrop}
      BackdropProps={{
        timeout: 500,
      }}
    >
      <Fade in={props.open}>
        <div>
          {isLoading || isUploading ? (
            <Box sx={styleIsLoading}>
              <CircularProgress />
            </Box>
          ) : (
            <Box sx={style(600)}>
              <Typography
                sx={{ display: "block", textAlign: "center" }}
                variant="h4"
              >
                Nộp ứng tuyển
              </Typography>
              <form
                onSubmit={handleSubmit(onSubmit)}
                onKeyDown={(e) => checkKeyDown(e)}
              >
                <MyTextField
                  control={control}
                  name="email"
                  label="Email"
                  type="email"
                  errors={errors}
                />
                <MyTextField
                  control={control}
                  name="phone"
                  label="Số điện thoại"
                  type="number"
                  errors={errors}
                />
                <DropZoneField
                  control={control}
                  name="CV"
                  component={<p>Chọn CV đính kèm</p>}
                  maxFiles={1}
                />
                <Box
                  sx={{
                    display: "flex",
                    justifyContent: "space-around",
                    alignItems: "center",
                  }}
                >
                  <Button
                    onClick={props.onClose}
                    variant="outlined"
                    color="success"
                    sx={{ width: "30%" }}
                  >
                    Trở về
                  </Button>
                  <Button
                    type="submit"
                    variant="contained"
                    color="success"
                    sx={{ width: "30%" }}
                  >
                    Nộp
                  </Button>
                </Box>
              </form>
            </Box>
          )}
        </div>
      </Fade>
    </Modal>
  );
};

export default CreateApplyModal;
