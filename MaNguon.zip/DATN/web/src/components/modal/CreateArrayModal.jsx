import { Box, Button, CircularProgress, Typography } from "@mui/material";
import Backdrop from "@mui/material/Backdrop";
import Fade from "@mui/material/Fade";
import Modal from "@mui/material/Modal";
import { useForm } from "react-hook-form";
import { useUpdateArrayMutation } from "../../hooks/useUsers";
import { MyFieldArray } from "../core-form";
import { style, styleIsLoading } from "./modal.style";

const defaultValuesFn = (payload) => ({
  data: payload,
});

const CreateArrayModal = (props) => {
  let payload = props.data;
  const { mutate, status } = useUpdateArrayMutation();
  // console.log("props", props);
  if (props.type === "educations" || props.type === "experiences") {
    payload = payload.map((element) => {
      const { name, school, ...info } = element;

      // console.log(info);

      info.start_date = info.start_date.split("/").reverse().join("-");
      info.end_date = info.end_date.split("/").reverse().join("-");

      return {
        name: name || school,
        nestedArray: [info],
      };
    });
  } else if (props.type === "skills" || props.type === "languages") {
    payload = payload.map((element) => {
      return {
        name: element,
      };
    });
  }
  const {
    control,
    register,
    handleSubmit,
    getValues,
    errors,
    reset,
    setValue,
  } = useForm({ defaultValues: defaultValuesFn(payload) });

  const onSubmit = (data) => {
    let filterData = {};
    if (props.type === "educations" || props.type === "experiences") {
      filterData = data.data.map((el) => {
        const { name, nestedArray } = el;
        const arrayStartDate = nestedArray[0]?.start_date?.split("-");
        let start_date, end_date;
        if (arrayStartDate) {
          start_date = `${arrayStartDate[1]}/${arrayStartDate[0]}`;
        }
        const arrayEndDate = nestedArray[0]?.end_date?.split("-");
        if (arrayEndDate) {
          end_date = `${arrayEndDate[1]}/${arrayEndDate[0]}`;
        }

        let obj = {
          school: name,
          ...nestedArray[0],
          start_date,
          end_date,
        };

        if (props.type === "experiences") {
          obj = {
            name,
            ...nestedArray[0],
            start_date,
            end_date,
          };
        }

        return obj;
      });
      // console.log(filterData);
    } else if (props.type === "skills" || props.type === "languages") {
      filterData = data.data.map((el) => {
        return el.name;
      });
    }
    // return;
    return mutate({
      userId: props.userId,
      data: filterData,
      type: props.type,
      onClose: props.onClose,
    });
  };

  const checkKeyDown = (e) => {
    if (e.code === "Enter") e.preventDefault();
  };

  return (
    <Modal
      // ref={ref}
      aria-labelledby="transition-modal-title"
      aria-describedby="transition-modal-description"
      open={props.open}
      onClose={props.onClose}
      closeAfterTransition
      BackdropComponent={Backdrop}
      BackdropProps={{
        timeout: 500,
      }}
    >
      <Fade in={props.open}>
        <div>
          {status === "loading" ? (
            <Box sx={styleIsLoading}>
              <CircularProgress />
            </Box>
          ) : status === "error" ? (
            <div>Error</div>
          ) : (
            <Box
              sx={style(600)}
              // ref={ref}
            >
              <Box
                sx={{
                  p: 1,
                  justifyContent: "space-between",
                  alignItems: "center",
                }}
              >
                <Typography variant="h5">{props.label}</Typography>
                <form
                  onSubmit={handleSubmit(onSubmit)}
                  onKeyDown={(e) => checkKeyDown(e)}
                >
                  <MyFieldArray
                    {...{
                      control,
                      register,
                      defaultValues: defaultValuesFn(payload),
                      getValues,
                      setValue,
                      errors,
                      type: props.type,
                    }}
                  />
                  <Box
                    sx={{
                      display: "flex",
                      justifyContent: "space-around",
                      alignItems: "center",
                    }}
                  >
                    <Button
                      onClick={props.onClose}
                      variant="outlined"
                      color="success"
                      sx={{ width: "30%" }}
                    >
                      Trở về
                    </Button>
                    <Button
                      type="submit"
                      variant="contained"
                      color="success"
                      sx={{ width: "30%" }}
                    >
                      Nộp
                    </Button>
                  </Box>
                </form>
              </Box>
            </Box>
          )}
        </div>
      </Fade>
    </Modal>
  );
};

export default CreateArrayModal;
