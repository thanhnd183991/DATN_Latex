import { yupResolver } from "@hookform/resolvers/yup";
import { Box, Button, CircularProgress, Typography } from "@mui/material";
import Backdrop from "@mui/material/Backdrop";
import Fade from "@mui/material/Fade";
import Modal from "@mui/material/Modal";
import { useForm } from "react-hook-form";
import { toast } from "react-toastify";
import {
  CREATE_REPORT_JOB,
  CREATE_REPORT_POST,
} from "../../constants/NotifyConstant";
import { useCreatePostMutation } from "../../hooks/post/usePosts";
import { useAuth } from "../../hooks/useAuth";
import { getSocket } from "../../socket";
import {
  formCreatePostSchema,
  formReportSchema,
} from "../../validations/PostValidation";
import { MyReactQuill, MySelectField, MyTextField } from "../core-form";
import MyRadioButtonField from "../core-form/MyRadioButtonField";
import { style, styleIsLoading } from "./modal.style";

const defaultValues = {
  access: "",
  onAccess: "",
  message: "",
  desc: "",
};

const ReportModal = ({ access, onAccess, open, onClose }) => {
  const {
    handleSubmit,
    formState: { errors, isSubmitting, isValid },
    reset,
    setValue,
    control,
  } = useForm({
    defaultValues: { ...defaultValues, access, onAccess },
    resolver: yupResolver(formReportSchema),
    mode: "onChange",
  });

  // console.log(errors);

  const onSubmit = (data) => {
    return getSocket().emit(
      onAccess === "Post" ? CREATE_REPORT_POST : CREATE_REPORT_JOB,
      {
        ...data,
        message:
          onAccess === "Post"
            ? `Báo cáo bài viết: <strong>${data.message}</strong>`
            : `Báo cáo tin tuyển dụng: <strong>${data.message}</strong>`,
      },
      (data) => {
        if (data.error) {
          toast.error(data.error);
        } else if (data.success) {
          toast.success(data.success);
        }
        onClose();
      }
    );
  };

  const checkKeyDown = (e) => {
    if (e.code === "Enter") e.preventDefault();
  };

  return (
    <Modal
      // ref={ref}
      aria-labelledby="transition-modal-title"
      aria-describedby="transition-modal-description"
      open={open}
      onClose={onClose}
      closeAfterTransition
      BackdropComponent={Backdrop}
      BackdropProps={{
        timeout: 500,
      }}
    >
      <Fade in={open}>
        <div>
          {isSubmitting ? (
            <Box sx={styleIsLoading}>
              <CircularProgress />
            </Box>
          ) : (
            <Box sx={style(600)}>
              <Box
                sx={{
                  p: 1,
                  justifyContent: "space-between",
                  alignItems: "center",
                }}
              >
                <form
                  onSubmit={handleSubmit(onSubmit)}
                  onKeyDown={(e) => checkKeyDown(e)}
                >
                  <Typography variant="h5">
                    {onAccess === "Post"
                      ? "Báo cáo bài đăng"
                      : "Báo cáo tin tuyển dụng"}
                  </Typography>

                  <MyRadioButtonField
                    control={control}
                    name="message"
                    label="Nội dung báo cáo"
                    errors={errors}
                    values={[
                      "chứa thông tin nhạy cảm",
                      "không phù hợp",
                      "tin rác (thiếu thông tin)",
                    ]}
                    labels={[
                      "Chứa thông tin nhạy cảm",
                      "Không phù hợp",
                      "Tin rác (thiếu thông tin)",
                    ]}
                  />

                  <Box
                    sx={{
                      display: "flex",
                      justifyContent: "space-around",
                      alignItems: "center",
                    }}
                  >
                    <Button
                      onClick={onClose}
                      variant="outlined"
                      color="success"
                      sx={{ width: "30%" }}
                    >
                      Trở về
                    </Button>
                    <Button
                      type="submit"
                      variant="contained"
                      color="success"
                      disabled={!isValid || isSubmitting}
                      sx={{ width: "30%" }}
                    >
                      Nộp
                    </Button>
                  </Box>
                </form>
              </Box>
            </Box>
          )}
        </div>
      </Fade>
    </Modal>
  );
};

export default ReportModal;
