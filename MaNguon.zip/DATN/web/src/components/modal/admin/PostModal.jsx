import { Box } from "@mui/material";
import { usePost } from "../../../hooks/post/usePosts";
import LayoutModal from "../../layout/LayoutModal";
import { style } from "../modal.style";
import Post from "../../post/Post";

const PostModal = (props) => {
  const { post, status } = usePost(props.postId);
  return (
    <LayoutModal open={props.open} onClose={props.onClose}>
      <Box sx={style(800)}>
        {status === "loading" ? (
          <p>loading ...</p>
        ) : status === "error" ? (
          <p>error ...</p>
        ) : (
          <Post post={post} />
        )}
      </Box>
    </LayoutModal>
  );
};

export default PostModal;
