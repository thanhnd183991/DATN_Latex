import { Box } from "@mui/material";
import { useUser } from "../../../hooks/useUsers";
import LayoutModal from "../../layout/LayoutModal";
import Profile from "../../profile/Profile";
import { style } from "../modal.style";

const UserModal = (props) => {
  const { isLoading, data: user, error } = useUser(props.userId);
  return (
    <LayoutModal open={props.open} onClose={props.onClose}>
      <Box sx={style(800)}>
        {error ? (
          <pre>{JSON.stringify(error)}</pre>
        ) : (
          <Profile user={user} isLoading={isLoading} />
        )}
      </Box>
    </LayoutModal>
  );
};

export default UserModal;
