import { Box, useMediaQuery } from "@mui/material";
import { MD_RESPONSIVE_WIDTH } from "../../../constants/Responsive";
import { useJob } from "../../../hooks/useJobs";
import DescJob from "../../job/detail/DescJob";
import LayoutModal from "../../layout/LayoutModal";
import { style } from "../modal.style";

const JobModal = (props) => {
  const MD_RESPONSIVE = useMediaQuery(MD_RESPONSIVE_WIDTH);
  const { job, status } = useJob(props.jobId);
  return (
    <LayoutModal open={props.open} onClose={props.onClose}>
      <Box sx={style(MD_RESPONSIVE ? 800 : 600)}>
        {status === "loading" ? (
          <p>loading ...</p>
        ) : status === "error" ? (
          <p>error ...</p>
        ) : (
          <DescJob job={job} />
        )}
      </Box>
    </LayoutModal>
  );
};

export default JobModal;
