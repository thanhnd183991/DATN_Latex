import { Box } from "@mui/material";
import Company from "../../company/Company";
import LayoutModal from "../../layout/LayoutModal";
import { style } from "../modal.style";

const CompanyModal = (props) => {
  return (
    <LayoutModal open={props.open} onClose={props.onClose}>
      <Box sx={style(800)}>
        <Company companyId={props.companyId} />
      </Box>
    </LayoutModal>
  );
};

export default CompanyModal;
