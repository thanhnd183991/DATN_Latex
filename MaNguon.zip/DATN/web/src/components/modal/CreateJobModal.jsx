import { yupResolver } from "@hookform/resolvers/yup";
import {
  Box,
  Button,
  CircularProgress,
  Typography,
  useMediaQuery,
} from "@mui/material";
import Backdrop from "@mui/material/Backdrop";
import Fade from "@mui/material/Fade";
import Modal from "@mui/material/Modal";
import { useForm } from "react-hook-form";
import { MD_RESPONSIVE_WIDTH } from "../../constants/Responsive";
import { useAuth } from "../../hooks/useAuth";
import { useCompany } from "../../hooks/useCompanies";
import { useCreateJobMutation } from "../../hooks/useJobs";
import { formCreateJobSchema } from "../../validations/JobValidation";
import {
  MyReactQuill,
  MySelectField,
  MyTextField,
  MyTextFieldChip,
} from "../core-form";
import { style, styleIsLoading } from "./modal.style";

const defaultValues = {
  title: "abcdef",
  job_type: "fulltime",
  numbers: 12,
  requirements:
    "Solid software development background (school, university, work exp…)",
  responsibilities:
    "Research, design, develop, and test blockchain technologies.",
  location: "Cầu Giấy, Hanoi, Vietnam ",
  experience:
    "Knowledge of Cryptocurrency is a plus Knowledge of Decentralized Finance is a plus",
  salary: 120000,
  deadline: "2022-07-03",
  categories: "",
  rank: "",
  other: "100% salary offer in 2-months of probation period 13th month salary",
};

const CreateJobModal = (props) => {
  const { user: me } = useAuth();
  const MD_RESPONSIVE = useMediaQuery(MD_RESPONSIVE_WIDTH);
  const { mutate, status } = useCreateJobMutation();
  const { data: company, status: statusCompany } = useCompany(me.company);

  const {
    handleSubmit,
    reset,
    setValue,
    control,
    setError,
    formState: { errors },
  } = useForm({
    defaultValues,
    resolver: yupResolver(formCreateJobSchema),
    mode: "onChange",
  });

  const onSubmit = (data) => {
    data.categories = data.categories.split(",");
    const payload = {
      job: data,
      setError,
      onClose: () => {
        reset();
        props.onClose();
      },
    };
    mutate(payload);
  };

  const checkKeyDown = (e) => {
    if (e.code === "Enter") e.preventDefault();
  };

  return (
    <Modal
      // ref={ref}
      aria-labelledby="transition-modal-title"
      aria-describedby="transition-modal-description"
      open={props.open}
      onClose={props.onClose}
      closeAfterTransition
      BackdropComponent={Backdrop}
      BackdropProps={{
        timeout: 500,
      }}
    >
      <Fade in={props.open}>
        <div>
          {status === "loading" || statusCompany === "loading" ? (
            <Box sx={styleIsLoading}>
              <CircularProgress />
            </Box>
          ) : (
            <Box sx={style(MD_RESPONSIVE ? 800 : 600)}>
              <Typography
                sx={{ display: "block", textAlign: "center" }}
                variant="h4"
              >
                {company.name}
              </Typography>
              <Typography sx={{ fontWeight: "bold" }} variant="h5">
                Tin tuyển dụng
              </Typography>
              <form
                onSubmit={handleSubmit(onSubmit)}
                onKeyDown={(e) => checkKeyDown(e)}
              >
                <MyTextField
                  errors={errors}
                  control={control}
                  name="title"
                  label="Tiêu đề"
                />
                <MySelectField
                  errors={errors}
                  control={control}
                  name="job_type"
                  label="Loại"
                  values={["fulltime", "parttime", "freelance"]}
                  labels={["Fulltime", "Parttime", "Freelance"]}
                />
                <MyTextField
                  errors={errors}
                  control={control}
                  name="numbers"
                  label="Số lượng tuyển"
                  type="number"
                />
                <MyReactQuill
                  errors={errors}
                  control={control}
                  name="requirements"
                  label="Yêu cầu"
                />
                <MyReactQuill
                  errors={errors}
                  control={control}
                  name="responsibilities"
                  label="Nhiệm vụ"
                />
                <MyTextField
                  errors={errors}
                  control={control}
                  name="location"
                  label="Địa điểm làm việc"
                />
                <MyReactQuill
                  errors={errors}
                  control={control}
                  name="experience"
                  label="Kinh nhiệm làm việc"
                />
                <MyTextField
                  errors={errors}
                  control={control}
                  name="rank"
                  label="Chức vụ"
                />
                <MyTextField
                  errors={errors}
                  control={control}
                  name="salary"
                  label="Lương"
                />
                <MyTextFieldChip
                  errors={errors}
                  control={control}
                  name="categories"
                  label="Kỹ năng"
                />
                <MyTextField
                  errors={errors}
                  control={control}
                  name="deadline"
                  label="Hạn nộp hồ sơ"
                  type="date"
                />
                <MyReactQuill
                  errors={errors}
                  control={control}
                  name="other"
                  label="Thông tin khác"
                />
                <Box
                  sx={{
                    display: "flex",
                    justifyContent: "space-around",
                    alignItems: "center",
                  }}
                >
                  <Button
                    onClick={props.onClose}
                    variant="outlined"
                    color="success"
                    sx={{ width: "30%" }}
                  >
                    Trở về
                  </Button>
                  <Button
                    type="submit"
                    variant="contained"
                    color="success"
                    sx={{ width: "30%" }}
                  >
                    Nộp
                  </Button>
                </Box>
              </form>
            </Box>
          )}
        </div>
      </Fade>
    </Modal>
  );
};

export default CreateJobModal;
