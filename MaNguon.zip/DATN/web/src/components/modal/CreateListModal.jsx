import {
  Box,
  Button,
  Skeleton,
  Stack,
  TextField,
  Typography,
} from "@mui/material";
import Backdrop from "@mui/material/Backdrop";
import Fade from "@mui/material/Fade";
import Modal from "@mui/material/Modal";
import { Fragment } from "react";
import { useListUser } from "../../hooks/useUsers";
import ItemCompany from "../item/ItemCompany";
import ItemUser from "../item/ItemUser";
import { style } from "./modal.style";

const defaultValues = {
  text: "",
  type: "",
  files: [],
};

const CreateListModal = (props) => {
  const {
    status,
    data,
    error,
    isFetching,
    isFetchingNextPage,
    isFetchingPreviousPage,
    fetchNextPage,
    fetchPreviousPage,
    hasNextPage,
    hasPreviousPage,
    refInView,
    value,
    handleChangeValue,
  } = useListUser({
    type: props.type,
    id: props.id,
    companyId: props.companyId,
    action: props.action,
  });

  return (
    <Modal
      // ref={ref}
      aria-labelledby="transition-modal-title"
      aria-describedby="transition-modal-description"
      open={props.open}
      onClose={props.onClose}
      closeAfterTransition
      BackdropComponent={Backdrop}
      BackdropProps={{
        timeout: 500,
      }}
    >
      <Fade in={props.open}>
        <div>
          <Box sx={style(600)}>
            <Box
              sx={{
                p: 1,
                justifyContent: "space-between",
                alignItems: "center",
              }}
            >
              <Typography variant="h5" sx={{ mt: -1 }}>
                {props.label}
              </Typography>

              <div>
                <TextField
                  variant="standard"
                  fullWidth
                  placeholder="Tìm kiếm..."
                  value={value}
                  onChange={(e) => handleChangeValue(e)}
                />
                {status === "loading" ? (
                  <Stack spacing={1}>
                    <Skeleton variant="text" height={200} />
                  </Stack>
                ) : status === "error" ? (
                  <span>Error: {error.message}</span>
                ) : (
                  <>
                    {data.pages.map((page) => (
                      <Fragment key={page.nextId}>
                        {page.data.map((data) =>
                          props.type !== "followingCompany" ? (
                            <Box
                              sx={{
                                border: "1px solid",
                                borderColor: "text.secondary",
                                borderRadius: "10px",
                                my: 1,
                              }}
                              key={data._id}
                            >
                              <ItemUser
                                user={data}
                                isAddMember={props.action === "add"}
                                companyId={props.companyIdToAdd}
                                me={props.me}
                              />
                            </Box>
                          ) : (
                            <Box
                              sx={{
                                border: "1px solid",
                                borderColor: "text.secondary",
                                borderRadius: "10px",
                                my: 1,
                              }}
                              key={data._id}
                            >
                              <ItemCompany company={data} />
                            </Box>
                          )
                        )}
                      </Fragment>
                    ))}
                    <div>
                      <Button
                        ref={refInView}
                        variant="text"
                        onClick={() => fetchNextPage()}
                        disabled={!hasNextPage || isFetchingNextPage}
                      >
                        {isFetchingNextPage
                          ? "Loading more..."
                          : hasNextPage
                          ? "Load Newer"
                          : "Nothing more to load"}
                      </Button>
                    </div>
                    <div>
                      {isFetching && !isFetchingNextPage
                        ? "Background Updating..."
                        : null}
                    </div>
                  </>
                )}
              </div>
            </Box>
          </Box>
        </div>
      </Fade>
    </Modal>
  );
};

export default CreateListModal;
