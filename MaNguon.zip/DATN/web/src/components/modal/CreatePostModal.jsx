import { yupResolver } from "@hookform/resolvers/yup";
import { Box, Button, CircularProgress, Typography } from "@mui/material";
import Backdrop from "@mui/material/Backdrop";
import Fade from "@mui/material/Fade";
import Modal from "@mui/material/Modal";
import { useForm } from "react-hook-form";
import { toast } from "react-toastify";
import { useCreatePostMutation } from "../../hooks/post/usePosts";
import { useAuth } from "../../hooks/useAuth";
import { uploadFiles } from "../../services/UploadService";
import { formCreatePostSchema } from "../../validations/PostValidation";
import { MyReactQuill, MySelectField } from "../core-form";
import DropZoneField from "../core-form/drop_zone/DropZoneField";
import { style, styleIsLoading } from "./modal.style";

const defaultValues = {
  content: "",
  type: "",
  files: [],
};

const CreatePostModal = (props) => {
  const { user } = useAuth();
  const { isLoading, isSuccess, mutate } = useCreatePostMutation();
  const {
    handleSubmit,
    formState: { errors, isSubmitting },
    reset,
    setValue,
    control,
  } = useForm({
    defaultValues,
    resolver: yupResolver(formCreatePostSchema),
    mode: "onChange",
  });

  const onSubmit = async (data) => {
    console.log(data);
    if (data.files.length > 0) {
      // setIsUploading(true);
      return uploadFiles(data.files)
        .then((rs) => {
          const payload = {
            content: data.content,
            type: data.type,
            files: rs.map((el) => ({
              file: el.secure_url,
              original_filename:
                el.original_filename + "." + el.public_id?.split(".")[1] ||
                el.format,
              resource_type: el.resource_type,
            })),
            onClose: props.onClose,
          };
          mutate(payload);
        })
        .catch((err) => {
          toast.error(err.message);
          // setIsUploading(false);
        });
    } else {
      const payload = {
        content: data.content,
        type: data.type,
        onClose: props.onClose,
      };
      return mutate(payload);
    }
  };

  const checkKeyDown = (e) => {
    if (e.code === "Enter") e.preventDefault();
  };

  return (
    <Modal
      // ref={ref}
      aria-labelledby="transition-modal-title"
      aria-describedby="transition-modal-description"
      open={props.open}
      onClose={props.onClose}
      closeAfterTransition
      BackdropComponent={Backdrop}
      BackdropProps={{
        timeout: 500,
      }}
    >
      <Fade in={props.open}>
        <div>
          {isSubmitting || isLoading ? (
            <Box sx={styleIsLoading}>
              <CircularProgress />
            </Box>
          ) : (
            <Box sx={style(600)}>
              <Box
                sx={{
                  p: 1,
                  justifyContent: "space-between",
                  alignItems: "center",
                }}
              >
                <Typography variant="h5">Tạo bài đăng</Typography>
                <form
                  onSubmit={handleSubmit(onSubmit)}
                  onKeyDown={(e) => checkKeyDown(e)}
                >
                  {user.role !== "employee" && (
                    <MySelectField
                      control={control}
                      name="type"
                      label="Loại"
                      values={["Personal", "Company"]}
                      labels={["Cá nhân", "Công ty"]}
                    />
                  )}

                  <MyReactQuill
                    control={control}
                    name="content"
                    label="Nội dung"
                    errors={errors}
                  />

                  <DropZoneField
                    control={control}
                    name="files"
                    component={<p>Chọn file đính kèm</p>}
                    // accept={{ "image/*": [], "video/*": [] }}
                  />

                  <Box
                    sx={{
                      display: "flex",
                      justifyContent: "space-around",
                      alignItems: "center",
                    }}
                  >
                    <Button
                      onClick={props.onClose}
                      variant="outlined"
                      color="success"
                      sx={{ width: "30%" }}
                    >
                      Trở về
                    </Button>
                    <Button
                      type="submit"
                      variant="contained"
                      color="success"
                      sx={{ width: "30%" }}
                    >
                      Nộp
                    </Button>
                  </Box>
                </form>
              </Box>
            </Box>
          )}
        </div>
      </Fade>
    </Modal>
  );
};

export default CreatePostModal;
