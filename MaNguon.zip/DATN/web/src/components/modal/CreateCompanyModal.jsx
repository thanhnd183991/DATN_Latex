import { yupResolver } from "@hookform/resolvers/yup";
import { Box, Button, CircularProgress, Typography } from "@mui/material";
import Backdrop from "@mui/material/Backdrop";
import Fade from "@mui/material/Fade";
import Modal from "@mui/material/Modal";
import { useForm } from "react-hook-form";
import { toast } from "react-toastify";
import { useCreateCompanyMutation } from "../../hooks/useCompanies";
import { uploadFile } from "../../services/UploadService";
import { formCreateCompanySchema } from "../../validations/CompanyValidation";
import { MyReactQuill, MyTextField } from "../core-form";
import DropZoneField from "../core-form/drop_zone/DropZoneField";
import MyTextFieldSuggestion from "../core-form/MyTextFieldSuggestion";
import { style, styleIsLoading } from "./modal.style";

const defaultValues = {
  name: "Công ty phát triển phần mềm IT",
  website: "https://react-hook-form.com/",
  industry: "",
  headquarters: "Hai Bà Trưng, Hà Nội",
  overview:
    "We have developed proprietary tools and strategies that have enabled us to lower cost and increase the quality of service to our client base, especially to state agencies, municipalities and school districts, where cost is a deciding factor in everyday decision making.",
  avatar: [],
};

const CreateCompanyModal = (props) => {
  const {
    mutate: createCompanyMutate,
    status,
    reset: resetMutate,
  } = useCreateCompanyMutation();

  const {
    handleSubmit,
    formState: { errors, isSubmitting, isValid },
    reset,
    setValue,
    control,
  } = useForm({
    defaultValues,
    resolver: yupResolver(formCreateCompanySchema),
    mode: "onChange",
  });

  // console.log(errors, isValid);

  const handleClose = () => {
    reset();
    resetMutate();
    props.onClose();
  };

  const onSubmit = (data) => {
    // console.log(data);
    if (data.avatar.length === 0) {
      return toast.error("Please upload an avatar");
    } else {
      return uploadFile(data.avatar[0])
        .then((rs) => {
          createCompanyMutate({
            body: {
              ...data,
              avatar: rs.data.result.secure_url,
            },
            onClose: handleClose,
          });
        })
        .catch((err) => {
          console.log(err);
          toast.error(err.messsage);
        });
    }
  };

  const checkKeyDown = (e) => {
    if (e.code === "Enter") e.preventDefault();
  };

  return (
    <Modal
      aria-labelledby="transition-modal-title"
      aria-describedby="transition-modal-description"
      open={props.open}
      onClose={handleClose}
      closeAfterTransition
      BackdropComponent={Backdrop}
      BackdropProps={{
        timeout: 500,
      }}
    >
      <Fade in={props.open}>
        <div>
          {isSubmitting || status === "loading" ? (
            <Box sx={styleIsLoading}>
              <CircularProgress />
            </Box>
          ) : status === "error" ? (
            <p>Error</p>
          ) : (
            <Box sx={style(600)}>
              <Box
                sx={{
                  p: 1,
                  justifyContent: "space-between",
                  alignItems: "center",
                }}
              >
                <Typography variant="h5">Tạo công ty</Typography>
                <form
                  onSubmit={handleSubmit(onSubmit)}
                  onKeyDown={(e) => checkKeyDown(e)}
                >
                  <MyTextField
                    control={control}
                    name="name"
                    label="Tên công ty"
                    errors={errors}
                  />
                  <MyTextField
                    errors={errors}
                    control={control}
                    name="website"
                    label="Website"
                  />
                  <MyTextFieldSuggestion
                    model="category"
                    control={control}
                    name="industry"
                    label="Lĩnh vực"
                    errors={errors}
                  />
                  <MyTextField
                    control={control}
                    name="headquarters"
                    label="Trụ sở"
                    errors={errors}
                  />

                  <MyReactQuill
                    control={control}
                    name="overview"
                    label="Tổng quan"
                    errors={errors}
                  />

                  <DropZoneField
                    maxFiles={1}
                    control={control}
                    name="avatar"
                    component={<p>Chọn avatar công ty</p>}
                    accept={{ "image/*": [] }}
                  />

                  <Box
                    sx={{
                      display: "flex",
                      justifyContent: "space-around",
                      alignItems: "center",
                    }}
                  >
                    <Button
                      onClick={props.onClose}
                      variant="outlined"
                      color="success"
                      sx={{ width: "30%" }}
                    >
                      Trở về
                    </Button>
                    <Button
                      type="submit"
                      disabled={!isValid}
                      variant="contained"
                      color="success"
                      sx={{ width: "30%" }}
                    >
                      Nộp
                    </Button>
                  </Box>
                </form>
              </Box>
            </Box>
          )}
        </div>
      </Fade>
    </Modal>
  );
};

export default CreateCompanyModal;
