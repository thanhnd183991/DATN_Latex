import { Box, CardMedia } from "@mui/material";
import Backdrop from "@mui/material/Backdrop";
import Fade from "@mui/material/Fade";
import Modal from "@mui/material/Modal";
import Slider from "react-slick";

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",

  width: 800,
  maxWidth: "100%",
  color: (theme) => theme.palette.text.primary,
  bgcolor: "transparent",
  //   border: "1px solid lightgray",
  //   borderRadius: 2,
  //   boxShadow: 24,
  p: 4,
};

const ImageModel = (props) => {
  const settings = {
    dots: false,
    infinite: true,
    speed: 500,
    lazyLoad: true,
    slidesToShow: 1,
    slidesToScroll: 1,
  };

  return (
    <Modal
      // ref={ref}
      aria-labelledby="transition-modal-title"
      aria-describedby="transition-modal-description"
      open={props.open}
      onClose={props.onClose}
      closeAfterTransition
      BackdropComponent={Backdrop}
      BackdropProps={{
        timeout: 500,
      }}
    >
      <Fade in={props.open}>
        <div>
          <Box sx={style}>
            <Slider {...settings}>
              {props?.images?.map((image, index) => (
                <CardMedia
                  component="img"
                  height="500px"
                  key={index}
                  image={image}
                  alt="Paella dish"
                />
              ))}
            </Slider>
          </Box>
        </div>
      </Fade>
    </Modal>
  );
};

export default ImageModel;
