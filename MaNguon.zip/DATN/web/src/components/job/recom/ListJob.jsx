import ArrowBackIosNewIcon from "@mui/icons-material/ArrowBackIosNew";
import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";
import { Box, CircularProgress, IconButton } from "@mui/material";
import { useState } from "react";
import { useRecomJobPage, useSaveOrApplyJobs } from "../../../hooks/useJobs";
import ItemJob from "../../item/ItemJob";
const ListJob = ({ isHR, isRecom, isSave, isApply }) => {
  const [page, setPage] = useState(1);
  const { jobs, statusJobs, errorJobs, isFetchingJobs } = useSaveOrApplyJobs(
    6,
    isSave,
    isApply
  );

  const { status, data, error, isFetching, isPreviousData } = useRecomJobPage(
    page,
    6,
    isRecom
  );

  if (isSave || isApply) {
    // console.log("vao");
    return (
      <Box bgcolor="background.paper">
        {statusJobs === "loading" ? (
          <div>Loading...</div>
        ) : statusJobs === "error" ? (
          <div>Error: {errorJobs?.message}</div>
        ) : (
          // `data` will either resolve to the latest page's data
          // or if fetching a new page, the last successful page's data
          <div>
            {jobs.data.slice((page - 1) * 6, (page - 1) * 6 + 6).map((job) => (
              <Box
                sx={{
                  border: "1px solid #e0e0e0",
                  borderRadius: 5,
                  mb: 1,
                  mx: 1,
                }}
                key={job._id}
              >
                <ItemJob job={job} page={page} />
              </Box>
            ))}
          </div>
        )}
        <Box
          sx={{
            display: "flex",
            justifyContent: "center",
            gap: 2,
          }}
        >
          <IconButton
            onClick={() => setPage((old) => Math.max(old - 1, 1))}
            disabled={page === 1}
          >
            <ArrowBackIosNewIcon />
          </IconButton>
          <IconButton
            onClick={() => {
              setPage((old) => (jobs?.numberOfPages > old ? old + 1 : old));
            }}
            disabled={isPreviousData || jobs?.numberOfPages <= page}
          >
            <ArrowForwardIosIcon />
          </IconButton>
        </Box>
        {
          // Since the last page's data potentially sticks around between page requests,
          // we can use `isFetching` to show a background loading
          // indicator since our `status === 'loading'` state won't be triggered
          isFetchingJobs ? (
            <Box sx={{ display: "flex" }}>
              <CircularProgress />
            </Box>
          ) : null
        }
      </Box>
    );
  }

  return (
    <Box bgcolor="background.paper">
      {status === "loading" ? (
        <div>Loading...</div>
      ) : status === "error" ? (
        <div>Error: {error.message}</div>
      ) : (
        // `data` will either resolve to the latest page's data
        // or if fetching a new page, the last successful page's data
        <div>
          {data.data.map((job) => (
            <Box
              sx={{
                border: "1px solid #e0e0e0",
                borderRadius: 5,
                mb: 1,
                mx: 1,
              }}
              key={job._id}
            >
              <ItemJob job={job} page={page} />
            </Box>
          ))}
        </div>
      )}
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          gap: 2,
        }}
      >
        <IconButton
          onClick={() => setPage((old) => Math.max(old - 1, 1))}
          disabled={page === 1}
        >
          <ArrowBackIosNewIcon />
        </IconButton>
        <IconButton
          onClick={() => {
            if (data?.numberOfPages) {
              setPage((old) => (data?.numberOfPages > old ? old + 1 : old));
            } else {
              setPage((old) => (data?.hasMore ? old + 1 : old));
            }
          }}
          disabled={
            isPreviousData || data?.numberOfPages
              ? data?.numberOfPages <= page
              : !data?.hasMore
          }
        >
          <ArrowForwardIosIcon />
        </IconButton>
      </Box>
      {
        // Since the last page's data potentially sticks around between page requests,
        // we can use `isFetching` to show a background loading
        // indicator since our `status === 'loading'` state won't be triggered
        isFetching ? (
          <Box sx={{ display: "flex" }}>
            <CircularProgress />
          </Box>
        ) : null
      }
    </Box>
  );
};

export default ListJob;
