import { yupResolver } from "@hookform/resolvers/yup";
import ReportIcon from "@mui/icons-material/Report";
import EditIcon from "@mui/icons-material/Edit";
import { Button, IconButton } from "@mui/material";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { useAuth } from "../../../hooks/useAuth";
import { useUpdateJobMutation } from "../../../hooks/useJobs";
import { numberWithCommas } from "../../../utils/number";
import { formCreateJobSchema } from "../../../validations/JobValidation";
import {
  MyReactQuill,
  MySelectField,
  MyTextField,
  MyTextFieldChip,
} from "../../core-form";
import RichText from "../../RichText";
import ReportModal from "../../modal/ReportModal";

export default function DescJob({ job, notifyId }) {
  const { user: me } = useAuth();
  const [edit, setEdit] = useState(false);
  const [openReport, setOpenReport] = useState(false);
  const fields = {
    requirements: "Yêu cầu công việc",
    numbers: "Số lượng tuyển",
    job_type: "Loại công việc",
    responsibilities: "Mô tả công việc",
    experience: "Kinh nghiệm",
    salary: "Mức lương",
    location: "Địa điểm",
    categories: "Kỹ năng",
    other: "Thông tin khác",
  };

  const {
    handleSubmit,
    reset,
    setValue,
    control,
    setError,
    formState: { errors, isSubmitting },
  } = useForm({
    defaultValues: {
      ...job,
      deadline: job.deadline.split("T")[0],
      categories: job.categories.map((category) => category.name).join(","),
    },
    resolver: yupResolver(formCreateJobSchema),
    mode: "onChange",
  });

  const { mutate, status } = useUpdateJobMutation();

  const onSubmit = (data) => {
    data.categories = data.categories.split(",");
    const {
      title,
      requirements,
      numbers,
      job_type,
      responsibilities,
      experience,
      salary,
      location,
      categories,
      other,
      deadline,
      _id,
    } = data;
    const payload = {
      data: {
        _id,
        title,
        requirements,
        numbers,
        job_type,
        responsibilities,
        experience,
        salary,
        location,
        categories,
        other,
        deadline,
      },
      setError,
      onClose: () => {
        setEdit(false);
      },
    };
    return mutate(payload);
  };

  const checkKeyDown = (e) => {
    if (e.code === "Enter") e.preventDefault();
  };

  return (
    <Box sx={{ px: 1 }}>
      {edit && me.role === "HR" ? (
        <form
          onSubmit={handleSubmit(onSubmit)}
          onKeyDown={(e) => checkKeyDown(e)}
        >
          <Typography
            variant="h6"
            sx={{
              color: "red",
              fontWeight: "bold",
            }}
            component="div"
          >
            Nhắc nhở
          </Typography>
          <Typography
            variant="body1"
            sx={{
              color: "red",
              fontWeight: "bold",
            }}
            component="div"
          >
            {job.note || "không có"}
          </Typography>
          <MyTextField
            errors={errors}
            control={control}
            name="title"
            label="Tiêu đề"
          />
          <MySelectField
            errors={errors}
            control={control}
            name="job_type"
            label="Loại"
            values={["fulltime", "parttime", "freelance"]}
            labels={["Fulltime", "Parttime", "Freelance"]}
          />
          <MyTextField
            errors={errors}
            control={control}
            name="numbers"
            label="Số lượng tuyển"
            type="number"
          />
          <MyReactQuill
            errors={errors}
            control={control}
            name="requirements"
            label="Yêu cầu"
          />
          <MyReactQuill
            errors={errors}
            control={control}
            name="responsibilities"
            label="Nhiệm vụ"
          />
          <MyTextField
            errors={errors}
            control={control}
            name="location"
            label="Địa điểm làm việc"
          />
          <MyReactQuill
            errors={errors}
            control={control}
            name="experience"
            label="Kinh nhiệm làm việc"
          />
          <MyTextField
            errors={errors}
            control={control}
            name="salary"
            label="Lương"
          />
          <MyTextFieldChip
            errors={errors}
            control={control}
            name="categories"
            label="Kỹ năng"
          />
          <MyTextField
            errors={errors}
            control={control}
            name="deadline"
            label="Hạn nộp hồ sơ"
            type="date"
          />
          <MyReactQuill
            errors={errors}
            control={control}
            name="other"
            label="Thông tin khác"
          />
          <Box
            sx={{
              display: "flex",
              justifyContent: "space-around",
              alignItems: "center",
            }}
          >
            <Button
              onClick={() => setEdit(false)}
              disabled={isSubmitting || status === "loading"}
              variant="outlined"
              color="success"
              sx={{ width: "30%" }}
            >
              Trở về
            </Button>
            <Button
              type="submit"
              disabled={isSubmitting || status === "loading"}
              variant="contained"
              color="success"
              sx={{ width: "30%" }}
            >
              Nộp
            </Button>
          </Box>
        </form>
      ) : (
        <Box sx={{ position: "relative" }}>
          {Object.keys(fields).map((field, index) => (
            <Box key={index} sx={{ my: 1 }}>
              <Typography
                variant="h6"
                sx={{
                  color: "green",
                  fontWeight: "bold",
                }}
                component="div"
              >
                {fields[field]}
              </Typography>
              <RichText
                text={
                  field === "categories"
                    ? job[field].map((el) => el.name).join(", ")
                    : field === "salary"
                    ? numberWithCommas(job[field])
                    : job[field] || ""
                }
              />
            </Box>
          ))}
          {!job.active && (
            <>
              <Typography
                variant="h6"
                sx={{
                  color: "green",
                  fontWeight: "bold",
                }}
                component="div"
              >
                Nhắc nhở
              </Typography>
              <Typography
                variant="body1"
                sx={{
                  color: "green",
                  fontWeight: "bold",
                }}
                component="div"
              >
                {job.note || "không có"}
              </Typography>
              {me.role === "HR" && (
                <IconButton
                  sx={{
                    position: "absolute",
                    top: 5,
                    right: 5,
                  }}
                  onClick={() => setEdit(true)}
                >
                  <EditIcon />
                </IconButton>
              )}
            </>
          )}
          {job.active && me._id != job.owner._id && me.role !== "admin" && (
            <Typography
              variant="body1"
              sx={{
                color: "red",
                display: "flex",
                alignItems: "center",
                textDecoration: "underline",
                gap: 0.5,
                cursor: "pointer",
              }}
              component="div"
              onClick={() => setOpenReport(true)}
            >
              <ReportIcon /> Tin xấu
            </Typography>
          )}
          {openReport && (
            <ReportModal
              open={openReport}
              access={job._id}
              onAccess="Job"
              onClose={() => setOpenReport(false)}
            />
          )}
        </Box>
      )}
    </Box>
  );
}
