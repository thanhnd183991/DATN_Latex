import { Box, Grid, Typography } from "@mui/material";
import { useMe } from "../../../hooks/useAuth";
import ItemUser from "../../item/ItemUser";
import BasicApplicantJobTable from "../../table/basic/BasicApplicantJobTable";

const ProgressJob = ({ job }) => {
  const { me, isLoadingMe } = useMe();
  return (
    <Box>
      <Typography variant="h6">Lượt theo dõi: {job.numFollowers}</Typography>
      {job.numFollowers > 0 && !isLoadingMe && (
        <Grid container spacing={1}>
          {job.followers.map((user) => (
            <Grid item sm={12} md={6} key={user._id}>
              <Box
                sx={{
                  border: "1px solid #e0e0e0",
                  borderRadius: 5,
                }}
              >
                <ItemUser user={user} me={me} />
              </Box>
            </Grid>
          ))}
        </Grid>
      )}
      <Typography variant="h6" sx={{ mt: 1 }}>
        Ứng tuyển: {job.numApplicants}
      </Typography>
      {job.applicants.length > 0 && (
        <BasicApplicantJobTable
          job={job}
          applicants={job.applicants || []}
          limit={4}
        />
      )}
    </Box>
  );
};

export default ProgressJob;
