import AccessTimeIcon from "@mui/icons-material/AccessTime";
import BookmarkIcon from "@mui/icons-material/Bookmark";
import BookmarkBorderIcon from "@mui/icons-material/BookmarkBorder";
import CloseIcon from "@mui/icons-material/Close";
import DoneIcon from "@mui/icons-material/Done";
import MessageIcon from "@mui/icons-material/Message";
import TelegramIcon from "@mui/icons-material/Telegram";
import {
  Avatar,
  Box,
  Button,
  Skeleton,
  Tooltip,
  Typography,
} from "@mui/material";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { CONNECT_JOB } from "../../../constants/NotifyConstant";
import { useMe } from "../../../hooks/useAuth";
import {
  useCloseJobMutation,
  useFollowingJobMutation,
} from "../../../hooks/useJobs";
import { getSocket } from "../../../socket";
import { dateFormat } from "../../../utils/dateUtils";
import AlertDialog from "../../dialog/AlertDialog";
import CreateApplyModal from "../../modal/job/CreateApplyModal";

const HeaderJob = ({ job }) => {
  const { me, isLoadingMe } = useMe();
  const navigate = useNavigate();
  const [openApply, setOpenApply] = useState(false);
  const { mutate: mutateCloseJob, status: statusCloseJob } =
    useCloseJobMutation();
  const [closeJob, setCloseJob] = useState(false);
  const handleClose = () => setOpenApply(false);
  const handleOpen = () => {
    if (job.isApply) {
      getSocket().emit(
        CONNECT_JOB,
        {
          jobId: job._id,
          userId: null,
        },
        (data) => {
          if (data.error) {
            toast.error(data.error);
          }
          if (data.success) {
            toast.success(data.success);
          }
          if (data?.data?._id) {
            navigate(`/chat/${data.data._id}`);
          }
        }
      );
      return;
    } else {
      setOpenApply(true);
    }
  };

  const handleCloseJobOpen = () => {
    setCloseJob(true);
  };

  const handleCloseJobClose = () => {
    setCloseJob(false);
  };

  const handleAgreeCloseJob = () => {
    mutateCloseJob({
      jobId: job._id,
      close: !job.closed,
      onClose: handleCloseJobClose,
    });
  };

  const { mutate } = useFollowingJobMutation();
  const handleSaveJob = () => {
    mutate({ jobId: job._id, isInfo: true, job });
  };

  if (isLoadingMe) {
    return <Skeleton variant="rect" width="100%" height={100} />;
  }

  return (
    <>
      <Box
        sx={{
          display: "flex",
          my: 1,
          p: 1,
          borderRadius: 4,
        }}
      >
        <Avatar
          sx={{ width: 50, height: 50, bgcolor: "red" }}
          src={job?.company?.avatar}
          alt="C"
        />
        <Box
          ml={2}
          sx={{
            flex: 1,
            display: "flex",
            flexDirection: "column",
            justifyContent: "space-around",
          }}
        >
          <Tooltip title={job.title}>
            <Typography
              variant="body1"
              sx={{
                fontWeight: "bold",
                fontSize: "1.2rem",
              }}
              component="p"
              className="ellipsis-1-lines"
            >
              {job.title}
            </Typography>
          </Tooltip>
          <Link to={`/company/${job.company._id}`}>
            <Typography
              variant="body2"
              component="p"
              sx={{ fontWeight: "bold", color: "text.primary" }}
            >
              Công ty: {job?.company?.name}
            </Typography>
          </Link>

          <Box sx={{ display: "flex", gap: 1, alignItems: "center" }}>
            <AccessTimeIcon sx={{ width: 15, height: 15 }} />
            <Typography variant="body2" component="p">
              Hạn nộp hồ sơ: {dateFormat(job.deadline, "DD/MM/YYYY")}
            </Typography>
          </Box>
          {job.active ? (
            me._id === job.owner._id && me.company === job.company._id ? (
              <Button
                sx={{ mt: 1 }}
                variant="outlined"
                onClick={handleCloseJobOpen}
              >
                {job.closed ? "Mở công việc" : "Đóng công việc"}
              </Button>
            ) : job.closed ? (
              <Typography
                variant="body1"
                component="p"
                color="red"
                sx={{ fontWeight: "bold" }}
              >
                Công việc đã đóng
              </Typography>
            ) : (
              <></>
            )
          ) : (
            <></>
          )}
        </Box>
        <Box
          sx={{
            display: "flex",
            gap: 2,
            flexDirection: "column",
            alignItems: "center",
          }}
        >
          {me._id === job.owner._id && me.company === job.company._id ? (
            <>{job.active ? <DoneIcon /> : <CloseIcon />}</>
          ) : (
            <>
              {!job.closed && (
                <Button
                  variant="contained"
                  onClick={handleOpen}
                  color="success"
                  sx={{ width: 150 }}
                  startIcon={job.isApply ? <MessageIcon /> : <TelegramIcon />}
                >
                  {job.isApply ? "Trao đổi" : "Apply"}
                </Button>
              )}
              {!job.isApply && (
                <Button
                  onClick={handleSaveJob}
                  variant="outlined"
                  sx={{ width: 150 }}
                  startIcon={
                    job.isSave ? <BookmarkIcon /> : <BookmarkBorderIcon />
                  }
                >
                  {job.isSave ? "Đã lưu" : "Lưu tin"}
                </Button>
              )}
            </>
          )}
        </Box>
      </Box>
      {openApply && (
        <CreateApplyModal
          jobId={job._id}
          isSave={job.isSave}
          open={openApply}
          onClose={handleClose}
        />
      )}
      {closeJob && (
        <AlertDialog
          desc={
            job.closed
              ? "Bạn có chắc chắn mở công việc này? Các ứng viên sẽ có thể ứng tuyển công việc này"
              : "Bạn có chắc chắn đóng công việc này? Các ứng viên quan tâm đến công việc này sẽ không thể ứng tuyển"
          }
          open={closeJob}
          status={statusCloseJob}
          handleAgree={handleAgreeCloseJob}
          handleClose={handleCloseJobClose}
          title={job.closed ? "Mở công việc" : "Đóng công việc"}
        />
      )}
    </>
  );
};

export default HeaderJob;
