import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import { useCompany } from "../../../hooks/useCompanies";
import RichText from "../../RichText";

export default function DescCompany({ job }) {
  // console.log(job.company._id);
  const { data, isLoading } = useCompany(job.company._id || job.company);
  const fields = {
    name: "Tên công ty",
    // owner_name: "Tên chủ sở hữu",
    overview: "Tóm tắt",
    website: "Website",
    industry: "Lĩnh vực",
    headquarters: "Trụ sở",
  };
  if (isLoading) {
    return <p>Loading...</p>;
  }
  return (
    <Box sx={{ px: 1 }}>
      {Object.keys(fields).map((field, index) => (
        <Box key={index} sx={{ my: 1 }}>
          <Typography
            variant="h6"
            sx={{
              color: "green",
              fontWeight: "bold",
              mb: 0,
            }}
            component="div"
          >
            {fields[field]}
          </Typography>
          {/* {console.log(job[field])} */}
          {data && (
            <RichText
              text={field === "industry" ? data[field].name : data[field] || ""}
            />
          )}
        </Box>
      ))}
    </Box>
  );
}
