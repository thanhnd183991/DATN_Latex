import { Paper } from "@mui/material";
import { useState } from "react";
import { useAuth } from "../../hooks/useAuth";
import LayoutTabs from "../layout/LayoutTab";
import DescCompany from "./detail/DescCompany";
import DescJob from "./detail/DescJob";
import HeaderJob from "./detail/HeaderJob";
import ProgressJob from "./detail/ProgressJob";

const DetailJob = ({ job }) => {
  const [value, setValue] = useState(0);
  const { user: me } = useAuth();

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const labels = ["Chi tiết công việc", "Thông tin công ty"];

  const components = [
    <DescJob job={job} />,
    // <p>2</p>,
    <DescCompany job={job} />,
  ];

  return (
    <Paper sx={{ p: 1 }}>
      <HeaderJob job={job} />
      <LayoutTabs
        value={value}
        handleChange={handleChange}
        labels={
          me.role === "HR" &&
          me.company === job.company._id &&
          me._id === job.owner._id
            ? [...labels, "Tiến độ"]
            : labels
        }
        components={
          me.role === "HR" &&
          me.company === job.company._id &&
          me._id === job.owner._id
            ? [...components, <ProgressJob job={job} />]
            : components
        }
      />
    </Paper>
  );
};

export default DetailJob;
