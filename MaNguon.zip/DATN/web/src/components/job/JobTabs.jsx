import { useMediaQuery } from "@mui/material";
import Box from "@mui/material/Box";
import { useState } from "react";
import { LG_RESPONSIVE_WIDTH } from "../../constants/Responsive";
import { useAuth } from "../../hooks/useAuth";
import CompanyListJob from "../company/company_tabs/CompanyListJob";
import LayoutTab from "../layout/LayoutTab";
import ListJob from "./recom/ListJob";

export default function JobTabs() {
  const { user: me } = useAuth();
  const [value, setValue] = useState(0);
  const LG_RESPONSIVE = useMediaQuery(LG_RESPONSIVE_WIDTH);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const labels = ["Đề xuất", "Đã lưu", "Đã ứng tuyển"];
  const components = [
    <ListJob isRecom />,
    <ListJob isSave />,
    <ListJob isApply />,
  ];

  return (
    <Box
      flex={LG_RESPONSIVE ? 4.5 : 3.5}
      sx={{
        marginTop: "18px !important",
        marginLeft: 2,
        marginRight: 3,
        borderRadius: 2,
      }}
      bgcolor="background.default"
    >
      <LayoutTab
        components={
          me.role === "employee"
            ? components
            : me.role === "HR"
            ? components
                .slice(0, 2)
                .concat(
                  <CompanyListJob
                    isHR
                    companyId={me.company._id || me.company}
                  />
                )
            : components.slice(0, 2)
        }
        value={value}
        handleChange={handleChange}
        labels={
          me.role === "employee"
            ? labels
            : me.role === "HR"
            ? labels.slice(0, 2).concat("Công việc của tôi")
            : labels.slice(0, 2)
        }
      />
    </Box>
  );
}
