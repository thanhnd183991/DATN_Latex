import { Typography } from "@mui/material";

const LayoutImages = ({ images }) => {
  const height = "400px";
  if (images.length === 0) {
    return <></>;
  }
  if (images.length === 1) {
    return (
      <img
        src={images[0]}
        alt=""
        width="100%"
        height={height}
        style={{ objectFit: "cover" }}
      />
    );
  }
  if (images.length === 2) {
    return (
      <div style={{ display: "flex", gap: "1px" }}>
        <img
          src={images[0]}
          alt=""
          width="50%"
          height={height}
          style={{ objectFit: "cover" }}
        />
        <img
          src={images[1]}
          alt=""
          width="50%"
          height={height}
          style={{ objectFit: "cover" }}
        />
      </div>
    );
  }

  if (images.length === 3) {
    return (
      <div style={{ display: "flex", gap: "1px" }}>
        <div style={{ flex: 1 }}>
          <img
            src={images[0]}
            alt=""
            width="100%"
            height="100%"
            style={{ objectFit: "cover" }}
          />
        </div>
        <div
          style={{
            flex: 1,
            display: "flex",
            flexDirection: "column",
            gap: "1px",
          }}
        >
          <img
            src={images[1]}
            alt=""
            width="100%"
            height="200px"
            style={{ objectFit: "cover" }}
          />
          <img
            src={images[2]}
            alt=""
            width="100%"
            height="200px"
            style={{ objectFit: "cover" }}
          />
        </div>
      </div>
    );
  }

  return (
    <div style={{ display: "flex", gap: "1px" }}>
      <div style={{ flex: 1 }}>
        <img
          src={images[0]}
          alt=""
          width="100%"
          height="100%"
          style={{ objectFit: "cover" }}
        />
      </div>
      <div
        style={{
          flex: 1,
          display: "flex",
          flexDirection: "column",
          gap: "1px",
        }}
      >
        <img
          src={images[1]}
          alt=""
          width="100%"
          height="200px"
          style={{ objectFit: "cover" }}
        />
        <div
          style={{
            width: "100%",
            height: "200px",
            background: `rgba(0,0,0,0.5) url(${images[2]}) no-repeat center`,
          }}
        >
          <div
            style={{
              width: "100%",
              height: "100%",
              display: "flex",
              overflow: "hidden",
              justifyContent: "center",
              alignItems: "center",
              backgroundColor: "rgba(0,0,0,0.5)",
            }}
          >
            <Typography
              variant="h6"
              style={{
                color: "white",
                fontSize: "1.5rem",
                textAlign: "center",
              }}
            >
              {images.length - 2} ảnh
            </Typography>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LayoutImages;
