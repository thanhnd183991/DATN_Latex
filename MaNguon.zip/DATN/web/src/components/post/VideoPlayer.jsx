import { useVideoAutoPlayback } from "../../hooks/useVideoAutoPlayback";
const VideoPlayer = ({ videoUrl }) => {
  const [containerRef, videoRef] = useVideoAutoPlayback({
    root: null,
    rootMargin: "0px",
    threshold: 0.1,
  });
  return (
    <>
      <div ref={containerRef}>
        <video width="100%" height="auto" muted loop ref={videoRef}>
          <source type="video/mp4" src={videoUrl} />
        </video>
      </div>
    </>
  );
};
export default VideoPlayer;
