import { Favorite, FavoriteBorder } from "@mui/icons-material";
import CommentIcon from "@mui/icons-material/Comment";
import DeleteIcon from "@mui/icons-material/Delete";
import ReportIcon from "@mui/icons-material/Report";
import AttachFileIcon from "@mui/icons-material/AttachFile";
import {
  Avatar,
  Box,
  Card,
  CardActions,
  CardContent,
  CardHeader,
  Checkbox,
  Divider,
  Grid,
  IconButton,
  styled,
  Typography,
} from "@mui/material";
import Collapse from "@mui/material/Collapse";
import { useEffect, useMemo, useState } from "react";
import { toast } from "react-toastify";
import { JOIN_POST } from "../../constants/PostConstant";
import { useInfoCountCommentPost } from "../../hooks/post/useCommentPost";
import { useDeletePostMutation } from "../../hooks/post/usePosts";
import {
  useReactionPost,
  useReactionPostMutation,
} from "../../hooks/post/useReactionPost";
import { useAuth } from "../../hooks/useAuth";
import { getPostSocket } from "../../socket/postSocket";
import { fromNow } from "../../utils/dateUtils";
import ListComment from "../comment/ListComment";
import ContentHyperlink from "../ContentHyperlink";
import AlertDialog from "../dialog/AlertDialog";
import ImageModal from "../modal/ImageModal";
import LayoutImages from "./LayoutImages";
import VideoPlayer from "./VideoPlayer";
import ReportModal from "../modal/ReportModal";

const ExpandMore = styled((props) => {
  const { expand, ...other } = props;
  return <IconButton {...other} />;
})(({ theme, expand }) => ({
  marginLeft: "auto",
}));

const Post = ({ post }) => {
  const { user } = useAuth();
  const { data, isLoading, ...info } = useReactionPost(post._id);
  const { countComment, isLoadingCountComment } = useInfoCountCommentPost(
    post._id
  );
  const { mutate } = useReactionPostMutation();
  const [expanded, setExpanded] = useState(false);
  const [openAlertDelete, setOpenAlertDelete] = useState(false);
  const [openReport, setOpenReport] = useState(false);
  const { mutate: deletePostMutate, status: statusDelete } =
    useDeletePostMutation();
  const [onOpenImageModal, setOnOpenImageModal] = useState(false);
  const handleOpen = () => setOnOpenImageModal(true);
  const handleClose = () => setOnOpenImageModal(false);

  const { images, videos, files } = useMemo(() => {
    let images = [],
      videos = [],
      files = [];
    post?.files?.forEach((file) => {
      if (file.resource_type === "image") {
        images.push(file.file);
      } else if (file.resource_type === "video") {
        videos.push(file.file);
      } else {
        files.push(file);
      }
    });
    return {
      images,
      videos,
      files,
    };
  }, [post._id]);

  useEffect(() => {
    if (getPostSocket()) {
      getPostSocket().emit(JOIN_POST, {
        post: post._id,
        posts: null,
      });
    }
  }, []);

  const handleExpandClick = () => {
    setExpanded(!expanded);
  };

  const isDelete = () => {
    if (post.onOwner === "User" && post.ownerId._id.toString() === user._id) {
      return true;
    }
    if (
      post.onOwner === "Company" &&
      post.ownerId?.owner?._id.toString() === user._id
    ) {
      return true;
    }
    return false;
  };

  const handleClickImage = (image) => {
    toast("Wow easy!");
  };

  const handleDeletePost = () => {
    deletePostMutate({
      postId: post._id,
      ownerId: post.ownerId?._id || post.ownerId,
      onClose: () => setOpenAlertDelete(false),
    });
  };

  return (
    <>
      <Card sx={{ mx: "auto", mb: 2, boxShadow: 2 }}>
        <CardHeader
          sx={{
            py: 1,
          }}
          avatar={
            <Avatar
              src={post.ownerId.avatar}
              // alt="M"
              sx={{ bgcolor: "red" }}
              aria-label="post"
            />
          }
          action={
            isDelete() ? (
              <IconButton
                aria-label="settings"
                onClick={() => setOpenAlertDelete(true)}
              >
                <DeleteIcon />
              </IconButton>
            ) : user.role !== "admin" ? (
              <IconButton
                aria-label="report"
                onClick={() => setOpenReport(true)}
              >
                <ReportIcon />
              </IconButton>
            ) : (
              <></>
            )
          }
          title={post?.ownerId?.name || "John Doe"}
          subheader={fromNow(post.createdAt)}
        />
        <CardContent sx={{ mt: -1, pb: 0 }}>
          {post?.content && (
            <ContentHyperlink contentText={post.content} post />
          )}
        </CardContent>

        {images.length > 0 && (
          <Box onClick={() => handleOpen()}>
            <LayoutImages images={images} />
          </Box>
        )}
        {videos.length > 0 && <VideoPlayer videoUrl={videos[0]} />}
        {files.length > 0 && (
          <Grid
            container
            spacing={0.5}
            sx={{ mt: 1 }}
            columns={{ xs: 4, sm: 8, md: 12 }}
          >
            {files.map((file, index) => (
              <Grid item xs={12} key={index}>
                <Box
                  sx={{
                    borderTop: "1px solid gray",
                    borderBottom: "1px solid gray",
                    bgcolor: "action.hover",
                    px: 1,
                    py: 2,
                  }}
                >
                  <a href={file.file} target="_blank" download>
                    <Typography
                      variant="body2"
                      color="textSecondary"
                      component="h5"
                      sx={{
                        textDecoration: "none",
                        display: "flex",
                        alginItems: "center",
                      }}
                    >
                      <AttachFileIcon /> {file.original_filename}
                    </Typography>
                  </a>
                </Box>
              </Grid>
            ))}
          </Grid>
        )}

        <CardActions disableSpacing sx={{ mt: 1 }}>
          {isLoading ? (
            <Box sx={{ width: "30px" }}></Box>
          ) : (
            <Box
              onClick={() =>
                user.role === "admin"
                  ? {}
                  : mutate({ postId: post._id, reaction: "love" })
              }
              sx={{ display: "flex", alignItems: "center", cursor: "pointer" }}
            >
              <Checkbox
                checked={data?.hasReaction}
                icon={<FavoriteBorder />}
                checkedIcon={<Favorite sx={{ color: "red" }} />}
              />
              <Typography variant="body2" color="text.secondary">
                {data?.countReaction}
              </Typography>
            </Box>
          )}
          <Box
            sx={{ display: "flex", alignItems: "center" }}
            onClick={() => handleExpandClick()}
          >
            <ExpandMore
              expand={expanded}
              aria-expanded={expanded}
              aria-label="show more"
            >
              <CommentIcon />
              <Typography sx={{ ml: 1 }} variant="body2" color="text.secondary">
                {!isLoading ? countComment?.data : ""}
              </Typography>
            </ExpandMore>
          </Box>
        </CardActions>
        <Collapse in={expanded} timeout="auto" unmountOnExit>
          <Divider />
          <ListComment postId={post._id} user={user} />
        </Collapse>
      </Card>
      {onOpenImageModal && (
        <ImageModal
          open={onOpenImageModal}
          images={images}
          onClose={handleClose}
        />
      )}
      {!!openAlertDelete && (
        <AlertDialog
          open={!!openAlertDelete}
          handleAgree={handleDeletePost}
          handleClose={() => setOpenAlertDelete(false)}
          title="Xác nhận"
          desc={`Bạn có chắc chắn muốn xóa bài viết này?`}
          status={statusDelete}
        />
      )}
      {openReport && (
        <ReportModal
          open={openReport}
          access={post._id}
          onAccess="Post"
          onClose={() => setOpenReport(false)}
        />
      )}
    </>
  );
};

export default Post;
