import { Box, Typography } from "@mui/material";

const LayoutField = ({ label, children }) => {
  return (
    <Box sx={{ my: 1 }}>
      {label === "none" ? null : (
        <Typography sx={{ fontWeight: "bold" }} variant="body1">
          {label}
        </Typography>
      )}
      {children}
    </Box>
  );
};

export default LayoutField;
