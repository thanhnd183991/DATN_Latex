import { Box, styled } from "@mui/material";
const MyUl = styled("ul")(({ theme }) => ({
  position: "absolute",
  zIndex: 9999,
  left: 0,
  top: 0,
  listStyleType: "none",
}));

const MyLi = styled("li")(({ theme }) => ({
  color: theme.palette.text.primary,
  width: "100%",
  padding: 2,
  cursor: "pointer",
  backgroundColor: theme.palette.background.paper,
  "&:hover": {
    backgroundColor: "lightgrey",
    zIndex: 9999,
  },
}));

const Suggestions = ({
  data,
  handleClick,
  setSuggestionIndex,
  suggestionIndex,
  width = 500,
}) => {
  return (
    <Box
      sx={{
        position: "relative",
      }}
    >
      <MyUl>
        {data?.map((suggestion, index) => {
          return (
            <MyLi
              style={{
                backgroundColor: suggestionIndex === index ? "lightgrey" : "",
                width,
              }}
              key={suggestion._id || index}
              onClick={handleClick}
              onMouseEnter={() => {
                setSuggestionIndex(index);
              }}
            >
              {suggestion.name || suggestion.title}
            </MyLi>
          );
        })}
      </MyUl>
    </Box>
  );
};

export default Suggestions;
