import { useCallback, useEffect, useMemo, useState } from "react";
import { useDropzone } from "react-dropzone";
import { Controller } from "react-hook-form";
import { toast } from "react-toastify";
import {
  acceptStyle,
  baseStyle,
  focusedStyle,
  img,
  rejectStyle,
  thumb,
  thumbInner,
  thumbsContainer,
} from "./DropZone.styles";

const StyledDropzone = ({ component, control, name, accept, maxFiles }) => {
  return (
    <Controller
      render={({ field }) => {
        const [files, setFiles] = useState([]);

        useEffect(() => {
          // Make sure to revoke the data uris to avoid memory leaks, will run on unmount
          return () =>
            files.forEach((file) => URL.revokeObjectURL(file.preview));
        }, []);

        const onDrop = useCallback((acceptedFiles) => {
          if (acceptedFiles.length === 0 && maxFiles) {
            toast.error(`Vui lòng chọn tối đa ${maxFiles} file`);
            return;
          }

          let rs = [];
          let tmpFiles = [];
          let countVideo = 0;
          let countImage = 0;
          let countFile = 0;
          acceptedFiles.forEach((file) => {
            rs.push(file);
            if (file.type.includes("image")) {
              countImage++;
              tmpFiles.push(
                Object.assign(file, {
                  preview: URL.createObjectURL(file),
                })
              );
            } else if (file.type.includes("video")) {
              countVideo++;
            } else {
              countFile++;
            }
          });
          if (countVideo > 1) {
            toast.error("Bạn chỉ được chọn 1 file video");
          } else {
            setFiles(tmpFiles);
            field.onChange(rs);
          }
        }, []);

        const {
          getRootProps,
          getInputProps,
          acceptedFiles,
          isFocused,
          isDragAccept,
          isDragReject,
        } = useDropzone({ onDrop, accept, maxFiles });

        const style = useMemo(
          () => ({
            ...baseStyle,
            ...(isFocused ? focusedStyle : {}),
            ...(isDragAccept ? acceptStyle : {}),
            ...(isDragReject ? rejectStyle : {}),
          }),
          [isFocused, isDragAccept, isDragReject]
        );

        const thumbs = files.map((file) => (
          <div style={thumb} key={file.name}>
            <div style={thumbInner}>
              <img
                src={file.preview}
                style={img}
                // Revoke data uri after image is loaded
                onLoad={() => {
                  URL.revokeObjectURL(file.preview);
                }}
              />
            </div>
          </div>
        ));
        return (
          <div className="container">
            <aside style={thumbsContainer}>{thumbs}</aside>
            <aside>
              <ul>
                {field.value
                  .filter((file) => !file.type.includes("image"))
                  .map((file) => (
                    <li key={file.path}>
                      {file.path} - {file.size} bytes
                    </li>
                  ))}
              </ul>
            </aside>
            <div {...getRootProps({ style })}>
              <input {...getInputProps()} />
              {component}
            </div>
          </div>
        );
      }}
      name={name}
      control={control}
    />
  );
};
export default StyledDropzone;
