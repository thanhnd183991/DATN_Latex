import { Box, styled } from "@mui/material";
import { useSearchInputField } from "../../hooks/useSearch";

const Search = styled("div")(({ theme }) => ({
  backgroundColor: "white",
  padding: "0 10px",
  borderRadius: 5,
  height: 30,
}));

const MyUl = styled("ul")(({ theme }) => ({
  position: "absolute",
  zIndex: 90,
  top: 15,
  left: -40,
  listStyleType: "none",
}));

const MyLi = styled("li")(({ theme }) => ({
  color: theme.palette.text.primary,
  width: "100%",
  padding: 2,
  cursor: "pointer",
  backgroundColor: theme.palette.background.paper,
  "&:hover": {
    backgroundColor: "lightgrey",
    zIndex: 90,
  },
}));

const MySearchInputField = ({
  type = "text",
  control,
  name,
  label,
  placeholder = "",
  fullWidth = true,
  errors = {},
  variant = "standard",
  width = "100%",
}) => {
  const {
    suggestions,
    suggestionsActive,
    setSuggestionsActive,
    suggestionIndex,
    setSuggestionIndex,
    value,
    setValue,
    isSearching,
    handleChange,
    setIsSearching,
    isEnter,
    setIsEnter,
  } = useSearchInputField();

  return (
    <Controller
      render={({ field: { ref, ...field } }) => {
        // console.log(errors);
        return (
          <Box sx={{ position: "relative", width: "100%" }}>
            <Search
              sx={{
                bgcolor: (theme) => theme.palette.divider,
                color: "primary.main",
              }}
            >
              <TextField
                inputRef={ref}
                error={!!errors[name]}
                helperText={errors[name]?.message || errors[name]}
                placeholder={placeholder}
                type={type}
                sx={{ width: "100%" }}
                fullWidth={fullWidth}
                variant={variant}
                {...field}
                value={value}
                ref={ref}
                onChange={(e) => {
                  setValue(e.target.value || "");
                }}
                onKeyDown={handleKeyDown}
                onBlur={handleBlur}
              />
            </Search>
            {isSearching && <div>Searching ...</div>}
            {suggestionsActive && <Suggestions />}
          </Box>
        );
      }}
      name={name}
      control={control}
    />
  );
};

export default MySearchInputField;
