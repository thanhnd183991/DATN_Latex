import { TextField } from "@mui/material";
import { Controller } from "react-hook-form";
import { useSearchInputField } from "../../hooks/useSearch";
import LayoutField from "./LayoutField";
import Suggestions from "./Suggestions";

const MyTextFieldSuggestion = ({
  type = "text",
  control,
  name,
  label,
  placeholder = "",
  fullWidth = true,
  model = "category",
  errors = {},
  variant = "standard",
}) => {
  return (
    <LayoutField label={label}>
      <Controller
        render={({ field: { ref, ...field } }) => {
          const { value, onChange } = field;
          const {
            handleChange,
            handleKeyDown,
            suggestionsActive,
            handleClick,
            results,
            setSuggestionIndex,
            suggestionIndex,
          } = useSearchInputField(model, value, onChange, ref);
          // console.log(errors);
          return (
            <>
              <TextField
                inputRef={ref}
                error={!!errors[name]}
                helperText={errors[name]?.message || errors[name]}
                placeholder={placeholder}
                type={type}
                fullWidth={fullWidth}
                variant={variant}
                {...field}
                value={field.value}
                onChange={handleChange}
                onKeyDown={handleKeyDown}
              />
              {suggestionsActive && (
                <Suggestions
                  data={results}
                  handleClick={handleClick}
                  setSuggestionIndex={setSuggestionIndex}
                  suggestionIndex={suggestionIndex}
                />
              )}
            </>
          );
        }}
        name={name}
        control={control}
      />
    </LayoutField>
  );
};

export default MyTextFieldSuggestion;
