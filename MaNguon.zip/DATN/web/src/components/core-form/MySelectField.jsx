import { MenuItem, Select, Typography } from "@mui/material";
import { Controller } from "react-hook-form";
import LayoutField from "./LayoutField";
const MySelectField = ({
  values,
  label,
  labels,
  name,
  control,
  errors = {},
}) => {
  return (
    <LayoutField label={label}>
      <Controller
        render={({ field }) => (
          <>
            <Select
              variant={"standard"}
              sx={{ my: 1, minWidth: 200 }}
              {...field}
            >
              {values.map((value, index) => (
                <MenuItem key={value} value={value}>
                  {labels[index]}
                </MenuItem>
              ))}
            </Select>
            {errors[name] && (
              <Typography variant="caption" color="error">
                {errors[name]?.message ||
                  errors[name] ||
                  "Nội dung không được để trống"}
              </Typography>
            )}
          </>
        )}
        name={name}
        control={control}
      />
    </LayoutField>
  );
};

export default MySelectField;
