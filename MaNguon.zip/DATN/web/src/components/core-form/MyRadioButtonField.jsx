import { Typography } from "@mui/material";
import FormControlLabel from "@mui/material/FormControlLabel";
import Radio from "@mui/material/Radio";
import RadioGroup from "@mui/material/RadioGroup";
import { Controller } from "react-hook-form";
import LayoutField from "./LayoutField";

const MyRadioButtonField = ({
  values,
  label,
  labels,
  name,
  control,
  errors = {},
}) => {
  return (
    <LayoutField label={label}>
      <Controller
        render={({ field }) => (
          <>
            <RadioGroup
              aria-labelledby="demo-radio-buttons-group-label"
              defaultValue={values[0]}
              name="radio-buttons-group"
              {...field}
            >
              {values.map((value, index) => (
                <FormControlLabel
                  value={value}
                  key={value}
                  control={<Radio />}
                  label={labels[index]}
                />
              ))}
            </RadioGroup>
            {errors[name] && (
              <Typography variant="caption" color="error">
                {errors[name]?.message ||
                  errors[name] ||
                  "Nội dung không được để trống"}
              </Typography>
            )}
          </>
        )}
        name={name}
        control={control}
      />
    </LayoutField>
  );
};

export default MyRadioButtonField;
