import { Box } from "@mui/material";
import { useFieldArray } from "react-hook-form";
import MyTextField from "../MyTextField";

export default ({ nestIndex, control, register }) => {
  const { fields, remove, append } = useFieldArray({
    control,
    name: `data.${nestIndex}.nestedArray`,
  });

  return (
    <div>
      {fields.map((item, k) => {
        // console.log("item", item);

        return (
          <Box
            key={k}
            sx={{ display: "flex", gap: 1, flexDirection: "column" }}
          >
            {Object.keys(item).map((key, index) =>
              key !== "id" && key !== "_id" ? (
                <MyTextField
                  label="none"
                  key={index}
                  placeholder={key}
                  name={`data.${nestIndex}.nestedArray.${k}.${key}`}
                  control={control}
                  multiline={key === "desc" ? true : false}
                  type={
                    key === "start_date" || key === "end_date"
                      ? "month"
                      : "text"
                  }
                />
              ) : null
            )}
          </Box>
        );
      })}
    </div>
  );
};
