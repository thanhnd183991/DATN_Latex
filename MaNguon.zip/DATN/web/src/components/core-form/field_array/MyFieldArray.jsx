import { Box, Button, Typography } from "@mui/material";
import { useFieldArray } from "react-hook-form";
import MyTextFieldSuggestion from "../MyTextFieldSuggestion";
import NestedArray from "./MyNestedFieldArray";

export default function Fields({
  control,
  register,
  setValue,
  getValues,
  type,
}) {
  const { fields, append, remove, prepend } = useFieldArray({
    control,
    name: "data",
  });

  const initAppendSchool =
    type === "educations"
      ? [
          {
            degree: "",
            field_of_study: "",
            start_date: "",
            end_date: "",
          },
        ]
      : [
          {
            position: "",
            start_date: "",
            end_date: "",
            desc: "",
          },
        ];

  const buttons =
    type === "educations" || type === "experiences"
      ? [
          {
            field: "Thêm trường",
            nestedArray: initAppendSchool,
          },
        ]
      : [
          {
            field: "Thêm trường",
          },
        ];

  return (
    <>
      <Box>
        {fields.map((item, index) => {
          // console.log("item", item);
          return (
            <Box key={item.id}>
              <Box sx={{ display: "flex", gap: 1, alignItems: "center" }}>
                <Typography variant="body1">{index + 1}.</Typography>
                <Box flex={1}>
                  <MyTextFieldSuggestion
                    label="none"
                    name={`data.${index}.name`}
                    placeholder="Tên trường"
                    model={type === "skills" ? "category" : type}
                    control={control}
                  />
                </Box>
                <Button
                  variant="outlined"
                  // sx={{ height: 20 }}
                  onClick={() => remove(index)}
                >
                  Xóa
                </Button>
              </Box>
              {item.nestedArray && (
                <Box sx={{ ml: 10 }}>
                  <NestedArray nestIndex={index} {...{ control, register }} />
                </Box>
              )}
            </Box>
          );
        })}
      </Box>

      <section>
        {buttons.map((item, i) => (
          <Button
            key={i}
            variant="outlined"
            sx={{ my: 1 }}
            onClick={() => {
              setValue("data", [
                ...(getValues().data || []),
                {
                  name: "",
                  nestedArray: item?.nestedArray,
                },
              ]);
            }}
          >
            {item.field}
          </Button>
        ))}
      </section>
    </>
  );
}
