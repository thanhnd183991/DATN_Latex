import { Paper, TextField } from "@mui/material";
import Chip from "@mui/material/Chip";
import { styled } from "@mui/material/styles";
import { Controller } from "react-hook-form";
import { useSearchInputChipField } from "../../hooks/useSearch";
import LayoutField from "./LayoutField";
import Suggestions from "./Suggestions";

const ListItem = styled("li")(({ theme }) => ({
  margin: theme.spacing(0.5),
}));

const MyTextFieldChip = ({
  type = "text",
  control,
  name,
  label,
  fullWidth = true,
  variant = "standard",
  model = "category",
  errors = {},
}) => {
  return (
    <LayoutField label={label}>
      <Controller
        render={({ field }) => {
          const { value, onChange } = field;
          const {
            chipData,
            ref,
            text,
            handleChange,
            handleKeyDown,
            isSearching,
            suggestionsActive,
            handleClick,
            results,
            handleDelete,
            suggestionIndex,
            setSuggestionIndex,
          } = useSearchInputChipField(
            model,
            onChange,
            !value ? [] : value.split(",")
          );

          return (
            <>
              {chipData.length > 0 && (
                <Paper
                  sx={{
                    display: "flex",
                    bgcolor: (theme) => theme.palette.divider,
                    borderRadius: 5,
                    justifyContent: "center",
                    flexWrap: "wrap",
                    listStyle: "none",
                    p: 0.5,
                    m: 0,
                    mb: 1,
                  }}
                  component="ul"
                >
                  {chipData.map((data, index) => {
                    let icon;

                    return (
                      <ListItem key={index}>
                        <Chip
                          icon={icon}
                          label={data}
                          onDelete={handleDelete(data)}
                        />
                      </ListItem>
                    );
                  })}
                </Paper>
              )}
              <TextField
                ref={ref}
                type={type}
                fullWidth={fullWidth}
                variant={variant}
                value={text}
                onChange={handleChange}
                helperText={errors[name]?.message || errors[name]}
                onKeyDown={handleKeyDown}
              />
              {suggestionsActive && (
                <Suggestions
                  data={results}
                  handleClick={handleClick}
                  setSuggestionIndex={setSuggestionIndex}
                  suggestionIndex={suggestionIndex}
                />
              )}
            </>
          );
        }}
        name={name}
        control={control}
      />
    </LayoutField>
  );
};

export default MyTextFieldChip;
