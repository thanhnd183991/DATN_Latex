import { Typography } from "@mui/material";
import { Controller } from "react-hook-form";
import ReactQuill from "react-quill";
import { formats, modules } from "../../constants/ReactQuillConst";
import LayoutField from "./LayoutField";

const MyReactQuill = ({
  label,
  control,
  name,
  placeholder = "Nhập nội dung... ",
  errors = {},
}) => {
  return (
    <LayoutField label={label}>
      <Controller
        render={({ field }) => (
          <>
            <ReactQuill
              theme="snow"
              placeholder={placeholder}
              modules={modules}
              formats={formats}
              {...field}
            />
            {errors[name] && (
              <Typography variant="caption" color="error">
                {errors[name]?.message ||
                  errors[name] ||
                  "Nội dung không được để trống"}
              </Typography>
            )}
          </>
        )}
        name={name}
        control={control}
      />
    </LayoutField>
  );
};

export default MyReactQuill;
