import { TextField } from "@mui/material";
import { Controller } from "react-hook-form";
import LayoutField from "./LayoutField";

const MyTextField = ({
  type = "text",
  control,
  name,
  label,
  placeholder = "",
  fullWidth = true,
  multiline = false,
  errors = {},
  variant = "standard",
}) => {
  return (
    <LayoutField label={label}>
      <Controller
        render={({ field: { ref, ...field } }) => {
          // console.log(errors);
          return (
            <TextField
              inputRef={ref}
              error={!!errors[name]}
              helperText={errors[name]?.message || errors[name]}
              placeholder={placeholder}
              type={type}
              multiline={multiline}
              minRows={multiline ? 5 : 1}
              fullWidth={fullWidth}
              variant={variant}
              {...field}
            />
          );
        }}
        name={name}
        control={control}
      />
    </LayoutField>
  );
};

export default MyTextField;
