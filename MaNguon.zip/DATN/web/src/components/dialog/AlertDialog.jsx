import { Box, CircularProgress } from "@mui/material";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import RichText from "../RichText";

const styleIsLoading = {
  position: "absolute",
  top: 0,
  right: 0,
  left: 0,
  bottom: 0,
  overflow: "hidden",
  color: "blue",
  bgcolor: "rgba(0,0,0,0.5)",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
};

export default function AlertDialog({
  handleClose,
  handleAgree,
  open,
  title,
  desc,
  status,
}) {
  return (
    <div>
      <Dialog
        open={open}
        onClose={handleClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
        sx={{ minWidth: 500, maxWidth: "90%" }}
      >
        {status === "loading" ? (
          <Box sx={styleIsLoading}>
            <CircularProgress />
          </Box>
        ) : (
          <>
            <DialogTitle id="alert-dialog-title">{title}</DialogTitle>
            <DialogContent>
              <RichText text={desc} />
            </DialogContent>
            <DialogActions>
              <Button onClick={handleClose}>Trở về</Button>
              {handleAgree && (
                <Button onClick={handleAgree} autoFocus>
                  Đồng ý
                </Button>
              )}
            </DialogActions>
          </>
        )}
      </Dialog>
    </div>
  );
}
