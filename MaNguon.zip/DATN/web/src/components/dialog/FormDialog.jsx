import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import { useForm } from "react-hook-form";
import {
  useActiveJobMutation,
  useUpdateJobMutation,
} from "../../hooks/useJobs";
import { MyTextField } from "../core-form";

const defaultValues = {
  note: "",
};

export default function FormDialog({ handleClose, title, open, notify, desc }) {
  const { mutate: activeJobNotifyMutate } = useActiveJobMutation();
  const { mutate: updateJobMutate } = useUpdateJobMutation();
  const {
    handleSubmit,
    formState: { errors, isSubmitting },
    setError,
    reset,
    setValue,
    control,
  } = useForm({
    defaultValues,
  });

  const onSubmit = (data) => {
    if (data.note.length < 0) {
      setError("note", { type: "required", message: "note được yêu cầu" });
    }

    const payload = {
      data: {
        ...data,
        _id: notify.access,
      },
      setError,
      onClose: () => {
        activeJobNotifyMutate({
          jobId: notify.access,
          notifyId: notify._id,
          status: false,
          isNotify: true,
        });
        handleClose();
      },
    };
    return updateJobMutate(payload);
  };

  const checkKeyDown = (e) => {
    if (e.code === "Enter") e.preventDefault();
  };

  return (
    <div>
      <Dialog open={open} onClose={handleClose}>
        {title && <DialogTitle>{title}</DialogTitle>}
        <DialogContent sx={{ width: 500 }}>
          <form
            onSubmit={handleSubmit(onSubmit)}
            onKeyDown={(e) => checkKeyDown(e)}
          >
            <MyTextField
              errors={errors}
              control={control}
              name="note"
              label="Lý do"
              multiline
            />
            <DialogActions>
              <Button onClick={handleClose}>Trở về</Button>
              <Button variant="contained" color="success" type="submit">
                Phản hồi
              </Button>
            </DialogActions>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
