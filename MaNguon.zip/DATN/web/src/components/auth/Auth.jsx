import { yupResolver } from "@hookform/resolvers/yup";
import LockOutlinedIcon from "@mui/icons-material/LockOutlined";
import Avatar from "@mui/material/Avatar";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Container from "@mui/material/Container";
import Grid from "@mui/material/Grid";
import Typography from "@mui/material/Typography";
import { useForm } from "react-hook-form";
import { useDispatch } from "react-redux";
import { Link, useNavigate } from "react-router-dom";
import { login, signup } from "../../redux/features/authSlice";
import {
  formLoginSchema,
  formSignupSchema,
} from "../../validations/AuthValidation";
import { MyTextField } from "../core-form";

const defaultValues = {
  name: "",
  email: "",
  password: "",
  confirmPassword: "",
};

export default function Auth({ isLogin }) {
  const { handleSubmit, reset, setValue, control, formState } = useForm({
    defaultValues,
    resolver: yupResolver(isLogin ? formLoginSchema : formSignupSchema),
    mode: "onChange",
  });

  const { errors, isSubmitting, isSubmitSuccessful, isSubmitted, isValid } =
    formState;

  const dispatch = useDispatch();
  const navigate = useNavigate();

  const onSubmit = (values) => {
    if (isLogin) {
      // call login api
      return dispatch(login({ email: values.email, password: values.password }))
        .unwrap()
        .then((rs) => {
          if (rs.user.role === "admin")
            navigate("/admin/home", { replace: true });
          else navigate("/", { replace: true });
        })
        .catch((err) => {
          console.log(err);
        });
    } else {
      return dispatch(
        signup({
          name: values.name,
          email: values.email,
          password: values.password,
        })
      )
        .unwrap()
        .then((rs) => {
          navigate("/", { replace: true });
        })
        .catch((err) => {
          console.log(err);
        });
    }
  };

  const checkKeyDown = (e) => {
    if (e.code === "Enter") e.preventDefault();
  };

  return (
    <Container component="main" maxWidth="xs">
      <Box
        sx={{
          marginTop: 8,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          backgroundColor: "background.paper",
          padding: 2,
          borderRadius: 4,
        }}
      >
        <Avatar sx={{ m: 1, bgcolor: "secondary.main" }}>
          <LockOutlinedIcon />
        </Avatar>
        <Typography component="h1" variant="h5">
          {isLogin ? "Đăng nhập" : "Đăng ký"}
        </Typography>
        <Box sx={{ mt: 1, width: "100%" }}>
          <form
            onSubmit={handleSubmit(onSubmit)}
            onKeyDown={(e) => checkKeyDown(e)}
          >
            {!isLogin && (
              <MyTextField
                control={control}
                name="name"
                errors={errors}
                label="none"
                variant="outlined"
                placeholder="Tên người dùng"
              />
            )}
            <MyTextField
              control={control}
              name="email"
              label="none"
              errors={errors}
              variant="outlined"
              placeholder="Email"
            />
            <MyTextField
              control={control}
              name="password"
              label="none"
              errors={errors}
              variant="outlined"
              type="password"
              placeholder="Mật khẩu"
            />
            {!isLogin && (
              <MyTextField
                control={control}
                name="confirmPassword"
                label="none"
                errors={errors}
                variant="outlined"
                type="password"
                placeholder="Xác nhận mật khẩu"
              />
            )}

            <Button
              type="submit"
              variant="contained"
              disabled={isSubmitting || !isValid}
              sx={{ mt: 3, mb: 2, width: "100%" }}
            >
              Nộp
            </Button>
          </form>
        </Box>
        <Grid container>
          <Grid item xs>
            <Link style={{ fontSize: "14px" }} to="/forgot-password">
              Quên mật khẩu?
            </Link>
          </Grid>
          <Grid item>
            <Link
              style={{ fontSize: "14px" }}
              to={isLogin ? "/signup" : "/login"}
            >
              {isLogin
                ? "Bạn chưa có tài khoản? Đăng ký"
                : "Đã có tài khoản? Đăng nhập"}
            </Link>
          </Grid>
        </Grid>
      </Box>
    </Container>
  );
}
