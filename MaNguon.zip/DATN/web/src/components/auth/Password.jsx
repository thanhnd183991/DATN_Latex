import { yupResolver } from "@hookform/resolvers/yup";
import LockOutlinedIcon from "@mui/icons-material/LockOutlined";
import Avatar from "@mui/material/Avatar";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Container from "@mui/material/Container";
import Grid from "@mui/material/Grid";
import Typography from "@mui/material/Typography";
import { useForm } from "react-hook-form";
import { Link } from "react-router-dom";
import { toast } from "react-toastify";
import { changePassword, forgotPassword } from "../../services/AuthService";
import {
  formChangePasswordSchema,
  formForgotPasswordSchema,
} from "../../validations/AuthValidation";
import { MyTextField } from "../core-form";

const defaultValues = {
  email: "",
  password: "",
  confirmPassword: "",
};

export default function Password({ isForgot, params }) {
  const {
    handleSubmit,
    reset,
    setValue,
    control,
    formState: { errors, isSubmitting },
  } = useForm({
    defaultValues,
    resolver: yupResolver(
      isForgot ? formForgotPasswordSchema : formChangePasswordSchema
    ),
    mode: "onChange",
  });

  const onSubmit = (values) => {
    if (isForgot) {
      return forgotPassword({ email: values.email })
        .then((rs) => {
          toast.success(rs.data.message);
        })
        .catch((err) => {
          console.log(err);
          toast.error(err.message);
        });
    } else {
      return changePassword({ password: values.password, token: params.token })
        .then((rs) => {
          localStorage.removeItem("token");
          localStorage.removeItem("user");
          toast.success(rs.data.message);
        })
        .catch((err) => {
          console.log(err);
          toast.error(err.message);
        });
    }
  };

  const checkKeyDown = (e) => {
    if (e.code === "Enter") e.preventDefault();
  };

  return (
    <Container component="main" maxWidth="xs">
      <Box
        sx={{
          marginTop: 8,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          backgroundColor: "background.paper",
          padding: 2,
          borderRadius: 4,
        }}
      >
        <Avatar sx={{ m: 1, bgcolor: "secondary.main" }}>
          <LockOutlinedIcon />
        </Avatar>
        <Typography component="h1" variant="h5">
          {isForgot ? "Nhập email" : "Mật khẩu mới"}
        </Typography>
        <Box sx={{ mt: 1, width: "100%" }}>
          <form
            onSubmit={handleSubmit(onSubmit)}
            onKeyDown={(e) => checkKeyDown(e)}
          >
            {isForgot ? (
              <MyTextField
                control={control}
                name="email"
                label="none"
                errors={errors}
                variant="outlined"
                placeholder="Email"
              />
            ) : (
              <>
                <MyTextField
                  control={control}
                  name="password"
                  label="none"
                  errors={errors}
                  variant="outlined"
                  type="password"
                  placeholder="Mật khẩu"
                />
                <MyTextField
                  control={control}
                  name="confirmPassword"
                  label="none"
                  errors={errors}
                  variant="outlined"
                  type="password"
                  placeholder="Xác nhận mật khẩu"
                />
              </>
            )}
            <Button
              type="submit"
              disabled={isSubmitting}
              variant="contained"
              sx={{ mt: 3, mb: 2, width: "100%" }}
            >
              Nộp
            </Button>
          </form>
        </Box>
        <Grid container>
          <Grid item xs>
            <Link style={{ fontSize: "14px" }} to="/forgot-password">
              Quên mật khẩu?
            </Link>
          </Grid>
          <Grid item>
            <Link style={{ fontSize: "14px" }} to="/login">
              "Đã có tài khoản? Đăng nhập"
            </Link>
          </Grid>
        </Grid>
      </Box>
    </Container>
  );
}
