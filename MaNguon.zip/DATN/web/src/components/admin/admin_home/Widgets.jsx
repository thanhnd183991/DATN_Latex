import ApartmentIcon from "@mui/icons-material/Apartment";
import EventNoteIcon from "@mui/icons-material/EventNote";
import GroupIcon from "@mui/icons-material/Group";
import WorkIcon from "@mui/icons-material/Work";
import { Box, CircularProgress, Grid, Paper, Typography } from "@mui/material";
import { Link } from "react-router-dom";
import { useTotalAll } from "../../../hooks/admin/useAdminHome";
import { numberWithCommas } from "../../../utils/number";

const Widgets = () => {
  const { data, isLoading } = useTotalAll();
  const widgets = [
    {
      path: "/admin/user",
      label: "Người dùng",
      Icon: GroupIcon,
    },
    {
      path: "/admin/post",
      label: "Bài đăng",
      Icon: EventNoteIcon,
    },
    {
      path: "/admin/job",
      label: "Công việc",
      Icon: WorkIcon,
    },
    {
      path: "/admin/company",
      label: "Công ty",
      Icon: ApartmentIcon,
    },
  ];
  return (
    <Grid container spacing={2}>
      {widgets.map(({ label, Icon, path }, index) => (
        <Grid item xs={12} sm={6} md={3} key={index}>
          <Paper
            sx={{
              p: 1,
              minHeight: 150,
              display: "flex",
              flexDirection: "column",
              justifyContent: "space-around",
            }}
          >
            <Typography variant="h6">{label}</Typography>
            {isLoading ? (
              <Box sx={{ textAlign: "center" }}>
                <CircularProgress />
              </Box>
            ) : (
              <Typography variant="h4">
                {numberWithCommas(data[index]) || "error"}
              </Typography>
            )}
            <Link to={path} style={{ textDecoration: "none" }}>
              <Box
                sx={{
                  display: "flex",
                  cursor: "pointer",
                  justifyContent: "space-between",
                  alignItems: "center",
                }}
              >
                <Typography
                  variant="body1"
                  color="text.primary"
                  sx={{ textDecoration: "underline" }}
                >
                  Xem tất cả
                </Typography>
                <Icon />
              </Box>
            </Link>
          </Paper>
        </Grid>
      ))}
    </Grid>
  );
};

export default Widgets;
