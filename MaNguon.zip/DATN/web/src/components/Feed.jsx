import { Box, Button, Skeleton, Stack, useMediaQuery } from "@mui/material";
import { Fragment, useState, useEffect } from "react";
import { useQueryClient } from "react-query";
import {
  LG_RESPONSIVE_WIDTH,
  MD_RESPONSIVE_WIDTH,
} from "../constants/Responsive";
import { usePosts } from "../hooks/post/usePosts";
import {
  cleanPostSocket,
  eventsForPost,
  initPostSocket,
} from "../socket/postSocket";
import Post from "./post/Post";
import Share from "./Share";

const Feed = ({ user, isFeed, companyId, me }) => {
  // console.log(user);
  const MD_RESPONSIVE = useMediaQuery(MD_RESPONSIVE_WIDTH);
  const LG_RESPONSIVE = useMediaQuery(LG_RESPONSIVE_WIDTH);
  const [isListening, setIsListening] = useState(false);
  const queryClient = useQueryClient();
  const {
    status,
    data,
    error,
    isFetching,
    isFetchingNextPage,
    isFetchingPreviousPage,
    fetchNextPage,
    fetchPreviousPage,
    hasNextPage,
    hasPreviousPage,
    refViewPost,
  } = usePosts(user ? { userId: user._id } : companyId ? { companyId } : {});

  useEffect(() => {
    if (user || isFeed || companyId || me) {
      // console.log("listenting to post events... ");
      setIsListening(false);
      initPostSocket();
      eventsForPost(queryClient);
      setIsListening(true);
    }
    return () => {
      cleanPostSocket();
    };
  }, [user, isFeed, companyId, me]);

  return (
    <Box
      flex={LG_RESPONSIVE ? 5 : 3.5}
      px={{ xs: isFeed ? 2 : 0, sm: isFeed ? 2 : 0, md: isFeed ? 5 : 2 }}
    >
      {((user && user?._id === me._id) || isFeed) && <Share />}
      {status === "loading" || !isListening ? (
        <Stack spacing={1}>
          <Skeleton variant="text" height={100} />
          <Skeleton variant="text" height={20} />
          <Skeleton variant="text" height={20} />
          <Skeleton variant="rectangular" height={300} />
        </Stack>
      ) : status === "error" ? (
        <span>Error: {error.message}</span>
      ) : (
        <>
          {data.pages.map((page) => (
            <Fragment key={page.nextId}>
              {page.data.map((post) => (
                <Post key={post._id} post={post} />
              ))}
            </Fragment>
          ))}
          <div>
            <Button
              ref={refViewPost}
              variant="text"
              onClick={() => fetchNextPage()}
              disabled={!hasNextPage || isFetchingNextPage}
            >
              {isFetchingNextPage
                ? "Loading more..."
                : hasNextPage
                ? "Load Newer"
                : "Hết"}
            </Button>
          </div>
          <div>
            {isFetching && !isFetchingNextPage
              ? "Background Updating..."
              : null}
          </div>
        </>
      )}
      <hr />
    </Box>
  );
};

export default Feed;
