import { Add as AddIcon } from "@mui/icons-material";
import { Fab, Tooltip } from "@mui/material";
import { useState } from "react";
import CreatePostModal from "./modal/CreatePostModal";

const Add = () => {
  const [open, setOpen] = useState(false);

  const handleOpen = () => {
    setOpen(true);
  };
  const handleClose = () => {
    setOpen(false);
  };

  return (
    <>
      <Tooltip
        onClick={(e) => setOpen(true)}
        title="Thêm bài viết"
        sx={{
          position: "fixed",
          bottom: 20,
          left: 20,
        }}
      >
        <Fab color="primary" aria-label="add">
          <AddIcon />
        </Fab>
      </Tooltip>
      <CreatePostModal open={open} onClose={handleClose} />,
    </>
  );
};

export default Add;
