import AddIcon from "@mui/icons-material/Add";
import ChatIcon from "@mui/icons-material/Chat";
import DoneIcon from "@mui/icons-material/Done";
import EditIcon from "@mui/icons-material/Edit";
import PhotoCamera from "@mui/icons-material/PhotoCamera";
import {
  Box,
  Button,
  CircularProgress,
  IconButton,
  Skeleton,
  styled,
  TextField,
  Typography,
} from "@mui/material";
import { useEffect, useState } from "react";
import Zoom from "react-medium-image-zoom";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { CONNECT_USER, FOLLOW_USER } from "../../constants/NotifyConstant";
import { useMe } from "../../hooks/useAuth";
import { useUpdateFieldMutation } from "../../hooks/useUsers";
import { deleteFile, uploadFile } from "../../services/UploadService";
import { getSocket } from "../../socket";
import { previewImage } from "../../utils/media/image";
import CreateListModal from "../modal/CreateListModal";

const Input = styled("input")({
  display: "none",
});

const ProfileHeader = ({ user }) => {
  const navigate = useNavigate();
  const { me, isLoadingMe } = useMe();
  const { mutate, isLoading } = useUpdateFieldMutation();
  const [open, setOpen] = useState(false);
  const [type, setType] = useState("");
  const [isUploading, setIsUploading] = useState(false);
  const [newAvatar, setNewAvatar] = useState(null);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const infoConnectUser = {
    followers: "Người theo dõi",
    following: "Đang theo dõi",
    followingCompany: "Theo dõi công ty",
  };

  useEffect(() => {
    setOpen(false);
  }, [user._id]);

  const isFollowing = me?.following.some((item) => item === user._id);
  const handleConnectOrFollow = () => {
    if (isFollowing) {
      // if follwing --> chat
      getSocket().emit(CONNECT_USER, { receiverId: user._id }, (data) => {
        if (data?.data?._id) {
          navigate(`/chat/${data.data._id}`);
        } else {
          if (data.error) {
            toast.error(data.error);
          } else if (data.success) {
            toast.success(data.success);
          }
        }
      });
    } else {
      // if no follow --> following
      getSocket().emit(FOLLOW_USER, { otherId: user._id }, (data) => {
        if (data.error) {
          toast.error(data.error);
        }
      });
    }
  };

  const handleClose = () => {
    setOpen(false);
  };
  const handleOpen = (type) => {
    setType(type);
    setOpen(true);
  };

  const handleSave = () => {
    if (name) {
      if (name === user.name) {
        setName("");
        return;
      }
      mutate({
        body: {
          name,
        },
        userId: me._id,
        onClose: () => setName(""),
      });
      return;
    }
    if (email) {
      if (email === user.email) {
        setEmail("");
        return;
      }
      mutate({
        body: {
          email,
        },
        userId: me._id,
        onClose: () => setEmail(""),
      });
      return;
    }

    setIsUploading(true);
    Promise.all([uploadFile(newAvatar), deleteFile(user.avatar)])
      .then((rs) => {
        mutate({
          body: {
            avatar: rs[0]?.secure_url || rs[1]?.secure_url,
          },
          userId: me._id,
          avatar: rs[0]?.secure_url || rs[1]?.secure_url,
          onClose: () => {
            setNewAvatar(null);
            setIsUploading(false);
          },
        });
      })
      .catch((err) => {
        console.log(err);
        setIsUploading(false);
      });
  };

  if (isLoadingMe) {
    return <Skeleton variant="rect" width="100%" height={200} />;
  }

  return (
    <>
      <Box
        sx={{
          p: 2,
          display: "flex",
          boxShadow: 1,
          bgcolor: "background.paper",
          mb: 2,
          borderRadius: 2,
        }}
      >
        <Box
          sx={{
            borderRadius: 4,
            mr: 2,
            position: "relative",
            width: "200px",
            height: "200px",
          }}
        >
          {newAvatar ? (
            <>
              <img
                src={newAvatar.preview}
                alt="newavatar"
                width="100%"
                height="100%"
                style={{ borderRadius: "10px" }}
                // Revoke data uri after image is loaded
                onLoad={() => {
                  URL.revokeObjectURL(newAvatar.preview);
                }}
              />
              <Button
                onClick={handleSave}
                sx={{
                  position: "absolute",
                  bottom: 10,
                  right: 10,
                }}
                variant="contained"
                color="success"
                disabled={isUploading}
              >
                {isUploading ? <CircularProgress size={24} /> : "Lưu"}
              </Button>
            </>
          ) : (
            !isLoading && (
              <Zoom zoomMargin={40}>
                <img
                  src={user?.avatar}
                  alt="avatar"
                  // className="img"
                  style={{ width: "100%", height: "200px" }}
                />
              </Zoom>
            )
          )}
          {!isLoadingMe && user._id === me._id && (
            <label
              htmlFor="icon-button-file"
              style={{
                position: "absolute",
                top: 0,
                right: 0,
              }}
            >
              <Input
                accept="image/*"
                id="icon-button-file"
                type="file"
                onChange={(event) => previewImage(event, setNewAvatar)}
              />
              <IconButton
                disabled={isUploading}
                color="primary"
                aria-label="upload picture"
                component="span"
              >
                <PhotoCamera />
              </IconButton>
            </label>
          )}
        </Box>
        <Box
          sx={{
            flex: 1,
            display: "flex",
            flexDirection: "column",
            justifyContent: "space-evenly",
          }}
        >
          <Box sx={{ display: "flex", justifyContent: "space-around" }}>
            <Box
              sx={{
                display: "flex",
                alignItems: "center",
                flex: 1,
                justifyContent: "space-between ",
                "&:hover": {
                  "& > *": {
                    display: "block",
                  },
                },
              }}
            >
              {!!name ? (
                <TextField
                  placeholder={name}
                  onChange={(event) => setName(event.target.value)}
                  fullWidth
                  variant="standard"
                />
              ) : (
                <Typography className="ellipsis-1-lines" variant="h5">
                  {user.name}
                </Typography>
              )}
              {user._id === me._id && (
                <Box
                  onClick={() => (name ? handleSave() : setName(user.name))}
                  sx={{
                    display: "none",
                    cursor: "pointer",
                  }}
                >
                  {name ? <DoneIcon /> : <EditIcon />}
                </Box>
              )}
            </Box>
            {!isLoadingMe && user._id !== me._id && me.role !== "admin" && (
              <Button
                sx={{
                  textTransform: "none",
                  borderRadius: 8,
                }}
                onClick={handleConnectOrFollow}
                variant="outlined"
                startIcon={isFollowing ? <ChatIcon /> : <AddIcon />}
              >
                <span className="ellipsis-1-lines">
                  {isFollowing ? "Trao đổi" : "Theo dõi"}
                </span>
              </Button>
            )}
          </Box>

          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              flex: 1,
              justifyContent: "space-between ",
              "&:hover": {
                "& > *": {
                  display: "block",
                },
              },
            }}
          >
            {!!email ? (
              <TextField
                placeholder={email}
                onChange={(event) => setEmail(event.target.value)}
                fullWidth
                variant="standard"
              />
            ) : (
              <Typography variant="h5" className="ellipsis-1-lines">
                {user.email}
              </Typography>
            )}
            {user._id === me._id && (
              <Box
                onClick={() => (email ? handleSave() : setEmail(user.email))}
                sx={{
                  display: "none",
                  cursor: "pointer",
                }}
              >
                {email ? <DoneIcon /> : <EditIcon />}
              </Box>
            )}
          </Box>

          <Typography variant="body1" sx={{ fontWeight: 550 }}>
            {user.activeCompany ? "Nhân viên công ty" : "Người tìm việc"}
          </Typography>
          <Box
            sx={{
              flex: 1,
              display: "flex",
              gap: 5,
              alignItems: "center",
              justifyContent: "space-evenly",
            }}
          >
            {Object.keys(infoConnectUser).map((el, index) => (
              <Box
                key={index}
                onClick={() => handleOpen(el)}
                sx={{
                  display: "flex",
                  alignItems: "center",
                  textAlign: "center",
                  cursor: "pointer",
                  flexDirection: "column",
                }}
              >
                <Typography variant="body1" className="ellipsis-2-lines">
                  {infoConnectUser[el]}
                </Typography>
                <Typography variant="body1">{user[el]?.length}</Typography>
              </Box>
            ))}
          </Box>
        </Box>
      </Box>
      {open && !isLoadingMe && (
        <CreateListModal
          id={user._id}
          open={open}
          onClose={handleClose}
          type={type}
          label={infoConnectUser[type]}
          user={user}
          me={me}
        />
      )}
    </>
  );
};

export default ProfileHeader;
