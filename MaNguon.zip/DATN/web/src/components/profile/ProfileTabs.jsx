import Box from "@mui/material/Box";
import { useState } from "react";
import { useMe } from "../../hooks/useAuth";
import Feed from "../Feed";
import LayoutTab from "../layout/LayoutTab";
import ProfileDetail from "./profile_tabs/ProfileDetail";
export default function ProfileTabs({ user }) {
  const { me, isLoadingMe } = useMe();
  const [value, setValue] = useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const labels = ["Thông tin chi tiết", "Hoạt động gần đây"];
  const components = [
    <ProfileDetail user={user} me={me} />,
    <Feed user={user} me={me} />,
  ];
  if (isLoadingMe) {
    return <Box>Loading...</Box>;
  }

  return (
    <Box bgcolor="">
      <LayoutTab
        components={components}
        value={value}
        handleChange={handleChange}
        labels={labels}
      />
    </Box>
  );
}
