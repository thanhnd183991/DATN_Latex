import ProfileItemArray from "../profile_item/ProfileItemArray";
import ProfileItemObject from "../profile_item/ProfileItemObject";
import ProfileItemString from "../profile_item/ProfileItemString";
import { PDFDownloadLink, PDFViewer } from "@react-pdf/renderer";
import { Typography } from "@mui/material";
import CV from "../../cv";

const ProfileDetail = ({ user, me }) => {
  // console.log(user);
  //   console.log(user);
  const descString = {
    about: "Tổng quan",
  };
  const descArray = {
    educations: "Đào tạo",
    // about: "Tổng quan",
    experiences: "Kinh nhiệm làm việc",
    skills: "Kỹ năng",
    languages: "Ngôn ngữ",
    // experience: "Kinh nhiệm",
    // languages: "Ngôn ngữ",
    // social: "Mạng xã hội",
  };
  const descObject = {
    social: "Mạng xã hội",
  };
  return (
    <>
      {Object.keys(descString).map((el, index) => (
        <ProfileItemString
          data={user[el] || "..."}
          label={descString[el]}
          field={el}
          key={index}
          isMe={me._id === user._id}
          userId={user._id}
        />
      ))}
      {Object.keys(descArray).map((el, index) => (
        <ProfileItemArray
          data={user[el]}
          label={descArray[el]}
          key={index}
          type={el}
          isMe={me._id === user._id}
          userId={user._id}
        />
      ))}
      {Object.keys(descObject).map((el, index) => (
        <ProfileItemObject
          isMe={me._id === user._id}
          data={user[el]}
          field={el}
          label={descObject[el]}
          key={index}
          userId={user._id}
        />
      ))}
      <PDFDownloadLink document={<CV user={user} />}>
        <Typography variant="h6">Download CV</Typography>
        {/* <Box>
          <PDFViewer style={{ width: "100%", minHeight: 500 }}>
            <Cv user={user} />
          </PDFViewer>
        </Box> */}
      </PDFDownloadLink>
    </>
  );
};

export default ProfileDetail;
