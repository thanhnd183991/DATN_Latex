import EditIcon from "@mui/icons-material/Edit";
import { Box, Button, Divider, Typography } from "@mui/material";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { useUpdateFieldMutation } from "../../../hooks/useUsers";
import { MyReactQuill } from "../../core-form";
import RichText from "../../RichText";

const ProfileItemString = ({ data, label, field, isMe, userId }) => {
  const [isEdit, setIsEdit] = useState(false);
  const { mutate } = useUpdateFieldMutation();
  const { handleSubmit, reset, setValue, control } = useForm({
    defaultValues: {
      text: data,
    },
  });
  if (!data) return null;
  const checkKeyDown = (e) => {
    if (e.code === "Enter") e.preventDefault();
  };
  const onSubmit = (data) => {
    // if (!text && !files.length) {
    //   toast.error("Bạn chưa nhập nội dung hoặc file đính kèm");
    //   return;
    // }
    let payload = {};
    Object.assign(payload, { [field]: data.text });
    mutate({
      userId,
      body: payload,
      onClose: () => setIsEdit(false),
    });
    return;
    // const rs = await uploadFiles(files);
    if (rs.status === 200) {
      // create post
      toast.success("Đăng bài thành công");
      props.onClose();
    } else {
      toast.error("Đăng bài thất bại");
    }
  };
  return (
    <Box
      sx={{ my: 2, boxShadow: 1, borderRadius: 2, bgcolor: "background.paper" }}
    >
      <Box
        sx={{
          p: 2,
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          "&:hover": {
            "& > *": {
              display: "block",
            },
          },
        }}
      >
        <Typography variant="h5">{label}</Typography>
        {isMe && (
          <Box
            onClick={() => setIsEdit(true)}
            sx={{
              display: "none",
              cursor: "pointer",
            }}
          >
            <EditIcon />
          </Box>
        )}
      </Box>
      <Divider />
      {isEdit ? (
        <form
          onSubmit={handleSubmit(onSubmit)}
          onKeyDown={(e) => checkKeyDown(e)}
          style={{
            padding: "0px 10px",
            paddingBottom: "5px",
          }}
        >
          <MyReactQuill control={control} name="text" label="none" />
          <Box
            sx={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              gap: 5,
            }}
          >
            <Button
              onClick={() => setIsEdit(false)}
              variant="outlined"
              sx={{
                width: "25%",
              }}
            >
              Trở về
            </Button>
            <Button
              type="submit"
              variant="contained"
              color="success"
              sx={{
                width: "25%",
              }}
            >
              Nộp
            </Button>
          </Box>
        </form>
      ) : (
        <Box sx={{ py: 1, px: 2 }}>
          {/* {console.log(data)} */}
          {data !== "..." ? (
            <div id={`profile-${field}`}>
              <RichText text={data} />
            </div>
          ) : (
            <Typography variant="body1" color="secondary">
              Viết gì đó...
            </Typography>
          )}
        </Box>
      )}
    </Box>
  );
};
export default ProfileItemString;
