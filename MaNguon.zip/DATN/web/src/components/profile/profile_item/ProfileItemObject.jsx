import EditIcon from "@mui/icons-material/Edit";
import { Box, Button, Divider, Typography } from "@mui/material";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { useUpdateFieldMutation } from "../../../hooks/useUsers";
import { MyTextField } from "../../core-form";
import RichText from "../../RichText";

const ProfileItemObject = ({ data, label, isMe, field, userId }) => {
  const [isEdit, setIsEdit] = useState(false);
  const { mutate } = useUpdateFieldMutation();
  const { handleSubmit, reset, setValue, control } = useForm({
    defaultValues: data,
  });
  if (!data) return null;
  const checkKeyDown = (e) => {
    if (e.code === "Enter") e.preventDefault();
  };

  const onSubmit = (data) => {
    let payload = {};
    Object.assign(payload, { [field]: data });
    mutate({
      userId,
      body: payload,
      onClose: () => setIsEdit(false),
    });
    return;
  };

  return (
    <Box
      sx={{ my: 2, boxShadow: 1, borderRadius: 2, bgcolor: "background.paper" }}
    >
      <Box
        sx={{
          p: 2,
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          "&:hover": {
            "& > *": {
              display: "block",
            },
          },
        }}
      >
        <Typography variant="h5">{label}</Typography>
        {isMe && (
          <Box
            onClick={() => setIsEdit(true)}
            sx={{
              display: "none",
              cursor: "pointer",
            }}
          >
            <EditIcon />
          </Box>
        )}
      </Box>
      <Divider />
      {isEdit ? (
        <Box sx={{ py: 1, px: 2 }}>
          <form
            onSubmit={handleSubmit(onSubmit)}
            onKeyDown={(e) => checkKeyDown(e)}
          >
            {Object.keys(data).map((el, index) => (
              <Box
                sx={{
                  display: "flex",
                  gap: 1,
                  alignItems: "center",
                }}
                key={index}
              >
                <Typography
                  sx={{
                    minWidth: 100,
                    fontWeight: "bold",
                  }}
                  variant="body1"
                >
                  {el[0].toUpperCase() + el.slice(1)}
                </Typography>
                <Box flex={1}>
                  <MyTextField name={el} control={control} label="none" />
                </Box>
              </Box>
            ))}
            <Box sx={{ display: "flex", gap: 1, justifyContent: "center" }}>
              <Button
                variant="outlined"
                sx={{
                  width: "30%",
                }}
                onClick={() => setIsEdit(false)}
              >
                Trở về
              </Button>

              <Button
                type="submit"
                variant="contained"
                color="success"
                sx={{
                  width: "30%",
                }}
              >
                Nộp
              </Button>
            </Box>
          </form>
        </Box>
      ) : (
        <Box sx={{ py: 1, px: 2 }}>
          {Object.keys(data).map(
            (el, index) =>
              data[el] && (
                <Box key={index} sx={{ display: "flex", gap: 1 }}>
                  <Typography
                    variant="body1"
                    sx={{
                      minWidth: 100,
                      textTransform: "capitalize",
                      fontWeight: "bold",
                    }}
                  >
                    {el}
                  </Typography>
                  <a
                    href={`${data[el]}`}
                    style={{ color: "inherit" }}
                    target="_blank"
                  >
                    {`${data[el]}`}
                  </a>
                </Box>
              )
          )}
        </Box>
      )}
    </Box>
  );
};
export default ProfileItemObject;
