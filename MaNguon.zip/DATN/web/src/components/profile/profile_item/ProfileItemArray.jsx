import EditIcon from "@mui/icons-material/Edit";
import { Box, Divider, Typography } from "@mui/material";
import { useState } from "react";
import CreateArrayModal from "../../modal/CreateArrayModal";

const ProfileItemArray = ({ data, label, type, isMe, userId }) => {
  const [onOpen, setOnOpen] = useState(false);

  const handleOpen = () => {
    // if (type === "skills") return;
    setOnOpen(true);
  };
  const handleClose = () => {
    setOnOpen(false);
  };

  // console.log(data, label);
  return (
    <>
      <Box
        sx={{
          my: 2,
          boxShadow: 1,
          borderRadius: 2,
          bgcolor: "background.paper",
        }}
      >
        <Box
          sx={{
            p: 2,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            "&:hover": {
              "& > *": {
                display: "block",
              },
            },
          }}
        >
          <Typography variant="h5">{label}</Typography>
          {isMe && (
            <Box
              onClick={handleOpen}
              sx={{
                display: "none",
                cursor: "pointer",
              }}
            >
              <EditIcon />
            </Box>
          )}
        </Box>
        <Divider />
        {data?.map((el, index) =>
          type === "educations" ? (
            <Box key={index} sx={{ px: 2, py: 1 }}>
              <Typography variant="h6">{el?.school}</Typography>
              <Typography variant="body1" color="secondary">
                {el?.degree}
              </Typography>

              <Typography variant="body1" color="secondary">
                {el?.field_of_study}
              </Typography>
              <Typography variant="body1" color="secondary">
                {el?.start_date} - {el?.end_date}
              </Typography>
            </Box>
          ) : type === "skills" || type === "languages" ? (
            <Box sx={{ py: 1, px: 2 }} key={index}>
              <Typography variant="body1">{el?.name}</Typography>
            </Box>
          ) : type === "experiences" ? (
            <Box key={index} sx={{ px: 2, py: 1 }}>
              <Typography variant="h6">{el?.name}</Typography>
              <Typography variant="body1">{el?.position}</Typography>

              <Typography variant="body1" color="">
                {el?.start_date} - {el?.end_date}
              </Typography>
              <Typography variant="body2" color="primary">
                {el?.desc}
              </Typography>
            </Box>
          ) : (
            <></>
          )
        )}
      </Box>
      {onOpen && (
        <CreateArrayModal
          data={
            type === "skills" || type === "languages"
              ? data.map((el) => el.name)
              : data
          }
          open={onOpen}
          type={type}
          label={label}
          userId={userId}
          onClose={handleClose}
        />
      )}
    </>
  );
};

export default ProfileItemArray;
