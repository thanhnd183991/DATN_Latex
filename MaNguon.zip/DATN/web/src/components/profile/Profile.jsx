import { Box, Skeleton, Stack } from "@mui/material";
import ProfileHeader from "./ProfileHeader";
import ProfileTabs from "./ProfileTabs";

const Profile = ({ user, isLoading }) => {
  return (
    <Box flex={5} p={2}>
      {isLoading ? (
        <Stack spacing={1}>
          <Skeleton variant="text" height={100} />
          <Skeleton variant="rectangular" height={300} />
          <Skeleton variant="rectangular" height={300} />
        </Stack>
      ) : (
        <>
          <ProfileHeader user={user} />
          <ProfileTabs user={user} />
        </>
      )}
    </Box>
  );
};

export default Profile;
