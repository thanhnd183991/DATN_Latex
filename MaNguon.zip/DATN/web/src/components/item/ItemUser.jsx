import {
  Avatar,
  Box,
  Button,
  Divider,
  ListItemAvatar,
  Tooltip,
  Typography,
  useMediaQuery,
} from "@mui/material";
import AddIcon from "@mui/icons-material/Add";
import { Link } from "react-router-dom";
import { toast } from "react-toastify";
import { ADD_MEMBER, FOLLOW_USER } from "../../constants/NotifyConstant";
import { XL_RESPONSIVE_WIDTH } from "../../constants/Responsive";
import { getSocket } from "../../socket";

const ItemUser = ({ user, isAddMember, companyId, me }) => {
  const XL_RESPONSIVE = useMediaQuery(XL_RESPONSIVE_WIDTH);
  // console.log("render item user");
  const handleClickButtonFollow = () => {
    if (isAddMember) {
      getSocket().emit(
        ADD_MEMBER,
        { companyId, employees: [user._id] },
        (data) => {
          if (data.error) {
            toast.error(data.error);
          }
          if (data.success) {
            toast.success(data.success);
          }
        }
      );
    } else {
      if (isMe) {
        return;
      }
      // console.log("vao");
      // mutate({ userId: me._id, otherId: user._id });
      getSocket().emit(FOLLOW_USER, { otherId: user._id }, (data) => {
        if (data.error) {
          toast.error(data.error);
        }
      });
    }
  };

  const isFollowing = me?.following.some((item) => item === user._id);
  const isMe = me._id === user._id;

  return (
    <>
      <Box sx={{ display: "flex", p: 2 }}>
        <Link
          to={me.role === "admin" ? `/admin/user` : `/profile/${user._id}`}
          style={{ textDecoration: "none", display: "flex", flex: 1 }}
        >
          <ListItemAvatar>
            <Avatar
              alt="Remy Sharp"
              sx={{ bgcolor: "lightgray" }}
              src={user.avatar}
            />
          </ListItemAvatar>
          <Box flex={1} sx={{ mr: 1 }}>
            <Tooltip title={user.name}>
              <Typography
                variant="body1"
                className="ellipsis-1-lines"
                color="primary"
              >
                {user.name}
              </Typography>
            </Tooltip>
            <Typography variant="body2" color="secondary">
              Người theo dõi :{user.numFollowers}
            </Typography>
          </Box>
        </Link>
        {me.role !== "admin" && (
          <Box>
            <Button
              sx={{
                bgcolor: "transparent",
                borderColor: "primary",
                border: 1,
                borderRadius: 8,
                textTransform: "none",
              }}
              variant={isMe ? "text" : "outlined"}
              color="primary"
              onClick={handleClickButtonFollow}
            >
              <span className="ellipsis-1-lines">
                {isAddMember ? (
                  "Thêm"
                ) : isMe ? (
                  "Bạn"
                ) : isFollowing ? (
                  "Đang theo dõi"
                ) : XL_RESPONSIVE ? (
                  "Theo dõi"
                ) : (
                  <Box
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <AddIcon />
                  </Box>
                )}
              </span>
            </Button>
          </Box>
        )}
      </Box>
    </>
  );
};

export default ItemUser;
