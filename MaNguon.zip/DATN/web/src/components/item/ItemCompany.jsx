import {
  Avatar,
  Box,
  Button,
  ListItemAvatar,
  Typography,
  useMediaQuery,
  Tooltip,
} from "@mui/material";
import { Link } from "react-router-dom";
import { useMe } from "../../hooks/useAuth";
import { useFollowingCompanyMutation } from "../../hooks/useUsers";
import { XL_RESPONSIVE_WIDTH } from "../../constants/Responsive";
import AddIcon from "@mui/icons-material/Add";
import { getSocket } from "../../socket";
import { FOLLOW_COMPANY } from "../../constants/NotifyConstant";

const ItemCompany = ({ company }) => {
  const { me, isLoadingMe } = useMe();
  const { mutate } = useFollowingCompanyMutation();
  const isFollowing = me?.followingCompany.some((item) => item === company._id);
  const XL_RESPONSIVE = useMediaQuery(XL_RESPONSIVE_WIDTH);
  const handleClickButtonFollow = () => {
    getSocket().emit(FOLLOW_COMPANY, { companyId: company._id }, (data) => {
      if (data.error) {
        toast.error(data.error);
      }
    });
  };
  return (
    <>
      <Box sx={{ display: "flex", p: 2 }}>
        <Link
          to={
            !isLoadingMe
              ? me.role === "admin"
                ? `/admin/company`
                : `/company/${company._id}`
              : ""
          }
          style={{ textDecoration: "none", display: "flex", flex: 1 }}
        >
          <ListItemAvatar>
            <Avatar
              alt="Remy Sharp"
              sx={{ bgcolor: "lightgray" }}
              src={company?.avatar}
            />
          </ListItemAvatar>
          <Box flex={1} sx={{ mr: 1 }}>
            <Tooltip title={company?.name}>
              <Typography
                variant="body1"
                color="primary"
                className="ellipsis-1-lines"
              >
                {company?.name}
              </Typography>
            </Tooltip>
            <Typography variant="body2" color="secondary">
              Theo dõi: {company.numFollowers}
            </Typography>
            {company.industry?.length > 0 && (
              <Typography
                className="ellipsis-1-lines"
                variant="body2"
                color="secondary"
              >
                {company.industry[0].name}
              </Typography>
            )}
            <Typography
              className="ellipsis-1-lines"
              variant="body2"
              color="secondary"
            >
              {company?.industry?.name
                ? company.industry.name
                : "LABEL_UNKNOWN"}
            </Typography>
          </Box>
        </Link>
        {!isLoadingMe && me.role !== "admin" && (
          <Box>
            <Button
              sx={{
                bgcolor: "transparent",
                borderColor: "primary",
                border: 1,
                borderRadius: 8,
                textTransform: "none",
              }}
              variant="outlined"
              color="primary"
              onClick={handleClickButtonFollow}
            >
              {isFollowing ? (
                "Đang theo dõi"
              ) : XL_RESPONSIVE ? (
                "Theo dõi"
              ) : (
                <Box
                  sx={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <AddIcon />
                </Box>
              )}
            </Button>
          </Box>
        )}
      </Box>
    </>
  );
};

export default ItemCompany;
