import { Avatar, Box, Button, Divider, Typography } from "@mui/material";
import { memo, useCallback, useState } from "react";
import { toast } from "react-toastify";
import {
  ACCEPTED,
  ADD_MEMBER,
  canAction,
  CONFIRM,
  CONFIRM_ADD_MEMBER,
  CONFIRM_CONNECT_JOB,
  CONFIRM_CONNECT_USER,
  CONFIRM_REPORT_JOB,
  CONFIRM_REPORT_POST,
  CONNECT_JOB,
  CONNECT_USER,
  CREATE_COMPANY,
  CREATE_JOB_FOR_ADMIN,
  CREATE_REPORT_JOB,
  CREATE_REPORT_POST,
  PENDING,
  REJECTED,
} from "../../constants/NotifyConstant";
import { useActiveCompanyMutation } from "../../hooks/useCompanies";
import { useActiveJobMutation } from "../../hooks/useJobs";
import { getSocket } from "../../socket";
import { fromNow } from "../../utils/dateUtils";
import FormDialog from "../dialog/FormDialog";
import RichText from "../RichText";

const ActionButtons = ({ labels, handleClick }) => (
  <Box sx={{ display: "flex", gap: 1 }}>
    {labels.map((label, index) => (
      <Button
        variant="outlined"
        key={index}
        onClick={() =>
          index === 0 ? handleClick(REJECTED) : handleClick(ACCEPTED)
        }
        sx={{ borderRadius: 10, py: 0, textTransform: "none" }}
      >
        {label}
      </Button>
    ))}
  </Box>
);

const ItemNotify = memo(({ notify, handleClickSelectNotify }) => {
  // console.log("render item notify");
  const { mutate: activeJobNotifyMutate } = useActiveJobMutation();
  const [open, setOpen] = useState(false);
  const { mutate: activeCompanyNotifyMutate } = useActiveCompanyMutation();
  const isAction = canAction.some((el) => el === notify.type);

  const handleClick = useCallback((status) => {
    switch (notify.type) {
      case ADD_MEMBER:
        getSocket().emit(
          CONFIRM_ADD_MEMBER,
          {
            notifyId: notify._id,
            status,
          },
          (data) => {
            if (data.error) {
              toast.error(data.error);
            }
          }
        );
        break;

      case CREATE_JOB_FOR_ADMIN:
        if (status === ACCEPTED) {
          activeJobNotifyMutate({
            jobId: notify.access,
            notifyId: notify._id,
            status: status === ACCEPTED ? true : false,
            isNotify: true,
          });
        } else {
          setOpen(true);
        }
        break;

      case CREATE_COMPANY:
        activeCompanyNotifyMutate({
          companyId: notify.access,
          notifyId: notify._id,
          status: status === ACCEPTED ? true : false,
          isNotify: true,
        });
        break;

      case CONNECT_USER:
        getSocket().emit(
          CONFIRM_CONNECT_USER,
          {
            notifyId: notify._id,
            status,
          },
          (data) => {
            if (data.error) {
              toast.error(data.error);
            }
            if (data.success) {
              toast.success(data.success);
            }
          }
        );
        break;

      case CONNECT_JOB:
        getSocket().emit(
          CONFIRM_CONNECT_JOB,
          {
            notifyId: notify._id,
            status,
          },
          (data) => {
            if (data.error) {
              toast.error(data.error);
            }
            if (data.success) {
              toast.success(data.success);
            }
          }
        );
        break;

      case CREATE_REPORT_JOB:
        getSocket().emit(
          CONFIRM_REPORT_JOB,
          {
            notifyId: notify._id,
            status,
          },
          (data) => {
            if (data.error) {
              toast.error(data.error);
            }
            if (data.success) {
              toast.success(data.success);
            }
          }
        );
        break;

      case CREATE_REPORT_POST:
        getSocket().emit(
          CONFIRM_REPORT_POST,
          {
            notifyId: notify._id,
            status,
          },
          (data) => {
            if (data.error) {
              toast.error(data.error);
            }
            if (data.success) {
              toast.success(data.success);
            }
          }
        );
        break;
    }
  }, []);

  return (
    <>
      <Box
        sx={{
          p: 1,
          bgcolor: (theme) =>
            notify?.receiver[0]?.status !== PENDING
              ? theme.palette.action.hover
              : "transparent",
        }}
      >
        <Box
          sx={{
            display: "flex",
            gap: 1,
          }}
        >
          <Avatar
            sx={{
              width: 40,
              height: 40,
            }}
            src={
              notify?.type?.includes(CONFIRM)
                ? notify.receiver[0]?.user?.avatar
                : notify?.sender?.avatar
            }
            alt="avatar"
          />
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              justifyContent: "space-between",
              flex: 1,
            }}
          >
            <Box
              sx={{
                flex: 1,
                cursor: "pointer",
              }}
              className="ellipsis-3-lines"
              onClick={() => handleClickSelectNotify(notify)}
            >
              <RichText text={notify.message} />
            </Box>

            {isAction && (
              <ActionButtons
                labels={["Từ chối", "Đồng ý"]}
                handleClick={handleClick}
              />
            )}
          </Box>
          <Box>
            <Typography variant="body2" color="secondary">
              {fromNow(notify?.updatedAt)}
            </Typography>
          </Box>
        </Box>
      </Box>
      <Divider />
      {open && (
        <FormDialog
          open={open}
          notify={notify}
          handleClose={() => setOpen(false)}
        />
      )}
    </>
  );
});

export default ItemNotify;
