import FormControl from "@mui/material/FormControl";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import Select from "@mui/material/Select";
import { useState } from "react";
import { useMembersCompany } from "../../hooks/useCompanies";
import { useChangeOwnerJob } from "../../hooks/useJobs";
import AlertDialog from "../dialog/AlertDialog";

export default function SelectVariants({ job }) {
  const { members, status } = useMembersCompany(job?.company?._id);
  const { mutate: mutateChangeOwner, status: statusChangeOwner } =
    useChangeOwnerJob();
  const [selectedValue, setSelectedValue] = useState(
    job?.owner?._id || job.owner || ""
  );
  const [open, setOpen] = useState(false);
  const [desc, setDesc] = useState("");

  const handleChange = (event) => {
    const source = members.find((member) => member._id === selectedValue);
    const dest = members.find((member) => member._id === event.target.value);
    setDesc(
      `Bạn có chắc chắn muốn chuyển ${source ? source.name : ""} sang ${
        dest.name
      } cho công việc ${job.title}`
    );

    setSelectedValue(event.target.value);

    setOpen(true);
  };

  const handleClose = (value) => {
    setOpen(false);
    setSelectedValue(job.owner._id || job.owner);
  };

  const handleArgee = () => {
    setOpen(false);
    mutateChangeOwner({
      jobId: job._id,
      newOwnerId: selectedValue,
      oldOwnerId: job.owner._id || job.owner,
    });
  };

  if (status === "loading") {
    return <div>Loading...</div>;
  }
  if (status === "error") {
    return <div>Error</div>;
  }

  return (
    <div>
      <FormControl variant="standard" sx={{ m: 1, minWidth: 120 }}>
        <InputLabel id="demo-simple-select-standard-label">
          Phụ trách
        </InputLabel>
        <Select
          labelId="demo-simple-select-standard-label"
          id="demo-simple-select-standard"
          value={selectedValue}
          onChange={handleChange}
          label="Phụ trách"
          disabled={statusChangeOwner === "loading"}
        >
          {members
            ?.filter((el) => el.role !== "manager")
            .map((member) => (
              <MenuItem key={member._id} value={member._id}>
                {member.name}
              </MenuItem>
            ))}

          {selectedValue === "" && (
            <MenuItem value="">
              <em>None</em>
            </MenuItem>
          )}
        </Select>
      </FormControl>
      <AlertDialog
        selectedValue={selectedValue}
        title="Chuyển giao tin chuyển dụng"
        open={open}
        handleClose={handleClose}
        handleAgree={handleArgee}
        desc={desc}
      />
    </div>
  );
}
