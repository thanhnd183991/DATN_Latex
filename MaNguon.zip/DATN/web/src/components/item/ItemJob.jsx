import BookmarkIcon from "@mui/icons-material/Bookmark";
import BookmarkBorderIcon from "@mui/icons-material/BookmarkBorder";
import EventNoteIcon from "@mui/icons-material/EventNote";
import MessageIcon from "@mui/icons-material/Message";
import TelegramIcon from "@mui/icons-material/Telegram";
import {
  Avatar,
  Box,
  Divider,
  IconButton,
  styled,
  Tooltip,
  Typography,
} from "@mui/material";
import Collapse from "@mui/material/Collapse";
import { memo, useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { CONNECT_JOB } from "../../constants/NotifyConstant";
import { useAuth } from "../../hooks/useAuth";
import {
  useFollowingJobMutation,
  useSaveOrApplyJobs,
} from "../../hooks/useJobs";
import { getSocket } from "../../socket";
import { fromNow } from "../../utils/dateUtils";
import CreateApplyModal from "../modal/job/CreateApplyModal";
import ViewApplyModal from "../modal/job/ViewApplyModal";
import BasicApplicantJobTable from "../table/basic/BasicApplicantJobTable";
import SelectMember from "./SelectMember";

const ExpandMore = styled((props) => {
  const { expand, ...other } = props;
  return <IconButton {...other} />;
})(({ theme, expand }) => ({
  marginLeft: "auto",
}));

const ItemJob = memo(({ job, page, isSearchPage }) => {
  const { user: me } = useAuth();
  const isHR =
    me.role === "HR" && job?.owner?._id
      ? job?.owner?._id === me._id
      : job?.owner === me._id;
  const isManager =
    me.role === "manager" && job?.company?._id
      ? me.company === job?.company?._id
      : job?.company === me.company;
  const { mutate } = useFollowingJobMutation();
  const { jobs: saveJobs, statusJobs: statusJobsSaveJobs } = useSaveOrApplyJobs(
    6,
    isHR || isManager ? false : true,
    false
  );
  const { jobs: applyJobs, statusJobs: statusApplyJobs } = useSaveOrApplyJobs(
    6,
    false,
    isHR || isManager ? false : true
  );
  const [openApply, setOpenApply] = useState(false);
  const [viewApply, setViewApply] = useState(false);
  const navigate = useNavigate();

  const handleApplyJob = () => setOpenApply(true);
  const handleClose = () => setOpenApply(false);
  const handleViewApply = () => setViewApply(true);
  const handleViewApplyClose = () => setViewApply(false);
  const [expanded, setExpanded] = useState(false);
  const handleExpandClick = () => {
    if (isHR && job.numApplicants === 0) {
      return;
    }
    setExpanded(!expanded);
  };

  const { isSave, isApply, isRecom } = useMemo(() => {
    let isSave = false;
    let isApply = false;
    if (isHR || isManager) {
      return {
        isSave,
        isApply,
        isRecom: false,
      };
    }

    if (saveJobs) {
      isSave = saveJobs?.data?.some((el) => job._id === el._id);
    }
    if (saveJobs) {
      isApply = applyJobs?.data?.some((el) => job._id === el._id);
    }
    return {
      isSave,
      isApply,
      isRecom: !isSave && !isApply ? true : false,
    };
  }, [saveJobs, applyJobs]);

  const handleSaveJob = () => {
    mutate({ job: job, page, isRecom, isSave, isApply });
  };

  const handleChat = () => {
    getSocket().emit(
      CONNECT_JOB,
      {
        jobId: job._id,
      },
      (data) => {
        if (data.error) {
          toast.error(data.error);
        }
        if (data.success) {
          toast.success(data.success);
        }
        if (data?.data?._id) {
          navigate(`/chat/${data.data._id}`);
        }
      }
    );
  };

  if (statusApplyJobs === "loading" && statusJobsSaveJobs === "loading") {
    return <p>Loading...</p>;
  }
  if (statusApplyJobs === "error" && statusJobsSaveJobs === "error") {
    return <p>Error</p>;
  }

  return (
    <>
      <Box
        sx={{
          display: "flex",
          cursor: "pointer",
          my: 1,
          p: 1,
          borderRadius: 4,
        }}
      >
        <Avatar
          src={
            job?.company?.avatar ||
            "https://ucarecdn.com/279ff8b8-ec1c-4cb9-956e-2039870ed81a/"
          }
          alt="C"
          sx={{ width: 50, height: 50 }}
        />
        <Box ml={2} sx={{ flex: 1 }}>
          <Link
            to={`/job/${job._id}`}
            style={{ textDecoration: "none", display: "flex", flex: 1 }}
          >
            <Box sx={{ display: "flex", flexDirection: "column" }}>
              <Tooltip title={job.title}>
                <Typography
                  variant="body1"
                  sx={{
                    fontWeight: "bold",
                    color: (theme) => theme.palette.action.active,
                    fontSize: "sm",
                    lineHeight: "sm",
                    textDecoration: "underline",
                  }}
                  component="p"
                  className="ellipsis-1-lines"
                >
                  {job.title}
                </Typography>
              </Tooltip>
              <Tooltip title={job?.company?.name || ""}>
                <Typography
                  variant="body2"
                  className="ellipsis-1-lines"
                  component="p"
                  color="text.primary"
                >
                  Công ty: {job?.company?.name}
                </Typography>
              </Tooltip>

              <Tooltip title={job.location}>
                <Typography
                  className="ellipsis-1-lines"
                  variant="body2"
                  component="p"
                  color="text.secondary"
                >
                  Địa điểm: {job.location}
                </Typography>
              </Tooltip>
            </Box>
          </Link>

          <Box sx={{ display: "flex", gap: 1 }}>
            {job?.categories?.map((cat) => (
              <Link
                to={`/search?category=${cat?.name}`}
                style={{ textDecoration: "none" }}
                key={cat?._id}
              >
                <Typography
                  variant="caption"
                  component="span"
                  sx={{
                    py: 0.5,
                    px: 1,
                    borderRadius: 8,
                    bgcolor: "action.hover",
                  }}
                  color="text.secondary"
                >
                  {cat.name}
                </Typography>
              </Link>
            ))}
          </Box>
          <Box sx={{ display: "flex", gap: 1, alignItems: "center" }}>
            <Box
              sx={{
                width: 10,
                height: 10,
                borderRadius: "50%",
                bgcolor: job.active ? "green" : "black",
              }}
            />
            <Typography variant="body2" component="p" color="text.secondary">
              {fromNow(job.deadline)}
            </Typography>
          </Box>
        </Box>
        <Box>
          {isManager ? (
            <>
              {window.location.href.includes("/company") ? (
                <SelectMember job={job} />
              ) : (
                <Typography
                  variant="body2"
                  component="p"
                  color="text.secondary"
                >
                  Thuộc công ty
                </Typography>
              )}
            </>
          ) : isHR ? (
            <>
              {isSearchPage ? (
                <Link
                  to={`/job/${job._id}`}
                  style={{ textDecoration: "none", display: "flex", flex: 1 }}
                >
                  <Typography
                    sx={{ ml: 1, fontWeight: "bold" }}
                    variant="body2"
                    color="text.secondary"
                  >
                    Tiến độ: {job.numApplicants}/{job.numbers}
                  </Typography>
                </Link>
              ) : (
                <ExpandMore
                  onClick={() => handleExpandClick()}
                  sx={{
                    p: 1,
                    borderRadius: 8,
                    border: 1,
                    borderColor: "action.selected",
                  }}
                  expand={expanded}
                  aria-expanded={expanded}
                  aria-label="show more"
                >
                  <Typography
                    sx={{ ml: 1, fontWeight: "bold" }}
                    variant="body2"
                    color="text.secondary"
                  >
                    Tiến độ: {job.numApplicants}/{job.numbers}
                  </Typography>
                </ExpandMore>
              )}
            </>
          ) : isRecom || isSave ? (
            <Box
              sx={{
                display: "flex",
                flexDirection: "column",
                justifyContent: "flex-start ",
              }}
            >
              {me.role === "HR" || me.role === "manager" ? (
                <></>
              ) : (
                <Box>
                  <IconButton aria-label="apply job" onClick={handleApplyJob}>
                    <TelegramIcon />
                  </IconButton>
                </Box>
              )}
              <Box>
                <IconButton aria-label="save job" onClick={handleSaveJob}>
                  {isSave ? <BookmarkIcon /> : <BookmarkBorderIcon />}
                </IconButton>
              </Box>
            </Box>
          ) : isApply ? (
            <Box
              sx={{
                display: "flex",
                flexDirection: "column",
                justifyContent: "flex-start ",
              }}
            >
              <Box>
                <IconButton
                  aria-label="detail apply job"
                  onClick={handleViewApply}
                >
                  <EventNoteIcon />
                </IconButton>
              </Box>
              <Box>
                <IconButton aria-label="chat job" onClick={handleChat}>
                  <MessageIcon />
                </IconButton>
              </Box>
            </Box>
          ) : null}
        </Box>
      </Box>
      <Collapse in={expanded} timeout="auto" unmountOnExit>
        <Divider />
        <BasicApplicantJobTable
          job={job}
          page={page}
          applicants={job.applicants}
        />
      </Collapse>
      {openApply && (
        <CreateApplyModal
          open={openApply}
          jobId={job._id}
          isSave={isSave}
          onClose={handleClose}
        />
      )}
      {viewApply && (
        <ViewApplyModal
          open={viewApply}
          jobId={job._id}
          onClose={handleViewApplyClose}
        />
      )}
    </>
  );
});

export default ItemJob;
