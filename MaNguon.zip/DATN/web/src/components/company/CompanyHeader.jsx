import AddIcon from "@mui/icons-material/Add";
import PhotoCamera from "@mui/icons-material/PhotoCamera";
import {
  Box,
  Button,
  CircularProgress,
  IconButton,
  Paper,
  styled,
  Typography,
} from "@mui/material";
import { useState } from "react";
import Zoom from "react-medium-image-zoom";
import { toast } from "react-toastify";
import { FOLLOW_COMPANY } from "../../constants/NotifyConstant";
import { useUpdateCompanyMutation } from "../../hooks/useCompanies";
import { deleteFile, uploadFile } from "../../services/UploadService";
import { getSocket } from "../../socket";
import { previewImage } from "../../utils/media/image";
import CreateListModal from "../modal/CreateListModal";

const Input = styled("input")({
  display: "none",
});

const CompanyHeader = ({ company, me }) => {
  const { mutate, isLoading } = useUpdateCompanyMutation();
  const [open, setOpen] = useState(false);
  const [type, setType] = useState("");
  const [isUploading, setIsUploading] = useState(false);
  const [newAvatar, setNewAvatar] = useState(null);

  const isFollowing = me?.followingCompany.some((item) => item === company._id);

  const handleSaveAvatar = () => {
    setIsUploading(true);
    Promise.all([uploadFile(newAvatar), deleteFile(company.avatar)])
      .then((rs) => {
        mutate({
          body: {
            avatar: rs[1]?.secure_url || rs[0]?.secure_url,
          },
          companyId: company._id,
          avatar: rs[1]?.secure_url || rs[0]?.secure_url,
          onClose: () => setNewAvatar(null),
        });
        setIsUploading(false);
      })
      .catch((err) => {
        console.log(err);
        setIsUploading(false);
      });
  };
  const infoConnectCompany = {
    numFollowers: "Người theo dõi",
    numJobs: "Công việc",
    numMembers: "Thành viên",
  };

  const handleClose = () => {
    setOpen(false);
  };
  const handleOpen = (type) => {
    setType(type);
    setOpen(true);
  };

  const handleFollow = () => {
    getSocket().emit(FOLLOW_COMPANY, { companyId: company._id }, (data) => {
      if (data.error) {
        toast.error(data.error);
      }
      if (data.success) {
        toast.success(data.success);
      }
    });
  };

  return (
    <>
      <Paper
        sx={{ p: 2, display: "flex", boxShadow: 1, my: 1, borderRadius: 2 }}
      >
        <Box
          sx={{
            borderRadius: 4,
            mr: 2,
            position: "relative",
            width: "200px",
            height: "200px",
          }}
        >
          {newAvatar ? (
            <>
              <img
                src={newAvatar.preview}
                alt="newavatar"
                width="100%"
                height="100%"
                style={{ borderRadius: "10px" }}
                // Revoke data uri after image is loaded
                onLoad={() => {
                  URL.revokeObjectURL(newAvatar.preview);
                }}
              />
              <Button
                onClick={handleSaveAvatar}
                sx={{
                  position: "absolute",
                  bottom: 10,
                  right: 10,
                }}
                variant="contained"
                color="success"
                disabled={isUploading}
              >
                {isUploading ? <CircularProgress size={24} /> : "Lưu"}
              </Button>
            </>
          ) : (
            !isLoading && (
              <Zoom zoomMargin={40}>
                <img
                  src={company?.avatar}
                  alt="avatar"
                  // className="img"
                  style={{ width: "100%", height: "200px" }}
                />
              </Zoom>
              // <img
              //   width="100%"
              //   height="100%"
              //   style={{ borderRadius: "10px" }}
              // />
            )
          )}
          {company?.owner?._id === me._id && (
            <label
              htmlFor="icon-button-file"
              style={{
                position: "absolute",
                top: 0,
                right: 0,
              }}
            >
              <Input
                accept="image/*"
                id="icon-button-file"
                type="file"
                onChange={(event) => previewImage(event, setNewAvatar)}
              />
              <IconButton
                disabled={isUploading}
                color="primary"
                aria-label="upload picture"
                component="span"
              >
                <PhotoCamera />
              </IconButton>
            </label>
          )}
        </Box>
        <Box
          sx={{
            flex: 1,
            display: "flex",
            flexDirection: "column",
            justifyContent: "space-evenly",
          }}
        >
          <Box
            sx={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <Typography variant="h5">{company.name}</Typography>
            {me.role !== "admin" && (
              <Button
                variant="outlined"
                sx={{
                  textTransform: "none",
                  borderRadius: 8,
                }}
                onClick={handleFollow}
                startIcon={<AddIcon />}
              >
                <span className="ellipsis-1-lines">
                  {isFollowing ? "Đang theo dõi" : "Theo dõi"}
                </span>
              </Button>
            )}
          </Box>

          <Typography variant="body1" color="secondary">
            {company?.industry?.name}
          </Typography>
          <Box
            sx={{
              display: "flex",
              gap: 5,
              alignItems: "center",
            }}
          >
            {Object.keys(infoConnectCompany).map((el, index) => (
              <Box
                key={index}
                onClick={() =>
                  el === "numFollowers"
                    ? handleOpen(infoConnectCompany[el])
                    : null
                }
                sx={{
                  display: "flex",
                  alignItems: "center",
                  flexDirection: "column",
                  textAlign: "center",
                  cursor: "pointer",
                }}
              >
                <Typography className="ellipsis-2-lines" variant="body1">
                  {infoConnectCompany[el]}
                </Typography>
                <Typography variant="body1">{company[el]}</Typography>
              </Box>
            ))}
          </Box>
        </Box>
      </Paper>
      {open && (
        <CreateListModal
          companyId={company._id}
          onClose={handleClose}
          label={"Người theo dõi"}
          open={open}
          me={me}
        />
      )}
    </>
  );
};

export default CompanyHeader;
