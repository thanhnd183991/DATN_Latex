import ArrowBackIosNewIcon from "@mui/icons-material/ArrowBackIosNew";
import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";
import { Box, CircularProgress, IconButton, Paper } from "@mui/material";
import { useState } from "react";
import { useAuth } from "../../../hooks/useAuth";
import { useListJobByCompany } from "../../../hooks/useJobs";
import ItemJob from "../../item/ItemJob";

const CompanyListJob = ({ companyId, isHR }) => {
  const [page, setPage] = useState(1);
  const { user: me } = useAuth();

  const { status, data, error, isFetching, isPreviousData } =
    useListJobByCompany({
      companyId,
      isHR,
      page,
      meId: me._id,
      limit: 4,
    });

  return (
    <Paper>
      {status === "loading" ? (
        <div>Loading...</div>
      ) : status === "error" ? (
        <div>Error: {error.message}</div>
      ) : (
        // `data` will either resolve to the latest page's data
        // or if fetching a new page, the last successful page's data
        <div>
          {data.data.map((job) => (
            <ItemJob key={job._id} job={job} page={page} />
          ))}
        </div>
      )}
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          gap: 2,
        }}
      >
        <IconButton
          onClick={() => setPage((old) => Math.max(old - 1, 1))}
          disabled={page === 1}
        >
          <ArrowBackIosNewIcon />
        </IconButton>
        <IconButton
          onClick={() => {
            setPage((old) => (data?.hasMore ? old + 1 : old));
          }}
          disabled={isPreviousData || !data?.hasMore}
        >
          <ArrowForwardIosIcon />
        </IconButton>
      </Box>
      {
        // Since the last page's data potentially sticks around between page requests,
        // we can use `isFetching` to show a background loading
        // indicator since our `status === 'loading'` state won't be triggered
        isFetching ? (
          <Box sx={{ display: "flex" }}>
            <CircularProgress />
          </Box>
        ) : null
      }
    </Paper>
  );
};

export default CompanyListJob;
