import AddIcon from "@mui/icons-material/Add";
import { Button } from "@mui/material";
import Box from "@mui/material/Box";
import Grid from "@mui/material/Grid";
import Typography from "@mui/material/Typography";
import { useState } from "react";
import {
  useMemberCompanyMutation,
  useMembersCompany,
} from "../../../hooks/useCompanies";
import CreateListModal from "../../modal/CreateListModal";
import CompanyItemMember from "../company_item/CompanyItemMember";

export default function CompanyMember({ companyId, isOwner, me }) {
  const { mutate } = useMemberCompanyMutation();
  const [open, setOpen] = useState(false);
  const handleAddMember = () => {
    setOpen(true);
  };
  const handleClose = () => {
    setOpen(false);
  };
  const { members, isLoading } = useMembersCompany(companyId);
  return (
    <>
      <Box sx={{ flexGrow: 1, my: 1, p: 1, bgcolor: "background.paper" }}>
        <Box
          display="flex"
          alignItems="center"
          justifyContent="space-between"
          pb={1}
        >
          <Typography variant="h6">Thành viên</Typography>
          {isOwner && (
            <Button
              variant="outlined"
              sx={{ textTransform: "none" }}
              onClick={handleAddMember}
              startIcon={<AddIcon />}
            >
              Thêm thành viên
            </Button>
          )}
        </Box>
        {isLoading ? (
          <Typography variant="body2">Đang tải...</Typography>
        ) : (
          <Grid container spacing={2}>
            {members.map((mem, index) => (
              <Grid item xs={6} sm={4} md={4} key={index}>
                <CompanyItemMember
                  member={mem}
                  isOwner={isOwner}
                  companyId={companyId}
                />
              </Grid>
            ))}
          </Grid>
        )}
      </Box>
      {open && (
        <CreateListModal
          open={open}
          onClose={handleClose}
          label="Thêm thành viên"
          action="add"
          companyIdToAdd={companyId}
          me={me}
        />
      )}
    </>
  );
}
