import { useMe } from "../../../hooks/useAuth";
import CompanyItemArray from "../company_item/CompanyItemArray";
import CompanyItemObject from "../company_item/CompanyItemObject";
import CompanyItemString from "../company_item/CompanyItemString";

const CompanyDetail = ({ company }) => {
  //   console.log(user);
  const { me, isLoadingMe } = useMe();
  const descString = {
    overview: "Tổng quan",
    website: "Website",
    // industry: "Lĩnh vực",
    headquarters: "Trụ sở",
  };
  const descArray = {};
  const descObject = {};
  return (
    <>
      {isLoadingMe ? (
        <div>Loading...</div>
      ) : (
        <>
          {Object.keys(descArray).map((el, index) => (
            <CompanyItemArray
              data={company[el]}
              label={descArray[el]}
              key={index}
              type={el}
              isOwner={company.owner._id === me._id}
            />
          ))}
          {Object.keys(descString).map((el, index) => (
            <CompanyItemString
              data={el === "industry" ? company[el].name : company[el]}
              label={descString[el]}
              key={index}
              isOwner={company.owner._id === me._id}
              field={el}
              companyId={company._id}
            />
          ))}
          {Object.keys(descObject).map((el, index) => (
            <CompanyItemObject
              data={company[el]}
              label={descObject[el]}
              key={index}
              isOwner={company.owner._id === me._id}
            />
          ))}
        </>
      )}
    </>
  );
};

export default CompanyDetail;
