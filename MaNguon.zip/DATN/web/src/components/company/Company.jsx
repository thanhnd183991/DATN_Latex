import { Box, Skeleton, Stack } from "@mui/material";
import { useMe } from "../../hooks/useAuth";
import { useCompany } from "../../hooks/useCompanies";
import CompanyHeader from "./CompanyHeader";
import CompanyTabs from "./CompanyTabs";

const Company = ({ companyId }) => {
  const { data, status } = useCompany(companyId);
  const { me, isLoadingMe } = useMe();
  // console.log(company);
  return (
    <Box flex={4} p={1}>
      {status === "loading" || isLoadingMe ? (
        <Stack spacing={1}>
          <Skeleton variant="text" height={100} />
          <Skeleton variant="rectangular" height={300} />
          <Skeleton variant="rectangular" height={300} />
        </Stack>
      ) : status === "error" ? (
        <p>error</p>
      ) : (
        <>
          <CompanyHeader company={data} me={me} />
          <CompanyTabs company={data} me={me} />
        </>
      )}
    </Box>
  );
};

export default Company;
