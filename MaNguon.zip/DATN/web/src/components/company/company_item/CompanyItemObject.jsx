import EditIcon from "@mui/icons-material/Edit";
import { Box, Button, Divider, Typography } from "@mui/material";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { MyTextField } from "../../core-form";
import RichText from "../../RichText";

const CompanyItemObject = ({ data, label, isOwner }) => {
  const [isEdit, setIsEdit] = useState(false);
  const { handleSubmit, reset, setValue, control } = useForm({
    defaultValues: data,
  });
  if (!data) return null;
  const checkKeyDown = (e) => {
    if (e.code === "Enter") e.preventDefault();
  };
  const onSubmit = (data) => {
    setIsEdit(false);
    return;
    if (rs.status === 200) {
      // create post
      toast.success("Đăng bài thành công");
      props.onClose();
    } else {
      toast.error("Đăng bài thất bại");
    }
  };
  return (
    <Box
      sx={{ my: 2, boxShadow: 1, borderRadius: 2, bgcolor: "background.color" }}
    >
      <Box
        sx={{
          p: 2,
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          "&:hover": {
            "& > *": {
              display: "block",
            },
          },
        }}
      >
        <Typography variant="h5">{label}</Typography>
        {isOwner && (
          <Box
            onClick={() => setIsEdit(true)}
            sx={{
              display: "none",
              cursor: "pointer",
            }}
          >
            <EditIcon />
          </Box>
        )}
      </Box>
      <Divider />
      {isEdit ? (
        <Box sx={{ py: 1, px: 2 }}>
          <form
            onSubmit={handleSubmit(onSubmit)}
            onKeyDown={(e) => checkKeyDown(e)}
          >
            {Object.keys(data).map((el, index) => (
              <Box
                sx={{
                  display: "flex",
                  gap: 1,
                  alignItems: "center",
                }}
                key={index}
              >
                <Typography
                  sx={{
                    minWidth: 100,
                    fontWeight: "bold",
                  }}
                  variant="body1"
                >
                  {el[0].toUpperCase() + el.slice(1)}
                </Typography>
                <Box flex={1}>
                  <MyTextField name={el} control={control} label="none" />
                </Box>
              </Box>
            ))}
            <Box sx={{ display: "flex" }}>
              <Button
                type="submit"
                variant="contained"
                color="success"
                sx={{
                  margin: "0px auto",
                  width: "30%",
                }}
              >
                Nộp
              </Button>
            </Box>
          </form>
        </Box>
      ) : (
        <Box sx={{ py: 1, px: 2 }}>
          {Object.keys(data).map((el, index) => (
            <Box key={index} sx={{ display: "flex", gap: 1 }}>
              <Typography variant="body1">{el}</Typography>
              <RichText text={data[el]} />
            </Box>
          ))}
        </Box>
      )}
    </Box>
  );
};
export default CompanyItemObject;
