import DeleteOutlineIcon from "@mui/icons-material/DeleteOutline";
import { Avatar, Box, IconButton, Typography } from "@mui/material";
import { useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../../../hooks/useAuth";
import ListJobByHRModal from "../../modal/job/ListJobByHRModal";

const CompanyItemMember = ({ member, isOwner, companyId }) => {
  const { user: me } = useAuth();
  const [HRId, setHRId] = useState(null);
  const handleOpenModal = () => {
    setHRId(member._id);
  };
  return (
    <>
      <Box
        sx={{
          p: 1,
          borderRadius: 3,
          borderWidth: 1,
          borderStyle: "solid",
          borderColor: "action.disabled",
          position: "relative",
        }}
      >
        <Link
          to={me.role !== "admin" ? `/profile/${member._id}` : "/admin/user"}
          style={{ textDecoration: "none" }}
        >
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <Avatar
              sx={{ width: "100px", height: "100px" }}
              src={member.avatar}
            />
            <Typography
              variant="h6"
              color="primary"
              className="ellipsis-1-lines"
            >
              {member.name}
            </Typography>
            <Typography variant="body1" color="secondary">
              {member.role}
            </Typography>
          </Box>
        </Link>
        {isOwner && member.role !== "manager" && (
          <IconButton
            onClick={handleOpenModal}
            sx={{
              position: "absolute",
              top: 0,
              right: 0,
            }}
          >
            <DeleteOutlineIcon />
          </IconButton>
        )}
      </Box>
      {!!HRId && (
        <ListJobByHRModal
          open={!!HRId}
          companyId={companyId}
          onClose={() => setHRId(null)}
          HRId={HRId}
        />
      )}
    </>
  );
};

export default CompanyItemMember;
