import { useState } from "react";
import Feed from "../Feed";
import LayoutTab from "../layout/LayoutTab";
import CompanyDetail from "./company_tabs/CompanyDetail";
import CompanyListJob from "./company_tabs/CompanyListJob";
import CompanyMember from "./company_tabs/CompanyMember";

export default function CompanyTabs({ company, me }) {
  const [value, setValue] = useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const labels = [
    "Tổng quan",
    "Bài đăng",
    "Công việc",
    "Thành viên",
    "Công việc của tôi",
  ];
  const components = [
    <CompanyDetail company={company} />,
    <Feed companyId={company._id} />,
    <CompanyListJob companyId={company._id} />,
    <CompanyMember
      companyId={company._id}
      isOwner={company.owner._id === me._id}
      me={me}
    />,
    <CompanyListJob isHR companyId={company._id} />,
  ];

  return (
    <LayoutTab
      components={
        me.role === "HR" && me.company === company._id
          ? components
          : components.slice(0, 4)
      }
      value={value}
      handleChange={handleChange}
      labels={
        me.role === "HR" && me.company === company._id
          ? labels
          : labels.slice(0, 4)
      }
    />
  );
}
