import MessageIcon from "@mui/icons-material/Message";
import { Box, Paper, Skeleton, Stack } from "@mui/material";
import { Fragment, useCallback, useState } from "react";
import InfiniteScroll from "react-infinite-scroll-component";
import { toast } from "react-toastify";
import { CREATE_MESSAGE } from "../../constants/ChatConstant";
import { useMessages } from "../../hooks/useMessages";
import { deleteFile, uploadFile } from "../../services/UploadService";
import { getSocket } from "../../socket";
import InputComment from "../comment/InputComment";
import ChatRoomHeader from "./ChatRoomHeader";
import ItemMessage from "./ItemMessage";

const ListChat = ({ roomId, me, isLoadingMe }) => {
  const [text, setText] = useState("");
  const [file, setFile] = useState(null);
  const [isUploading, setIsUploading] = useState(false);
  const [replyingTo, setReplyingTo] = useState("");

  const {
    status,
    data,
    error,
    isFetching,
    isFetchingNextPage,
    isFetchingPreviousPage,
    fetchNextPage,
    fetchPreviousPage,
    hasNextPage,
    hasPreviousPage,
  } = useMessages(roomId);

  const handleChangeReplyTo = useCallback((replyingTo) => {
    setReplyingTo(replyingTo);
  }, []);

  const handleSubmit = async (event) => {
    if (event.preventDefault) {
      event.preventDefault();
    }

    if (text.trim() === "" && !file) {
      toast.error("Please enter a message");
      return;
    }
    if (file) {
      try {
        setIsUploading(true);
        const result = await uploadFile(file);
        // console.log(result);
        setIsUploading(false);
        let message = {
          text,
          attachment: {
            file: result.secure_url,
            resource_type: result.resource_type,
            original_filename: file.name,
          },
        };
        if (replyingTo) {
          message = {
            ...message,
            replyingTo: replyingTo._id,
          };
        }
        getSocket().emit(
          CREATE_MESSAGE,
          {
            roomId,
            message,
          },
          async (data) => {
            setText("");
            setFile(null);
            setReplyingTo(null);
            if (data.error) {
              toast.error(data.error);
              await deleteFile(result.secure_url);
            }
          }
        );
      } catch (err) {
        console.log(err);
        setIsUploading(false);
      }
    } else {
      let message = {
        text,
      };
      if (replyingTo) {
        message = {
          ...message,
          replyingTo: replyingTo._id,
        };
      }
      getSocket().emit(
        CREATE_MESSAGE,
        {
          roomId,
          message,
        },
        (data) => {
          setText("");
          setFile(null);
          setReplyingTo(null);
          if (data.error) {
            toast.error(data.error);
          }
        }
      );
    }
  };

  return (
    <Box flex={4} p={2}>
      {status === "loading" ? (
        <Stack spacing={1}>
          <Skeleton variant="text" height={100} />
          <Skeleton variant="text" height={20} />
          <Skeleton variant="text" height={20} />
          <Skeleton variant="rectangular" height={300} />
        </Stack>
      ) : status === "error" ? (
        <span>Error: {error.message}</span>
      ) : (
        <Paper>
          {!roomId || isLoadingMe ? (
            <Box
              sx={{
                height: "83vh",
                overflow: "auto",
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              <MessageIcon sx={{ width: 300, height: 300 }} />
            </Box>
          ) : (
            <Box sx={{ mt: -1 }}>
              <ChatRoomHeader roomId={roomId} me={me} />
              <Box
                sx={{
                  height: "75vh",
                  overflow: "auto",
                  display: "flex",
                  flexDirection: "column",
                }}
              >
                <div
                  id="scrollableDiv"
                  style={{
                    flex: 1,
                    height: "66vh",
                    overflow: "auto",
                    display: "flex",
                    flexDirection: "column-reverse",
                    padding: "5px",
                  }}
                >
                  {/*Put the scroll bar always on the bottom*/}
                  <InfiniteScroll
                    dataLength={data.pages.reduce(
                      (acc, page) => acc + page.data.length,
                      0
                    )}
                    next={fetchNextPage}
                    style={{ display: "flex", flexDirection: "column-reverse" }} //To put endMessage and loader to the top.
                    inverse={true} //
                    hasMore={hasNextPage}
                    loader={<h4>Loading...</h4>}
                    scrollableTarget="scrollableDiv"
                  >
                    {data.pages.map((page, indexPage) => (
                      <Fragment key={page.nextId}>
                        {page.data.map((message, index) => (
                          <ItemMessage
                            page={indexPage}
                            index={index}
                            key={message._id}
                            message={message}
                            me={me}
                            handleChangeReplyTo={handleChangeReplyTo}
                          />
                        ))}
                      </Fragment>
                    ))}
                  </InfiniteScroll>
                </div>
                {/* <input type="text" value={text} onChange={handleText} /> */}
                <InputComment
                  setText={setText}
                  replyingTo={replyingTo}
                  setReplyingTo={handleChangeReplyTo}
                  text={text}
                  image={file}
                  setImage={setFile}
                  handleSubmit={handleSubmit}
                  isLoading={isUploading}
                  backgroundColor="transparent"
                  type="chat"
                />
              </Box>
            </Box>
          )}
        </Paper>
      )}
    </Box>
  );
};

export default ListChat;
