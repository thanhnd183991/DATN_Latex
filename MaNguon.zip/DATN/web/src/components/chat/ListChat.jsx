import { useDispatch, useSelector } from "react-redux";
import { setTabRoom } from "../../redux/features/roomSlice";
import LayoutTabs from "../layout/LayoutTab";
import ListChatType from "./ListChatType";

const ListChat = ({ roomId, isLoadingMe, me }) => {
  const { tabRoom } = useSelector((state) => state.room);
  const dispatch = useDispatch();

  const handleChange = (event, newValue) => {
    // setValue(newValue);
    dispatch(setTabRoom(newValue));
  };

  const labels = ["Cá nhân", "Công việc"];

  const components = [
    <ListChatType
      type="Personal"
      roomId={roomId}
      isLoadingMe={isLoadingMe}
      me={me}
    />,
    <ListChatType
      type="Company"
      roomId={roomId}
      isLoadingMe={isLoadingMe}
      me={me}
    />,
  ];

  return (
    <LayoutTabs
      value={tabRoom}
      handleChange={handleChange}
      labels={labels}
      components={components}
      style={{ p: 0, m: 0 }}
    />
  );
};

export default ListChat;
