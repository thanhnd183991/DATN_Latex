import InsertEmoticonIcon from "@mui/icons-material/InsertEmoticon";
import ReplyIcon from "@mui/icons-material/Reply";
import { Box, Divider, IconButton, Typography } from "@mui/material";
import { styled } from "@mui/material/styles";
import Tooltip, { tooltipClasses } from "@mui/material/Tooltip";
import { memo, useMemo } from "react";
import Zoom from "react-medium-image-zoom";
import { toast } from "react-toastify";
import { REACTION_MESSAGE } from "../../constants/ChatConstant";
import { getSocket } from "../../socket";
import { fromNow } from "../../utils/dateUtils";
import { getPublicId } from "../../utils/media/file";
import ContentHyperlink from "../ContentHyperlink";

const LightTooltip = styled(({ className, ...props }) => (
  <Tooltip {...props} classes={{ popper: className }} />
))(({ theme }) => ({
  [`& .${tooltipClasses.tooltip}`]: {
    backgroundColor: theme.palette.common.white,
    color: "rgba(0, 0, 0, 0.87)",
    boxShadow: theme.shadows[1],
    fontSize: 11,
  },
}));

const ItemMessage = memo(({ message, me, handleChangeReplyTo }) => {
  // console.log("render item message");

  const isMe = useMemo(() => {
    return message.sender === me._id ? true : false;
  }, [message.sender]);

  const handleReaction = () => {
    getSocket().emit(
      REACTION_MESSAGE,
      {
        // roomId: message.roomId,
        messageId: message._id,
        reaction: {
          reaction: "like",
        },
        // page,
        // index,
      },
      (data) => {
        if (data.error) {
          toast.error(data.error);
        }
      }
    );
  };

  return (
    <Box
      sx={{
        display: "flex",
        flexDirection: isMe ? "row-reverse" : "row",
        alignItems: "center",
        justifyContent: "space-between",
        // p: { xs: 1, md: 2 },
        maxWidth: "100%",
        mb: 1,
        "&:hover": {
          cursor: "pointer",
          "& > *": {
            display: "block",
          },
        },
      }}
    >
      <Box sx={{ display: "flex", maxWidth: "75%" }}>
        <Box
          sx={{
            color: isMe ? "primary.contrastText" : "text.primary",
            bgcolor: isMe ? "primary.main" : "action.hover",
            p: 1,
            borderRadius: 4,
          }}
        >
          {message.replyingTo && (
            <>
              <Typography
                variant="body2"
                sx={{
                  color: isMe ? "primary.contrastText" : "text.primary",
                }}
              >
                <span style={{ fontStyle: "italic" }}>Phản hồi tin nhắn:</span>{" "}
                {message.replyingTo.text || "Reply file"}
              </Typography>
              <Divider
                sx={{
                  color: isMe ? "primary.contrastText" : "text.primary",
                }}
              />
            </>
          )}
          {message.text && (
            <LightTooltip title={fromNow(message.createdAt)}>
              <ContentHyperlink contentText={message.text} />
            </LightTooltip>
          )}
          {message.attachment && message.attachment.resource_type === "image" && (
            <Zoom zoomMargin={40}>
              <img
                src={message.attachment.file}
                alt="attachment"
                style={{ maxWidth: "200px", maxHeight: "200px" }}
              />
            </Zoom>
          )}
          {message.attachment && message.attachment.resource_type === "video" && (
            <Zoom zoomMargin={40}>
              <video
                src={message.attachment.file}
                autoPlay={false}
                muted={true}
                loop={false}
              />
            </Zoom>
          )}
          {message.attachment && message.attachment.resource_type === "raw" && (
            <Box>
              Download{" "}
              <a
                style={{ color: isMe ? "white" : "black" }}
                href={message.attachment.file}
                target="_blank"
              >
                {message.attachment.original_filename}
              </a>
            </Box>
          )}
          {message.reactions.length > 0 && (
            <Typography
              variant="body2"
              sx={{
                marginLeft: "auto",
              }}
            >
              {message.reactions.length} 👍
            </Typography>
          )}
        </Box>
      </Box>
      <Box
        onClick={() => handleChangeReplyTo(message)}
        sx={{
          display: "none",
        }}
      >
        <IconButton>
          <ReplyIcon />
        </IconButton>
      </Box>

      <Box
        onClick={handleReaction}
        sx={{
          display: "none",
        }}
      >
        <IconButton>
          <InsertEmoticonIcon />
        </IconButton>
      </Box>

      <Box flex={1} />
    </Box>
  );
});

export default ItemMessage;
