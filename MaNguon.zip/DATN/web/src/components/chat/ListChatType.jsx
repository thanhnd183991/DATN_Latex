import { Box, Button, Skeleton, Stack } from "@mui/material";
import { Fragment, useEffect } from "react";
import { useInView } from "react-intersection-observer";
import { useRooms } from "../../hooks/useChats";
import ItemChat from "./ItemChat";

const ListChatType = ({ type, roomId, isLoadingMe, me }) => {
  const { ref, inView } = useInView();

  const {
    status,
    data,
    error,
    isFetching,
    isFetchingNextPage,
    isFetchingPreviousPage,
    fetchNextPage,
    fetchPreviousPage,
    hasNextPage,
    hasPreviousPage,
  } = useRooms(type);

  useEffect(() => {
    if (inView) {
      fetchNextPage();
    }
  }, [inView]);

  if (isLoadingMe) {
    return <p>Loading...</p>;
  }

  return (
    <Box sx={{ height: "73vh", overflow: "auto" }}>
      {status === "loading" ? (
        <Stack spacing={1}>
          <Skeleton variant="text" height={200} />
        </Stack>
      ) : status === "error" ? (
        <span>Error: {error.message}</span>
      ) : (
        <>
          {data.pages.map((page) => (
            <Fragment key={page.nextId}>
              {page.data.map((chat) => (
                <ItemChat key={chat._id} room={chat} roomId={roomId} me={me} />
              ))}
            </Fragment>
          ))}
          <div>
            <Button
              ref={ref}
              variant="text"
              onClick={() => fetchNextPage()}
              disabled={!hasNextPage || isFetchingNextPage}
              sx={{
                textTransform: "none",
              }}
            >
              {isFetchingNextPage
                ? "Loading more..."
                : hasNextPage
                ? "Load Newer"
                : "End"}
            </Button>
          </div>
          <div>
            {isFetching && !isFetchingNextPage
              ? "Background Updating..."
              : null}
          </div>
        </>
      )}
    </Box>
  );
};

export default ListChatType;
