import {
  Box,
  Divider,
  FormControlLabel,
  Switch,
  Typography,
} from "@mui/material";
import { memo, useMemo } from "react";
import { useDispatch } from "react-redux";
import { toast } from "react-toastify";
import { BLOCK_ROOM } from "../../constants/ChatConstant";
import { useRoom } from "../../hooks/useChats";
import { setTabRoom } from "../../redux/features/roomSlice";
import { getSocket } from "../../socket";

const ChatRoomHeader = memo(({ roomId, me }) => {
  const dispatch = useDispatch();
  const { room, isLoadingRoom, isSuccess } = useRoom(roomId);
  if (isSuccess || room) {
    dispatch(setTabRoom(room.roomType === "Personal" ? 0 : 1));
  }

  const handleActive = (e) => {
    getSocket().emit(
      BLOCK_ROOM,
      { roomId: room._id, active: e.target.checked },
      (data) => {
        if (data.error) {
          toast.error(data.error);
        }
      }
    );
  };

  const { avatarRoom, nameRoom } = useMemo(() => {
    let avatarRoom = null;
    let nameRoom = null;
    if (!isLoadingRoom) {
      for (let i = 0; i < room.members.length; i++) {
        // console.log(room.members[i]);
        if (room.members[i]._id !== me._id) {
          avatarRoom = room.members[i].avatar;
          nameRoom = room.members[i].name;
          break;
        }
      }
      if (room.roomType === "Company") {
        if (me.role !== "HR") {
          avatarRoom = room.company?.avatar || "";
          nameRoom = room.roomName;
        }
      }
    }
    return {
      avatarRoom,
      nameRoom,
    };
  }, [roomId, isLoadingRoom]);

  if (isLoadingRoom) {
    return (
      <Box p={1}>
        <Typography variant="h6">Loading...</Typography>
      </Box>
    );
  }

  return (
    <>
      <Box
        display="flex"
        flexDirection="row"
        height="49px"
        alignItems="center"
        justifyContent="space-between"
        p={{ xs: 1, md: 2 }}
        sx={{
          mt: 1,
        }}
      >
        <Box flex={1}>
          {" "}
          <Typography variant="h6">{nameRoom}</Typography>{" "}
        </Box>
        {room.blocked && room.blocked !== me._id ? (
          <Box>
            <Typography variant="h6" color="secondary">
              Đã bị khóa
            </Typography>
          </Box>
        ) : (
          <FormControlLabel
            control={
              <Switch checked={room.active} onChange={(e) => handleActive(e)} />
            }
            label={room.active ? "Mở" : "Đóng"}
          />
        )}
      </Box>
      <Divider />
    </>
  );
});

export default ChatRoomHeader;
