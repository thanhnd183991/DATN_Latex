import { Avatar, Box, Divider, Typography } from "@mui/material";
import { useMemo } from "react";
import { Link } from "react-router-dom";
import { fromNow } from "../../utils/dateUtils";

const ItemChat = ({ room, roomId: roomIdParam, me }) => {
  const { avatarRoom, nameRoom } = useMemo(() => {
    let avatarRoom = null;
    let nameRoom = null;
    for (let i = 0; i < room.members.length; i++) {
      // console.log(room.members[i]);
      if (room.members[i]._id !== me._id) {
        avatarRoom = room.members[i].avatar;
        nameRoom = room.members[i].name;
        break;
      }
    }
    if (room.roomType === "Company") {
      if (me.role !== "HR") {
        avatarRoom = room.company?.avatar || "";
        nameRoom = room.roomName;
      }
    }
    return {
      avatarRoom,
      nameRoom,
    };
  }, [room]);
  return (
    <>
      <Link to={`/chat/${room._id}`} style={{ textDecoration: "none" }}>
        <Box
          sx={{
            p: 2,
            cursor: "pointer",
            display: "flex",
            gap: 1,
            borderRadius: 1,
            "&:hover": {
              backgroundColor: (theme) => theme.palette.action.hover,
            },
            bgcolor:
              roomIdParam === room._id ? "action.hover" : "background.paper",
          }}
        >
          <Box>
            <Avatar src={avatarRoom} alt="A" />
          </Box>
          <Box flex={1}>
            <Typography color="textPrimary" variant="body1" component="p">
              {nameRoom}
            </Typography>
            <Typography
              className="ellipsis-1-lines"
              variant="body2"
              color="secondary"
            >
              {room?.latestMessage
                ? room.latestMessage.text || "Gửi đính kèm"
                : "Chưa có tin nhắn"}
            </Typography>
            {/* <Typography variant="body2">{room.roomType}</Typography> */}
          </Box>
          <Box>
            <Typography variant="body2" color="secondary">
              {fromNow(room?.latestMessage?.createdAt)}
            </Typography>
          </Box>
        </Box>
      </Link>
      <Divider />
    </>
  );
};

export default ItemChat;
