import ArrowBackIosNewIcon from "@mui/icons-material/ArrowBackIosNew";
import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";
import { Box, CircularProgress, Grid, IconButton } from "@mui/material";
import { useState } from "react";
import { useMe } from "../../hooks/useAuth";
import { useSearchPage } from "../../hooks/useSearch";
import ItemCompany from "../item/ItemCompany";
import ItemJob from "../item/ItemJob";
import ItemUser from "../item/ItemUser";
import LayoutPagination from "../layout/LayoutPagination";

const ListSearch = ({ model, params }) => {
  const [page, setPage] = useState(0);
  const { me, isLoadingMe } = useMe();

  const { status, data, error, isFetching, isPreviousData } = useSearchPage({
    model,
    page,
    setPage,
    limit: 6,
    columnField: model === "job" ? "title" : "name",
    operatorValue: "contains",
    params,
  });
  if (isLoadingMe) {
    return <CircularProgress />;
  }

  return (
    <div>
      {status === "loading" ? (
        <div>Loading...</div>
      ) : status === "error" ? (
        <div>Error: {error.message}</div>
      ) : (
        // `data` will either resolve to the latest page's data
        // or if fetching a new page, the last successful page's data
        <div>
          <Grid container spacing={1}>
            {model === "user" || params.suggestion === "user"
              ? data.data.map((user) => (
                  <Grid item sm={12} md={6} key={user._id}>
                    <Box
                      sx={{
                        border: "1px solid #e0e0e0",
                        borderRadius: 5,
                      }}
                    >
                      <ItemUser user={user} me={me} />
                    </Box>
                  </Grid>
                ))
              : model === "job" || params.suggestion === "job"
              ? data.data.map((job) => (
                  <Grid item xs={12} sm={12} md={12} lg={6} key={job._id}>
                    <Box
                      sx={{
                        border: "1px solid #e0e0e0",
                        borderRadius: 5,
                      }}
                    >
                      <ItemJob job={job} page={page} isSearchPage />
                    </Box>
                  </Grid>
                ))
              : model === "company" || params.suggestion === "company"
              ? data.data.map((company) => (
                  <Grid item sm={12} md={6} key={company._id}>
                    <Box
                      sx={{
                        border: "1px solid #e0e0e0",
                        borderRadius: 5,
                      }}
                    >
                      <ItemCompany company={company} />
                    </Box>
                  </Grid>
                ))
              : null}
          </Grid>
        </div>
      )}
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          gap: 2,
        }}
      >
        <IconButton
          onClick={() => setPage((old) => Math.max(old - 1, 0))}
          disabled={page === 0}
        >
          <ArrowBackIosNewIcon />
        </IconButton>
        <IconButton
          onClick={() => {
            setPage((old) => (data?.hasMore ? old + 1 : old));
          }}
          disabled={isPreviousData || !data?.hasMore}
        >
          <ArrowForwardIosIcon />
        </IconButton>
      </Box>
      {
        // Since the last page's data potentially sticks around between page requests,
        // we can use `isFetching` to show a background loading
        // indicator since our `status === 'loading'` state won't be triggered
        isFetching ? (
          <Box sx={{ display: "flex" }}>
            <CircularProgress />
          </Box>
        ) : null
      }
    </div>
  );
};

export default ListSearch;
