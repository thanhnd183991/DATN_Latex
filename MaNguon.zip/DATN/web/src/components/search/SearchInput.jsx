import ApartmentIcon from "@mui/icons-material/Apartment";
import CategoryIcon from "@mui/icons-material/Category";
import PersonIcon from "@mui/icons-material/Person";
import WorkIcon from "@mui/icons-material/Work";
import { Box, InputBase, styled, Typography } from "@mui/material";
import { useEffect, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { useSearchInput } from "../../hooks/useSearch";

const Search = styled("div")(({ theme }) => ({
  backgroundColor: "white",
  padding: "0 10px",
  borderRadius: 5,
  height: 30,
}));

const MyUl = styled("ul")(({ theme }) => ({
  position: "absolute",
  zIndex: 90,
  top: 30,
  left: 0,
  listStyleType: "none",
}));

const MyLi = styled("li")(({ theme }) => ({
  color: theme.palette.text.primary,
  width: "100%",
  padding: 2,
  cursor: "pointer",
  backgroundColor: theme.palette.background.paper,
  "&:hover": {
    backgroundColor: "lightgrey",
    zIndex: 90,
  },
}));

const ItemSuggestion = ({ Icon, name, text }) => (
  <Box
    display="flex"
    alignItems="center"
    sx={{ justifyContent: "space-between" }}
  >
    <Box display="flex" alignItems="center">
      <Icon />
      <Typography component="span" sx={{ ml: 1 }}>
        {name}
      </Typography>
    </Box>
    <Box>
      <Typography color="secondary" component="span">
        {text}
      </Typography>
    </Box>
  </Box>
);

const SearchInput = ({ width = 500 }) => {
  const navigate = useNavigate();
  const ref = useRef();
  const {
    suggestions,
    suggestionsActive,
    setSuggestionsActive,
    suggestionIndex,
    setSuggestionIndex,
    value,
    setValue,
    isSearching,
    isEnter,
    setIsEnter,
    setIsSearching,
  } = useSearchInput();

  useEffect(() => {
    const handleClickOutside = (event) => {
      const isClickInsideElement = ref?.current?.contains(event.target);
      if (!isClickInsideElement) {
        //Do something click is outside specified element
        // console.log("click outside input search");
        if (isEnter) {
          setIsEnter(false);
        }
        if (suggestionIndex !== -1) {
          setSuggestionIndex(-1);
        }
      }
    };

    document.body.addEventListener("click", handleClickOutside);
    // remove event listener when unmount
    return () => {
      document.body.removeEventListener("click", handleClickOutside);
    };
  }, []);

  const handleClick = (e) => {
    let tmp = null;
    setIsEnter(true);
    if (
      suggestions &&
      suggestions.length > 0 &&
      suggestionIndex < suggestions.length &&
      suggestionIndex >= 0
    ) {
      setValue(
        suggestions[suggestionIndex]?.name ||
          suggestions[suggestionIndex]?.title
      );
      tmp = suggestions[suggestionIndex];
    } else {
      setValue(value);
      tmp = value;
    }
    setSuggestionIndex(-1);
    setSuggestionsActive(false);
    setIsSearching(false);
    e.target.blur();
    if (typeof tmp === "string") {
      // la 1 key word
      navigate(`/search?keyword=${encodeURI(tmp)}`);
    } else {
      // la mot doi tuong
      if (tmp.role) {
        navigate(`/profile/${tmp._id}`);
      } else if (tmp.website) {
        navigate(`/company/${tmp._id}`);
      } else if (tmp.title) {
        navigate(`/job/${tmp._id}`);
      } else if (tmp.numJobs && tmp.numJobs >= 0) {
        navigate(`/search?category=${tmp.name}`);
      }
    }
  };

  const handleKeyDown = (e) => {
    // UP ARROW
    if (e.keyCode === 38) {
      // console.log("key up arrow");
      if (suggestionIndex === 0) {
        return;
      }
      setSuggestionIndex(suggestionIndex - 1);
    }
    // DOWN ARROW
    else if (e.keyCode === 40) {
      // console.log("key down arrow");
      if (suggestionIndex + 1 === suggestions.length) {
        setSuggestionIndex(-1);
        return;
      }
      setSuggestionIndex(suggestionIndex + 1);
    }
    // ENTER
    else if (e.keyCode === 13) {
      handleClick(e);
    }
  };

  const Suggestions = () => {
    // console.log(suggestionIndex);
    return (
      <MyUl>
        {suggestions?.map((suggestion, index) => {
          return (
            <MyLi
              style={{
                backgroundColor: suggestionIndex === index ? "lightgrey" : "",
                width,
              }}
              key={suggestion._id || index}
              onClick={handleClick}
              onMouseEnter={() => {
                setSuggestionIndex(index);
              }}
            >
              <ItemSuggestion
                Icon={
                  suggestion.website
                    ? ApartmentIcon
                    : suggestion.role
                    ? PersonIcon
                    : suggestion.title
                    ? WorkIcon
                    : CategoryIcon
                }
                name={suggestion.name || suggestion.title}
                text={
                  suggestion.numFollowers || suggestion.numFollowers === 0
                    ? `${suggestion.numFollowers} theo dõi`
                    : `${suggestion.numJobs} công việc`
                }
              />
            </MyLi>
          );
        })}
      </MyUl>
    );
  };

  return (
    <Box sx={{ position: "relative", width: "100%" }}>
      <Search
        sx={{
          bgcolor: (theme) => theme.palette.divider,
          color: "primary.main",
        }}
      >
        <InputBase
          sx={{ width: "100%" }}
          value={value}
          ref={ref}
          onChange={(e) => {
            // console.log("onchange", e.target.value);
            if (isEnter) {
              setIsEnter(false);
            }
            setSuggestionsActive(true);
            setValue(e.target.value || "");
          }}
          onKeyDown={handleKeyDown}
          placeholder="Tìm kiếm..."
          onBlur={() => {
            setTimeout(() => {
              // console.log("trigger");
              setIsEnter(true);
              // setSuggestions([]);
              setSuggestionsActive(false);
            }, 100);
          }}
        />
      </Search>
      {isSearching && <div>Searching ...</div>}
      {suggestionsActive && <Suggestions />}
    </Box>
  );
};

export default SearchInput;
