import { Box, Paper } from "@mui/material";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import LayoutTabs from "../layout/LayoutTab";
import ListSearch from "./ListSearch";

const SearchTabs = ({ params }) => {
  const navigate = useNavigate();
  const [value, setValue] = useState(0);

  useEffect(() => {
    if (params.type) {
      setValue(+params.type);
    }
  }, [params.type]);

  useEffect(() => {
    if (params.category) {
      setValue(1);
    }
  }, [params.category]);

  useEffect(() => {
    if (params.suggestion) {
      if (params.suggestion === "user") {
        setValue(0);
      } else if (params.suggestion === "job") {
        setValue(1);
      } else if (params.suggestion === "company") {
        setValue(2);
      }
    }
  }, [params.suggestion]);

  const handleChange = (event, newValue) => {
    if (params.suggestion) {
      if (newValue === 0) {
        navigate(`/search?suggestion=user`);
      } else if (newValue === 1) {
        navigate(`/search?suggestion=job`);
      } else if (newValue === 2) {
        navigate(`/search?suggestion=company`);
      }
    } else {
      setValue(newValue);
    }
  };

  const labels = ["Người", "Công việc", "Công ty"];

  const components = [
    <ListSearch model={params.suggestion ? null : "user"} params={params} />,
    <ListSearch model={params.suggestion ? null : "job"} params={params} />,
    <ListSearch model={params.suggestion ? null : "company"} params={params} />,
  ];

  return (
    <Box flex={6.5} p={2}>
      <Paper sx={{ p: 1 }}>
        <LayoutTabs
          value={value}
          handleChange={handleChange}
          labels={labels}
          components={components}
        />
      </Paper>
    </Box>
  );
};

export default SearchTabs;
