import { Box, Typography } from "@mui/material";
import { useEffect, useState } from "react";
import {
  detectURLs,
  getSites,
  replaceURLs,
  siteData,
} from "../utils/media/hyperlink";

const blue = "#3777f0";
const grey = "lightgrey";
const ContentHyperlink = ({
  contentText,
  post = false,
  styleMessage,
  stylePost,
  styleComment,
}) => {
  const arrayHyperlink = detectURLs(contentText);
  const [websites, setWebsites] = useState([]);

  const createMarkup = () => {
    const str = replaceURLs(contentText);
    return {
      __html: str,
    };
  };

  const handleClickLink = (url) => {
    // toast.info(`Đang mở trang ${JSON.stringify(url)}`);
    console.log(url);
    window.open(url, "_blank");
  };

  useEffect(() => {
    getSites([...arrayHyperlink])
      .processSites()
      .then((sites) => {
        const rs = [];
        for (let i in sites) {
          let site = sites[i];
          let data = siteData(site);
          data.getMetaTags();
          data.cleanTags();
          rs.push({ ...data.preview, linkUrl: arrayHyperlink[i] });
        }
        setWebsites(rs);
      });
  }, []);
  return (
    <Box>
      <Typography
        dangerouslySetInnerHTML={createMarkup()}
        variant={post ? "body1" : "body2"}
        component="span"
        // color="primary"
        sx={{
          wordBreak: "break-word",
        }}
      />
      {websites &&
        websites.length > 0 &&
        websites.map((item, index) => (
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              cursor: "pointer",
            }}
            onClick={() => handleClickLink(item?.linkUrl || "www.google.com")}
            key={index}
          >
            <img
              src={item.image}
              style={{
                objectFit: "cover",
                display: "block",
                height: "150px",
                width: "150px",
              }}
            />
            <Typography variant="body2" component="span" color="inherit">
              {item?.title}
            </Typography>
            {item.description && (
              <Typography
                variant="body2"
                component="span"
                color="inherit"
                className="ellipsis-2-lines"
              >
                {item?.description}
              </Typography>
            )}
          </Box>
        ))}
    </Box>
  );
};

export default ContentHyperlink;
