import { ReactionBarSelector } from "@charkour/react-reactions";
import { Fragment } from "react";

export default function Reaction() {
  const buildNode = (emoji) => <div>{emoji}</div>;

  const reactions = [
    { label: "Upvote", node: buildNode("👍") },
    { label: "Funny", node: buildNode("😛") },
    { label: "Love", node: buildNode("😍") },
    { label: "Surprised", node: buildNode("😮") },
    { label: "Angry", node: buildNode("😤") },
    { label: "Sad", node: buildNode("😥") },
  ];

  const handleClick = (reaction) => {
    console.warn(reaction);
  };

  return (
    <Fragment>
      <ReactionBarSelector reactions={reactions} onSelect={handleClick} />
    </Fragment>
  );
}
