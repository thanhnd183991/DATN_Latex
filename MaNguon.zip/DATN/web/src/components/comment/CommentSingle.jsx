import { Avatar, Box, CircularProgress, Typography } from "@mui/material";
import { memo, useState } from "react";
import {
  useCommentPostMutation,
  useInfoChildrenCommentPost,
  useReactionCommentPostMutation,
} from "../../hooks/post/useCommentPost";
import { uploadFile } from "../../services/UploadService";
import { fromNow } from "../../utils/dateUtils";
import ContentHyperlink from "../ContentHyperlink";
import ImageModal from "../modal/ImageModal";
import InputComment from "./InputComment";

const CommentSingle = memo(
  ({ comment, deep, user, defaultEnabled = false, defaultReplyId = null }) => {
    const [replyId, setReplyId] = useState(defaultReplyId);
    const [enabled, setEnabled] = useState(defaultEnabled);
    const [open, setOpen] = useState(false);
    const {
      childrenComment,
      isLoadingChildrenComment,
      refetchChildrenComment,
    } = useInfoChildrenCommentPost(comment._id, {
      enabled,
    });
    const { mutate, isLoading, isSuccess } = useCommentPostMutation();
    const { mutate: reactionCmtMutate } = useReactionCommentPostMutation();
    const [commentInput, setCommentInput] = useState("");
    const [image, setImage] = useState(null);
    const [isUploading, setIsUploading] = useState(false);

    const handleClose = () => {
      setOpen(false);
    };
    const handleOpen = () => {
      setOpen(true);
    };

    //root comment
    const handleSubmit = async (event) => {
      if (user.role === "admin") return;
      if (event.preventDefault) {
        event.preventDefault();
      }
      if (commentInput.trim() === "" && !image) {
        return;
      }
      if (image) {
        setIsUploading(true);
        const result = await uploadFile(image);
        setIsUploading(false);
        mutate({
          file: {
            file: result.secure_url,
            resource_type: result.resource_type,
            original_filename: image.name,
          },
          text: commentInput,
          rootId: replyId,
          postId: comment.postId,
        });
        setCommentInput("");
        setImage(null);
      } else {
        mutate({
          text: commentInput,
          rootId: replyId,
          postId: comment.postId,
        });
        setCommentInput("");
        setImage(null);
      }
    };

    const handleReplyComment = () => {
      if (replyId) {
        setReplyId(null);
      } else {
        setReplyId(comment._id);
        setEnabled(true);
        refetchChildrenComment();
      }
    };

    const handleReactionComment = () => {
      // console.log(comment);
      if (user.role === "admin") return;
      reactionCmtMutate({
        commentId: comment._id,
        postId: comment.postId,
        reaction: "like",
        root: comment.root ? comment.root : null,
      });
    };

    return (
      <>
        <Box sx={{ my: 1 }}>
          <Box sx={{ marginLeft: deep * 45 + "px", display: "flex" }}>
            <Avatar
              src={comment.userId.avatar}
              alt="Bj"
              sx={{ bgcolor: "red", marginRight: 1 }}
            />
            <Box>
              <Box
                sx={{
                  bgcolor: (theme) => theme.palette.action.hover,
                  display: "flex",
                  justifyContent: "space-between",
                  p: 1,
                  mr: 1,
                  borderRadius: 5,
                }}
              >
                <Box>
                  <Typography sx={{ fontWeight: "bold" }}>
                    {comment.userId.name}
                  </Typography>
                  {comment?.content && (
                    <ContentHyperlink
                      styleComment={{}}
                      contentText={comment.content}
                    />
                  )}
                  {comment?.file?.file && (
                    <Box
                      onClick={() => handleOpen()}
                      sx={{
                        width: "auto",
                        cursor: "pointer",
                        height: "100px",
                      }}
                    >
                      <img
                        src={comment.file.file}
                        alt="image"
                        style={{ width: "100%", height: "100%" }}
                      />
                    </Box>
                  )}
                </Box>
                {comment?.reactions?.length > 0 && (
                  <Typography
                    sx={{
                      fontWeight: "bold",
                      color: "textSecondary",
                      fontSize: "14px",
                      marginTop: "-5px",
                    }}
                  >
                    {comment.reactions.length} 👍
                  </Typography>
                )}
              </Box>

              <Box sx={{ display: "flex", gap: 1 }}>
                <Typography variant="body2" comonent="span" color="secondary">
                  {fromNow(comment.createdAt)}
                </Typography>
                <Typography
                  onClick={handleReactionComment}
                  variant="body2"
                  sx={{ cursor: "pointer" }}
                  comonent="span"
                  color="secondary"
                >
                  Thích
                </Typography>
                <Typography
                  variant="body2"
                  comonent="span"
                  color="secondary"
                  sx={{
                    cursor: "pointer",
                  }}
                  onClick={() => handleReplyComment()}
                >
                  Phản hồi
                </Typography>
              </Box>
            </Box>
          </Box>
          {(comment.children.length > 0 || childrenComment?.data?.length > 0) &&
            !replyId && (
              <Typography
                onClick={() => handleReplyComment()}
                sx={{
                  marginLeft: deep * 45 + 45 + "px",
                  color: "text.secondary",
                  cursor: "pointer",
                  fontSize: "13px",
                  textDecoration: "underline",
                }}
              >
                {childrenComment?.data?.length || comment.children.length} trả
                lời
              </Typography>
            )}

          {(comment.children.length > 0 || childrenComment?.data?.length > 0) &&
            replyId && (
              <>
                {isLoadingChildrenComment ? (
                  <CircularProgress />
                ) : (
                  <>
                    {childrenComment?.data?.map((cmt, index) => (
                      <CommentSingle
                        key={cmt._id}
                        replyId={isSuccess ? replyId : null}
                        user={user}
                        comment={cmt}
                        deep={deep + 1}
                      />
                    ))}
                  </>
                )}
              </>
            )}
          {replyId && user?.role !== "admin" && (
            <Box sx={{ marginLeft: deep * 45 + 35 + "px" }}>
              <InputComment
                setText={setCommentInput}
                text={commentInput}
                image={image}
                setImage={setImage}
                handleSubmit={handleSubmit}
                isLoading={isLoading || isUploading}
              />
            </Box>
          )}
        </Box>
        <ImageModal
          open={open}
          images={[comment.image]}
          onClose={handleClose}
        />
      </>
    );
  }
);
export default CommentSingle;
