import AttachFileIcon from "@mui/icons-material/AttachFile";
import CloseIcon from "@mui/icons-material/Close";
import ImageIcon from "@mui/icons-material/Image";
import SendIcon from "@mui/icons-material/Send";
import { Box, styled, Typography } from "@mui/material";
import Divider from "@mui/material/Divider";
import IconButton from "@mui/material/IconButton";
import Paper from "@mui/material/Paper";
import InputEmoji from "react-input-emoji";

const Input = styled("input")({
  display: "none",
});

export default function InputComment({
  handleSubmit,
  type,
  setText,
  text,
  isLoading,
  setReplyingTo,
  replyingTo,
  image,
  setImage,
  backgroundColor = "action.hover",
}) {
  const previewImage = (event, type) => {
    if (type === "chat") {
      const file = event.target.files[0];
      setImage(file);
    } else {
      const file = event.target.files[0];
      setImage(
        Object.assign(file, {
          preview: URL.createObjectURL(file),
        })
      );
    }
  };

  return (
    <div
      style={{
        cursor: isLoading ? "not-allowed" : "auto",
      }}
    >
      {image && (
        <div
          style={{
            position: "relative",
            overflow: "hidden",
            paddding: 1,
            backgroundColor: "secondary",
          }}
        >
          {image.preview ? (
            <img
              src={image.preview}
              style={{ width: "100px", height: "100px" }}
              // Revoke data uri after image is loaded
              onLoad={() => {
                URL.revokeObjectURL(image.preview);
              }}
            />
          ) : (
            <Typography sx={{ pr: 2 }}>
              {image.name || image.pathname || "file"}
            </Typography>
          )}

          <IconButton
            onClick={() => {
              setImage(null);
            }}
            sx={{ position: "absolute", top: "-5px", right: "-5px" }}
          >
            <CloseIcon sx={{ width: "20px", height: "20px" }} />
          </IconButton>
        </div>
      )}
      {isLoading && (
        <Typography color="secondary" variant="caption">
          Đang gửi...
        </Typography>
      )}
      {replyingTo && (
        <Box
          sx={{
            position: "relative",
            overflow: "hidden",
            paddding: 1,
            backgroundColor: "secondary",
          }}
        >
          <Typography color="secondary" variant="caption" sx={{ p: 2 }}>
            Trả lời: {replyingTo.text || "File đính kèm"}
          </Typography>
          <IconButton
            onClick={() => {
              setReplyingTo(null);
            }}
            sx={{ position: "absolute", top: "-5px", right: "-5px" }}
          >
            <CloseIcon sx={{ width: "20px", height: "20px" }} />
          </IconButton>
        </Box>
      )}
      <Paper
        elevation={0}
        component="form"
        sx={{
          p: "2px 4px",
          display: "flex",
          alignItems: "center",
          bgcolor: backgroundColor,
          borderRadius: 8,
          position: "relative",
          width: "100%",
        }}
      >
        <InputEmoji
          value={text}
          onChange={setText}
          cleanOnEnter
          onEnter={handleSubmit}
          placeholder="Type a message"
        />

        <label htmlFor="icon-button-file">
          <Input
            onChange={(event) => previewImage(event, null)}
            accept="image/*"
            id="icon-button-file"
            type="file"
          />

          <IconButton
            color="primary"
            aria-label="upload picture"
            component="span"
          >
            <ImageIcon />
          </IconButton>
        </label>

        {type === "chat" && (
          <label htmlFor="icon-button-file-chat">
            <Input
              onChange={(event) => previewImage(event, type)}
              // accept="image/*"
              id="icon-button-file-chat"
              type="file"
            />
            <IconButton color="primary" component="span">
              <AttachFileIcon />
            </IconButton>
          </label>
        )}

        <Divider sx={{ height: 28, m: 0.5 }} orientation="vertical" />
        <IconButton
          onClick={handleSubmit}
          color="primary"
          sx={{ p: "10px" }}
          aria-label="search"
        >
          <SendIcon />
        </IconButton>
      </Paper>
    </div>
  );
}
