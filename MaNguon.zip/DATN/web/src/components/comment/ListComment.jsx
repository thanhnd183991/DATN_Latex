import { Box, CircularProgress } from "@mui/material";
import { useState } from "react";
import {
  useCommentPostMutation,
  useInfoRootCommentPost,
} from "../../hooks/post/useCommentPost";
import { uploadFile } from "../../services/UploadService";
import CommentSingle from "./CommentSingle";
import InputComment from "./InputComment";

const ListComment = ({ postId, user, deep = 0 }) => {
  const { mutate, isLoading } = useCommentPostMutation();
  const { rootComment, isLoadingRootComment } = useInfoRootCommentPost(postId);
  const [commentInput, setCommentInput] = useState("");
  const [image, setImage] = useState(null);
  const [isUploading, setIsUploading] = useState(false);

  //root comment
  const handleSubmit = async (event) => {
    if (event.preventDefault) {
      event.preventDefault();
    }

    if (commentInput.trim() === "" && !image) {
      return;
    }
    if (image) {
      setIsUploading(true);
      const result = await uploadFile(image);
      setIsUploading(false);
      mutate({
        file: {
          file: result.secure_url,
          resource_type: result.resource_type,
          original_filename: image.name,
        },
        text: commentInput,
        postId,
      });
      setCommentInput("");
      setImage(null);
    } else {
      mutate({ text: commentInput, postId });
      setCommentInput("");
      setImage(null);
    }
  };

  return (
    <Box sx={{ p: 1, width: "100%" }}>
      {isLoadingRootComment ? (
        <CircularProgress />
      ) : (
        <>
          {rootComment.data.map((el, index) => (
            <CommentSingle key={el._id} comment={el} deep={deep} user={user} />
          ))}
        </>
      )}
      {user.role !== "admin" && (
        <InputComment
          setText={setCommentInput}
          text={commentInput}
          image={image}
          setImage={setImage}
          handleSubmit={handleSubmit}
          isLoading={isLoading || isUploading}
        />
      )}
    </Box>
  );
};

export default ListComment;
