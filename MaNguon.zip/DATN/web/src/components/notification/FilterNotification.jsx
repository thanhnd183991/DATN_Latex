import FormControl from "@mui/material/FormControl";
import MenuItem from "@mui/material/MenuItem";
import Select from "@mui/material/Select";
import { useMemo } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  ADD_MEMBER,
  CHANGE_OWNER,
  CONFIRM_ADD_MEMBER,
  CONFIRM_APPLY_JOB,
  CONFIRM_COMPANY,
  CONFIRM_CONNECT_JOB,
  CONFIRM_CONNECT_USER,
  CONFIRM_DELETE_MEMBER,
  CONFIRM_JOB,
  CONFIRM_REPORT_JOB,
  CONFIRM_REPORT_POST,
  CONNECT_JOB,
  CONNECT_USER,
  CREATE_COMPANY,
  CREATE_JOB_FOR_ADMIN,
  CREATE_JOB_FOR_USER,
  CREATE_POST,
  CREATE_REPORT_JOB,
  CREATE_REPORT_POST,
  FOLLOW_COMPANY,
  FOLLOW_JOB,
  FOLLOW_USER,
} from "../../constants/NotifyConstant";
import { useAuth } from "../../hooks/useAuth";
import { setTypeNotifyFitler } from "../../redux/features/badgeSlice";

export default function FilterNotification({}) {
  const { user: me } = useAuth();
  const dispatch = useDispatch();
  const { typeNotifyFilter: type } = useSelector((state) => state.badge);

  const items = useMemo(() => {
    let rs = {};
    rs["All"] = "Tất cả";
    rs[FOLLOW_USER] = "Theo dõi người dùng";
    rs[CREATE_POST] = "Tạo bài viết";

    if (me.role === "employee") {
      rs[ADD_MEMBER] = "Thêm thành viên";
      rs[CONFIRM_APPLY_JOB] = "Xác nhận ứng tuyển";
      rs[CONFIRM_ADD_MEMBER] = "Xác nhận thêm thành viên";
    }
    if (me.role === "HR") {
      rs[FOLLOW_JOB] = "Theo dõi công việc";
      rs[CONFIRM_JOB] = "Thông báo xác nhận công việc";
      rs[CHANGE_OWNER] = "Thay đổi chủ công việc";
    }
    if (me.role === "manager") {
      rs[FOLLOW_COMPANY] = "Theo dõi công ty";
      rs[CONFIRM_COMPANY] = "Xác nhận công ty";
      rs[CONFIRM_ADD_MEMBER] = "Xác nhận thêm thành viên";
      rs[CONFIRM_DELETE_MEMBER] = "Xóa người dùng";
    }

    rs[CREATE_JOB_FOR_USER] = "Thông báo tạo việc làm";
    rs[CONNECT_USER] = "Kết nối người dùng";
    rs[CONNECT_JOB] = "Kết nối việc làm";
    rs[CONFIRM_CONNECT_JOB] = "Xác nhận kết nối việc làm";
    rs[CONFIRM_CONNECT_USER] = "Xác nhận kết nối người dùng";

    rs[CONFIRM_REPORT_JOB] = "Xác nhận báo cáo việc làm";
    rs[CONFIRM_REPORT_POST] = "Xác nhận báo cáo bài viết";
    if (me.role === "admin") {
      delete rs[CREATE_JOB_FOR_USER];
      delete rs[FOLLOW_USER];
      delete rs[FOLLOW_COMPANY];
      delete rs[CREATE_POST];
      delete rs[CONFIRM_CONNECT_JOB];
      delete rs[CONFIRM_CONNECT_USER];
      delete rs[CONNECT_USER];
      delete rs[CONNECT_JOB];
      delete rs[CONFIRM_REPORT_JOB];
      delete rs[CONFIRM_REPORT_POST];
      rs[CREATE_JOB_FOR_ADMIN] = "Thông báo tạo việc làm";
      rs[CREATE_COMPANY] = "Tạo công ty";
      rs[CONFIRM_JOB] = "Thông báo xác nhận công việc";
      rs[CONFIRM_COMPANY] = "Xác nhận công ty";
      rs[CREATE_REPORT_JOB] = "Báo cáo việc làm";
      rs[CREATE_REPORT_POST] = "Báo cáo bài viết";
      rs[CONFIRM_REPORT_JOB] = "Xác nhận báo cáo việc làm";
      rs[CONFIRM_REPORT_POST] = "Xác nhận báo cáo bài viết";
    }
    return rs;
  }, []);

  const handleChange = (event) => {
    dispatch(setTypeNotifyFitler({ type: event.target.value }));
  };

  return (
    <div>
      <FormControl variant="standard" sx={{ m: 1, minWidth: 80 }}>
        {/* <InputLabel id="demo-simple-select-autowidth-label">
          Loại thông báo
        </InputLabel> */}
        <Select
          id="demo-simple-select-autowidth"
          value={type}
          onChange={handleChange}
          autoWidth
          label="Loại thông báo"
        >
          {Object.keys(items).map((key) => {
            return (
              <MenuItem key={key} value={key}>
                {items[key]}
              </MenuItem>
            );
          })}
        </Select>
      </FormControl>
    </div>
  );
}
