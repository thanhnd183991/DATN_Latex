import { Box, Button, Skeleton, Stack } from "@mui/material";
import { Fragment, useCallback, useState } from "react";
import { useNavigate } from "react-router-dom";
import { CONFIRM_APPLY_JOB, REJECTED } from "../../constants/NotifyConstant";
import { useAuth } from "../../hooks/useAuth";
import { useNotifications } from "../../hooks/useNotifications";
import AlertDialog from "../dialog/AlertDialog";
import ItemNotify from "../item/ItemNotify";
import CompanyModal from "../modal/admin/CompanyModal";
import JobModal from "../modal/admin/JobModal";
import PostModal from "../modal/admin/PostModal";
import UserModal from "../modal/admin/UserModal";
import FilterNotification from "./FilterNotification";

const ListNotification = () => {
  const { user: me } = useAuth();
  const navigate = useNavigate();
  const [selectNotify, setSelectNotify] = useState(null);
  const {
    status,
    data,
    error,
    isFetching,
    isFetchingNextPage,
    isFetchingPreviousPage,
    fetchNextPage,
    fetchPreviousPage,
    hasNextPage,
    ref,
    hasPreviousPage,
  } = useNotifications();

  const handleClickSelectNotify = useCallback((notify) => {
    setSelectNotify(notify);
  }, []);

  const handleSelectNotify = useCallback(() => {
    if (!selectNotify) return <></>;

    if (
      selectNotify.type === CONFIRM_APPLY_JOB &&
      selectNotify.receiver[0].status === REJECTED
    ) {
      return (
        <AlertDialog
          title="Từ chối ứng tuyển"
          desc={selectNotify.desc}
          handleClose={() => setSelectNotify(null)}
          open={!!selectNotify}
        />
      );
    }

    if (selectNotify.onAccess === "User") {
      return (
        <UserModal
          open={!!selectNotify}
          userId={selectNotify?.access?._id || selectNotify?.access}
          onClose={() => setSelectNotify(null)}
        />
      );
    }

    if (selectNotify.onAccess === "Room") {
      return navigate(
        `/chat/${selectNotify?.access?._id || selectNotify?.access}`
      );
    }

    if (selectNotify.onAccess === "Post") {
      if (me.role === "admin") {
        return (
          <PostModal
            open={!!selectNotify}
            postId={selectNotify?.access?._id || selectNotify?.access}
            onClose={() => setSelectNotify(null)}
          />
        );
      } else {
        return navigate(
          `/${selectNotify.onSender === "User" ? "profile" : "company"}/${
            selectNotify?.sender?._id || selectNotify?.sender
          }`
        );
      }
    }

    if (
      selectNotify.onAccess === "Job" &&
      selectNotify.type !== CONFIRM_APPLY_JOB
    ) {
      if (me.role === "admin") {
        return (
          <JobModal
            open={!!selectNotify}
            jobId={selectNotify?.access?._id || selectNotify?.access}
            onClose={() => setSelectNotify(null)}
          />
        );
      } else {
        return navigate(
          `/job/${selectNotify?.access?._id || selectNotify?.access}`
        );
      }
    }

    if (selectNotify.onAccess === "Company") {
      if (me.role === "admin") {
        return (
          <CompanyModal
            open={!!selectNotify}
            companyId={selectNotify?.access?._id || selectNotify?.access}
            onClose={() => setSelectNotify(null)}
          />
        );
      } else {
        return navigate(
          `/company/${selectNotify?.access?._id || selectNotify?.access}`
        );
      }
    }
  }, [selectNotify]);

  return (
    <>
      <Box flex={5} p={2}>
        {status === "loading" ? (
          <>
            {Array.from({ length: 5 }).map((_, index) => (
              <Stack spacing={1} key={index}>
                <Skeleton variant="text" height={100} />
                <Skeleton variant="text" height={20} />
                <Skeleton variant="text" height={20} />
              </Stack>
            ))}
          </>
        ) : status === "error" ? (
          <span>Error: {error.message}</span>
        ) : (
          <Box sx={{ boxShadow: 1 }} bgcolor="background.paper">
            <Box>
              <FilterNotification />
            </Box>

            {data.pages.map((page) => (
              <Fragment key={page.nextId}>
                {page.data.map((notify) => (
                  <ItemNotify
                    key={notify._id}
                    notify={notify}
                    handleClickSelectNotify={handleClickSelectNotify}
                  />
                ))}
              </Fragment>
            ))}
            <div>
              <Button
                ref={ref}
                variant="text"
                sx={{ border: "none", borderColor: "transparent" }}
                onClick={() => fetchNextPage()}
                disabled={!hasNextPage || isFetchingNextPage}
              >
                {isFetchingNextPage
                  ? "Loading more..."
                  : hasNextPage
                  ? "Load Newer"
                  : "Hết"}
              </Button>
            </div>
            <div>
              {isFetching && !isFetchingNextPage
                ? "Background Updating..."
                : null}
            </div>
          </Box>
        )}
      </Box>

      {handleSelectNotify()}

      {/* {!!selectNotify &&
        selectNotify.type === CONFIRM_APPLY_JOB &&
        selectNotify.receiver[0].status === REJECTED && (
          <AlertDialog
            title="Từ chối ứng tuyển"
            desc={selectNotify.desc}
            handleClose={() => setSelectNotify(null)}
            open={!!selectNotify}
          />
        )}
      {!!selectNotify && selectNotify.onAccess === "User" && (
        <UserModal
          open={!!selectNotify}
          userId={selectNotify?.access?._id || selectNotify?.access}
          onClose={() => setSelectNotify(null)}
        />
      )}
      {!!selectNotify &&
        selectNotify.onAccess === "Room" &&
        navigate(`/chat/${selectNotify?.access?._id || selectNotify?.access}`)}
      {!!selectNotify &&
        selectNotify.onAccess === "Post" &&
        (me.role === "admin" ? (
          <PostModal
            open={!!selectNotify}
            postId={selectNotify?.access?._id || selectNotify?.access}
            onClose={() => setSelectNotify(null)}
          />
        ) : (
          navigate(
            `/${selectNotify.onSender === "User" ? "profile" : "company"}/${
              selectNotify?.sender?._id || selectNotify?.sender
            }`
          )
        ))}
      {!!selectNotify &&
        selectNotify.onAccess === "Job" &&
        selectNotify.type !== CONFIRM_APPLY_JOB &&
        (me.role === "admin" ? (
          <JobModal
            open={!!selectNotify}
            jobId={selectNotify?.access?._id || selectNotify?.access}
            onClose={() => setSelectNotify(null)}
          />
        ) : (
          navigate(`/job/${selectNotify?.access?._id || selectNotify?.access}`)
        ))}
      {!!selectNotify &&
        selectNotify.onAccess === "Company" &&
        (me.role === "admin" ? (
          <CompanyModal
            open={!!selectNotify}
            companyId={selectNotify?.access?._id || selectNotify?.access}
            onClose={() => setSelectNotify(null)}
          />
        ) : (
          navigate(
            `/company/${selectNotify?.access?._id || selectNotify?.access}`
          )
        ))} */}
    </>
  );
};

export default ListNotification;
