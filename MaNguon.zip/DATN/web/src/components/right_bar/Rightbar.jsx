import {
  Box,
  Divider,
  List,
  Paper,
  Skeleton,
  Typography,
  useMediaQuery,
} from "@mui/material";
import { Link } from "react-router-dom";
import { useMe } from "../../hooks/useAuth";
import { useSearchPage } from "../../hooks/useSearch";
import ItemCompany from "../item/ItemCompany";
import ItemJob from "../item/ItemJob";
import ItemUser from "../item/ItemUser";
import {
  LG_RESPONSIVE_WIDTH,
  MD_RESPONSIVE_WIDTH,
} from "../../constants/Responsive";

const Rightbar = ({ type, relate }) => {
  const MD_RESPONSIVE = useMediaQuery(MD_RESPONSIVE_WIDTH);
  const LG_RESPONSIVE = useMediaQuery(LG_RESPONSIVE_WIDTH);
  const { me, isLoadingMe, errorMe } = useMe();
  const { status, data, error, isFetching, isPreviousData } = useSearchPage({
    params: {
      suggestion: type,
      relate,
    },
    page: 0,
    limit: 6,
  });

  if (!isLoadingMe && me.role === "admin") {
    return <Box flex={1} />;
  }

  return (
    <Box
      flex={LG_RESPONSIVE ? 2.5 : 2}
      py={2}
      sx={{
        borderRadius: 1,
        display: { xs: "none", sm: "none", md: "block" },
      }}
    >
      {isLoadingMe ? (
        <Box p={2}>
          <Skeleton variant="rectangular" height={100} />
        </Box>
      ) : errorMe ? (
        <p>error</p>
      ) : (
        <Paper
          sx={{
            mx: 2,
            position: "fixed",
            py: 1,
            minWidth: 200,
          }}
        >
          <Typography
            variant="h6"
            fontWeight={100}
            sx={{
              display: "flex",
              alginItem: "center",
              justifyContent: "center",
            }}
          >
            {type === "job"
              ? "Công việc liên quan"
              : type === "company"
              ? "Công ty"
              : "Theo dõi"}
          </Typography>

          <Divider component="li" />
          <List
            sx={{
              width: "100%",
              bgcolor: "background.paper",
            }}
          >
            {status === "loading" ? (
              <div>Loading...</div>
            ) : status === "error" ? (
              <div>Error: {error.message}</div>
            ) : (
              <>
                {type === "user" &&
                  data.data.slice(0, 3).map((item, index) => (
                    <Box key={index}>
                      <ItemUser user={item} me={me} />
                      <Divider variant="inset" sx={{ mt: -1 }} component="li" />
                    </Box>
                  ))}
                {type === "job" &&
                  data.data.slice(0, 3).map((item, index) => (
                    <Box key={index}>
                      <ItemJob job={item} />
                      <Divider variant="inset" sx={{ mt: -1 }} component="li" />
                    </Box>
                  ))}
                {type === "company" &&
                  data.data.slice(0, 3).map((item, index) => (
                    <Box key={index}>
                      <ItemCompany key={index} company={item} />
                      <Divider variant="inset" sx={{ mt: -1 }} component="li" />
                    </Box>
                  ))}
              </>
            )}
          </List>
          <Divider component="li" />
          <Link
            to={
              relate
                ? `/search?relate=${relate}&type=1`
                : `/search?suggestion=${type}`
            }
            style={{ textDecoration: "none" }}
          >
            <Typography
              variant="body1"
              sx={{
                display: "block",
                textAlign: "center",
                mt: 1,
                cursor: "pointer",
              }}
              color="secondary"
            >
              Xem tất cả
            </Typography>
          </Link>
        </Paper>
      )}
    </Box>
  );
};

export default Rightbar;
