const RichText = ({ text, className = "" }) => {
  const createMarkup = () => {
    return {
      __html: text,
    };
  };

  return <div dangerouslySetInnerHTML={createMarkup()} className={className} />;
};

export default RichText;
