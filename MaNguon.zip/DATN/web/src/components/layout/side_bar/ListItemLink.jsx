import { Button, useMediaQuery } from "@mui/material";
import Badge from "@mui/material/Badge";
import ListItem from "@mui/material/ListItem";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import { forwardRef, useCallback, useMemo } from "react";
import { useQueryClient } from "react-query";
import { useDispatch, useSelector } from "react-redux";
import {
  Link as RouterLink,
  useMatch,
  useResolvedPath,
} from "react-router-dom";
import { toast } from "react-toastify";
import {
  LG_RESPONSIVE_WIDTH,
  SM_RESPONSIVE_WIDTH,
} from "../../../constants/Responsive";
import { logout } from "../../../redux/features/authSlice";
import { resetChat, resetNotify } from "../../../redux/features/badgeSlice";

const ListItemLink = (props) => {
  const { icon, primary, to } = props;
  const LG_RESPONSIVE = useMediaQuery(LG_RESPONSIVE_WIDTH);
  const SM_RESPONSIVE = useMediaQuery(SM_RESPONSIVE_WIDTH);
  const dispatch = useDispatch();
  const { notify, chat } = useSelector((state) => state.badge);
  const queryClient = useQueryClient();

  let resolved = useResolvedPath(to);
  let match = useMatch({
    path: resolved.pathname.includes("/admin")
      ? resolved.pathname
      : "/" + resolved.pathname.split("/")[1] + "/*",
  });

  const logoutFn = useCallback(() => {
    queryClient.clear();
    dispatch(resetChat());
    dispatch(resetNotify());
    dispatch(logout());

    toast.success("Logged out successfully");
  }, [dispatch, queryClient]);

  const renderLink = useMemo(
    () =>
      forwardRef(function Link(itemProps, ref) {
        return <RouterLink to={to} ref={ref} {...itemProps} role={undefined} />;
      }),
    [to]
  );

  return (
    <li>
      <ListItem
        onClick={to === "/logout" ? () => logoutFn() : () => {}}
        sx={{
          borderRadius: 4,
          bgcolor: (theme) =>
            match ? theme.palette.action.selected : "transparent",
          fontWeight: match ? "bold" : "normal",
          textTransform: "none",
          display: "flex",
          flexShrink: 0,
          width: LG_RESPONSIVE ? "100%" : "55px",
        }}
        button
        component={to === "/logout" ? Button : renderLink}
      >
        {icon && (
          <ListItemIcon sx={{ maxWidth: "24px" }}>
            {to === "/chat" && chat.length > 0 ? (
              <Badge badgeContent={chat.length} max={50} color="primary">
                {icon}
              </Badge>
            ) : to === "/notification" && notify > 0 ? (
              <Badge badgeContent={notify} max={50} color="primary">
                {icon}
              </Badge>
            ) : (
              icon
            )}
          </ListItemIcon>
        )}
        {LG_RESPONSIVE && (
          <ListItemText
            primary={primary}
            sx={{ display: { xs: "none", sx: "none", md: "block" } }}
          />
        )}
      </ListItem>
    </li>
  );
};

export default ListItemLink;
