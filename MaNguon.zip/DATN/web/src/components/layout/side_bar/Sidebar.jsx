import { AccountBox, Home } from "@mui/icons-material";
import ApartmentIcon from "@mui/icons-material/Apartment";
import CategoryIcon from "@mui/icons-material/Category";
import EventNoteIcon from "@mui/icons-material/EventNote";
import LogoutIcon from "@mui/icons-material/Logout";
import MessageIcon from "@mui/icons-material/Message";
import NotificationsIcon from "@mui/icons-material/Notifications";
import PersonIcon from "@mui/icons-material/Person";
import SearchIcon from "@mui/icons-material/Search";
import WorkIcon from "@mui/icons-material/Work";
import { Box, List, useMediaQuery } from "@mui/material";
import { useMemo } from "react";
import {
  LG_RESPONSIVE_WIDTH,
  SM_RESPONSIVE_WIDTH,
} from "../../../constants/Responsive";
import { useAuth } from "../../../hooks/useAuth";
import ListItemLink from "./ListItemLink";

const Sidebar = ({ mode, setMode }) => {
  const { user } = useAuth();
  const SM_RESPONSIVE = useMediaQuery(SM_RESPONSIVE_WIDTH);
  const LG_RESPONSIVE = useMediaQuery(LG_RESPONSIVE_WIDTH);
  const navigationPath = useMemo(() => {
    return [
      {
        path: "/",
        Icon: Home,
        text: "Trang chủ",
      },
      {
        path: "/job",
        Icon: WorkIcon,
        text: "Việc làm",
      },
      {
        path: "/notification",
        Icon: NotificationsIcon,
        text: "Thông báo",
      },
      {
        path: "/search",
        Icon: SearchIcon,
        text: "Tìm kiếm",
      },
      {
        path: "/chat",
        Icon: MessageIcon,
        text: "Trao đổi",
      },
      {
        path: `/profile/${user._id}`,
        Icon: AccountBox,
        text: "Hồ sơ",
      },
      // {
      //   path: "/CV",
      //   Icon: LogoutIcon,
      //   text: "CV",
      // },
      // ,
      {
        path: "/logout",
        Icon: LogoutIcon,
        text: "Thoát",
      },
    ];
  }, []);

  const navigationAdminPath = useMemo(() => {
    return [
      {
        path: "/admin/home",
        Icon: Home,
        text: "Trang chủ",
      },
      {
        path: "/admin/user",
        Icon: PersonIcon,
        text: "Người dùng",
      },
      {
        path: "/admin/post",
        text: "Bài đăng",
        Icon: EventNoteIcon,
      },
      {
        path: "/admin/job",
        Icon: WorkIcon,
        text: "Việc làm",
      },
      {
        path: "/notification",
        Icon: NotificationsIcon,
        text: "Thông báo",
      },
      {
        path: "/admin/company",
        Icon: ApartmentIcon,
        text: "Công ty",
      },
      {
        path: "/admin/category",
        Icon: CategoryIcon,
        text: "Kỹ năng",
      },
      {
        path: "/logout",
        Icon: LogoutIcon,
        text: "Thoát",
      },
    ];
  }, []);

  return (
    <Box flex={LG_RESPONSIVE ? 1 : 0.2} p={2}>
      <Box position="fixed">
        <List>
          {user.role === "admin"
            ? navigationAdminPath.map(({ path, Icon, text }, index) => (
                <ListItemLink
                  to={path}
                  primary={text}
                  icon={<Icon />}
                  key={index}
                />
              ))
            : navigationPath.map(({ path, Icon, text }, index) => (
                <ListItemLink
                  to={path}
                  primary={text}
                  icon={<Icon />}
                  key={index}
                />
              ))}

          {/* <ListItem disablePadding>
            <Switch onChange={(e) => setIsAdmin(!isAdmin)} />
            <Typography>Change Role</Typography>
          </ListItem> */}
        </List>
      </Box>
    </Box>
  );
};

export default Sidebar;
