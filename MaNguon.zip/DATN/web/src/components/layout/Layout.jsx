import { Box, createTheme, Stack, ThemeProvider } from "@mui/material";
import { useState } from "react";
import Add from "../Add";
import Navbar from "./Navbar";
import Sidebar from "./side_bar/Sidebar";
import { Outlet } from "react-router-dom";
import { useAuth } from "../../hooks/useAuth";

const Layout = ({ children }) => {
  const { user } = useAuth();
  const [mode, setMode] = useState(localStorage.getItem("mode") || "light");
  // console.log("layout");

  const darkTheme = createTheme({
    palette: {
      mode: mode,
    },
  });

  const handleMode = () => {
    if (mode === "light") {
      localStorage.setItem("mode", "dark");
      setMode("dark");
    } else {
      localStorage.setItem("mode", "light");
      setMode("light");
    }
  };

  return (
    <ThemeProvider theme={darkTheme}>
      <Box
        bgcolor="action.hover"
        sx={{ minHeight: "100vh" }}
        color={"text.primary"}
      >
        <Navbar handleMode={handleMode} mode={mode} />
        <Stack
          direction="row"
          spacing={1}
          justifyContent="space-around"
          sx={{
            bgcolor: mode === "light" ? "rgba(0, 0, 0, 0.04)" : "black",
            minHeight: "100vh",
          }}
        >
          <Sidebar />
          <Outlet />
        </Stack>
        {user.role !== "admin" && <Add />}
      </Box>
    </ThemeProvider>
  );
};

export default Layout;
