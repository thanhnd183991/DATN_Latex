import Backdrop from "@mui/material/Backdrop";
import Fade from "@mui/material/Fade";
import Modal from "@mui/material/Modal";
import { forwardRef } from "react";

const LayoutModal = forwardRef(function LayoutModal(props, ref) {
  return (
    <Modal
      // ref={ref}
      aria-labelledby="transition-modal-title"
      aria-describedby="transition-modal-description"
      open={props.open}
      onClose={props.onClose}
      closeAfterTransition
      BackdropComponent={Backdrop}
      BackdropProps={{
        timeout: 500,
      }}
    >
      <Fade in={props.open}>
        <div>{props.children}</div>
      </Fade>
    </Modal>
  );
});

export default LayoutModal;
