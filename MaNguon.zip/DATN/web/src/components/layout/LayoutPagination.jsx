import ArrowBackIosNewIcon from "@mui/icons-material/ArrowBackIosNew";
import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";
import {
  Box,
  CircularProgress,
  IconButton,
  Pagination,
  PaginationItem,
} from "@mui/material";
import { Link, useLocation } from "react-router-dom";
import ItemJob from "../item/ItemJob";

const LayoutPagination = ({
  status,
  page,
  setPage,
  data,
  error,
  isFetching,
  numberOfPages,
}) => {
  const handleChange = (event, value) => {
    setPage(value);
  };

  return (
    <Box>
      {status === "loading" ? (
        <div>Loading...</div>
      ) : status === "error" ? (
        <div>Error: {error.message}</div>
      ) : (
        // `data` will either resolve to the latest page's data
        // or if fetching a new page, the last successful page's data
        <div>
          {data.data.map((job) => (
            <ItemJob key={job._id} job={job} page={page} />
          ))}
        </div>
      )}
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          gap: 2,
        }}
      >
        <Pagination page={page} count={numberOfPages} onChange={handleChange} />
        {/* <IconButton
          onClick={() => setPage((old) => Math.max(old - 1, 1))}
          disabled={page === 1}
        >
          <ArrowBackIosNewIcon />
        </IconButton>
        <IconButton
          onClick={() => {
            if (data?.numberOfPages) {
              setPage((old) => (data?.numberOfPages > old ? old + 1 : old));
            } else {
              setPage((old) => (data?.hasMore ? old + 1 : old));
            }
          }}
          disabled={
            isPreviousData || data?.numberOfPages
              ? data?.numberOfPages <= page
              : !data?.hasMore
          }
        >
          <ArrowForwardIosIcon />
        </IconButton> */}
      </Box>
      {
        // Since the last page's data potentially sticks around between page requests,
        // we can use `isFetching` to show a background loading
        // indicator since our `status === 'loading'` state won't be triggered
        isFetching ? (
          <Box sx={{ display: "flex" }}>
            <CircularProgress />
          </Box>
        ) : null
      }
    </Box>
  );
};

export default LayoutPagination;
