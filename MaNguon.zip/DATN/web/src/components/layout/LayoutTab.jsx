import { Box } from "@mui/material";
import Tab from "@mui/material/Tab";
import Tabs from "@mui/material/Tabs";
import PropTypes from "prop-types";

const TabPanel = (props) => {
  const { children, value, index, ...other } = props;

  // console.log("render tab " + value);

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && <Box>{children}</Box>}
    </div>
  );
};

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.number.isRequired,
  value: PropTypes.number.isRequired,
};

function a11yProps(index) {
  return {
    id: `simple-tab-${index}`,
    "aria-controls": `simple-tabpanel-${index}`,
  };
}

export default function LayoutTabs({
  value,
  handleChange,
  labels,
  components,
  activeTabs,
  style = {},
}) {
  return (
    <>
      <Box
        sx={{
          bgcolor: "background.paper",
          borderBottom: 1,
          borderRadius: 2,
          borderColor: "divider",
          mb: 2,
          ...style,
        }}
      >
        <Tabs
          value={value}
          onChange={handleChange}
          variant="scrollable"
          scrollButtons="auto"
          aria-label="scrollable auto tabs example"
        >
          {labels.map((label, index) =>
            activeTabs ? (
              <Tab
                key={index}
                label={label}
                sx={{ textTransform: "none", fontSize: "16px" }}
                {...a11yProps(index)}
                disabled={activeTabs[index]}
              />
            ) : (
              <Tab
                key={index}
                label={label}
                sx={{ textTransform: "none", fontSize: "16px" }}
                {...a11yProps(index)}
              />
            )
          )}
        </Tabs>
      </Box>
      {labels.map((_, index) => (
        <TabPanel key={index} value={value} index={index}>
          {components[index]}
        </TabPanel>
      ))}
    </>
  );
}
