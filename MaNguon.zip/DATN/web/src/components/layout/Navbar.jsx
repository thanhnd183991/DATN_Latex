import { Pets } from "@mui/icons-material";
import Brightness4Icon from "@mui/icons-material/Brightness4";
import Brightness7Icon from "@mui/icons-material/Brightness7";
import {
  AppBar,
  Avatar,
  Box,
  IconButton,
  Menu,
  MenuItem,
  styled,
  Toolbar,
  Typography,
  useMediaQuery,
} from "@mui/material";
import { useState } from "react";
import { useQueryClient } from "react-query";
import { useDispatch } from "react-redux";
import { useLocation, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import Logo from "../../assets/logo.png";
import { LG_RESPONSIVE_WIDTH } from "../../constants/Responsive";
import { keys } from "../../hooks/queryKeys";
import { useAuth } from "../../hooks/useAuth";
import { logout } from "../../redux/features/authSlice";
import { resetChat, resetNotify } from "../../redux/features/badgeSlice";
import CreateCompanyModal from "../modal/CreateCompanyModal";
import SearchInput from "../search/SearchInput";

const StyledToolbar = styled(Toolbar)({
  display: "flex",
  justifyContent: "space-between",
});

const Icons = styled(Box)(({ theme }) => ({
  display: "none",
  alignItems: "center",
  gap: "20px",
  color: theme.palette.text.secondary,
  [theme.breakpoints.up("sm")]: {
    display: "flex",
  },
}));

const UserBox = styled(Box)(({ theme }) => ({
  display: "flex",
  alignItems: "center",
  gap: "10px",
  [theme.breakpoints.up("sm")]: {
    display: "none",
  },
}));
const Navbar = ({ mode, handleMode }) => {
  const location = useLocation();
  const navigate = useNavigate();
  const LG_RESPONSIVE = useMediaQuery(LG_RESPONSIVE_WIDTH);
  const { user } = useAuth();
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);
  const [openCreateCompany, setOpenCreateCompany] = useState(false);
  const dispatch = useDispatch();
  const queryClient = useQueryClient();

  const logoutFn = () => {
    queryClient.clear();
    dispatch(resetChat());
    dispatch(resetNotify());
    dispatch(logout());
    toast.success("Logged out successfully");
  };

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    // console.log(anchorEl);
    setAnchorEl(null);
  };

  const handleOpenCompany = () => {
    handleClose();
    if (user.role === "employee") {
      setOpenCreateCompany(true);
    } else {
      // console.log(user.company);
      navigate(`/company/${user.company}`);
    }
  };
  const handleCloseCompany = () => {
    setOpenCreateCompany(false);
  };

  const handleOpenMyProfile = () => {
    handleClose();
    navigate(`/profile/${user._id}`);
  };

  const handleHome = () => {
    if (location.pathname !== "/" && user.role !== "admin") {
      navigate("/");
    } else if (location.pathname === "/" && user.role !== "admin") {
      queryClient.invalidateQueries(keys.infinitePosts());
    } else if (location.pathname !== "/admin/home" && user.role === "admin") {
      navigate("/admin/home");
    }
  };

  return (
    <>
      <AppBar
        position="sticky"
        sx={{
          bgcolor: "background.default",
          boxShadow: (theme) => theme.shadows[1],
        }}
      >
        <StyledToolbar>
          <Typography
            onClick={handleHome}
            variant="h6"
            sx={{ display: { xs: "none", sm: "block" } }}
          >
            <Avatar sx={{ width: 40, height: 40 }} src={Logo} />
          </Typography>
          <Pets sx={{ display: { xs: "block", sm: "none" } }} />
          {user.role !== "admin" && (
            <Box sx={{ width: LG_RESPONSIVE_WIDTH ? 500 : 300 }}>
              <SearchInput />
            </Box>
          )}
          <Icons>
            <IconButton
              sx={{ ml: 1 }}
              onClick={() => handleMode()}
              color="inherit"
            >
              {mode === "dark" ? <Brightness7Icon /> : <Brightness4Icon />}
            </IconButton>
            <Avatar
              sx={{ width: 40, height: 40, cursor: "pointer" }}
              src={user.avatar}
              onClick={handleClick}
            />
          </Icons>
        </StyledToolbar>
        <Menu
          id="demo-positioned-menu"
          aria-labelledby="demo-positioned-button"
          anchorEl={anchorEl}
          open={open}
          onClose={handleClose}
          anchorOrigin={{
            vertical: "top",
            horizontal: "right",
          }}
          transformOrigin={{
            vertical: "top",
            horizontal: "right",
          }}
        >
          {user.role !== "admin" && (
            <MenuItem onClick={handleOpenMyProfile}>Hồ sơ của tôi</MenuItem>
          )}
          {user.role !== "admin" && (
            <MenuItem onClick={handleOpenCompany}>
              {user.role === "HR" || user.role === "manager"
                ? "Công ty của tôi"
                : "Tạo công ty"}
            </MenuItem>
          )}
          <MenuItem onClick={logoutFn}>Đăng xuất</MenuItem>
        </Menu>
      </AppBar>
      <CreateCompanyModal
        open={openCreateCompany}
        onClose={handleCloseCompany}
      />
    </>
  );
};

export default Navbar;
