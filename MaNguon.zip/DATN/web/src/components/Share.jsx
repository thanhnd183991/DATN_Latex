import ImageIcon from "@mui/icons-material/Image";
import VideoLibraryIcon from "@mui/icons-material/VideoLibrary";
import WorkIcon from "@mui/icons-material/Work";
import { Avatar, Box, Button, Paper, styled } from "@mui/material";
import { useMemo, useState } from "react";
import { toast } from "react-toastify";
import { useAuth } from "../hooks/useAuth";
import CreateJobModal from "./modal/CreateJobModal";
import CreatePostModal from "./modal/CreatePostModal";

const Input = styled("input")(({ theme }) => ({
  border: "none",
  flex: 1,
  cursor: "pointer",
  fontSize: 16,
  p: 15,
  paddingTop: 10,
  paddingBottom: 10,
  paddingLeft: 10,
  marginLeft: 10,
  marginBottom: -3,
  color: theme.palette.text.primary,
  borderRadius: 20,
  backgroundColor: theme.palette.action.selected,
  "&:focus": {
    outline: "none",
  },
}));

export default function Share() {
  const { user } = useAuth();
  const [open, setOpen] = useState(false);
  const [openJob, setOpenJob] = useState(false);
  const handleOpen = (type) => {
    if (!open && !openJob && type === "post") {
      setOpen(true);
    } else if (!openJob && !open && type === "job") {
      if (user.role !== "HR") {
        toast.error("Bạn không có quyền tạo công việc");
        return;
      }
      setOpenJob(true);
    }
  };
  const handleClose = () => {
    if (open) {
      setOpen(false);
    } else if (openJob) {
      setOpenJob(false);
    }
  };

  const buttons = useMemo(
    () => [
      {
        Icon: ImageIcon,
        onClick: () => {
          console.log("icon image");
        },
        text: "Hình ảnh",
      },
      {
        Icon: VideoLibraryIcon,
        onClick: () => {
          console.log("icon video");
        },
        text: "Video",
      },
      {
        Icon: WorkIcon,
        onClick: () => {
          handleOpen("job");
        },
        text: "Công việc",
      },
    ],
    []
  );

  return (
    <Paper sx={{ mx: "auto", mb: 2, mt: 2 }}>
      <Box p={1} sx={{ display: "flex", alignItems: "center" }}>
        <Avatar alt="Remy Sharp" src={user.avatar} />
        <Input
          readOnly
          onClick={() => setOpen(true)}
          placeholder="Hoạt động gần đây"
        />
      </Box>
      <Box
        pb={0.5}
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        {buttons.map(({ Icon, onClick, text }, index) => (
          <Button
            variant="text"
            key={index}
            sx={{ flex: 1, padding: 1, borderRadius: 10 }}
            onClick={onClick}
            startIcon={<Icon />}
          >
            {text}
          </Button>
        ))}
      </Box>
      {open && <CreatePostModal open={open} onClose={handleClose} />}
      {openJob && <CreateJobModal open={openJob} onClose={handleClose} />}
    </Paper>
  );
}
