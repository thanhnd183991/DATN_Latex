import { Paper, Skeleton, Typography } from "@mui/material";
import Chart from "react-apexcharts";

const DonutChart = ({ status, payload, label, width }) => {
  const series = status === "success" ? payload.data : [];
  const element = document.getElementById("bar-chart");

  const options = {
    labels: status === "success" ? payload.categories : [],
    chart: {
      type: "donut",
    },
    responsive: [
      {
        breakpoint: 480,
        options: {
          chart: {
            width: 200,
          },
          legend: {
            position: "bottom",
          },
        },
      },
    ],
  };

  return (
    <Paper sx={{ width, my: 2, p: 1, height: element?.offsetHeight || 350 }}>
      <Typography
        sx={{ fontWeight: "bold", my: 1 }}
        variant="h5"
        component="h5"
      >
        {label}
      </Typography>
      {status === "loading" ? (
        <Skeleton variant="rect" width={width} height={300} />
      ) : status === "error" ? (
        <Typography
          sx={{ fontWeight: "bold", my: 1 }}
          variant="h5"
          component="h5"
        >
          Lỗi khi tải dữ liệu
        </Typography>
      ) : (
        <div className="donut">
          <Chart
            options={options}
            series={series}
            type="donut"
            height={element?.offsetHeight ? 300 : element?.offsetHeight - 80}
            width="100%"
          />
        </div>
      )}
    </Paper>
  );
};
export default DonutChart;
