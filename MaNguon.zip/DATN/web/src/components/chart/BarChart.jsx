import { Paper, Skeleton, Typography } from "@mui/material";
import Chart from "react-apexcharts";

const BarChart = ({
  status,
  payload,
  name = "series-1",
  label = "Thống kê",
  width = "50%",
}) => {
  const options = {
    chart: {
      id: "basic-bar",
    },
    xaxis: {
      categories: status === "success" ? payload.categories : [],
    },
  };
  const series = [
    {
      name,
      data: status === "success" ? payload.data : [],
    },
  ];

  return (
    <Paper sx={{ width, my: 2, p: 1 }} id="bar-chart">
      <Typography
        sx={{ fontWeight: "bold", my: 1 }}
        variant="h5"
        component="h5"
      >
        {label}
      </Typography>
      {status === "loading" ? (
        <Skeleton variant="rect" width={width} height={350} />
      ) : status === "error" ? (
        <Typography
          sx={{ fontWeight: "bold", my: 1 }}
          variant="h5"
          component="h5"
        >
          Lỗi khi tải dữ liệu
        </Typography>
      ) : (
        <div className="app">
          <div className="row">
            <div className="mixed-chart">
              <Chart
                options={options}
                series={series}
                type="bar"
                width="100%"
              />
            </div>
          </div>
        </div>
      )}
    </Paper>
  );
};

export default BarChart;
