import CloseIcon from "@mui/icons-material/Close";
import DoneIcon from "@mui/icons-material/Done";
import RemoveRedEyeIcon from "@mui/icons-material/RemoveRedEye";
import {
  Avatar,
  Box,
  IconButton,
  Paper,
  Tooltip,
  Typography,
} from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import { useState } from "react";
import { toast } from "react-toastify";
import { useAdminTable } from "../../../hooks/admin/useAdminTable";
import { useActiveCompanyMutation } from "../../../hooks/useCompanies";
import { dateFormat } from "../../../utils/dateUtils";
import CompanyModal from "../../modal/admin/CompanyModal";
import RichText from "../../RichText";
import AlertDialog from "../../dialog/AlertDialog";

const MyCompanyTableGrid = () => {
  const [companyId, setCompanyId] = useState("");
  const [openAlert, setOpenAlert] = useState(null);

  const handleOpen = (companyId) => {
    setCompanyId(companyId);
  };

  const handleClose = () => {
    setCompanyId("");
  };
  const {
    status,
    rows,
    error,
    isFetching,
    isPreviousData,
    queryOptions,
    setQueryOptions,
    onFilterChange,
    handleSortModelChange,
  } = useAdminTable("company");

  const { mutate: activeCompanyMutate, status: activeCompanyStatus } =
    useActiveCompanyMutation();

  const handleAgree = () => {
    activeCompanyMutate({
      page: queryOptions.page,
      companyId: openAlert._id,
      status: !openAlert.active,
      onClose: () =>
        toast.success(
          !openAlert.active ? `Kích hoạt thành công` : `Ẩn thành công`
        ),
    });
  };

  const columns = [
    { field: "_id", hide: true },
    {
      field: "name",
      headerName: "Tên công ty",
      width: 200,
      renderCell: (params) => {
        return (
          <>
            <Avatar
              src={params.row.avatar}
              sx={{ width: "32px", height: "32px", mr: "5px" }}
            />
            <Tooltip title={params.row.name || ""}>
              <p>{params.row.name}</p>
            </Tooltip>
          </>
        );
      },
    },
    {
      field: "ownerName",
      filterable: false,
      sortable: false,
      headerName: "Chủ sở hữu",
      width: 150,
      renderCell: (params) => {
        return (
          <Tooltip title={params.row.owner.name || ""}>
            <p>{params.row.owner.name}</p>
          </Tooltip>
        );
      },
    },
    {
      field: "numFollowers",
      filterable: false,
      headerName: "Theo dõi",
      width: 100,
      headerAlign: "center",
      align: "center",
    },
    {
      field: "overview",
      filterable: false,
      sortable: false,
      headerName: "Tổng quan",
      width: 200,
      renderCell: (params) => {
        return <RichText text={params.row.overview} />;
      },
    },
    {
      field: "industry",
      headerName: "Ngành nghề",
      width: 100,
      renderCell: (params) => {
        return <p>{params.row.industry?.name || ""}</p>;
      },
    },
    {
      field: "headquarters",
      filterable: false,
      sortable: false,
      headerName: "Trụ sở",
      width: 100,
    },
    {
      field: "createdAt",
      filterable: false,
      headerName: "Ngày tạo",
      width: 150,
      renderCell: (params) => {
        // console.log(params);
        const tmp = dateFormat(params.row.createdAt, "LLL");
        return (
          <Tooltip title={tmp || ""}>
            <p>{tmp}</p>
          </Tooltip>
        );
      },
    },
    {
      field: "active",
      type: "boolean",
      headerName: "Trạng thái",
      sortable: false,
      width: 100,
      renderCell: (params) => {
        return (
          <Box sx={{ display: "flex", ml: 1 }}>
            <IconButton onClick={() => setOpenAlert(params.row)}>
              {params.row.active ? <DoneIcon /> : <CloseIcon />}
            </IconButton>
          </Box>
        );
      },
    },
    {
      field: "view",
      filterable: false,
      headerName: "Xem",
      width: 100,
      sortable: false,
      renderCell: (params) => {
        return (
          <Box sx={{ display: "flex", ml: 1 }}>
            <IconButton onClick={() => handleOpen(params.row._id)}>
              <RemoveRedEyeIcon sx={{ mb: "-5px" }} />
            </IconButton>
          </Box>
        );
      },
    },
  ];

  return (
    <Paper sx={{ p: 1, my: 2 }}>
      <Typography
        sx={{ fontWeight: "bold", my: 1 }}
        variant="h5"
        component="h5"
      >
        Thống kê công ty
      </Typography>
      <div style={{ height: "71vh", width: "100%" }}>
        {/* {console.log("rows", rows)} */}
        <DataGrid
          loading={status === "loading"}
          rows={rows ? rows.data : []}
          // onRowClick={null}
          getRowId={(row) => row._id}
          columns={columns}
          filterMode="server"
          onFilterModelChange={onFilterChange}
          sortingMode="server"
          onSortModelChange={handleSortModelChange}
          onPageChange={(newPage) =>
            setQueryOptions((prev) => ({ ...prev, page: newPage }))
          }
          onPageSizeChange={(newPageSize) => {
            console.log("newPageSize", newPageSize);
          }}
          pagination
          paginationMode="server"
          page={queryOptions.page}
          pageSize={6}
          rowsPerPageOptions={[6]}
          rowCount={status === "success" ? rows.total : 0}
        />
      </div>
      {!!companyId && (
        <CompanyModal
          open={!!companyId}
          companyId={companyId}
          onClose={handleClose}
        />
      )}
      {!!openAlert && (
        <AlertDialog
          open={!!openAlert}
          handleAgree={handleAgree}
          handleClose={() => setOpenAlert(null)}
          title="Xác nhận"
          desc={`Bạn có chắc chắn muốn ${
            openAlert.active ? "khóa" : "mở"
          } trạng thái của ${openAlert.name}? <div>${
            openAlert.active
              ? "Điều này sẽ khóa tất cả bài đăng liên quan đến công ty, phòng trao đổi của nhà tuyển dụng công ty, tin tuyển dụng của công ty, vô hiệu hóa các thành viên trong công ty"
              : "Điều này sẽ mở khóa tất cả bài đăng liên quan đến công ty, phòng trao đổi của nhà tuyển dụng công ty, tin tuyển dụng của công ty, kích hoạt lại các nhà tuyển dụng của công ty các thành viên trong công ty"
          }</div>`}
          status={activeCompanyStatus}
        />
      )}
    </Paper>
  );
};
export default MyCompanyTableGrid;
