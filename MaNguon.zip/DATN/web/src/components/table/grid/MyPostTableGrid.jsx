import DeleteIcon from "@mui/icons-material/Delete";
import RemoveRedEyeIcon from "@mui/icons-material/RemoveRedEye";
import {
  Avatar,
  Box,
  IconButton,
  Paper,
  Tooltip,
  Typography,
} from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import { useState } from "react";
import { useAdminTable } from "../../../hooks/admin/useAdminTable";
import { useDeletePostMutation } from "../../../hooks/post/usePosts";
import { dateFormat } from "../../../utils/dateUtils";
import PostModal from "../../modal/admin/PostModal";
import RichText from "../../RichText";
import AlertDialog from "../../dialog/AlertDialog";

const MyPostTableGrid = () => {
  const [postId, setPostId] = useState("");
  const [openAlert, setOpenAlert] = useState(null);

  const handleOpen = (postId) => {
    setPostId(postId);
  };

  const handleClose = () => {
    setPostId("");
  };

  const { mutate: deletePostMutate, status: deletePostStatus } =
    useDeletePostMutation();

  const handleAgree = () => {
    deletePostMutate({
      postId: openAlert._id,
      pageAdmin: queryOptions.page,
      onClose: () => setOpenAlert(null),
    });
  };

  const {
    status,
    rows,
    error,
    isFetching,
    isPreviousData,
    queryOptions,
    setQueryOptions,
    onFilterChange,
    handleSortModelChange,
  } = useAdminTable("post");

  const columns = [
    { field: "_id", hide: true },
    {
      field: "name",
      headerName: "Họ và tên",
      width: 150,
      renderCell: (params) => {
        return (
          <>
            <Avatar
              src={params.row.ownerId.avatar}
              sx={{ width: "32px", height: "32px", mr: "5px" }}
            />
            <Tooltip title={params.row.ownerId.name || ""}>
              <p>{params.row.ownerId.name}</p>
            </Tooltip>
          </>
        );
      },
    },
    {
      field: "content",
      filterable: false,
      sortable: false,
      headerName: "Nội dung",
      width: 200,
      renderCell: (params) => {
        return (
          <RichText text={params.row.content} className="ellipsis-1-lines" />
        );
      },
    },
    {
      field: "numImages",
      filterable: false,
      sortable: false,
      headerName: "Ảnh",
      width: 100,
    },
    {
      field: "numVideos",
      filterable: false,
      sortable: false,
      headerName: "Video",
      width: 100,
    },
    {
      field: "numComments",
      filterable: false,
      sortable: false,
      headerName: "Bình luận",
      width: 100,
    },
    {
      field: "numReactions",
      filterable: false,
      sortable: false,
      headerName: "Tương tác",
      width: 100,
    },
    {
      field: "onOwner",
      headerName: "Loại",
      sortable: false,
      width: 100,
    },
    {
      field: "createdAt",
      filterable: false,
      headerName: "Ngày tạo",
      width: 150,
      renderCell: (params) => {
        // console.log(params);
        const tmp = dateFormat(params.row.createdAt, "LLL");
        return (
          <Tooltip title={tmp || ""}>
            <p>{tmp}</p>
          </Tooltip>
        );
      },
    },
    {
      field: "view",
      filterable: false,
      headerName: "Xem",
      width: 100,
      sortable: false,
      renderCell: (params) => {
        return (
          <Box sx={{ display: "flex", ml: 1 }}>
            <IconButton onClick={() => handleOpen(params.row._id)}>
              <RemoveRedEyeIcon sx={{ mb: "-5px" }} />
            </IconButton>
            <IconButton onClick={() => setOpenAlert(params.row)}>
              <DeleteIcon sx={{ mb: "-5px" }} />
            </IconButton>
          </Box>
        );
      },
    },
  ];

  return (
    <Paper sx={{ p: 1, my: 2 }}>
      <Typography
        sx={{ fontWeight: "bold", my: 1 }}
        variant="h5"
        component="h5"
      >
        Thống kê bài viết
      </Typography>
      <div style={{ height: "71vh", width: "100%" }}>
        {/* {console.log("rows", rows)} */}
        <DataGrid
          loading={status === "loading"}
          rows={rows ? rows.data : []}
          // onRowClick={null}
          getRowId={(row) => row._id}
          columns={columns}
          filterMode="server"
          onFilterModelChange={onFilterChange}
          sortingMode="server"
          onSortModelChange={handleSortModelChange}
          onPageChange={(newPage) =>
            setQueryOptions((prev) => ({ ...prev, page: newPage }))
          }
          onPageSizeChange={(newPageSize) => {
            console.log("newPageSize", newPageSize);
          }}
          pagination
          paginationMode="server"
          page={queryOptions.page}
          pageSize={6}
          rowsPerPageOptions={[6]}
          rowCount={status === "success" ? rows.total : 0}
        />
      </div>
      {!!postId && (
        <PostModal open={!!postId} postId={postId} onClose={handleClose} />
      )}
      {!!openAlert && (
        <AlertDialog
          open={!!openAlert}
          handleAgree={handleAgree}
          handleClose={() => setOpenAlert(null)}
          title="Xác nhận"
          desc={`Bạn có chắc chắn muốn xóa bài viết này?`}
          status={deletePostStatus}
        />
      )}
    </Paper>
  );
};
export default MyPostTableGrid;
