import { IconButton, Paper, Tooltip, Typography } from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import { memo, useState } from "react";
import { useAdminTable } from "../../../hooks/admin/useAdminTable";
import { dateFormat } from "../../../utils/dateUtils";
import DeleteIcon from "@mui/icons-material/Delete";
import AlertDialog from "../../dialog/AlertDialog";
import { useDeleteCategoryMutation } from "../../../hooks/useCategories";
import { toast } from "react-toastify";

const MyCategoryTableGrid = memo(() => {
  const [openAlert, setOpenAlert] = useState(null);
  const {
    status,
    rows,
    error,
    isFetching,
    isPreviousData,
    queryOptions,
    setQueryOptions,
    onFilterChange,
    handleSortModelChange,
  } = useAdminTable("category");

  const { mutate: deleteCategoryMutate, status: deleteCategoryStatus } =
    useDeleteCategoryMutation();

  const handleAgree = () => {
    deleteCategoryMutate({
      page: queryOptions.page,
      catId: openAlert._id,
      onClose: () => {
        setOpenAlert(null);
        toast.success("Xoá thành công");
      },
    });
  };

  const columns = [
    { field: "_id", hide: true },
    {
      field: "name",
      headerName: "Tên kỹ năng",
      width: 200,
      renderCell: (params) => {
        return (
          <>
            <Tooltip title={params.row.name || ""}>
              <p>{params.row.name}</p>
            </Tooltip>
          </>
        );
      },
    },
    {
      field: "numJobs",
      filterable: false,
      headerAlign: "center",
      headerName: "Số lượng việc làm",
      width: 150,
      align: "center",
    },
    {
      field: "numUsers",
      filterable: false,
      headerAlign: "center",
      headerName: "Số lượng người dùng",
      width: 150,
      align: "center",
    },
    {
      field: "numParents",
      filterable: false,
      headerAlign: "center",
      headerName: "Số lượng cha",
      width: 150,
      align: "center",
      renderCell: (params) => {
        // console.log(params);
        return (
          <Tooltip
            title={params.row.arrParents.map((el) => el.name).join(", ") || ""}
          >
            <p>{params.row.numParents}</p>
          </Tooltip>
        );
      },
    },
    {
      field: "createdAt",
      filterable: false,
      headerName: "Ngày tạo",
      width: 150,
      renderCell: (params) => {
        // console.log(params);
        const tmp = dateFormat(params.row.createdAt, "LLL");
        return (
          <Tooltip title={tmp || ""}>
            <p>{tmp}</p>
          </Tooltip>
        );
      },
    },
    {
      field: "delete-category",
      filterable: false,
      headerName: "Hành động",
      width: 150,
      renderCell: (params) => {
        // console.log(params);
        return (
          <IconButton onClick={() => setOpenAlert(params.row)}>
            <DeleteIcon sx={{ mb: "-5px" }} />
          </IconButton>
        );
      },
    },
  ];

  return (
    <Paper sx={{ p: 1, my: 2 }}>
      <Typography
        sx={{ fontWeight: "bold", my: 1 }}
        variant="h5"
        component="h5"
      >
        Thống kê kỹ năng
      </Typography>
      <div style={{ height: "71vh", width: "100%" }}>
        {/* {console.log("rows", rows)} */}
        <DataGrid
          loading={status === "loading"}
          rows={rows ? rows.data : []}
          // onRowClick={null}
          getRowId={(row) => row._id}
          columns={columns}
          filterMode="server"
          onFilterModelChange={onFilterChange}
          sortingMode="server"
          onSortModelChange={handleSortModelChange}
          onPageChange={(newPage) =>
            setQueryOptions((prev) => ({ ...prev, page: newPage }))
          }
          onPageSizeChange={(newPageSize) => {
            console.log("newPageSize", newPageSize);
          }}
          pagination
          paginationMode="server"
          page={queryOptions.page}
          pageSize={6}
          rowsPerPageOptions={[6]}
          rowCount={status === "success" ? rows.total : 0}
        />
      </div>
      {!!openAlert && (
        <AlertDialog
          open={!!openAlert}
          handleAgree={handleAgree}
          handleClose={() => setOpenAlert(null)}
          title="Xác nhận"
          desc="Bạn có chắc chắn muốn xóa kỹ năng này? <br /> <strong>Lưu ý:</strong> Khi xóa kỹ năng, kỹ năng sẽ không tồn tại trong tin tuyển việc làm cũng như kỹ năng của người dùng"
          status={deleteCategoryStatus}
        />
      )}
    </Paper>
  );
});
export default MyCategoryTableGrid;
