import CloseIcon from "@mui/icons-material/Close";
import DoneIcon from "@mui/icons-material/Done";
import RemoveRedEyeIcon from "@mui/icons-material/RemoveRedEye";
import {
  Avatar,
  Box,
  IconButton,
  Paper,
  Tooltip,
  Typography,
} from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import { useState } from "react";
import { toast } from "react-toastify";
import { useAdminTable } from "../../../hooks/admin/useAdminTable";
import { useDeleteUserMutation } from "../../../hooks/useUsers";
import { dateFormat } from "../../../utils/dateUtils";
import AlertDialog from "../../dialog/AlertDialog";
import UserModal from "../../modal/admin/UserModal";

const MyUserTableGrid = () => {
  const [userId, setUserId] = useState("");
  const [openAlert, setOpenAlert] = useState(null);

  const handleOpen = (userId) => {
    setUserId(userId);
  };

  const handleClose = () => {
    setUserId("");
  };
  const {
    status,
    rows,
    error,
    isFetching,
    isPreviousData,
    queryOptions,
    setQueryOptions,
    onFilterChange,
    handleSortModelChange,
  } = useAdminTable("user");
  const { mutate: activeUserMutate, status: statusActiveUser } =
    useDeleteUserMutation();

  const handleAgree = () => {
    activeUserMutate({
      page: queryOptions.page,
      userId: openAlert._id,
      currentState: openAlert.active,
      onClose: () => {
        setOpenAlert(null);
        toast.success(
          !openAlert.active ? `Kích hoạt thành công` : `Ẩn thành công`
        );
      },
    });
  };

  const columns = [
    { field: "_id", hide: true },
    {
      field: "name",
      headerName: "Họ và tên",
      operatorValue: "contains",
      width: 150,
      renderCell: (params) => {
        return (
          <>
            <Avatar
              src={params.row.avatar}
              sx={{ width: "32px", height: "32px", mr: "5px" }}
            />
            <Tooltip title={params.row.name || ""}>
              <p>{params.row.name}</p>
            </Tooltip>
          </>
        );
      },
    },
    {
      field: "numFollowers",
      filterable: false,
      headerName: "Người theo dõi",
      width: 100,
      align: "center",
    },
    {
      field: "numFollowing",
      filterable: false,
      headerName: "Đang theo dõi",
      width: 100,
      align: "center",
    },
    {
      field: "numFollowingCompany",
      filterable: false,
      headerName: "Công ty theo dõi",
      width: 100,
      align: "center",
    },
    {
      field: "numJobs",
      filterable: false,
      headerName: "Công việc ứng tuyển",
      width: 100,
      align: "center",
    },
    {
      field: "numSaveJobs",
      filterable: false,
      headerName: "Công việc đã lưu",
      width: 100,
      align: "center",
    },
    {
      field: "role",
      headerName: "Quyền",
      width: 100,
    },
    {
      field: "createdAt",
      filterable: false,
      headerName: "Ngày tạo",
      width: 150,

      renderCell: (params) => {
        // console.log(params);
        const tmp = dateFormat(params.row.createdAt, "LLL");
        return (
          <Tooltip title={tmp || ""}>
            <p>{tmp}</p>
          </Tooltip>
        );
      },
    },
    {
      field: "active",
      type: "boolean",
      headerName: "Trạng thái",
      sortable: false,
      width: 100,
      renderCell: (params) => {
        return (
          <Box sx={{ display: "flex", ml: 1 }}>
            <IconButton onClick={() => setOpenAlert(params.row)}>
              {params.row.active ? <DoneIcon /> : <CloseIcon />}
            </IconButton>
          </Box>
        );
      },
    },
    {
      field: "view",
      filterable: false,
      headerName: "Xem",
      width: 100,
      sortable: false,
      renderCell: (params) => {
        return (
          <Box sx={{ display: "flex", ml: 1 }}>
            <IconButton onClick={() => handleOpen(params.row._id)}>
              <RemoveRedEyeIcon sx={{ mb: "-5px" }} />
            </IconButton>
          </Box>
        );
      },
    },
  ];

  return (
    <>
      <Paper sx={{ p: 1, my: 2 }}>
        <Typography
          sx={{ fontWeight: "bold", my: 1 }}
          variant="h5"
          component="h5"
        >
          Thống kê người dùng
        </Typography>
        <div style={{ height: "71vh", width: "100%" }}>
          {/* {console.log("rows", rows)} */}
          <DataGrid
            loading={status === "loading"}
            rows={rows ? rows.data : []}
            // onRowClick={null}
            getRowId={(row) => row._id}
            columns={columns}
            filterMode="server"
            onFilterModelChange={onFilterChange}
            sortingMode="server"
            onSortModelChange={handleSortModelChange}
            onPageChange={(newPage) =>
              setQueryOptions((prev) => ({ ...prev, page: newPage }))
            }
            onPageSizeChange={(newPageSize) => {
              console.log("newPageSize", newPageSize);
            }}
            pagination
            paginationMode="server"
            page={queryOptions.page}
            pageSize={6}
            rowsPerPageOptions={[6]}
            rowCount={status === "success" ? rows.total : 0}
          />
        </div>
        {!!userId && (
          <UserModal open={!!userId} userId={userId} onClose={handleClose} />
        )}
      </Paper>
      {!!openAlert && (
        <AlertDialog
          open={!!openAlert}
          handleAgree={handleAgree}
          handleClose={() => setOpenAlert(null)}
          title="Xác nhận"
          desc={`Bạn có chắc chắn muốn ${
            openAlert.active ? "khóa" : "mở"
          } trạng thái của ${openAlert.name}?`}
          status={statusActiveUser}
        />
      )}
    </>
  );
};
export default MyUserTableGrid;
