import CloseIcon from "@mui/icons-material/Close";
import DoneIcon from "@mui/icons-material/Done";
import RemoveRedEyeIcon from "@mui/icons-material/RemoveRedEye";
import { Box, IconButton, Paper, Tooltip, Typography } from "@mui/material";
import { DataGrid } from "@mui/x-data-grid";
import { memo, useState } from "react";
import { toast } from "react-toastify";
import { useAdminTable } from "../../../hooks/admin/useAdminTable";
import { useActiveJobMutation } from "../../../hooks/useJobs";
import { dateFormat } from "../../../utils/dateUtils";
import JobModal from "../../modal/admin/JobModal";
import AlertDialog from "../../dialog/AlertDialog";
import LayoutPagination from "../../layout/LayoutPagination";

const MyJobTableGrid = memo(() => {
  const [jobId, setJobId] = useState("");
  const [openAlert, setOpenAlert] = useState(null);

  const handleOpen = (jobId) => {
    setJobId(jobId);
  };

  const handleClose = () => {
    setJobId("");
  };
  const {
    status,
    rows,
    error,
    isFetching,
    isPreviousData,
    queryOptions,
    setQueryOptions,
    onFilterChange,
    handleSortModelChange,
  } = useAdminTable("job");

  const { mutate: activeJobMutate, status: activeJobStatus } =
    useActiveJobMutation();

  const handleAgree = () => {
    activeJobMutate({
      page: queryOptions.page,
      jobId: openAlert._id,
      status: !openAlert.active,
      onClose: () =>
        toast.success(
          !openAlert.active ? `Kích hoạt thành công` : `Ẩn thành công`
        ),
    });
  };

  const columns = [
    { field: "_id", hide: true },
    {
      field: "title",
      headerName: "Nhan đề",
      width: 200,
      renderCell: (params) => {
        return (
          <Tooltip title={params.row.title || ""}>
            <p>{params.row.title}</p>
          </Tooltip>
        );
      },
    },
    {
      field: "company",
      headerName: "Công ty",
      sortable: false,
      width: 150,
      renderCell: (params) => {
        return (
          <Tooltip title={params.row.company.name || ""}>
            <p>{params.row.company.name}</p>
          </Tooltip>
        );
      },
    },
    {
      field: "job_type",
      sortable: false,
      headerName: "Kiểu công việc",
      width: 100,
    },
    {
      field: "numbers",
      headerName: "Số lượng",
      filterable: false,
      width: 100,
      headerAlign: "center",
      align: "center",
    },
    {
      field: "deadline",
      headerName: "Hạn chót",
      filterable: false,
      width: 200,
      renderCell: (params) => {
        // console.log(params);
        const tmp = dateFormat(params.row.deadline, "LLL");
        return (
          <Tooltip title={tmp || ""}>
            <p>{tmp}</p>
          </Tooltip>
        );
      },
    },
    {
      field: "numFollowers",
      headerName: "Theo dõi",
      filterable: false,
      width: 100,
      headerAlign: "center",
      align: "center",
      renderCell: (params) => {
        return <p>{params.row.numFollowers}</p>;
      },
    },
    {
      field: "numApplicants",
      filterable: false,
      headerName: "Đã ứng tuyển",
      width: 100,
      headerAlign: "center",
      align: "center",
      renderCell: (params) => {
        return <p>{params.row.numApplicants}</p>;
      },
    },
    {
      field: "createdAt",
      filterable: false,
      headerName: "Ngày tạo",
      width: 150,
      renderCell: (params) => {
        // console.log(params);
        const tmp = dateFormat(params.row.createdAt, "LLL");
        return (
          <Tooltip title={tmp || ""}>
            <p>{tmp}</p>
          </Tooltip>
        );
      },
    },
    {
      field: "active",
      type: "boolean",
      headerName: "Trạng thái",
      sortable: false,
      width: 100,
      renderCell: (params) => {
        return (
          <Box sx={{ display: "flex", ml: 1 }}>
            <IconButton onClick={() => setOpenAlert(params.row)}>
              {params.row.active ? <DoneIcon /> : <CloseIcon />}
            </IconButton>
          </Box>
        );
      },
    },
    {
      field: "view",
      filterable: false,
      headerName: "Xem",
      width: 100,
      sortable: false,
      renderCell: (params) => {
        return (
          <Box sx={{ display: "flex", ml: 1 }}>
            <IconButton onClick={() => handleOpen(params.row._id)}>
              <RemoveRedEyeIcon sx={{ mb: "-5px" }} />
            </IconButton>
          </Box>
        );
      },
    },
  ];

  return (
    <Paper sx={{ p: 1, my: 2 }}>
      <Typography
        sx={{ fontWeight: "bold", my: 1 }}
        variant="h5"
        component="h5"
      >
        Thống kê công việc
      </Typography>
      <div style={{ height: "71vh", width: "100%" }}>
        {/* {console.log("rows", rows)} */}
        <DataGrid
          loading={status === "loading"}
          rows={rows ? rows.data : []}
          // onRowClick={null}
          getRowId={(row) => row._id}
          columns={columns}
          filterMode="server"
          onFilterModelChange={onFilterChange}
          sortingMode="server"
          onSortModelChange={handleSortModelChange}
          onPageChange={(newPage) =>
            setQueryOptions((prev) => ({ ...prev, page: newPage }))
          }
          onPageSizeChange={(newPageSize) => {
            console.log("newPageSize", newPageSize);
          }}
          pagination
          paginationMode="server"
          page={queryOptions.page}
          pageSize={6}
          rowsPerPageOptions={[6]}
          rowCount={status === "success" ? rows.total : 0}
        />
      </div>
      {!!jobId && (
        <JobModal open={!!jobId} jobId={jobId} onClose={handleClose} />
      )}
      {!!openAlert && (
        <AlertDialog
          open={!!openAlert}
          handleAgree={handleAgree}
          handleClose={() => setOpenAlert(null)}
          title="Xác nhận"
          desc={`Bạn có chắc chắn muốn ${
            openAlert.active ? "khóa" : "mở"
          } trạng thái của ${openAlert.title}?`}
          status={activeJobStatus}
        />
      )}
    </Paper>
  );
});
export default MyJobTableGrid;
