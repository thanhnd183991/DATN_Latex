import DeleteIcon from "@mui/icons-material/Delete";
import RemoveRedEyeIcon from "@mui/icons-material/RemoveRedEye";
import { useState } from "react";
import { toast } from "react-toastify";
import MyTable from "./MyTable";

const MyTableUser = () => {
  const [page, setPage] = useState(1);

  const handleChange = (event, value) => {
    setPage(value);
  };
  // labels={["Avatar", "Tên", "Thông tin", "Người theo dõi","Đang theo dõi"]}
  const reduceUsers = users.reduce((acc, user) => {
    acc.push({
      id: user.id,
      avatar: user.avatar,
      name: user.name,
      about: user.about,
      numFollowers: user.numFollowers,
      numFollowing: user.numFollowing,
      current_job: user.current_job,
    });
    return acc;
  }, []);
  return (
    <MyTable
      page={page}
      count={Math.ceil(jobs.length / 5)}
      handleChange={handleChange}
      rows={reduceUsers.slice((page - 1) * 5, page * 5)}
      size={5}
      actions={[
        {
          to: "/profile",
          icon: <RemoveRedEyeIcon />,
          onClick: (row) => {
            toast.success(`${row.name} đã được xem`);
          },
        },
        {
          icon: <DeleteIcon />,
          label: "Xóa",
          onClick: (row) => {
            toast.error(`Xóa ${row.name}`);
          },
        },
      ]}
      labels={[
        "Avatar",
        "Tên",
        "Thông tin",
        "Người theo dõi",
        "Đang theo dõi",
        "Việc hiện tại",
        "Hành động",
      ]}
    />
  );
};

export default MyTableUser;
