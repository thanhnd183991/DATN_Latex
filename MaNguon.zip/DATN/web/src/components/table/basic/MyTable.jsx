import Avatar from "@mui/material/Avatar";
import Box from "@mui/material/Box";
import IconButton from "@mui/material/IconButton";
import Pagination from "@mui/material/Pagination";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Tooltip from "@mui/material/Tooltip";
import Typography from "@mui/material/Typography";
import { Link } from "react-router-dom";

export default function MyTable({
  rows,
  count,
  actions,
  page,
  handleChange,
  labels,
}) {
  return (
    <Box p={1}>
      <TableContainer component={Box}>
        <Table stickyHeader aria-label="sticky table">
          <TableHead>
            <TableRow>
              {labels.map((label, index) => {
                return (
                  <TableCell
                    sx={{ fontWeight: "bold", fontSize: "1.05rem" }}
                    key={index}
                  >
                    {label}
                  </TableCell>
                );
              })}
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.map((row) => (
              <TableRow
                key={row._id}
                sx={{
                  "&:last-child td, &:last-child th": { border: 0 },
                  "&:hover": {
                    backgroundColor: "action.selected",
                    cursor: "pointer",
                  },
                }}
              >
                {Object.keys(row).map(
                  (key, index) =>
                    key !== "_id" && (
                      <TableCell
                        sx={{
                          width:
                            index < 1 ? "5%" : `${100 / (labels.length - 1)}%`,
                        }}
                        component="th"
                        scope="row"
                        key={key}
                      >
                        {key === "avatar" ? (
                          <Avatar src={row[key]} alt="Remy Sharp" />
                        ) : (
                          <Tooltip title={row[key] || "something wrong"}>
                            <Typography
                              className="ellipsis-2-lines"
                              variant="body2"
                              component="p"
                            >
                              {row[key]}
                            </Typography>
                          </Tooltip>
                        )}
                      </TableCell>
                    )
                )}
                <TableCell component="th" scope="row">
                  <Box sx={{ display: "flex", gap: 1 }}>
                    {actions &&
                      actions.map(({ icon, onClick: handleClick, to }, index) =>
                        to ? (
                          <Link key={index} to={`${to}/${row.id}`}>
                            <IconButton onClick={() => handleClick(row)}>
                              {icon}
                            </IconButton>
                          </Link>
                        ) : (
                          <IconButton
                            key={index}
                            onClick={() => handleClick(row)}
                          >
                            {icon}
                          </IconButton>
                        )
                      )}
                  </Box>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
      <Box sx={{ display: "flex", mt: 1, justifyContent: "flex-end" }}>
        <Pagination
          count={count}
          page={page}
          onChange={handleChange}
          variant="outlined"
          color="primary"
        />
      </Box>
    </Box>
  );
}
