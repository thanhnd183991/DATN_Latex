import DeleteIcon from "@mui/icons-material/Delete";
import MessageIcon from "@mui/icons-material/Message";
import RemoveRedEyeIcon from "@mui/icons-material/RemoveRedEye";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { CONNECT_JOB } from "../../../constants/NotifyConstant";
import { getSocket } from "../../../socket";
import DeleteApplyModal from "../../modal/job/DeleteApplyModal";
import ViewApplyModal from "../../modal/job/ViewApplyModal";
import MyTable from "./MyTable";

const BasicApplicantJobTable = ({
  applicants,
  page: pageListByHR,
  job,
  limit = 3,
}) => {
  const navigate = useNavigate();
  const [page, setPage] = useState(1);
  const [viewApply, setViewApply] = useState(false);
  const [deleteApply, setDeleteApply] = useState(false);
  const [user, setUser] = useState(null);

  const handleViewApply = (user) => {
    setUser(user);
    setViewApply(true);
  };
  const handleViewApplyClose = () => setViewApply(false);

  const handleDeleteApply = (user) => {
    setUser(user);
    setDeleteApply(true);
  };
  const handleDeleteApplyClose = () => {
    setDeleteApply(false);
  };

  const handleChange = (event, value) => {
    setPage(value);
  };
  // labels={["Avatar", "Tên", "Thông tin", "Người theo dõi","Đang theo dõi"]}
  return (
    <>
      {/* {isLoading && <div>Đang xóa...</div>} */}
      <MyTable
        page={page}
        count={Math.ceil(applicants.length / 3)}
        handleChange={handleChange}
        rows={applicants
          .slice((page - 1) * limit, (page - 1) * limit + limit)
          .map((el) => ({
            _id: el.user?._id || el._id,
            avatar: el?.user?.avatar || el?.avatar,
            name: el?.user?.name || el?.name,
            email: el.email,
          }))}
        actions={[
          {
            icon: <RemoveRedEyeIcon />,
            onClick: (row) => {
              handleViewApply(row);
              toast.success(`${row._id} được xem`);
            },
          },
          {
            icon: <MessageIcon />,
            onClick: (row) => {
              // handleViewApply(row._id);
              getSocket().emit(
                CONNECT_JOB,
                {
                  jobId: job._id,
                  userId: row._id,
                },
                (data) => {
                  if (data.error) {
                    toast.error(data.error);
                  }
                  if (data.success) {
                    toast.success(data.success);
                  }
                  if (data?.data?._id) {
                    navigate(`/chat/${data.data._id}`);
                  }
                }
              );
            },
          },
          {
            icon: <DeleteIcon />,
            label: "Xóa",
            onClick: (row) => {
              handleDeleteApply(row);
            },
          },
        ]}
        labels={["Avatar", "Tên", "Email", "Hành động"]}
      />
      {viewApply && (
        <ViewApplyModal
          open={viewApply}
          jobId={job._id}
          userId={user._id}
          onClose={handleViewApplyClose}
        />
      )}
      {deleteApply && (
        <DeleteApplyModal
          open={deleteApply}
          job={job}
          user={user}
          onClose={handleDeleteApplyClose}
        />
      )}
    </>
  );
};

export default BasicApplicantJobTable;
