import React from "react";
import {
  Text,
  Font,
  Page,
  View,
  Image,
  Document,
  StyleSheet,
} from "./reactPdf.js";

import Header from "./Header";
import ItemArray from "./ItemArray";
import Education from "./Education";
import Experience from "./Experience";
import Contact from "./Contact";
import Language from "./Language";
import RichTextPdf from "./RichTextPdf";

const styles = StyleSheet.create({
  page: {
    padding: 30,
  },
  container: {
    flex: 1,
    flexDirection: "row",
    "@media max-width: 400": {
      flexDirection: "column",
    },
  },
  image: {
    marginBottom: 10,
  },
  leftColumn: {
    flexDirection: "column",
    width: 170,
    paddingTop: 30,
    paddingRight: 15,
    "@media max-width: 400": {
      width: "100%",
      paddingRight: 0,
    },
    "@media orientation: landscape": {
      width: 200,
    },
  },

  rightColumn: {
    flexDirection: "column",
    width: 500,
    paddingTop: 30,
    paddingRight: 15,
    "@media max-width: 400": {
      width: "100%",
      paddingRight: 0,
    },
    "@media orientation: landscape": {
      width: 600,
    },
  },
  footer: {
    fontSize: 12,
    fontFamily: "Roboto Bold",
    textAlign: "center",
    marginTop: 15,
    paddingTop: 5,
    borderWidth: 3,
    borderColor: "gray",
    borderStyle: "dashed",
    "@media orientation: landscape": {
      marginTop: 10,
    },
  },
});

Font.register({
  family: "Roboto",
  src: "https://cdnjs.cloudflare.com/ajax/libs/ink/3.1.10/fonts/Roboto/roboto-light-webfont.ttf",
});

Font.register({
  family: "Roboto Bold",
  src: "https://cdnjs.cloudflare.com/ajax/libs/ink/3.1.10/fonts/Roboto/roboto-bold-webfont.ttf",
});

Font.register({
  family: "Roboto Italic",
  src: "https://cdnjs.cloudflare.com/ajax/libs/ink/3.1.10/fonts/Roboto/roboto-italic-webfont.ttf",
});

const Resume = ({ user, ...info }) => (
  <Page props={info} style={styles.page}>
    {/* {console.log(user)} */}
    <Header user={user} />
    <View style={styles.container}>
      <View style={styles.leftColumn}>
        <Image
          src={
            user.avatar ||
            "https://media.istockphoto.com/photos/businessman-silhouette-as-avatar-or-default-profile-picture-picture-id476085198?b=1&k=20&m=476085198&s=170667a&w=0&h=Ct4e1kIOdCOrEgvsQg4A1qeuQv944pPFORUQcaGw4oI="
          }
          style={styles.image}
        />
        <Contact user={user} />
        {user?.skills?.length > 0 && (
          <ItemArray title="Kỹ năng" list={user.skills.map((el) => el.name)} />
        )}
        {user?.languages?.length > 0 && (
          <ItemArray
            title="Ngoại ngữ"
            list={user.languages.map((el) => el.name)}
          />
        )}
      </View>
      <View style={styles.rightColumn}>
        <RichTextPdf user={user} id="profile-about" title="Tổng quan" />
        <Education user={user} />
        {user?.experiences?.length > 0 && (
          <Experience exps={user.experiences} />
        )}
      </View>
    </View>
  </Page>
);

export default ({ user }) => (
  <Document
    author="Luke Skywalker"
    keywords="awesome, resume, start wars"
    subject="The resume of Luke Skywalker"
    title="Resume"
  >
    <Resume size="A4" user={user} />
  </Document>
);
