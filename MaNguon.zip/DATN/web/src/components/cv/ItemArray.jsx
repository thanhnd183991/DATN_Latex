/* eslint-disable react/no-array-index-key */

import React from "react";

import Title from "./Title";
import List, { Item } from "./List";

import { Text, View, StyleSheet } from "./reactPdf";

const styles = StyleSheet.create({
  title: {
    fontFamily: "Roboto Bold",
    fontSize: 11,
    marginBottom: 10,
  },
  skills: {
    fontFamily: "Roboto",
    fontSize: 10,
    marginBottom: 10,
  },
  container: {
    marginBottom: 10,
  },
});

const ListEntry = ({ list }) => (
  <View>
    <List>
      {list.map((skill, i) => (
        <Item key={i}>{skill}</Item>
      ))}
    </List>
  </View>
);

const ItemArray = ({ list, title }) => (
  <View style={styles.container}>
    <Title>{title}</Title>
    <ListEntry list={list} />
  </View>
);

export default ItemArray;
