/* eslint-disable react/no-array-index-key */

import React from "react";

import Title from "./Title";
import List, { Item } from "./List";

import { Text, View, StyleSheet } from "./reactPdf";

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  entryContainer: {
    marginBottom: 10,
  },
  date: {
    fontSize: 11,
    fontFamily: "Roboto Italic",
  },
  detailContainer: {
    flexDirection: "row",
  },
  detailLeftColumn: {
    flexDirection: "column",
    marginLeft: 10,
    marginRight: 10,
  },
  detailRightColumn: {
    flexDirection: "column",
    flexGrow: 9,
  },
  bulletPoint: {
    fontSize: 10,
  },
  desc: {
    fontSize: 10,
    fontFamily: "Roboto",
  },
  headerContainer: {
    flexDirection: "row",
    marginBottom: 5,
  },
  leftColumn: {
    flexDirection: "column",
    flexGrow: 9,
  },
  rightColumn: {
    flexDirection: "column",
    flexGrow: 1,
    alignItems: "flex-end",
    justifySelf: "flex-end",
  },
  title: {
    fontSize: 11,
    color: "black",
    textDecoration: "none",
    fontFamily: "Roboto Bold",
  },
});

const ExperienceEntry = ({ name, desc, position, date }) => {
  return (
    <View style={styles.entryContainer}>
      <View style={styles.headerContainer}>
        <View style={styles.leftColumn}>
          <Text style={styles.title}>{name}</Text>
        </View>
        <View style={styles.rightColumn}>
          <Text style={styles.date}>{date}</Text>
        </View>
      </View>
      <Text style={styles.desc}>Ví trị: {position}</Text>
      <Text style={styles.desc}>Mô tả: {desc}</Text>
    </View>
  );
};

const Experience = ({ exps }) => (
  <View style={styles.container}>
    <Title>Kinh nhiệm làm việc</Title>
    {exps.map(({ name, start_date, end_date, desc, position }) => (
      <ExperienceEntry
        name={name}
        date={`${start_date} - ${end_date}`}
        desc={desc}
        key={name + position}
        position={position}
      />
    ))}
  </View>
);

export default Experience;
