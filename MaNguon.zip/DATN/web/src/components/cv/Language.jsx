/* eslint-disable react/no-array-index-key */

import React from "react";

import Title from "./Title";
import List, { Item } from "./List";

import { Text, View, StyleSheet } from "./reactPdf";

const styles = StyleSheet.create({
  text: {
    fontFamily: "Roboto",
    fontSize: 10,
    marginBottom: 10,
  },
});

const Language = ({ user }) => (
  <View>
    {user.languages && (
      <>
        <Title>Ngoại ngữ</Title>
        <Text style={styles.text}>{user?.languages || "some thing wrong"}</Text>
      </>
    )}
  </View>
);

export default Language;
