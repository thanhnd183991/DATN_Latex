import React from "react";

const LeftSection = () => {
  return (
    <section class="left-section">
      <div class="left-content">
        <div class="profile">
          <div class="image">
            <img
              src="https://png.pngtree.com/png-clipart/20190924/original/pngtree-user-vector-avatar-png-image_4830521.jpg"
              alt=""
            />
          </div>
          <h2 class="name">Lorem Dola Ipsum</h2>
          <p class="career">Software Engineer</p>
        </div>
        <div class="contact-info">
          <h3 class="main-title">Contact Info</h3>
          <ul>
            <li>
              <i class="fa fa-phone"></i>
              07661892982
            </li>
            <li>
              <i class="fa fa-fax"></i>
              loremipsum@gmail.com
            </li>
            <li>
              <i class="fa fa-globe"></i>
              www.loremipsum.com
            </li>
            <li>
              <i class="fa fa-facebook"></i>
              www.facebook.com/lorem
            </li>
            <li>
              <i class="fa fa-instagram"></i>
              @loremipsum
            </li>
            <li>
              <i class="fa fa-map-marker"></i>
              37 Pramount St, London
            </li>
          </ul>
        </div>
        <div class="skills-section">
          <h3 class="main-title">Skills</h3>
          <ul>
            <li>
              <p class="skill-title">Javascript</p>
              <div class="progress-bar">
                <div class="progress js-progress"></div>
              </div>
            </li>
            <li>
              <p class="skill-title">Photoshop</p>
              <div class="progress-bar">
                <div class="progress ps-progress"></div>
              </div>
            </li>
            <li>
              <p class="skill-title">Java</p>
              <div class="progress-bar">
                <div class="progress j-progress"></div>
              </div>
            </li>
            <li>
              <p class="skill-title">C++</p>
              <div class="progress-bar">
                <div class="progress c-progress"></div>
              </div>
            </li>
            <li>
              <p class="skill-title">Ruby</p>
              <div class="progress-bar">
                <div class="progress ps-progress"></div>
              </div>
            </li>
            <li>
              <p class="skill-title">Node js</p>
              <div class="progress-bar">
                <div class="progress n-progress"></div>
              </div>
            </li>
            <li>
              <p class="skill-title">html/css</p>
              <div class="progress-bar">
                <div class="progress ps-progress"></div>
              </div>
            </li>
            <li>
              <p class="skill-title">illustrator</p>
              <div class="progress-bar">
                <div class="progress ps-progress"></div>
              </div>
            </li>
            <li>
              <p class="skill-title">Wordpress</p>
              <div class="progress-bar">
                <div class="progress ps-progress"></div>
              </div>
            </li>
          </ul>
        </div>
        <div class="references-section">
          <h3 class="main-title">References</h3>
          <div class="referee">
            <h6 class="sub-title">Michael Bowen</h6>
            <p class="sub-para">Product Manager</p>
            <ul>
              <li>
                <i class="fa fa-phone"></i>
                07661892982
              </li>
              <li>
                <i class="fa fa-fax"></i>
                loremipsum@gmail.com
              </li>
            </ul>
          </div>
          <div class="referee">
            <h6 class="sub-title">Joseph Kumar</h6>
            <p class="sub-para">Senior Developer</p>
            <ul>
              <li>
                <i class="fa fa-phone"></i>
                07661892982
              </li>
              <li>
                <i class="fa fa-fax"></i>
                loremipsum@gmail.com
              </li>
            </ul>
          </div>
          <div class="referee">
            <h6 class="sub-title">Rick Ross</h6>
            <p class="sub-para">Product Manager</p>
            <ul>
              <li>
                <i class="fa fa-phone"></i>
                07661892982
              </li>
              <li>
                <i class="fa fa-fax"></i>
                loremipsum@gmail.com
              </li>
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
};

export default LeftSection;
