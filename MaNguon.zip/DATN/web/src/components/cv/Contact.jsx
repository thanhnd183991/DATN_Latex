import React from "react";
import { Text, View, StyleSheet } from "./reactPdf";
import Title from "./Title";
import YouTubeIcon from "@mui/icons-material/YouTube";
import TwitterIcon from "@mui/icons-material/Twitter";
import FacebookIcon from "@mui/icons-material/Facebook";
import LinkedInIcon from "@mui/icons-material/LinkedIn";
import InstagramIcon from "@mui/icons-material/Instagram";
import LanguageIcon from "@mui/icons-material/Language";

const styles = StyleSheet.create({
  container: {
    marginBottom: 10,
  },
  school: {
    fontFamily: "Roboto Bold",
    fontSize: 10,
  },
  degree: {
    fontFamily: "Roboto",
    fontSize: 10,
  },
  candidate: {
    fontFamily: "Roboto Italic",
    fontSize: 10,
  },
});

export default ({ user }) => {
  const contacts = [
    {
      icon: <YouTubeIcon />,
      label: "Youtube",
      url: user?.social?.youtube,
    },
    {
      icon: <TwitterIcon />,
      label: "Twitter",
      url: user?.social?.twitter,
    },
    {
      icon: <FacebookIcon />,
      label: "Facebook",
      url: user?.social?.facebook,
    },
    {
      icon: <LinkedInIcon />,
      label: "LinkedIn",
      url: user?.social?.linkedin,
    },
    {
      icon: <InstagramIcon />,
      label: "Instagram",
      url: user?.social?.instagram,
    },
    {
      icon: <LanguageIcon />,
      label: "Website",
      url: user?.social?.website,
    },
  ];
  return (
    <View style={styles.container}>
      <Title>Liên hệ</Title>
      {contacts
        .filter((contact) => contact.url)
        .map((contact) => (
          <View key={contact.url}>
            <Text style={styles.degree}>
              • {contact.label}: {contact.url}
            </Text>
          </View>
        ))}
    </View>
  );
};
