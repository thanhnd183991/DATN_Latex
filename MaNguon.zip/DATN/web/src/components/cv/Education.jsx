import React from "react";
import { Text, View, StyleSheet } from "./reactPdf";
import Title from "./Title";

const styles = StyleSheet.create({
  container: {
    marginBottom: 10,
  },
  school: {
    fontFamily: "Roboto Bold",
    fontSize: 10,
  },
  degree: {
    fontFamily: "Roboto",
    fontSize: 10,
  },
  candidate: {
    fontFamily: "Roboto Italic",
    fontSize: 10,
  },
  headerContainer: {
    flexDirection: "row",
    marginBottom: 5,
  },
  leftColumn: {
    flexDirection: "column",
    flexGrow: 9,
  },
  rightColumn: {
    flexDirection: "column",
    flexGrow: 1,
    alignItems: "flex-end",
    justifySelf: "flex-end",
  },
});

export default ({ user }) => (
  <View style={styles.container}>
    {user?.educations?.length > 0 && (
      <>
        <Title>Học vấn</Title>
        {user.educations.map((education, index) => (
          <View key={education._id || index} style={styles.container}>
            <View style={styles.headerContainer}>
              <View style={styles.leftColumn}>
                <Text style={styles.school}>{education.school}</Text>
              </View>
              <View style={styles.rightColumn}>
                <Text style={styles.candidate}>
                  {education.start_date} - {education.end_date}
                </Text>
              </View>
            </View>
            <Text style={styles.degree}>Trình độ: {education.degree}</Text>
            <Text style={styles.degree}>
              Ngành học: {education.field_of_study}
            </Text>
          </View>
        ))}
      </>
    )}
  </View>
);
