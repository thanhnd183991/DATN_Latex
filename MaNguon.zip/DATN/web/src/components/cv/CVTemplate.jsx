import React from "react";
import "./styles.css";
import LeftSection from "./left-section/LeftSection";
import RightSection from "./right-section/RightSection";

const CVTemplate = () => {
  return (
    <main class="main-content">
      <LeftSection />
      <RightSection />
    </main>
  );
};

export default CVTemplate;
