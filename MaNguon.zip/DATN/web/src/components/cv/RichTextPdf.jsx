/* eslint-disable react/no-array-index-key */

import React, { Fragment } from "react";

import Title from "./Title";
import RichText from "../RichText";
import List, { Item } from "./List";

import { Text, View, StyleSheet } from "./reactPdf";

const styles = StyleSheet.create({
  text: {
    fontFamily: "Roboto",
    fontSize: 10,
    marginBottom: 10,
  },
});

const RichTextPdf = ({ user, id, title }) => {
  const sentences = () => {
    const rs = [];
    window.document
      .getElementById(id)
      .childNodes[0].childNodes.forEach((el) => {
        if (el.innerText) {
          rs.push(el.innerText);
        }
      });
    if (rs.length === 0) {
      const tmp = window.document.getElementById(id).childNodes[0].innerText;
      if (tmp) {
        rs.push(tmp);
      }
    }
    return rs;
  };
  return (
    <View>
      {user.about && (
        <>
          <Title>{title}</Title>
          {sentences().map((sen, index) => (
            <Text style={styles.text} key={index}>
              {sen}
            </Text>
          ))}
        </>
      )}
    </View>
  );
};

export default RichTextPdf;
